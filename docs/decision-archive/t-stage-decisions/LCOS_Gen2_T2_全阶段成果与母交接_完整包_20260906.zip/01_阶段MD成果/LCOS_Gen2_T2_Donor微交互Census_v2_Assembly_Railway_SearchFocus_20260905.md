# LCOS Gen2 · T2 Donor 微交互 Census v2
## Assembly 入口纠正 / Railway / Search→Focus / Pin / Locator / Minimap

日期：2026-09-05

> 本文承接 v1，并以 2026-09-05 最终产品冻结和用户刚刚的 Assembly 明确纠偏覆盖旧施工稿冲突项。
> 目标不是重新定义产品，而是把每个 T2 用户动作拆成 donor / OSS / Huabu 的最优供应关系。

---

# 0. 本轮最大纠正：Assembly 不是 Main 节点，也不是全局顶部导航模式

错误 prototype：

```text
Main Canvas
→ [项目装配仓节点]
→ click
→ FOCUS
```

最终：

```text
真实对象被 Selection
→ Selection 附近 Action Arc
→ Assembly
→ current selection / trigger / current worksite 作为打开上下文
→ 同一个 project-level Assembly Work View 从触发点进入 FOCUS
→ 可继续 Dock / Float / Immersive / Restore
```

因此：

- Main 不创建 `AssemblyNode`。
- Assembly 不是 Artifact。
- Selection 只是本次 target/source context。
- Restore 回触发现场，而不是回一个“Assembly 节点”。
- 无 Selection 时若未来保留全局 Assembly launcher，也只是打开同一个 project-level Assembly，不创建画布对象。

## 对旧 Phase D 的覆盖

旧稿曾把 centered index mode 写为：

```text
location / pins / search / assembly / focus / command
```

本轮修正：

### 普通 Main / Context / Workflow 顶部 dominant navigation

```text
Search > Focus > Pin > none
```

### Assembly 打开之后

Assembly Work View 可以拥有自己的：

```text
Artifacts / Context / Workflow / Skill / Collection / Conversation ... category index
```

但这是 Assembly Work View 内部导航，不是全局项目导航顶部再新增一个 `Assembly mode`。

理由：Assembly 的主要语义是“从项目已有内容和能力里找东西，装到当前 target”，入口应由当前操作上下文直接给出，而不是把它做成一个长期顶栏模式。

---

# 1. Universal Action Arc：Assembly / Pin 都应该从当前 Selection 就近出现

最新冻结与前序强制上下文一致：

```text
Artifact Arc:
Open / Preview
Relation
Pin
Assembly
More
```

不同物种按 capability 裁掉无效项，但：

- Assembly 对可装配 target 是直接高频能力；
- Pin 是直接 wayfinding authoring；
- 管理操作进入 More / right-click；
- Arc 不常驻，Selection 后才出现；
- 不允许为了 Assembly 再加一个 Main 常驻 launcher node。

## Donor 分工

Arc 的语义由 LCOS capability registry 决定。

视觉与 motion 可继续借：

- TapNow node-local controls；
- Lovart selection contextual top bar / quick actions 的 progressive disclosure；
- Codex Desktop local anchor；
- permissive Orbit/radial primitives。

Assembly 本体则由 shared Work View lifecycle 承接。

---

# 2. Railway：产品语义已经比 donor 更特殊，不能整套抄 TapNow / Lovart

最新产品收敛：

```text
Railway
= Main / Context / Workflow
+ 长期 worksite / 子画布
+ 当前现场 identity
+ member / Conversation preview
+ Active Receiver
+ cross-Surface drop target
```

它是项目级持续导航骨架。

## 2.1 TapNow 能借什么

TapNow 当前 canvas switching：

```text
upper-left current canvas name
→ dropdown
→ choose another canvas
→ save current
→ open destination
```

这个行为说明：

- worksite switching 应直接；
- 当前 identity 必须一眼可见；
- 不需要先回 Home；
- 切换不需要确认流程。

但它不适合作为 LCOS Railway 的最终壳，因为 TapNow 的 switcher 是“多个独立 canvas 的 dropdown”，LCOS Railway 还承担 Receiver、跨 Surface Drop、长期 worksite 和 member preview。

结论：

```text
TapNow canvas switch UX
= BEHAVIOR_REFERENCE
not Railway body donor
```

## 2.2 Lovart 能借什么

Lovart 的 Layer / Canvas tool shell 证明：

- 大 hit area、小视觉主体；
- 图标优先；
- panel 按需打开；
- Canvas 本体保持主角。

但 Lovart Layer 是当前 Canvas object/history panel，不是项目级 Railway。

结论：

```text
Lovart low-chrome shell / hit-area grammar
= VISUAL_DONOR

Lovart Layer panel
= REJECT as Railway
```

## 2.3 Railway 目前真正开放的视觉项

仍待 donor 决胜：

- collapsed visual width；
- Main / Context / Workflow glyph morphology；
- active worksite identity；
- long-term worksite preview；
- member / conversation mini preview；
- Receiver status shape；
- drag-receive state；
- worksite order / reordering motion；
- narrow viewport / Dock coexistence。

但硬语义不开放：

```text
click worksite = direct navigation
Drop target = destination already expressed
Receiver remains project-level
Railway != Layer Panel
Railway != Work View
```

---

# 3. Search：TapNow 的“找节点”行为非常值得拿，但数据语义不能拿

TapNow 官方当前行为：

```text
left toolbar Search icon
or Cmd/Ctrl+F
→ enter node query
→ optional type filters
→ Arrow Up/Down
→ Enter / click result
→ Search closes
→ Canvas moves to node
→ node selected / briefly highlighted
```

Esc：

```text
first Esc = clear query
second Esc = close Search
```

这套交互可以直接成为 LCOS Search 的 craft donor：

- 快捷键；
- keyboard result navigation；
- direct locate；
- close after activation；
- arrival highlight；
- layered Esc。

但 TapNow 搜的是当前 canvas nodes。

LCOS Search 搜的是 Core project federated truth。

所以：

```text
TapNow Search shell / keyboard / activation
= TAKE

TapNow node-search datasource / taxonomy
= DO NOT TAKE
```

LCOS：

```text
Core Project Search
→ result identity
→ locationRefs / bindings
→ known target
→ Focus / locate
```

---

# 4. Search → Focus：动态图标共享入口是对的，但不能共享 truth

产品心智：

```text
不知道是什么 / 在哪
→ Search

对象已经知道
→ Focus / 在哪
```

建议 GUI：

同一个 screen-space navigation affordance 在不同上下文中 morph：

```text
magnifier
↔
locate / target glyph
```

正式实现优先：

```text
Morphicons v1.7.1 MIT
```

优点：

- path morph；
- controlled progress；
- spring preset；
- reduced motion；
- 无 semantic state owner。

若 path topology 不适合 morph：

```text
Amicro IconSwap MIT
```

作为 fallback。

禁止：

```text
[Search] [Focus]
```

两个常驻文字模式按钮。

---

# 5. 顶部 Centered Index：用同一 presentation family，不再做“万能 mode manager”

目前应收敛成：

## Search active

显示：

- compact query；
- readable result identity；
- 主要结果围绕 safe top center 展开。

Search 结束后不留下第二层 navigation shell。

## Focus active

已知对象的 occurrence：

```text
1 occurrence
→ 一个位置 glyph

2–4
→ 中轴对称 compact group

many
→ first N + overflow / fan
```

没有 Search input。

## Pin idle

只有项目里真实存在的 Pin group 才显示。

没有 Pin：

```text
不保留空色槽
```

## Arbitration

```text
Search
> Focus
> Pin
> none
```

Assembly 不再作为普通 Surface 的 global dominant mode。

---

# 6. Pin：TapNow 仍是最成熟 donor

继续保留 v1 的参数：

```text
trigger stage 26px
pin icon 18px
color dots ~6px
hover 200ms cubic-bezier(.2,.85,.2,1)
membership bump 320ms
single local pin ~18px
multi pin ~14px with ~-10px overlap
active group node border ~3px
active group glow ~22px
```

Camera locate：

```text
padding = 1
minZoom = .5
maxZoom = 2
duration = 500ms
```

LCOS 只做 safeRect-aware fit。

TapNow 官方也再次确认：

```text
click color group
→ matching nodes list
→ click name/thumbnail
→ canvas moves to node and selects it
```

因此 Pin 成员 click 不应打开 Search。

---

# 7. Minimap：TapNow 行为 + Lovart 低 Chrome + Huabu engine

TapNow 官方：

```text
open minimap from lower-left
click destination → jump there
drag white viewport box → keep moving
```

Lovart 官方：

```text
Mini Map = button on Canvas
click → reveal miniature overview
drag inside → move view
```

两者共同证明：

> Minimap 应当是 on-demand direct manipulation，不是常驻大导航面板。

最终组合仍建议：

```text
Engine:
Huabu / ReactFlow viewport truth

Expanded direct behavior:
TapNow

Rest shell / low chrome:
Lovart/tldraw
```

---

# 8. Locator：行为冻结，视觉 donor 继续 OPEN

目前 donor 搜索仍没有得到足够可靠的：

```text
inside object navigation glyph
→ near-edge morph
→ edge directional locator
```

完整产品级参考。

因此：

```text
VISUAL_DONOR = OPEN
```

不能因为 v4 HTML 现在画了一支箭头就写进 final CSS。

已经冻结的是：

```text
target offscreen
→ directional cue on active safe edge

click
→ zero confirmation
→ direct camera locate

camera
→ TapNow-like bounded fit feel
→ LCOS safeRect correction

arrival
→ target-body feedback
→ no toast
```

候选 implementation primitive：

```text
Morphicons controlled progress
```

但 exact shape 继续 donor research。

---

# 9. FOCUS / Work View：Spatial 用在正确的位置

Spatial 不能提供 Minimap / Pin / Locator 产品功能。

它提供的真正价值：

```text
CanvasTransition*
presentedScale
itemScaleWhenPresented
itemCanvasFrame
```

所以它应该用于：

```text
Selection / trigger point
→ Work View presented state
→ FOCUS
→ Restore
```

而不是：

```text
Assembly Node
→ FOCUS
```

最新 v4 prototype 已按这个语义修正。

---

# 10. v4 Prototype 的正确阅读方式

v4 中：

- Main 不存在 Assembly node；
- click 真实 node 可改变 Selection；
- Action Arc 跟 Selection 走；
- Arc 包含 Pin / Assembly / More；
- Assembly 从 Arc / Selection 附近展开为 FOCUS；
- Restore 收回到触发现场；
- Dock 后 Camera 不自动移动；
- Pin / Search / Focus / Minimap 继续验证 donor 行为。

仍然只是 prototype，不是 final visual freeze。

尤其：

```text
Railway body
Focus occurrence exact glyph
Locator exact morphology
```

仍然开放。

---

# 11. 下一轮必须继续闭合

## Railway donor

继续检查：

- LibTV workspace / canvas switcher；
- TapNow canvas switch craft；
- Lovart low-chrome navigation shell；
- Spatial persistent-chrome reduction。

目标不是找一个“侧栏”，而是找：

```text
worksite identity
active state
hover preview
drag receive
receiver cue
compact reorder
```

各自最优答案。

## Focus Index

需要逐数量状态：

```text
1 / 2 / 3 / 4 / 7 / 12 / 20 occurrences
```

验证：

- center balance；
- overflow；
- labels；
- current occurrence；
- cross-surface identity。

## Locator

继续寻找：

- edge bead / arrow / wedge / morphing cursor；
- target cluster；
- unavailable / archived target；
- hover label；
- arrival handoff。

---

# 12. 当前裁决一句话

> **LCOS T2 的导航不再从“我们需要哪些组件”出发，而是从“用户现在想找什么、去哪、给谁、留下什么空间记忆”出发；每个动作再分别去 TapNow / Lovart / Spatial / Huabu / permissive OSS 拿最成熟的器官。**
