# LCOS Gen2 · T3 第三路正式施工规划
## 01_Evidence_Census_Authority_Recovery
### Local Object Interaction / Action Arc / Compact Composer / Reference / Voice

> 日期：2026-09-04  
> 线程：T3  
> 目的：建立本线程所有产品语义、历史原话、current source、upstream、donor 的 authority chain。  
> 规则：**索引不替代原文；历史结论不替代 current source；donor 不替代 LCOS 产品语义。**

---

# 0. 本册结论

T3 的 Round 1 blocker 已闭合。

当前可以进入正式源码施工规划的依据不是：

```text
“我大概记得用户想要一个局部输入框”
```

而是已经形成以下证据链：

```text
Latest user/freeze originals
↓
Context recovery / supersession audit
↓
Gen2 audit source package
↓
Current LCOS Gen2 source
↓
Vendored Huabu current construction host
↓
Live Huabu upstream
↓
External donor exact bundle/provenance
↓
Permissive OSS exact upstream
```

T3当前没有“因为缺原文只能脑补”的 known blocker。

仍然存在的 open item 都是：

```text
跨线程 owner 尚未最终交接
或
micro UX policy原文没有规定到那一粒度
```

这些会明确标 `OPEN/CROSS_THREAD`，不由本线程自动发明。

---

# 1. Authority Order

T3 使用以下优先顺序：

```text
A0 更晚用户原话 / 最新冻结裁决
A1 Exact File Library 原文
A2 Gen2 current source / current tests
A3 Current construction host Huabu vendored source
A4 Live Huabu upstream
A5 历史审计 / 旧施工计划
A6 proprietary donor observable behavior / architecture evidence
A7 permissive OSS upstream implementation
A8 model inference
```

注意：

OSS source虽然可直接实现，但它不能覆盖 LCOS product semantics。

例如：

```text
CopilotKit支持 transcribe mode
```

不代表 LCOS Voice可以 auto send。

LCOS冻结明确：

```text
Voice是 Composer input modality
转写后可编辑
explicit Send
```

---

# 2. V6 Package Authority

本轮最新线程引导：

```text
LCOS_Gen2_六线程_ExactFile_反惰性规划引导包_
V6_LibTV_SpatialV4_轮子溯源_20260904
```

T3 exact guide：

```text
03_T3_LocalInteraction_ActionArc_Composer_30KB_Planning_Guide.md
```

它 supersede 本线程早先 V2/V3/V5 类引导。

---

# 3. V6 新增硬要求

相对早期包，T3关键新增：

```text
1. Spatial v4 supersession
2. LibTV wheel provenance
3. proprietary donor工程/视觉双轨
4. 轮子 exact upstream追溯
5. 26项 gesture deep dive
6. current/upstream动态核验
7. 每册实际 UTF-8 ≥30KB
8. donor replacement boundary
9. failure blast radius
10. 源码计划必须写到 props/JSX/CSS/state/motion
```

这些都已进入 02/03/04 册。

---

# 4. Shared Anti-Reinvention Constitution · T3相关硬规则

## P0 项目第一性

目标不是做最原创的 UI。

目标：

```text
最快形成可靠产品力
+
避免重复造成熟通用轮子
```

## P2 Huabu唯一 Spatial Body

T3不允许新：

```text
canvas
viewport
pointer engine
geometry truth
```

## P3 Local Core唯一 Domain Truth

T3不能让 Composer本地 store成为：

```text
Relation
Run
Receiver
Conversation durable truth
```

## P4 ProjectionBinding唯一身份桥

nodeId→Core identity必须来自 binding。

## P5 Selection / Reference / Relation分离

这是 T3最高优先级产品语义之一。

## P6 三 Surface共享物理内核

Main/Context/Workflow不各写交互系统。

## P11 Content is Body, Controls are Satellites

Action Arc / Reference satellite符合这一原则。

## P14 模块化 = 小 blast radius

不是目录拆分。

## P16 轮子优先

先 Huabu、OSS、upstream，再 self-build。

## P17 DON'T BUILD

T3重点：

```text
second pointer
second Selection
second Run domain
Voice Workbench
duplicate positioning engine
```

---

# 5. Shared File Library mandatory originals

V6 shared list包含：

```text
LCOS_20260821至20260902_全功能最新冻结总账_白话UX与Gen2施工映射.md
LCOS_v015_MANDATORY_PRECONSTRUCTION_CONTEXT_20260831.md
LCOS_v015_CONSTRUCTION_CONTEXT_INDEX_20260831.md
LCOS_v015_原文到后续施工计划_差分审计_20260831.md
LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md
LCOS_v015_Frontend_Gen2_Huabu_First_重建总纲_20260901.md
LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md
LCOS_Gen2_Context_Recovery_可见对话原文_20260903.md
LCOS_Gen2_重构进度审计澄清_Context_Recovery_Census_20260903.md
LCOS_Gen2_详细施工方案_SOP_审计优先版_20260903.md
```

状态：

```text
EXACT SOURCE AVAILABLE / T3 AUTHORITY RECOVERED
```

---

# 6. T3-specific File Library originals

```text
LCOS_v0.15_UX冻结_Relation_Glyth_Colony_SpatialNavigation_20260829.md
LCOS_v015_三Surface交互同构硬规则_20260831.md
LCOS_v015_UNIFIED_COMPACT_COMPOSER_PROMPT_REFERENCE_VOICE_GUI_FREEZE_20260831.md
LCOS_v015_Lovart_Composer_ReferencePick_补充拆解_20260831.md
LCOS_v015_VIDEO_DONOR_原稿总索引与施工映射_20260831.md
LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md
LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md
LCOS_v015_LATEST_L0_WORKVIEW_HUD_DIRECT_MANIPULATION_ADDENDUM_20260901.md
LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md
LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md
```

上轮缺口已经由：

```text
Library补充(4).zip
+
File Library original
```

闭合。

---

# 7. `Library补充(4).zip` exact evidence

本次包直接包含 T3大量缺口：

```text
LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md
LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md
LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md
LCOS_v015_Lovart_Composer_ReferencePick_补充拆解_20260831.md
LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md
LCOS_v015_三Surface交互同构硬规则_20260831.md
LCOS_v015_原文到后续施工计划_差分审计_20260831.md
LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md
...
```

因此旧 Round1 blocker不再成立。

---

# 8. Relation/Glyth exact original recovery

`LCOS_v0.15_UX冻结_Relation_Glyth_Colony_SpatialNavigation_20260829.md`

没有在 Library补充 ZIP清单中直接出现，但已从 File Library取得 exact original。

所以不能再用：

```text
历史 D03g
```

冒充最新产品 authority。

D03g只作为源码施工谱系参考。

---

# 9. Context recovery authority

重要恢复文件：

```text
LCOS_Gen2_Context_Recovery_可见对话原文_20260903.md
LCOS_Gen2_重构进度审计澄清_Context_Recovery_Census_20260903.md
```

用途：

- 识别后续裁决覆盖关系；
- 区分 FOUND_FULL / PARTIAL / CONTEXT_ONLY；
- 防止某个早期计划被当成最新冻结。

它们不是 product spec替代品。

---

# 10. Parallel Planning Context Pack

本轮：

```text
LCOS_Gen2_Parallel_Planning_Context_Pack_20260904(5).zip
```

包含：

```text
shared context
code/GitHub common context
source authority
live upstream watch
T3 scope
visible transcript continuity
library read map
Gen2 ZIP read map
module replacement audit
```

用途：

```text
跨六线程一致上下文
```

不是用来覆盖 exact product originals。

---

# 11. Gen2 audit source package

T3必须回读的历史审计：

```text
LCOS_Gen2_交互级摸牌_SemanticDrop迁移审计_20260902.md
LCOS_Gen2_交互级摸牌_GPT审计盲区排查_20260902.md
LCOS_Gen2_摸牌三_A系列谱系考古_20260902.md
MD2_交互与导航层_源码对应审计_20260903.md
MD3_工作台与现场编排层_源码对应审计_20260903.md
Phase_A_Shared_Kernel_Host_Owner
Phase_C_Surfaces_Instruments_Composer
D03g_GlythNeighborGrammar
```

这些文件用于：

```text
历史意图
current/old implementation genealogy
哪里已经做过
哪里只是旧计划
```

---

# 12. Historical docs supersession rule

旧 Phase C如果写：

```text
新增 capability registry
```

而最新架构纪律发现 pure function已足够：

```text
旧建议降级
```

历史计划不是 contract。

本线程已经做的典型纠错：

```text
旧 MD2 capability registry
→ 不采用
→ pure resolveLocalObjectActions()
```

原因不是个人偏好，而是当前没有 runtime dynamic registration失败场景。

---

# 13. Latest Composer freeze authority

`LCOS_v015_UNIFIED_COMPACT_COMPOSER_PROMPT_REFERENCE_VOICE_GUI_FREEZE_20260831.md`

T3抽出的关键冻结：

```text
Action Arc = high-frequency direct actions
Right-click/More = management
Composer = Prompt / Reference / Skill / Run / Voice

Selection != Reference

content node stable click可出现 local feedback
pointerdown/drag不让 Composer抢 focus

Structural Surface Component
不因 selection自动弹 generic Composer

Composer小而轻
2–4 lines
内部 scroll

Voice
Idle
Recording
Transcribing
Editable Text
Explicit Send
```

这些直接约束 04册。

---

# 14. Three-Surface grammar authority

`LCOS_v015_三Surface交互同构硬规则_20260831.md`

T3使用：

```text
Main
Context
Workflow
共享 Huabu physical interaction mechanics
```

但不共享：

```text
canonical spatial state
semantic Relation
surface-specific objects
```

因此 04册没有 Main/Context/Workflow三个 pointer implementation。

---

# 15. Relation/Glyth authority

关键区分：

```text
spatial proximity
!= durable context

Glyth body drop
= durable Conversation Context Mapping

Ctrl/Cmd Reference
= current Run input

Relation port
= Project Relation
```

这成为 02/04册 Glyth gesture matrix的 authority。

---

# 16. WorkView authority

最新 L0 addendum：

WorkView：

- 占 viewport空间；
- camera不因打开而移动；
- 暴露 occupied/safe rect；
- HUD/floating/navigation避让；
- local transient UI需要 arbitration。

T3只消费这些 state。

不建 WorkView local copy。

---

# 17. Product pain recovery

历史用户明确不满意的交互方向包括：

```text
拖到感应区
→ 再弹选项
```

因为：

> 既然有跨空间可视化 drop，drop到哪就应该表示哪里要用。

这覆盖早期更“sensor zone”式方案。

因此 current Semantic Drop纯 FSM可以保留，但 left/bottom hardcoded destination不能成为最终产品。

---

# 18. Current LCOS Gen2 source authority

Repo：

```text
DZWFLi/LCOS_Gen2
```

Observed main：

```text
c2ff890a867922a1256572199458438572eb0a8c
```

这是本轮 current source audit基线。

若施工开始前 HEAD变化，必须 rebase/re-audit touched paths。

---

# 19. Huabu construction host authority

`HUABU_UPSTREAM.md`声明：

```text
construction host = repo内 huabu/
```

Pin：

```text
58339e269b784728d67730c70bfe7792cae2457d
```

Standalone Huabu clone不是施工 host。

所以 final task card修改：

```text
DZWFLi/LCOS_Gen2/huabu/...
```

不是另一个 clone。

---

# 20. Huabu live upstream authority

Observed：

```text
microsoft/Huabu
dc128fff2d37b5481ec305070a7e86d3de85f7d2
```

相对 pin：

```text
ahead 19 commits
```

T3相关：

```text
Canvas
DropdownMenu
NodeFloatingToolbar
ChatInput
ThreadChatInput
tests
composer performance e2e
```

所以 upstream是动态 supplier。

不能把 pin当“唯一最新设计”。

---

# 21. `ThreadChatInput` upstream evidence

Current upstream新增：

```text
ThreadChatInput
```

其结构：

```text
thread draft owner
→ controlled ChatInput body
```

T3用它作为：

```text
draft/body separation pattern evidence
```

不是把 Huabu thread owner搬进 LCOS Composer。

---

# 22. Current pointer authority

`pointerRouter.ts`

明确：

- DOM-independent；
- first claimant；
- observer channel；
- host recognizers；
- current context；
- cancel/preempt。

这直接证明：

```text
selected-reclick
```

应加入现有 observer channel。

不是新 pointer engine。

---

# 23. Current pointer context authority

`CanvasPointerRouterContext`

已有：

```text
wrapper
ReactFlow instance
inputMode
interactivityLocked
explicitToolActive
touch callbacks
```

T3 recognizer可获得现有 context。

无需 window-global geometry。

---

# 24. Current Selection authority

Canvas当前：

```text
multiSelectionKeyCode='Shift'
```

并由 Huabu selectNodes / ReactFlow control。

这是用户冻结 grammar已真正进入 production source的证据。

---

# 25. Current Reference authority

`referenceController.ts`：

```text
ordered
idempotent
Selection != Reference != Relation
open Composer doesn't copy Selection
```

`lcosReferenceState.ts`：

```text
ProjectionBinding-derived identity cache
```

`lcosRecognizers.ts`：

```text
Ctrl/Cmd Reference
unbound fail-close
```

因此 Reference不是规划概念，已经有 production owner。

---

# 26. Current Overlay authority

`overlayArbitration.ts`：

已有：

```text
action-arc
composer
work-view
drop-preview
```

说明系统早就为这些 transient overlay留了 arbitration模型。

缺的是 production input/body。

不是要新 Overlay Manager。

---

# 27. Current Floating authority

`CanvasFloatingPopover.tsx`：

- Floating UI；
- virtual anchor；
- flow→screen；
- boundary；
- resize；
- portal；
- attention suppression。

所以 T3 guide明确：

```text
Action Arc positioning 禁止造 engine
```

与 current source完全一致。

---

# 28. Current Menu authority

`Popover.tsx`
`DropdownMenu.tsx`

已经足够：

```text
context menu UI mechanics
```

T3缺 host event seam和 action semantics。

---

# 29. Current Composer evidence

`LcosComposerShell.tsx`

文件注释自己承认：

```text
Phase A shell
full state machine/receiver/voice later
```

所以它不能被审计标成：

```text
Composer DONE
```

只能：

```text
TRANSITIONAL
```

---

# 30. Current ChatInput evidence

Huabu ChatInput已成熟覆盖：

- IME；
- textarea resize；
- history；
- attachment；
- paste/drop；
- slash；
- submit/stop。

这说明 T3不该自写 generic input mechanics。

同时其 thread coupling又证明：

```text
whole component不能直接当 LCOS Composer
```

---

# 31. Current Run Core authority

`apps/local-core/src/routes/runs.ts`

已有：

```text
create
dispatch
recover
sync
cancel
events
input-request
orderedReferences
receiverRef
```

所以 T3不能新：

```text
PromptRun API
ComposerExecution domain
```

---

# 32. Current Receiver authority

`receiver.ts`

已有：

```text
connected-conversations
receiver-binding
handoff
```

所以 receiver不是 UI-local dropdown truth。

---

# 33. Current Voice authority

`voice-transcription.ts`

已有正式 multipart route。

Frontend只缺 transport/client。

---

# 34. Donor dual-track authority

文件：

```text
LCOS_Gen2_Donor双轨裁决_
工程实现复用与UIUX高保真设计借鉴_20260904.md
```

硬规则：

```text
Engineering donor
!=
Visual donor
```

proprietary code不能 copy，
但成熟 visible UI solution可高保真借。

它还要求正式 plan压到：

```text
props
JSX
CSS
token
state
motion
safe rect
LOD
provenance
acceptance
```

04册按此执行。

---

# 35. LibTV evidence

V6指定 T3 exact chunks：

```text
inflated/3v6vra2bie_te.js
inflated/1c07ntdgxr2xp.js
inflated/0j4789ye3y9ym.js
inflated/299_g8ffwqxsy.js
```

价值：

```text
wheel archaeology
```

本轮从中追到 CopilotKit等成熟依赖痕迹。

LibTV product build本身不是 copy source。

---

# 36. LibTV direct-use exception

`libtv-skills`有 permissive/MIT路径时，可独立作为 implementation donor。

但 T3 current relevance低。

不能因为可用就硬塞。

---

# 37. CopilotKit exact upstream

Repo：

```text
CopilotKit/CopilotKit
```

Observed：

```text
3472104d06eb53ae9d23541d8b60ff81c0c7684a
```

LICENSE：

```text
MIT
```

T3 exact value：

```text
CopilotChatAudioRecorder.tsx
```

Whole input：

```text
REJECT
```

Recorder：

```text
LIFT
```

---

# 38. Orbit exact upstream

Repo：

```text
zumerlab/orbit
```

Pin：

```text
9b8906713a9e8d5fb48e04df824401c65acf6a16
```

Version：

```text
1.4.12
```

License：

```text
MIT
```

T3 exact source：

```text
src/scss/_radial-layout.scss
src/scss/_satellite.scss
```

它只提供 radial geometry，适合作为 Action Arc body supplier。

---

# 39. Lovart authority

Engineering：

```text
PROPRIETARY_REFERENCE_ONLY
```

Visual：

```text
HIGH_FIDELITY
```

T3关键：

```text
AddToReference
SelectFromCanvas
Composer reference flow
```

不复制 JS/CSS。

---

# 40. TapNow authority

Engineering：

```text
REFERENCE_ONLY
```

Architecture：

```text
RESPONSIBILITY_DONOR
```

Visual：

```text
HIGH_FIDELITY
```

关键不是照抄 store，而是观察：

```text
selection/menu/voice/run/recovery
```

被成熟地分开。

---

# 41. Spatial v4 authority

V6明确 v4 supersede v3。

Spatial：

```text
behavior / motion donor
```

不是 T3 implementation owner。

禁止从它反投影：

```text
LCOS Search/Run/Reference能力
```

---

# 42. Visual evidence boundary

Donor visual允许记录：

```text
position
size
spacing
density
hover
selected
motion
persistent/transient
```

不允许记录为：

```text
“Vendor CSS exact value”
```

除非 source许可且确实来自 OSS。

Observable measure应标：

```text
observed
```

---

# 43. Current authority conflict examples

## 43.1 Old plan vs latest UX

旧 Semantic Drop shelf/sensor方案：

```text
SUPERSEDED
```

pure FSM：

```text
KEEP
```

## 43.2 Old registry proposal

```text
SUPERSEDED BY THIN PURE RESOLVER
```

## 43.3 Current fixed Composer

```text
SOURCE_EXISTS
!= DONE
```

## 43.4 Reference current code

```text
SOURCE_EXISTS + actual production wiring
= KEEP
```

---

# 44. Evidence status taxonomy

本线程使用：

```text
EXACT_ORIGINAL
CURRENT_SOURCE_VERIFIED
UPSTREAM_VERIFIED
DONOR_RAW_EXAMINED
OSS_UPSTREAM_VERIFIED
HISTORICAL_REFERENCE
SUPERSEDED
CROSS_THREAD_PENDING
OPEN_MICRO_POLICY
```

不使用模糊：

```text
“应该是”
“看起来有”
```

---

# 45. Current unresolved micro policies

这些不是 blocker，但不能静默脑补。

## Voice transcript + existing prompt

原文确认：

```text
transcript becomes editable text
```

但若 prompt已有文字，exact insertion：

```text
replace?
append?
cursor insert?
```

当前证据不足以声称某一条是冻结。

标：

```text
OPEN_MICRO_POLICY
```

施工可先抽 adapter，不冻结 merge behavior。

---

# 46. LCOS-specific double-click

是否 Glyth double-click一定覆盖 stock Preview，需要 T4/T6/species final handoff。

当前只证明：

```text
如果需要 override，必须极窄 seam
```

不是现在无条件建 contract。

状态：

```text
CONDITIONAL
```

---

# 47. Complete Surface slot drop taxonomy

T3知道：

```text
Glyth body durable context
```

但 Assembly/Context/Workflow所有 concrete slot是 T4 authority。

T3不编造全表。

状态：

```text
CROSS_THREAD_PENDING
```

---

# 48. WorkView state selector

T3知道：

```text
must consume canonical workViewOpen/occupiedRect
```

但 exact T4 file/API由 T4施工正本决定。

所以 04册不创建 shadow store。

---

# 49. Evidence sufficiency for 02册

已足够回答：

- current owner；
- current producer；
- current consumer；
- false/transitional implementation；
- duplicate risk；
- recovery gap。

所以 Round2完成。

---

# 50. Evidence sufficiency for 03册

已完成：

- Huabu direct-use；
- Huabu upstream delta；
- Orbit license/source；
- CopilotKit license/source；
- proprietary donor dual-track；
- LibTV provenance；
- reject/retire matrix。

所以 Round4对 T3关键 donor足够。

---

# 51. Evidence sufficiency for 04册

已足够冻结：

- selected-reclick observer；
- Action Arc composition；
- Composer draft separation；
- contextmenu seam；
- Reference Pick；
- Voice/Run clients；
- transitional retirements。

Cross-thread target detail仍通过明确接口 handoff，不影响这些基础施工。

---

# 52. Evidence insufficiency handling

如果施工时出现：

```text
“Glyth到底哪个 node type?”
“WorkView state exact store在哪?”
“Assembly concrete target descriptor是什么?”
```

施工 Agent不得猜。

必须：

```text
回 T4/T5/T6 handoff
或 current source search
```

不是添加临时 string。

---

# 53. Source pin policy

本规划记录 SHA是 evidence pin。

不是新增永久 hash gate。

施工开始：

```text
git status
HEAD
Huabu upstream relevant diff
```

普通 Git 足够。

只有 upstream API/schema变更影响不可逆边界时重新审计。

---

# 54. No hidden baseline

本线程不新增：

```text
visual golden baseline
contract freeze hash
release gate
```

浏览器 acceptance + screenshot/manual measurement可做证据，但不自动变永久门禁。

---

# 55. Authority handoff to施工 Agent

施工 task必须写：

```text
READ FIRST:
01/02/03/04/05 T3正本
exact target files
donor provenance
cross-thread handoff
```

不要让施工 Agent重读所有历史聊天再自己总结。

---

# 56. Evidence integrity rules

1. 不把 File Library index当全文；
2. 不把 donor bundle符号名当 semantic proof；
3. 不把 current file存在当用户路径已接；
4. 不把 test通过当 UX已验；
5. 不把 proprietary source当可 copy；
6. 不把 old plan当 latest freeze；
7. 不把 upstream latest当 construction host；
8. 不把 UI state当 Core truth。

---

# 57. Final Evidence Census Table

| Evidence | Status | Role |
|---|---|---|
| latest product freeze | EXACT_ORIGINAL | product authority |
| composer/reference/voice freeze | EXACT_ORIGINAL | T3 semantic authority |
| three-surface grammar | EXACT_ORIGINAL | interaction grammar |
| Relation/Glyth freeze | EXACT_ORIGINAL | Glyth semantics |
| context recovery census | EXACT_ORIGINAL | supersession |
| V6 T3 guide | EXACT_CURRENT | process authority |
| Gen2 audit package | EXACT_CURRENT | genealogy |
| Gen2 current repo | CURRENT_SOURCE_VERIFIED | runtime truth |
| vendored Huabu | CURRENT_SOURCE_VERIFIED | construction host |
| Huabu upstream | UPSTREAM_VERIFIED | dynamic supplier |
| Orbit | OSS_UPSTREAM_VERIFIED | Arc primitive |
| CopilotKit | OSS_UPSTREAM_VERIFIED | recorder |
| Lovart | DONOR_RAW_EXAMINED | visual/reference UX |
| TapNow | DONOR_RAW_EXAMINED | visual/responsibility |
| Spatial v4 | DONOR_RAW_EXAMINED | motion/behavior |
| LibTV | DONOR_RAW_EXAMINED | wheel provenance |

---

# 58. Round 1 Final Status

```text
SCOPE = LOCKED
MANDATORY ORIGINAL GAP = CLOSED
CURRENT SOURCE = VERIFIED
UPSTREAM = VERIFIED
DONOR PROVENANCE = SUFFICIENT
OPEN ISSUES = MICRO_POLICY / CROSS_THREAD ONLY
```

T3不再停在 Context Recovery。

---

# 59. What evidence changed the plan most

## 1

`CanvasFloatingPopover`

证明 positioning engine完全不用造。

## 2

Huabu pointer observer channel

证明 selected-reclick不用第二 listener。

## 3

Run/Receiver/Voice Core routes

证明 Composer后端不用重建。

## 4

ThreadChatInput upstream

证明 draft/body separation是成熟 upstream方向。

## 5

LibTV→CopilotKit provenance

证明 recorder不用自写。

## 6

Orbit MIT

证明 radial geometry不用自写。

## 7

latest Semantic Drop UX

证明 hardcoded edge destination必须退。

---

# 60. Coordinator handoff statement

任何其它线程引用 T3时，应引用：

```text
01 Evidence
02 Current Owner Audit
03 Donor Matrix
04 Construction Plan
05 Acceptance Plan
```

不要只引用某个早期 Phase C文档。

---

# Appendix A · Mandatory exact read checklist

Shared：

```text
[OK] 全功能冻结总账
[OK] mandatory preconstruction
[OK] context index
[OK] 原文→计划差分审计
[OK] 最新UX vs现实
[OK] Huabu-first总纲
[OK] SpatialTruth裁决
[OK] Context Recovery transcript
[OK] Recovery Census
[OK] SOP
```

T3：

```text
[OK] Relation/Glyth/Colony/SpatialNavigation
[OK] 三Surface同构
[OK] Unified Compact Composer
[OK] Lovart Composer/ReferencePick
[OK] Video donor index
[OK] Lovart/Trae/TapNow interaction
[OK] CodexDesktop anchor
[OK] L0 WorkView HUD addendum
[OK] latest UX reality audit
[OK] FigmaMake correction prompt
```

---

# Appendix B · Gen2 audit checklist

```text
[READ] SemanticDrop migration audit
[READ] GPT audit blind spot
[READ] A-series genealogy
[READ] MD2 interaction/nav
[READ] MD3 workbench/site composition
[READ] Phase A historical construction reference
[READ] Phase C historical construction reference
[READ] D03g Glyth grammar
```

Historical施工文件：

```text
REFERENCE_ONLY
```

除非 current source与latest freeze再次验证。

---

# Appendix C · Current source checklist

```text
[VERIFIED] createLcosHostRuntime
[VERIFIED] CanvasHostExtension
[VERIFIED] Canvas pointer router
[VERIFIED] Canvas current contextmenu/doubleclick/drop
[VERIFIED] NodeWrapper
[VERIFIED] nodePresentation phase
[VERIFIED] CanvasFloatingPopover
[VERIFIED] NodeFloatingToolbar
[VERIFIED] Popover
[VERIFIED] DropdownMenu
[VERIFIED] ChatInput
[VERIFIED] LcosHostOverlay
[VERIFIED] LcosComposerShell
[VERIFIED] lcosReferenceState
[VERIFIED] lcosRecognizers
[VERIFIED] semanticDropMachine
[VERIFIED] lcosDropState
[VERIFIED] LcosDropPreview
[VERIFIED] Core runs
[VERIFIED] Core receiver
[VERIFIED] Core voice-transcription
[VERIFIED] web-gen2 backend client
```

---

# Appendix D · Upstream checklist

```text
[VERIFIED] Huabu current HEAD observed
[VERIFIED] current vs vendored divergence
[VERIFIED] ThreadChatInput upstream exists
[VERIFIED] ChatInput upstream touched
[VERIFIED] menu/floating relevant upstream paths touched
```

施工前如果 upstream再次变：

只重核 T3 touched supplier paths，不全仓重做考古。

---

# Appendix E · Donor checklist

```text
[VERIFIED] Orbit repo/license/commit/files
[VERIFIED] CopilotKit repo/license/recorder
[EXAMINED] LibTV T3 exact chunks
[EXAMINED] Lovart T3 bundle/source archaeology
[EXAMINED] TapNow T3 bundle/source archaeology
[EXAMINED] Spatial v4 T3 behavior/motion evidence
```

---

# Appendix F · Evidence → plan trace examples

```text
Freeze:
Selection != Reference
→ 02 Reference owner
→ 04 ComposerDraft + ReferenceController

Current:
CanvasFloatingPopover exists
→ 03 DIRECT_USE
→ 04 no positioning engine

Donor:
Orbit MIT radial geometry
→ 03 LIFT
→ 04 lcosActionArc.css

Core:
voice transcription exists
→ 02 MISSING_TYPED_CLIENT
→ 04 backend/voice.ts

Pain:
sensor zone UX rejected
→ 02 drop adapter TRANSITIONAL
→ 04 retire left/bottom hardcode
```

这种可追溯性是本规划的核心。


---

# Appendix G · Supersession / Conflict Ledger

## G01 Semantic Drop

Historical source：

```text
SemanticDrop迁移审计
Phase A drop shelf / edge dwell
```

Useful：

- pure payload closure；
- tracking/dwell/preview/commit separation；
- cancel zero side effect；
- pointer owner discipline。

Superseded：

```text
left/right/bottom sensor = final business destination
sensor → chooser as final user flow
```

Latest user pain与冻结要求：

```text
具体 drop 到哪里
→ 哪里就是 intent
```

因此：

```text
machine fabric KEEP
destination taxonomy RETIRE
```

这是典型：

```text
历史代码/计划部分保留
产品交互部分被覆盖
```

不能整份文档简单标 KEEP/DELETE。

---

## G02 Composer

Historical：

```text
Phase C fixed shell / bottom composer
```

有价值：

- Reference strip；
- overlay composition；
- draft概念；
- Reference不等 Selection。

Superseded：

- fixed bottom center作为最终；
- prompt只在 local React state；
- lack target anchor；
- lack real Run/Voice。

Latest：

```text
target-local compact
2–4 lines
Voice input modality
explicit Reference
```

所以：

```text
semantics KEEP
shell RETIRE
```

---

## G03 Action Arc / Orbit

Historical old planning：

可能存在：
```text
capability registry
```

Current reasoning：

没有 runtime plugin registration requirement。

Ordinary pure function + union能覆盖：

```text
Arc
Right-click
More
```

因此 registry不进入最新施工。

这不是删安全措施。

因为 registry本来不是 safety measure，而是潜在扩展 abstraction。

---

## G04 WorkView

Huabu PreviewWorkspace：

可以提供：

```text
window/panel mechanic references
```

但最新明确：

```text
PreviewWorkspace != LCOS canonical WorkView
```

T3只消费 T4 WorkView state。

不得从 Huabu Preview state推导 LCOS WorkView truth。

---

## G05 Voice

任何旧“语音助手/Workbench”设想若与最新：

```text
Voice = Composer input modality
```

冲突，后者优先。

因此：

```text
Voice panel
Voice workbench
Voice domain
```

都不进入 T3。

---

# Appendix H · Source Existence vs Product Done Ledger

## `LcosComposerShell.tsx`

```text
EXISTS = yes
PRODUCT DONE = no
```

证据：
文件注释 + 无 submit/voice/target。

## `referenceController.ts`

```text
EXISTS = yes
SEMANTIC DONE = yes for ordered draft reference primitive
FULL UX DONE = no
```

因为 explicit Reference Pick UI仍缺。

## `CanvasFloatingPopover.tsx`

```text
EXISTS = yes
MECHANIC DONE = yes
T3 USE = not wired
```

## `semanticDropMachine.ts`

```text
EXISTS = yes
PURE FABRIC = usable
FINAL DESTINATION = no
```

## Core runs

```text
ROUTE EXISTS = yes
T3 Composer path = no
```

这张表防止“源码有文件=功能已经落地”的典型误判。

---

# Appendix I · Negative Evidence

规划还需要记录“没找到什么”。

## No Run client in web-gen2 backend

Current directory只有：

```text
artifacts
client
coreTypes
projects
relations
search
sqliteBindingStore
```

未见：

```text
runs
receiver
voice
```

所以 04册新 typed client不是重复建设。

## No Action Arc body

HostOverlay：

```text
actionArcOpen=false
```

未发现 production body。

## No local contextmenu host callback

Canvas root仅 suppress。

所以 contextmenu seam有真实 gap。

## No final Composer state owner

prompt local + refs另 store。

所以 draft owner有真实 gap。

---

# Appendix J · Why Evidence Did Not Justify More New Infrastructure

没有证据要求：

```text
dynamic plugin actions
→ 不建 action registry

offline cross-device Composer draft
→ 不建 persistent draft DB

voice background recording
→ 不建 Voice service worker

multiple canvas engines
→ 不建 Spatial abstraction platform

remote UI layout server
→ 不建 layout contract

full undo for transient Arc reveal
→ 不写 Core event
```

这也是 evidence census的一部分：

> 不能只证明“该做什么”，还要证明“哪些看起来高级的东西没有需求证据”。

---

# Appendix K · Planning Authority by Layer

```text
Product semantics
→ File Library latest freeze

Gesture mechanics
→ Huabu current source

Domain persistence
→ Local Core current source

Host identity
→ ProjectionBinding

Visual target
→ high-fidelity donor

Generic implementation
→ Huabu / permissive OSS

Construction sequence
→ T3 02/03/04/05
```

发生冲突时沿这个层级解决。

例如：

```text
Lovart Selection behavior
```

不能覆盖：

```text
LCOS Shift Selection / Ctrl Reference
```

因为 donor visual层权威更低。

---

# Appendix L · Evidence Refresh Triggers

施工前只在以下情况重做相关证据：

1. Gen2 HEAD touched T3 current files；
2. Huabu upstream相关 path再次变化且准备 sync；
3. 用户给出更晚 Composer/Reference/Voice/Glyth裁决；
4. T4/T6 handoff改变 target/Run/Receiver canonical contract；
5. OSS donor license/version变化。

不因为：

```text
过了一天
```

就全量重做 census。

---

# Appendix M · Evidence Freeze Is Not Product Contract Freeze

本 01册记录的是：

```text
planning evidence snapshot
```

不是新增 permanent contract/baseline。

Git commit与版本号已足以重现 source状态。

无需给 Markdown再做 hash gate。

