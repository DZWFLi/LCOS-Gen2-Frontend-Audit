# LCOS Gen2 · T3 第三路正式施工规划
## 04_Source_Level_Construction_Plan
### Local Object Interaction / Action Arc / Compact Composer / Reference / Voice

> 日期：2026-09-04  
> 基线：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`  
> 性质：源码级施工蓝图，不是 patch。  
> 施工原则：**Huabu mechanics 不重写；LCOS semantics 不外包；donor body 可替换；先退役过渡 truth 再堆功能。**

---

# 0. 施工目标

最终用户路径：

```text
第一次点击对象
→ Huabu Selection

已选对象稳定再点击
→ 局部 Action Arc

Arc 中 Compose
→ target-local Compact Composer

Composer
→ Prompt
→ Reference
→ Skill/Tool
→ Voice
→ Run

Ctrl/Cmd click
→ Quick Reference

Composer → Add Reference
→ temporary Reference Pick
→ 点击对象直接加入有序 References

Right click
→ management context menu

Double click
→ native Preview
或
LCOS species-specific activation

Drag
→ 仍然 Huabu drag
→ Arc/Composer让道

WorkView
→ overlay body让道
→ draft不丢
```

---

# 1. 施工顺序总览

必须按依赖顺序：

```text
C03-00  owner cleanup
C03-01  threshold unification
C03-02  local affordance presentation owner
C03-03  selected-reclick observer
C03-04  pure action resolver
C03-05  Action Arc body
C03-06  contextmenu host seam + menu
C03-07  Composer draft owner
C03-08  Compact Composer body
C03-09  Reference draft migration + Reference Pick
C03-10  Run/Receiver clients
C03-11  Voice FormData client + recorder
C03-12  Voice→draft wiring
C03-13  Semantic Drop adapter cleanup
C03-14  Glyth body target cross-thread wiring
C03-15  WorkView/takeover/safe-rect cross review
C03-16  retire Phase-A shell/hardcodes
```

禁止跳到 C03-08 先“把 Composer 画出来”。

否则会继续把 prompt local state当 owner。

---

# 2. C03-00 · Current truth cleanup

## Goal

明确：

```text
哪些 state是真 owner
哪些只是 Phase-A placeholder
```

## Target

```text
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
huabu/apps/web/src/lcos/LcosComposerShell.tsx
huabu/apps/web/src/lcos/lcosReferenceState.ts
huabu/apps/web/src/lcos/lcosDropState.ts
```

## No behavior change yet

先加测试/注释和接口准备。

## Must not

删除旧 shell。

它要等新 Composer browser acceptance 后再退。

---

# 3. C03-01 · Unified pointer threshold

## Current problem

`lcosRecognizers.ts`：

```ts
const SLOP_PX = 4;
```

Huabu Canvas：

```text
getDragActivationDistance(inputMode)
nodeDragThreshold
nodeClickDistance
```

## Target file

```text
huabu/apps/web/src/lcos/lcosRecognizers.ts
```

## Reuse

```text
huabu/apps/web/src/handler/canvasGestureSession.ts
getDragActivationDistance
```

## Planned change

Reference recognizer `onMove(event, ctx)`：

```ts
const threshold = getDragActivationDistance(
  event.pointerType === 'pen'
    ? 'pen'
    : event.pointerType === 'touch'
      ? 'touch'
      : 'mouse'
);
```

若 helper签名实际使用 effective input mode，则以现有 helper类型为准，不复制 mapping。

核心要求：

```text
Reference 与 canvas click/drag使用同一 policy source
```

## Tests

更新：

```text
huabu/apps/web/src/lcos/lcosRecognizers.test.ts
```

场景：

- movement below threshold → Reference；
- equal/above threshold → no Reference；
- Shift仍 Selection；
- unbound仍 fail-close。

---

# 4. C03-02 · Local affordance presentation owner

## Concrete reason

需要跨：

```text
pointer recognizer
→ LcosHostOverlay
→ Arc/Composer body
```

共享：

```text
target
mode
```

不用 store就只能：

- event emitter；
- global callback；
- renderer local copies。

这些都更隐式。

## New file

```text
huabu/apps/web/src/lcos/lcosLocalAffordanceState.ts
```

## Exact responsibility

只存 transient presentation：

```ts
export type LocalAffordanceState =
  | { kind: 'closed' }
  | { kind: 'arc'; nodeId: string }
  | { kind: 'composer'; nodeId: string }
  | {
      kind: 'context-menu';
      nodeId: string | null;
      clientX: number;
      clientY: number;
    };
```

Store actions：

```ts
openArc(nodeId)
openComposer(nodeId)
openContextMenu(target, point)
close()
```

## Do NOT store

```text
Selection
CoreEntityRef canonical cache
Reference list
prompt
Run
Voice blob
Relation
WorkView
```

## Why context-menu in same union

它与：

```text
Arc / Composer
```

是同一 local-affordance channel。

右键打开菜单时不应同时保持 Arc。

这避免：

```text
ActionArcStore
ContextMenuStore
ComposerVisibilityStore
```

三个互相协调。

---

# 5. C03-03 · Selected re-click observer

## Target

```text
huabu/apps/web/src/lcos/lcosRecognizers.ts
```

## New recognizer

概念：

```ts
createLocalAffordanceRecognizer()
```

## Important

使用 `observe`，不 claim：

```ts
canClaim: () => false
```

## State inside recognizer instance

```text
activePointerId
start point
candidateNodeId
wasSelectedAtDown
cancelled
```

## onDown observer

仅：

```text
mouse
primary
button 0
not explicitToolActive
not interactivityLocked
not editable target
not floating chrome
```

通过：

```text
nodeIdAtScreenPoint()
```

得到 target。

从 Huabu canvasStore读取：

```text
node.selected
```

若 pointerdown 时还未 selected：

```text
只记录 nothing
```

第一 click交给 Huabu Selection。

## onMove

同 Huabu threshold。

超过：

```text
candidate = null
```

## onUp

若：

```text
same node
wasSelectedAtDown
stable
not dragging/resizing/editing
```

则：

```text
openArc(nodeId)
```

## Important race

因为 `wasSelectedAtDown` 在 pointerdown 读：

第一 click不会在 pointerup因为 Selection已更新而误开 Arc。

这点必须测试。

---

# 6. Editable target filter

不要新建复杂 DOM taxonomy。

优先复用已有 input policy helper。

如果当前无共用 helper，可在 Huabu Canvas input policy附近抽：

```text
isEditableInteractionTarget(element)
```

至少包括：

```text
input
textarea
select
contenteditable
a[href]
button
[data-floating-chrome]
```

注意 button：

普通 node body内功能按钮不能触发 selected-reclick。

## File priority

先查/复用：

```text
huabu/apps/web/src/components/Panels/Canvas/canvasInputPolicy.ts
```

只有没有才新增 helper。

---

# 7. C03-04 · Pure local action resolver

## New file

```text
apps/web-gen2/src/interaction/localObjectActions.ts
```

## Why here

这是 LCOS product semantic policy。

不是 Huabu Common。

## Shape

不做 registry。

概念：

```ts
export type LocalObjectActionId =
  | 'open'
  | 'compose'
  | 'add-reference'
  | 'relation'
  | 'pin'
  | 'assembly'
  | 'focus'
  | 'reveal-source'
  | 'duplicate'
  | 'remove-projection'
  | 'delete';

export type LocalObjectAction = {
  id: LocalObjectActionId;
  placement: 'arc' | 'menu' | 'both';
  destructive?: boolean;
};
```

Resolver输入：

```ts
type LocalObjectActionTarget = {
  entityType: string;
  entityId: string;
  visualFamily?: string;
  surface: 'main' | 'context' | 'workflow';
};
```

注意：

真正 closed entity types以当前 Core type为准，不要最终留下裸 string；这里只是结构说明。

## Output

只返回 action descriptors。

不 dispatch。

不存 state。

## Arc filtering

```text
placement arc/both
→ top 3–5
```

顺序就是 UX顺序。

不再二次排序。

## Menu filtering

```text
menu/both
```

完整 management set。

---

# 8. Action execution owner

建议由 host adapter集中 dispatch：

```text
huabu/apps/web/src/lcos/lcosLocalActionDispatch.ts
```

但只有在多个 body都需要同一 dispatch时创建。

如果 `LcosHostOverlay`可直接将 action callbacks从 host/runtime传入，则不额外造文件。

优先：

```text
pure resolver in web-gen2
+
thin runtime callbacks
```

禁止 action resolver直接 import React/store。

---

# 9. C03-05 · Action Arc body

## New file

```text
huabu/apps/web/src/lcos/LcosActionArc.tsx
```

## CSS

```text
huabu/apps/web/src/lcos/lcosActionArc.css
```

## Donor provenance comment

CSS顶部：

```text
Radial geometry adapted from zumerlab/orbit
commit 9b890671...
MIT
relevant upstream:
src/scss/_radial-layout.scss
src/scss/_satellite.scss
```

并按 license要求保留 notice。

## Do not add Sass dependency

Orbit是SCSS源，但 Huabu当前不需要为了几条 radial formula加入 Sass。

将必要 geometry转成普通 CSS custom properties。

---

# 10. LcosActionArc props

```ts
interface LcosActionArcProps {
  nodeId: string;
  actions: readonly LocalObjectAction[];
  anchor: CanvasAnchorRect | null;
  onAction(action: LocalObjectAction): void;
  onDismiss(): void;
}
```

若 anchor由组件内部复用 Huabu resolver更合适，则最终 props可只传 nodeId。

但不要 body自己读 camera。

---

# 11. Action Arc JSX skeleton

近似：

```tsx
<CanvasFloatingPopover
  anchor={anchor}
  open
  side="top"
  offset={10}
  className="pointer-events-none"
>
  <div
    {...FLOATING_CHROME_PROPS}
    data-lcos-action-arc=""
    className="relative h-20 w-20"
  >
    {actions.map((action, index) => (
      <Button
        key={action.id}
        variant="outline"
        tone={action.destructive ? 'danger' : 'neutral'}
        iconOnly
        size="sm"
        shape="pill"
        className={cn(
          'lcos-action-arc__satellite',
          'pointer-events-auto h-8 w-8',
          'border-edge-default bg-surface shadow-bottom',
        )}
        style={{
          '--lcos-arc-index': index,
          '--lcos-arc-count': actions.length,
        } as React.CSSProperties}
        title={labelOf(action)}
        onClick={() => onAction(action)}
      >
        <ActionIcon action={action.id} />
      </Button>
    ))}
  </div>
</CanvasFloatingPopover>
```

这是施工骨架，不是最终 patch。

---

# 12. Arc CSS geometry

普通 CSS逻辑：

```css
.lcos-action-arc__satellite {
  position: absolute;
  left: 50%;
  top: 50%;
  --lcos-arc-angle:
    calc(
      var(--lcos-arc-range, 180deg)
      / max(1, calc(var(--lcos-arc-count) - 1))
      * var(--lcos-arc-index)
      + var(--lcos-arc-start, 180deg)
    );
  transform:
    translate(-50%, -50%)
    rotate(var(--lcos-arc-angle))
    translateX(var(--lcos-arc-radius, 38px))
    rotate(calc(-1 * var(--lcos-arc-angle)));
}
```

浏览器 CSS `max()`/typed calc支持需跑当前 target browser。

若不稳定：

用 React只计算 `angle` 数值，仍不引入新 geometry owner。

---

# 13. Arc motion

优先 CSS。

```text
opacity 0→1
scale .94→1
duration initial 160ms
ease-out
```

不引入新 animation library。

Huabu虽然已有 `motion` package，但本组件简单 CSS就够。

Reduced motion：

```css
@media (prefers-reduced-motion: reduce) {
  transition-duration: 0ms;
}
```

---

# 14. Arc action count

Hard max：

```text
5
```

不是为了技术限制。

是 frozen UX。

Resolver若给 >5 arc action：

单测失败。

低频项去 More/right-click。

---

# 15. C03-06 · Contextmenu host seam

## Existing

`CanvasHostExtension`没有 contextmenu。

Canvas root已经 owns/prevents contextmenu。

## Modify

```text
huabu/apps/web/src/lcos-seam/types.ts
huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx
```

## Neutral type

建议：

```ts
export interface CanvasHostContextMenuIntent {
  onContextMenu(input: {
    target: { kind: 'node'; nodeId: string } | { kind: 'pane' };
    clientX: number;
    clientY: number;
  }): 'handled' | 'native';
}
```

Host extension：

```ts
readonly contextMenuIntent?: CanvasHostContextMenuIntent;
```

Huabu仍 domain-free。

---

# 16. Canvas contextmenu wiring

优先 ReactFlow props：

```tsx
onNodeContextMenu={(event, node) => {
  if (isNativeContextMenuTarget(event.target)) return;
  const handler = hostExtension?.contextMenuIntent;
  if (!handler) return;
  event.preventDefault();
  event.stopPropagation();
  handler.onContextMenu({
    target: { kind: 'node', nodeId: node.id },
    clientX: event.clientX,
    clientY: event.clientY,
  });
}}

onPaneContextMenu={(event) => {
  ...
}}
```

具体 @xyflow prop类型编译核验。

根容器当前 `onContextMenu`保留 native-editor exclusion作为 fallback。

不得 global listener。

---

# 17. Context menu producer

在：

```text
useLcosCanvasProps.tsx
```

构建 seam 时：

```text
contextMenuIntent
→ lcosLocalAffordanceState.openContextMenu(...)
```

Host callback只改变 transient presentation。

---

# 18. Context menu body

## New file

```text
huabu/apps/web/src/lcos/LcosContextMenu.tsx
```

或如果很小，内联到 HostOverlay。

推荐独立，因为后续 visual body可替换。

## Mechanics

```text
Popover
DropdownMenuItem
```

不新造 framework。

## Skeleton

```tsx
<Popover
  position={{ x: clientX, y: clientY }}
  onDismiss={close}
  boundary={canvasRoot}
>
  <div
    {...FLOATING_CHROME_PROPS}
    role="menu"
    className="min-w-44 overflow-hidden py-1"
  >
    {actions.map(action => (
      <DropdownMenuItem
        key={action.id}
        icon={<... />}
        onClick={() => execute(action)}
      >
        {label}
      </DropdownMenuItem>
    ))}
  </div>
</Popover>
```

注意：

`DropdownMenu`本身是 trigger-based。

直接 context position时用：

```text
Popover + DropdownMenuItem
```

更合适。

---

# 19. C03-07 · Composer Draft owner

## New file

```text
huabu/apps/web/src/lcos/lcosComposerDraftState.ts
```

## Why new store is justified

Current：

```text
prompt local useState
refs in lcosReferenceState
```

body unmount会丢 prompt。

## State

概念：

```ts
interface LcosComposerDraftState {
  draftId: string;
  targetNodeId: string | null;
  prompt: string;
  references: ReferenceControllerState<CoreEntityRefLike>;
  referencePickMode: 'idle' | 'composer-pick';
  selectedSkillId: string | null;
  voiceStatus: 'idle' | 'recording' | 'transcribing';
  submitStatus: 'idle' | 'submitting' | 'failed';
  lastError: string | null;
}
```

## Important

`voiceStatus`只记录 UI process。

不存 audio blob长期 truth。

若 retry transcription需要暂存 Blob，可放组件/adapter scoped ref，不持久化 store，除非 browser recovery需要。

---

# 20. Draft actions

至少：

```text
openForTarget(nodeId)
setPrompt(text)
toggleReference(ref)
removeReference(ref)
startReferencePick()
stopReferencePick()
setSkill(id)
setVoiceStatus(status)
beginSubmit()
submitFailed(error)
submitAccepted()
reset()
```

## openForTarget policy

不要隐式把 Selection复制成 Reference。

target：

```text
Composer target
```

与：

```text
Reference
```

也是两个概念。

---

# 21. Migrate `lcosReferenceState.ts`

## Current responsibilities

```text
nodeEntityRefs
draft references
```

## After

保留：

```text
nodeEntityRefs
register/reset/forget
resolve node→entity
is node referenced? 这一读取应改读 ComposerDraft
```

移走：

```text
draft
toggleReference owner
ordered draft owner
```

pure `referenceController`仍调用于 ComposerDraft store。

## Goal

```text
Projection binding cache lifecycle
≠ Composer draft lifecycle
```

---

# 22. Reference deletion behavior

当前 node projection delete会：

```text
dropDraftReferenceOnNodeDelete
```

迁移后：

```text
resolve entity ref before forget
→ ComposerDraft.removeReference(ref)
→ forget node index
```

Core entity未删时：

是否 Reference应该继续存在？

这里要严格服从 frozen semantics：

当前注释明确 projection删除会从 pending draft去掉。

沿用。

---

# 23. C03-08 · Compact Composer body

## Replace

```text
LcosComposerShell.tsx
```

## New file

建议直接保留旧文件路径重写，还是新文件后退役？

为了清晰迁移：

```text
新增 LcosCompactComposer.tsx
旧 LcosComposerShell保留到验收后删除
```

HostOverlay先双路径 feature test，但不能 production同时 render。

验收后删除 shell。

---

# 24. Composer placement

使用：

```text
CanvasFloatingPopover
```

Anchor：

- target full node；
- takeover mark；
- future T1 shared anchor。

默认：

```text
side='bottom' 或 top
offset 10–12
```

最终根据浏览器 real visual确定。

不要 fixed bottom-center。

---

# 25. Composer body class strategy

优先 Huabu现有 semantic classes：

```text
bg-surface
border-edge-default
shadow-bottom
text-fg-muted
text-fg-subtle
bg-hover
bg-info-bg
text-info
rounded-lg/xl
```

不新增整套 LCOS颜色 token。

建议 root：

```tsx
className={cn(
  'bg-surface border-edge-default shadow-bottom',
  'w-[360px] max-w-[min(72vw,520px)]',
  'rounded-xl border p-2',
  'flex flex-col gap-2',
)}
```

`360px` 是 LCOS initial implementation choice，来自当前 compact尺度连续性，不宣称是 donor测量值。

真实 browser review后可调整。

---

# 26. Composer references

Top strip：

```tsx
<div className="flex flex-wrap items-center gap-1.5">
  {orderedRefs.map(ref => <ReferenceChip ... />)}
  <Button ... title="Add reference">
    <Plus />
  </Button>
</div>
```

ReferenceChip：

- image/content有缩略时小 thumb；
-否则 icon + compact label；
- remove x；
- order按 draft。

不要显示内部 id `#index` 给最终用户，除非 product需要顺序提示。

当前 shell的 `Artifact · shortId` 是 debug/transition味，应退。

---

# 27. Composer textarea

不要直接复用 thread-bound `ChatInput` whole。

先抽 generic input body，或在 LCOS body复用其成熟实现 pattern。

目标：

```text
min 2 lines
max 4 lines
overflow auto
IME safe
Enter submit
Shift+Enter newline
```

如果 Huabu `ChatInput` generic extraction能低冲突：

建议新 Common：

```text
components/Common/CompactTextComposer.tsx
```

但只有 upstream compare后确认可抽。

否则 T3 body可以复用同一逻辑片段，但必须避免长期复制。

第一个选择是 WRAP/EXTRACT，不是 copy-paste fork。

---

# 28. Composer bottom row

Layout：

```text
left:
Add Reference
Skill/Tool
Voice

right:
Send/Run
```

Action controls：

```text
Button ghost sm
```

Send：

```text
Button solid/ghost info
```

不要常驻模式按钮动物园。

---

# 29. Composer focus

root：

```text
pointer-events auto
data-floating-chrome
```

不要：

```text
autoFocus
```

Input只在：

```text
user click
或 explicit keyboard Compose command
```

focus。

Composer root pointerdown不应回传 canvas selection。

但不要用：

```text
preventDefault()
```

在整个 root，否则 textarea无法 focus/select。

使用：

```text
stopPropagation
```

按事件层精确处理。

---

# 30. C03-09 · Explicit Reference Pick

## State

ComposerDraft：

```text
referencePickMode
```

## Recognizer update

现 Reference recognizer `canClaim` 当前只 modifier。

改成：

```text
isReferencePick(modifiers)
||
composerDraft.referencePickMode === 'composer-pick'
```

但 Shift优先。

## In explicit mode

左键 eligible LCOS bound node：

```text
toggle Reference
```

Selection不变。

## Quick mode

Ctrl/Cmd仍原行为。

## UI

Composer Add Reference：

```text
startReferencePick()
```

HostOverlay额外显示小 hint：

```text
Reference Pick · Esc
```

可以在 Composer body顶部/旁边，不新全局 modal。

---

# 31. Reference Pick Escape

仅在 pick active时挂 `keydown`。

Esc：

```text
stopReferencePick()
```

不：

```text
close Composer
clear References
```

event propagation应允许更内层 popover先处理；实现时依赖现有 `useCloseOnEscape` ordering或局部 capture review。

---

# 32. C03-10 · Backend typed clients

Current backend：

```text
artifacts
projects
relations
search
```

缺：

```text
runs
receiver
voice
```

## New

```text
apps/web-gen2/src/backend/runs.ts
apps/web-gen2/src/backend/receiver.ts
apps/web-gen2/src/backend/voice.ts
```

如果 T6已有另一命名规划，以 T6正本为准。

---

# 33. runs.ts frontend

只映射现有 Core。

至少：

```ts
createRun(projectId, input, signal)
dispatchRun(runId, signal)
recoverRun(runId, signal)
syncRun(runId, signal)
cancelRun(runId, signal)
getRunEvents(runId, after, signal)
```

使用 contracts包已有 type。

不要在 web-gen2再声明第二份 CreateRun schema。

---

# 34. receiver.ts frontend

至少 T3需要：

```text
getReceiverBinding(projectId)
listConnectedConversations(projectId)
```

若 Composer支持切 receiver：

```text
setActiveReceiver
```

handoff由 T4/T6路径，不强塞进 T3 UI。

---

# 35. C03-11 · HttpClient FormData support

## Modify

```text
apps/web-gen2/src/backend/client.ts
```

## Minimal design

扩 RequestOptions：

```ts
body?: unknown
rawBody?: BodyInit
```

mutually exclusive通过类型 union更好。

例如：

```ts
type RequestBody =
  | { body?: unknown; rawBody?: never }
  | { body?: never; rawBody: BodyInit };
```

但如果改动太大，直接新方法：

```ts
postFormData<T>(
  path: string,
  form: FormData,
  signal?: AbortSignal
): Promise<T>
```

## Critical

FormData：

```text
不设置 Content-Type
```

浏览器生成 boundary。

仍设置：

```text
Accept
Authorization
```

## No new business state

---

# 36. voice.ts frontend

构造：

```text
FormData
file/blob
durationMs?
language?
prompt?
timestamps?
providerId?
```

POST：

```text
/runtime/voice/transcriptions
```

返回 existing contract：

```text
VoiceTranscriptionResponseV1
```

---

# 37. C03-11 · Lift Copilot recorder

## Local destination

建议：

```text
huabu/apps/web/src/lcos/voice/LcosAudioRecorder.tsx
```

顶部 provenance notice。

为什么不放 Common：

目前唯一 consumer LCOS Composer。

等 Huabu自身第二 consumer出现，再考虑 Common。

## Keep

- MediaRecorder lifecycle；
- MIME fallback；
- cleanup；
- waveform。

## Replace

- `cpk:` classes；
- donor names；
- product labels。

---

# 38. Recorder props

不要把 CopilotKit ref API原封不动暴露全世界。

LCOS wrapper：

```ts
interface LcosAudioRecorderHandle {
  start(): Promise<void>;
  stop(): Promise<Blob>;
  dispose(): void;
}

interface LcosAudioRecorderProps {
  status: 'idle' | 'recording';
}
```

内部保留 donor state。

---

# 39. Voice UI in Composer

Idle：

```text
Mic icon
```

Recording：

```text
waveform
Cancel
Finish
```

Transcribing：

```text
small spinner/status
```

成功：

```text
setPrompt(transcript)
voiceStatus=idle
```

若 prompt已有文字：

不能静默覆盖。

推荐：

```text
insert at cursor / append with spacing
```

但 precise insertion policy必须以 frozen Composer voice原文为准。

如果原文只说转写成可编辑文字、没有规定插入规则：
第 04 册不自行发明，默认当 prompt为空时替换，非空时需要产品裁决/既有原文。

此项标：

```text
OPEN_MICRO_POLICY
```

不阻塞 recorder/client施工。

---

# 40. C03-12 · Voice errors

局部状态：

```text
permission denied
no mic
recording failed
transcription unavailable
aborted
```

显示在 Composer。

不得 toast-only。

因为用户要知道当前 voice input为什么没进 prompt。

错误后：

```text
prompt/ref/target intact
```

---

# 41. C03-10/12 · Run submit adapter

Composer submit：

```text
read immutable draft snapshot
resolve target
read active receiver
map ordered references
createRun
```

不要 submit中边读边让 UI变动影响 payload。

## Snapshot

普通 JS object即可。

不新增 hash。

---

# 42. Run submit lifecycle

```text
idle
→ submitting
→ accepted
```

失败：

```text
failed(error)
```

## On accepted

什么时候 clear draft？

默认安全策略：

```text
收到 201 createRun成功后
```

再 clear/roll。

如果产品要求直到 dispatch成功再清，应以 Run UX正本覆盖。

不在前端 optimistic clear。

---

# 43. Ordered Reference mapping

当前 referenceController：

```text
CoreEntityRefLike entityType/entityId
```

Core runs `orderedReferences` 有正式 ref union。

需要一个 typed adapter：

```text
toRunOrderedReference(ref)
```

不要用 `as never` 在 UI随便硬塞。

如果某 entityType不支持：

```text
fail-close
```

或 action resolver不提供 Run。

---

# 44. C03-13 · Semantic Drop adapter cleanup

## KEEP

```text
semanticDropMachine.ts
```

## MODIFY

```text
lcosDropState.ts
lcosRecognizers.ts
LcosDropPreview.tsx
```

## Remove

```text
DOCK_LEFT
DOCK_BOTTOM
destinationFor(left/bottom)
SURFACE_LABEL hardcodes
```

但只有 real target resolver接好后删。

---

# 45. Drop target resolution

不新建 mutable registry。

概念纯函数：

```text
resolveSemanticDropTarget({
  nodeId,
  point,
  binding,
  surfaceContext
})
```

返回：

```text
null
或
concrete target descriptor
```

T3本册只冻结：

```text
Glyth body
```

完整 Surface slot/Assembly由 T4提供正式 target descriptor。

T3不猜。

---

# 46. Drop machine destination redesign

Current `DropDestination.place`坐标含混。

施工时改成分离概念。

建议：

```ts
interface DropDestination {
  readonly target: SemanticDropTargetRef;
  readonly previewAnchorPx: SurfacePoint;
}
```

真正 world placement若需要：

由 commit adapter调用 Huabu transformer现算。

不要存成 presentation truth。

---

# 47. Drop `overDestination`

Current：

```text
false
```

改：

```text
target != null
```

并传 concrete target。

Preview carry zone才真正有意义。

---

# 48. Drop commit

pointerup：

若：

```text
state.preview
target still valid
```

执行 target-specific commit。

先收到：

```text
transaction/run/mutation id
```

再：

```text
commitAt(id)
```

commit结果：

```text
success → reset
failure → fail(reason,recoverable)
```

如果 Core API本身返回最终结果不需要 long committing，按正式 API简化。

不要为了保留 FSM形状强造 transaction。

---

# 49. C03-14 · Glyth body drop

Cross-thread dependency：

```text
Glyth production species
Core Conversation Context Mapping mutation
```

T3负责：

```text
hit
preview
intent
feedback
cancel
```

T6/Core负责 mutation client。

## Hit

只 body。

不能 relation port。

不能 halo。

## Preview copy

说明：

```text
“加入该 Conversation Context”
```

不是：

```text
“创建 Relation”
```

---

# 50. C03-15 · WorkView

`LcosHostOverlay`必须读真实 T4 state。

当前：

```text
workViewOpen=false
```

改成：

```text
T4 canonical presentation state selector
```

若 T4接口尚未合并：

本 card等待 T4 handoff，不在 T3造 shadow boolean。

---

# 51. WorkView draft continuity test

流程：

```text
open Composer
type text
add refs
open WorkView
close WorkView
```

Expected：

```text
same prompt
same refs
same target
```

Composer body可以 unmount。

Draft owner不能。

---

# 52. Safe rect

CanvasFloatingPopover当前 boundary是 Canvas DOM rect。

WorkView occupied region需要 T2/T4提供。

T3不新建 safe rect。

接入方案优先：

```text
扩 CanvasFloatingPopover boundary/available rect input
```

或由 T2统一处理。

Action Arc/Composer都跟着同一个 primitive受益。

---

# 53. Takeover mark

不要自己算。

优先从：

```text
NodeFloatingToolbar anchor resolution
```

共享/抽最小 helper。

若抽：

```text
resolveNodeFloatingAnchor(nodeId)
```

放 Huabu Common/Canvas helper。

只有 Arc + Composer + Toolbar确实三处重复后再抽。

---

# 54. C03-16 · Retirement

## LcosComposerShell

删除条件：

- new Compact Composer e2e green；
- draft continuity green；
- Reference Pick green；
- Run submit green；
- Voice可独立降级。

## Drop edge hardcode

删除条件：

- concrete target preview；
- cancel；
- commit；
- Glyth path；
- external native path不回归。

---

# 55. Overlay arbitration modifications

建议将 local affordance union转成 booleans。

如果 context menu也纳入 central arbitration：

修改：

```text
apps/web-gen2/src/interaction/overlayArbitration.ts
```

添加：

```text
context-menu
contextMenuOpen
```

优先级：

```text
drag
resize
workview
context-menu
composer
action-arc
rest
```

由于 local mode互斥，顺序不是隐式业务政策，但仍保证外部错误输入不会 Christmas tree。

如果 ContextMenu使用 Huabu Popover且 local mode已经互斥，也可以暂不扩 OverlayKind。

最终以测试简洁度决定。

---

# 56. LcosHostOverlay final composition

目标接近：

```tsx
export function LcosHostOverlay() {
  const affordance = useLcosLocalAffordanceStore(...);
  const drop = ...
  const workViewOpen = useCanonicalWorkViewState(...);

  const visible = visibleOverlays({
    dragging,
    resizing,
    selected,
    hovered,
    composerOpen: affordance.kind === 'composer',
    actionArcOpen: affordance.kind === 'arc',
    workViewOpen,
    dropPreview,
    referenceBadge,
  });

  return (
    <>
      {showArc && <LcosActionArc ... />}
      {showComposer && <LcosCompactComposer ... />}
      {affordance.kind === 'context-menu' && <LcosContextMenu ... />}
      {showDrop && <LcosDropPreview ... />}
    </>
  );
}
```

注意：

HostOverlay仍然是 composition。

不是业务 service。

---

# 57. Floating chrome marker

所有 portal local controls必须：

```tsx
{...FLOATING_CHROME_PROPS}
```

原因：

Huabu attention tracking会把这些 chrome视为 neutral。

不加会出现：

```text
用户鼠标移到 Arc
→ 系统以为离开 canvas surface
→ Arc自己把自己关了
```

---

# 58. Visual classes · Action Arc

优先现成：

```text
bg-surface
border-edge-default
shadow-bottom
text-fg-muted
hover:bg-hover
text-info
bg-info-bg
```

按钮：

```text
Button
variant outline/ghost
iconOnly
size sm
shape pill
```

不手写新的 hover JS。

---

# 59. Visual classes · Composer

Card：

```text
bg-surface
border-edge-default
shadow-bottom
rounded-xl
border
```

Prompt：

```text
bg-transparent
text-fg-default/muted
outline-none
```

Reference chip：

```text
bg-info-bg
text-info
rounded-md
```

具体 token以现有 Tailwind token名称编译为准。

---

# 60. Motion token policy

不先新建全局 token。

组件初值：

```text
Arc reveal 160ms ease-out
Reference satellite 150ms ease-out
Composer local reveal 180ms ease-out
```

这些是 LCOS initial construction values，不冒充 donor source exact values。

真实浏览器测量后：

如果三处最终需要同一个值且有多个 consumer，再升 shared token。

---

# 61. CSS/JS hover

禁止旧 shell这种：

```ts
onMouseEnter => element.style.background = ...
```

全部用：

```text
Tailwind/CSS pseudo-class
```

便于 theme/accessibility。

---

# 62. Keyboard

Action Arc：

- Tab可达；
- button aria-label；
- Escape close；
- Enter/Space button native。

Composer：

- IME；
- Enter submit；
- Shift+Enter newline；
- Escape按局部层级。

Menu：

Huabu现有 keyboard mechanics。

---

# 63. Accessibility

视觉小按钮 24–32px时：

至少实际 hit target 32px左右。

可以：

```text
visual circle 28
button hit 32
```

不为了复刻 donor把 hit target压小。

---

# 64. LOD

低 LOD：

- target body可能 takeover；
- Arc anchor mark；
- Composer仍 screen-space；
- reference badge可降细节。

禁止随 canvas zoom把屏幕按钮缩到不可点。

CanvasFloatingPopover本来就是 screen-space。

---

# 65. Testing files

预期新增/修改测试：

```text
apps/web-gen2/src/interaction/localObjectActions.test.ts
apps/web-gen2/src/interaction/overlayArbitration.test.ts
apps/web-gen2/src/backend/*.test.ts

huabu/apps/web/src/lcos/lcosRecognizers.test.ts
huabu/apps/web/src/lcos/lcosLocalAffordanceState.test.ts
huabu/apps/web/src/lcos/lcosComposerDraftState.test.ts
huabu/apps/web/src/lcos/LcosActionArc.test.tsx
huabu/apps/web/src/lcos/LcosCompactComposer.test.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.test.tsx
huabu/apps/web/src/lcos/LcosDropPreview.test.tsx
```

加 Playwright：

```text
local interaction
composer continuity
voice mock
semantic drop
```

---

# 66. Test · no new truth

必须有 architecture tests/assertions：

```text
Reference opening doesn't select
Selection doesn't copy Reference
Arc open doesn't mutate Core
Composer reveal doesn't create Run
Voice transcript doesn't auto-send
drop preview doesn't mutate Core
```

这些普通测试足够。

不建 formal gate。

---

# 67. Test · exact first-click/re-click

Playwright：

```text
click node
expect selected
expect no arc

click same node
expect arc

drag selected node 8px
expect no arc
```

阈值用 actual helper-derived预期，不硬编码 test另一套 magic。

---

# 68. Test · context menu

```text
right click node body
→ LCOS menu

right click textarea
→ native / no LCOS menu

right click blank
→ blank menu or none per policy

menu open
→ Arc closed
```

---

# 69. Test · Composer no focus steal

```text
selected re-click
→ Composer/Arc visible
document.activeElement not textarea

click textarea
→ focused
```

---

# 70. Test · draft continuity

```text
prompt = hello
refs = [A,B]
open WorkView
close
expect prompt hello
expect A,B order
```

---

# 71. Test · Reference Pick

```text
open Composer target A
enter pick
click B
click C
expect refs [B,C]
expect Selection unchanged
Esc
expect pick off
expect Composer still open
```

Quick modifier：

```text
Ctrl/Cmd click D
```

同 controller。

---

# 72. Test · Voice

Mock navigator MediaDevices + Core HTTP。

场景：

- permission denied；
- no device；
- stop Blob；
- FormData boundary；
- transcription text；
- prompt editable；
- no Run POST before explicit Send。

---

# 73. Test · Run

Mock Core：

201：

```text
payload ordered refs exact order
receiver exact
```

409：

```text
draft retained
```

Abort：

```text
draft retained
submitStatus reset/error
```

---

# 74. Test · Drop

- acquisition without payload impossible；
- preview pointer-events none；
- visible target hit；
- pointercancel zero mutation；
- Glyth body mapping；
- relation port not Glyth context drop；
- native file blank canvas still Huabu。

---

# 75. Construction cards dependency

## C03-A

Threshold + local affordance.

No backend dependency。

## C03-B

Action resolver + Arc + contextmenu。

No Core mutation except action callbacks。

## C03-C

Draft + Composer + Reference Pick。

Requires ProjectionBinding only。

## C03-D

Run/Receiver.

T6 contract review。

## C03-E

Voice.

Core route existing。

## C03-F

Semantic Drop/Glyth.

T4/T6 target/mutation handoff。

---

# 76. Rollback boundaries

不是做 formal rollback gate。

代码上每阶段可通过模块边界撤回：

Arc body坏：

```text
disable Arc render
Selection不变
```

Composer body坏：

```text
draft owner仍可测
旧 shell在正式 retirement前可暂时 fallback
```

Voice坏：

```text
hide/disable mic
text Composer仍工作
```

Drop新 target resolver坏：

```text
不能回到错误 left/bottom UX作为正式 fallback
应 fail-close semantic drop
native Huabu drop仍可用
```

---

# 77. No feature flags by default

不新增永久 feature flag体系。

施工期间若测试需要局部 conditional mounting：

仅测试/开发临时，最终删。

用户默认不要新 gate。

---

# 78. Upstream sync risk

Huabu upstream有新的 `ThreadChatInput`。

在修改 ChatInput前：

```text
主协调先决定是否同步相关 upstream commits
```

若不同步：

T3改动必须避免与其结构冲突。

不要手工 cherry-copy成私有 duplicate。

---

# 79. Source ownership final table

| Source | Final responsibility |
|---|---|
| `referenceController.ts` | Reference pure semantics |
| `localObjectActions.ts` | T3 pure action policy |
| `semanticDropMachine.ts` | Drop pure reducer |
| `lcosRecognizers.ts` | host gesture observers/claims |
| `lcosLocalAffordanceState.ts` | transient local UI mode/target |
| `lcosComposerDraftState.ts` | unsubmitted Composer draft |
| `LcosActionArc.tsx` | replaceable Arc body |
| `LcosCompactComposer.tsx` | replaceable Composer body |
| `LcosContextMenu.tsx` | management menu body |
| `LcosHostOverlay.tsx` | composition/arbitration |
| `lcosReferenceState.ts` | ProjectionBinding-derived node identity index |
| `CanvasFloatingPopover.tsx` | floating geometry |
| Core Runs | Run truth |
| Core Receiver | receiver truth |
| Core Voice | transcription truth |

---

# 80. Final anti-pattern list

施工 Agent看到以下冲动直接停：

```text
“做一个 InteractionManager”
停。

“做一个 ActionCapabilityRegistry”
停。

“Composer自己useState就够了”
不够，已有失败场景。

“右键用window listener简单点”
不行。

“Orbit有组件直接全装”
不需要。

“CopilotKit输入框挺完整直接用”
会带第二 chat owner。

“Semantic Drop先继续左边/下边感应区”
已被最新 UX覆盖。

“为了统一把 Selection放ComposerStore”
绝对不行。

“Voice录完直接发”
不行。
```

---

# 81. Completion definition

第 04 册施工完成不是：

```text
UI看起来有 Arc 和输入框
```

而是：

```text
first click / re-click / drag因果正确
Reference/Selection/Relation不串
target local
draft连续
right-click层级正确
Voice可编辑不自动发
Run使用正式 Core
Drop concrete destination
WorkView不丢draft
donor body可替换
```

这才是 T3 close。


---

# Appendix A · Proposed exact new file census

新增数量应保持克制。

高概率新增：

```text
apps/web-gen2/src/interaction/localObjectActions.ts
apps/web-gen2/src/backend/runs.ts
apps/web-gen2/src/backend/receiver.ts
apps/web-gen2/src/backend/voice.ts

huabu/apps/web/src/lcos/lcosLocalAffordanceState.ts
huabu/apps/web/src/lcos/lcosComposerDraftState.ts
huabu/apps/web/src/lcos/LcosActionArc.tsx
huabu/apps/web/src/lcos/lcosActionArc.css
huabu/apps/web/src/lcos/LcosCompactComposer.tsx
huabu/apps/web/src/lcos/LcosContextMenu.tsx
huabu/apps/web/src/lcos/voice/LcosAudioRecorder.tsx
```

可能不新增：

```text
lcosLocalActionDispatch.ts
```

只有多个 consumer无法复用 callback时再加。

条件新增：

```text
CanvasHostActivationIntent
```

只有 Glyth double-click经 T4/T6确认需要 override。

---

# Appendix B · Proposed modified file census

```text
apps/web-gen2/src/backend/client.ts
apps/web-gen2/src/interaction/overlayArbitration.ts       # if context menu arbitration needed

huabu/apps/web/src/lcos-seam/types.ts
huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/lcos/lcosRecognizers.ts
huabu/apps/web/src/lcos/lcosReferenceState.ts
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
huabu/apps/web/src/lcos/lcosDropState.ts
huabu/apps/web/src/lcos/LcosDropPreview.tsx
```

Retire：

```text
LcosComposerShell.tsx
```

---

# Appendix C · action descriptor sketch

```ts
type LocalActionOwner =
  | 'preview'
  | 'reference'
  | 'relation'
  | 'pin'
  | 'assembly'
  | 'workview'
  | 'projection'
  | 'entity';

type LocalObjectAction = {
  id: LocalObjectActionId;
  owner: LocalActionOwner;
  placement: 'arc' | 'menu' | 'both';
  destructive?: boolean;
};
```

为何记录 owner：

不是新增 truth。

它帮助 dispatch adapter fail-close，避免：

```text
delete action误调用 projection remove
```

实际 owner union以现有 Core API核验后冻结。

---

# Appendix D · Composer draft invariants

```text
I1 target != Reference
I2 opening target does not populate refs
I3 ordered refs stable
I4 prompt survives body unmount
I5 WorkView doesn't clear
I6 Voice doesn't auto-submit
I7 failed Run doesn't clear
I8 project switch does clear or explicitly migrate according to session lifecycle
I9 ProjectionBinding resync doesn't silently reorder refs
```

I8需与主 session lifecycle对齐。

---

# Appendix E · local affordance invariants

```text
A1 only one of arc/composer/context-menu
A2 first click doesn't open
A3 drag cancels candidate
A4 editing suppresses
A5 WorkView suppresses
A6 drop suppresses
A7 transient close has zero data mutation
A8 target delete closes affordance
A9 target project swap closes affordance
```

---

# Appendix F · Context menu action order initial policy

不是最终视觉，但可作为施工顺序：

```text
Open / Focus
Compose
Add Reference
Relation
Pin
Assembly
---
Duplicate
Reveal Source
---
Remove Projection / Delete
```

必须由 pure resolver对 target删掉不适用项。

不要 disabled项目堆满菜单证明“功能很多”。

---

# Appendix G · Arc initial action policy

普通 content：

```text
Open
Compose
Add Reference
Pin
More
```

Glyth：

```text
Open/Work
Compose/Speak
Relation
Pin
More
```

这些 action label必须以最新 frozen product原文/T4 handoff最终核准。

此处是 structural placeholder，不把示例当 canonical list。

施工 Agent不得直接硬编码这个示例后声称完成。

---

# Appendix H · DOM layering

```text
Canvas
├─ ReactFlow renderer
├─ node chrome
└─ host overlays

CanvasFloatingPopover
→ document.body portal
→ FLOATING_CHROME_PROPS
```

Context menu Popover也是 portal。

z-index继续走：

```text
overlayArbitration / existing Huabu chrome
```

不要 Action Arc inline `99999`。

---

# Appendix I · Performance

selected-reclick observer：

- 不订阅所有 node React state；
- pointerdown时用 store getState；
- recognizer instance稳定；
- 不为每 node mount listener。

Action Arc只 mount一个 active target。

Composer只 mount一个。

Reference badge per-node已有路线需要 T5注意 selector成本。

---

# Appendix J · Security / privacy

Voice：

- microphone仅用户显式点；
- stop/dispose tracks；
- 不后台持续录；
- transcription endpoint现有 auth；
- audio不放 global persisted store。

Run：

- 使用已有 bearer client；
- receiver显式。

---

# Appendix K · Browser measurement checklist

Action Arc：

```text
node near top
node near bottom
node near left/right
panel open
zoom 25/100/200%
takeover
```

Composer：

```text
1 line
4 lines
long reference labels
5+ refs
target near edge
WorkView open
```

Voice：

```text
Chrome
Edge
permission denied
device disconnect
```

---

# Appendix L · Construction handoff format

每个 Codex task最终应写：

```text
READ FIRST
TARGET FILES
KEEP
CHANGE
DO NOT CHANGE
DONOR
OWNER
EXACT STATE
JSX
CLASS
MOTION
TEST
RETIREMENT
```

不要只发一段总 prompt。
