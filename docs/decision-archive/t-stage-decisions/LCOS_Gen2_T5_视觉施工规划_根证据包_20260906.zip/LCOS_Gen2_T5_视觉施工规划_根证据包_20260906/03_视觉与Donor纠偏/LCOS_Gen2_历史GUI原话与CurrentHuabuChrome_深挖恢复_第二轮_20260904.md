# LCOS Gen2 · 历史 GUI 原话与 Current Huabu Chrome 深挖恢复 · 第二轮

> 日期：2026-09-04
> 性质：恢复账，不是视觉正本，不冻结 HUD/LOD/Railway/Minimap 最终布局。
> 目标：把“用户为什么反复打回”与 current Huabu 真实 viewport chrome / production mechanics 对上，作为后续 Spatial 反编译源码和最终 Source Adoption Matrix 的证据层。

## 本轮已恢复的关键证据

### 1. 8/26 可见对话原文
恢复到的用户核心意图：
- 主画布操作可以平权，但视觉绝不能平权；
- Glyth/Conversation 是主画布一级视觉身份之一；
- 导航信标是另一一级空间识别；
- 二线视觉语法主要用于 Selection/Focus/Search/Agent layout 等需要时，不应平时制造噪音；
- Surface Component 的初衷不是在自由画布上摆 SaaS 表格，而是提供纯粹视觉/整理原语，帮助 Artifact 比较、归纳、排整齐；
- 复杂智能整理交给 Skill，GUI 只保留少量确定性排布原语；
- Assembly 需要独立持续工作语义，不能只是一个子画布；
- “逻辑尽量不变，通过 CSS/成熟动效/视觉组件撮合成新形态”已经是 8/26 用户原话，而不是 9/4 新发明。

### 2. Image2 UI Prompt 全文
恢复：
- 第二轮已经明确首轮三联图“平庸画布感”；
- 当时已经找到短 L 角线、segment light、pixel matrix、Glyth badge、provenance trace 等视觉词汇；
- 但这些视觉词汇仍大量寄生在 card body 上；
- shell 仍是 Collect shelf + Activity rail + bottom dock + petri-dish group + centered Assembly modal。
因此今天不能复刻 Prompt 的 anatomy，只能保留它验证过的视觉词汇和“为什么普通画布不够”的问题意识。

### 3. Figma Make 定向校正全文
恢复：
- EVERY OBJECT SHOULD FIRST LOOK LIKE ITSELF, NOT FIRST LOOK LIKE “AN LCOS CARD”；
- Glyth near→mid→far；
- Color Pin / off-screen locator / minimap 同导航族；
- Context：Structure Island / Evolution Track / Relation Field / Source Rail；
- Workflow：Action Path 本身是 body；
- Assembly：heterogeneous masonry/waterfall；
- Glyth Assembly：target body + satellites，不是 toggles/settings；
- Skill ≠ live execution；
- Main/Context/Workflow 必须 silhouette 上可辨。
但 “不要 permanent sidebars / bottom dock” 属当时 prototype shell correction，不可覆盖后来的 Railway 与 current Huabu shell truth。

### 4. 8/31 Centered Spatial Index / Assembly
恢复：
- Color Pin / Focus / Search / Map Locator / Assembly 是不同 user intents；
- top-center slot 是历史上减少常驻 chrome 的共享 presentation experiment，不等于今天必须保留；
- Assembly category candidate：
  Artifacts/Materials, Contexts, Workflows, Skills, Collections, Conversations, Workspaces；
- category 为空则不显示；
- taxonomy 必须是用户对象族，不是 JSON/view/scope/database type。
- historical node-local Color Pin = above node, not Action Arc anchor；
- Map Locator = large directional morphology，不是小 Pin dot。

### 5. Current Huabu viewport chrome
Production composition:
- CanvasPage → MainLayout
- Header = CanvasHeader
- Left = CanvasLayerPanel
- Right = PreviewWorkspacePanel
- Center = CenterArea/Canvas

Current Huabu owners:
- CanvasHeader：AppMenu + Canvas title/menu + left panel toggle；left panel collapsed 时转 floating header；
- CanvasLayerPanel：
  hierarchy tree,
  type filter,
  canvas-wide search,
  frame/group collapse,
  missing-content state,
  question ambient status；
- Bottom-center NodeToolbar：
  Select/Pan/Lasso,
  Note/Text/Frame/Sketch creation,
  content import/link,
  Question/Agent creation；
- Bottom-left ReactFlow Controls；
- Minimap 独立，由 store state 控制；
- Canvas local:
  SelectionOutlines / MultiSelect / NodeFloatingToolbar / Edge toolbar / overlays。
因此未来 Railway 不能机械复制成第二个左 sidebar；必须与“Surface/worksite navigation”和“current-Surface layer/content hierarchy”做责任分离。

### 6. Current Huabu LOD/takeover
- common Semantic Zoom: full↔minimal, screen width threshold；
- Question continuous takeover:
  card body fades,
  identity mark corner→center,
  screen-space mark,
  selection/toolbar/ports follow mark footprint。
这已是“world object shrinks but persistent identity takes over”的 production precedent。
明日 Spatial decompile 重点比较：
binary LOD vs continuous takeover vs stepped fixed-size mark vs Pin/Locator handoff。

## 本轮仍未冻结
- Railway 与 CanvasLayerPanel exact geometry；
- Minimap launcher placement；
- top-center index 是否保留、何时出现；
- permanent HUD family；
- Pin exact node anchor；
- Selection footprint per species；
- Frame/packing/layout；
- Work View/Assembly exact width/category chrome；
- dynamic donor exact component mapping。
这些必须等 Spatial deeper source + donor final census。

## 新的历史解释
0.15 的问题不是“没有产品思路”。
更准确：
1. 产品与交互法条已大量形成；
2. visual vocabulary 也找到不少；
3. 但 anatomy 仍是 card/rail/modal 旧壳；
4. 当时缺成熟 visual body/component supply；
5. 自研 frontend 实现能力不足，使正确语义被翻译成粗糙 UI；
6. Gen2 应保留语义，替换身体，不重新发明 Domain/Spatial kernel。
