# LCOS Gen2 · T4 第四路
## V6 ExactFile 前置施工表 · KEEP / ADOPT / WRAP / RETIRE
### Unified Work View / Assembly / Context / Workflow / Skill

日期：2026-09-04  
当前源码基线：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`  
状态：`EXACTFILE_PREPLAN / NOT_FINAL_CONSTRUCTION_PLAN`

> 本文是第四路深挖后的 ExactFile 前置收敛稿，不是最终施工正本。  
> 目的：把旧 B06e/C06e 过度施工项逐项砍掉，把真正需要施工的文件范围收窄到“现有 owner + 薄 typed client + 专业 donor body”。

---

# 0. 最新结论

T4 当前最合理的架构不是：

```text
WorkView Framework
+ WorkView Store
+ WorkView Registry
+ Dock Framework
+ Immersive Framework
+ Context custom engines
+ Skill custom UI engines
```

而是：

```text
Core canonical truth
    ↓
small typed Core clients
    ↓
project-session WorkView presentation session
    ↓
Huabu existing placement mechanics
    ↓
replaceable professional bodies / donor adapters
```

关键纪律：

```text
WorkView 不拥有 Camera
WorkView 不拥有 Dock width truth
WorkView 不拥有 fullscreen truth
WorkView 不拥有 Run truth
WorkView 不拥有 Context history truth
WorkView 不拥有 Skill package truth
Assembly 不拥有 Warehouse truth
donor 不拥有 canonical identity
```

---

# 1. 本轮确认的具体失败场景

## 1.1 当前 fullscreen 会杀掉 LCOS runtime

当前链路：

```text
CanvasPage
└── MainLayout
    ├── children = CenterArea
    └── rightPanel = PreviewWorkspacePanel
```

`CenterArea` 当前调用：

```text
useLcosCanvasProps(projectId)
```

而 `useLcosCanvasProps()` 的 unmount cleanup 会：

```text
runtimeRef.current?.dispose()
```

同时 `MainLayout` 当前在 Preview fullscreen 时：

```text
unmount center children
```

也就是：

```text
enter fullscreen
→ CenterArea unmount
→ useLcosCanvasProps cleanup
→ Gen2 runtime dispose
→ reconciler dispose
```

如果直接拿现有 fullscreen mechanics 做 WorkView IMMERSIVE，而不先移动 runtime lifecycle owner：

```text
Project-session continuity 会在进入 Immersive 时被自己销毁
```

这是当前唯一已经足以强制架构调整的具体失败，不是抽象洁癖。

---

# 2. 因此，runtime owner 最小移动不是 RootLayout，而是 CanvasPage

旧倾向：

```text
RootLayout / global Project Runtime Provider
```

当前更小的修复：

```text
CenterArea
    ↓ hoist one level
CanvasPage
```

原因：

- `CanvasPage` 同时覆盖 center 与 right sibling；
- MainLayout fullscreen 不会卸载 CanvasPage 本身；
- Canvas route parameter change 可以继续 retarget；
- 不需要新增全局 project runtime store；
- 后续只有在真实证明 Context/Workflow 会脱离 CanvasPage lifecycle 时，再向更高层提。

---

# 3. WorkView shell 当前真实 supplier

## 3.1 FLOATING

已确认当前 exact supplier：

```text
huabu/apps/web/src/components/Common/CanvasFloatingPopover.tsx
```

当前能力：

- flow-space → screen-space
- body portal
- flip / shift
- viewport/panel overflow avoidance
- resize reposition
- canvas floating geometry owner

裁决：

```text
KEEP / DIRECT REUSE
```

禁止：

```text
new WorkViewFloatingGeometry
new FloatingPositionStore
```

---

## 3.2 DOCKED

当前 exact supplier：

```text
huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
```

已有：

- right panel slot
- width resize
- collapse
- animation
- panel persistence interaction
- center layout

裁决：

```text
KEEP / DIRECT REUSE
```

禁止：

```text
new WorkViewDock.tsx as geometry owner
react-resizable-panels as first path
new dock-width truth
```

---

## 3.3 IMMERSIVE

当前 supplier：

```text
MainLayout preview fullscreen mechanics
```

Camera recovery 已有源码链：

```text
canvasStore.viewport
→ useInitialCanvasViewport()
→ defaultViewport on Canvas remount
```

因此：

```text
Camera restore = EXISTING
```

T4 不新增 Camera restore。

但必须先做 runtime owner hoist，且浏览器验收：

- LCOS runtime still alive
- ProjectionBinding continuity
- Reference index continuity
- Selection continuity
- WorkView target continuity
- Escape / modal priority

裁决：

```text
KEEP MECHANICS
+ FIX OWNER LIFETIME
+ BROWSER PROOF
```

---

# 4. PreviewWorkspace 与 WorkView 的真实分工

当前：

```text
PreviewWorkspacePanel
```

只是 MainLayout right-panel 的薄 wrapper。

它接收：

```text
onToggle
isHostCollapsed
isFullscreen
onToggleFullscreen
```

并传给：

```text
PreviewWorkspace
```

PreviewWorkspace 自身拥有：

- tab/groups
- split
- transient/permanent preview
- DnD
- retained preview state

但 persistence 是：

```text
per-canvas
```

LCOS WorkView 冻结是：

```text
project / active UI session
cross Main / Context / Workflow / subcanvas
one dominant Work View
```

因此：

```text
PreviewWorkspace != WorkView canonical session owner
```

但是：

```text
MainLayout right-slot mechanics = shared
```

---

# 5. ExpandedNodePanel 的最新裁决

当前 exact role：

```text
PreviewRenderer
  ├── Chat target → ChatPanel
  └── Node target → ExpandedNodePanel
```

因此 `ExpandedNodePanel` 是：

```text
Preview body primitive
```

不是：

```text
parallel panel host
WorkView owner
```

可复用：

- embedded header behavior
- preview search
- connected-node navigation
- focus priority
- edit / close body behavior

禁止：

```text
再把 ExpandedNodePanel 包成 WorkView shell
```

---

# 6. WorkView presentation state 再砍一刀

旧模型：

```ts
type WorkViewMode =
  | 'spatial'
  | 'focus'
  | 'floating'
  | 'docked'
  | 'immersive'

interface WorkViewSession {
  sessionId
  projectId
  target
  mode
  origin
  dockWidth
}
```

问题：

- `dockWidth` 已由 MainLayout 拥有；
- `fullscreen` 已由 panelStore 拥有；
- Focus 已由 Canvas Camera/selection interaction 拥有；
- spatial 不是 WorkView 自己的 mode truth。

因此 T4 不再建议复制完整 mode state。

最薄候选：

```ts
interface WorkViewSession {
  readonly projectId: string
  readonly target: WorkViewTarget
  readonly body: WorkViewBodyKind
  readonly origin: SpatialReturnPoint
}
```

右侧是否显示：

```text
MainLayout / panelStore
```

是否 fullscreen：

```text
panelStore
```

floating：

```text
CanvasFloatingPopover presentation placement
```

---

# 7. one functional renderer state：不能用 generic unknown 垃圾桶解决

L0 冻结要求：

```text
one canonical target/truth
one functional renderer state
Docked / Immersive = same projection
```

这不意味着建立：

```ts
rendererState: unknown
```

放进 WorkViewStore。

正确策略：

1. 先跑真实 Dock ↔ Floating ↔ Immersive；
2. 哪个 body 存在 unsaved local state 丢失，再由该 body 自己持有；
3. Run Review 本身大多是 canonical read projection，不需要通用 draft；
4. Skill Builder 若存在未保存 draft，由 Skill Builder session 自己持有；
5. Assembly 浏览过滤/当前选择由 Assembly body 持有；
6. Context instrument viewport/selection 属各 instrument body。

禁止：

```text
WorkView Generic Renderer State Store
```

---

# 8. WorkView 右侧 host 最小形态

旧计划：

```text
WorkViewHost
WorkViewDock
WorkViewImmersive
WorkViewRendererRegistry
LcosRightSurfaceHost
```

新裁决：

只保留一个非常薄的：

```text
LcosRightSurfaceHost
```

职责：

```text
if active LCOS WorkView:
    render WorkView body
else:
    render PreviewWorkspacePanel
```

并接受 MainLayout 已注入的：

```text
onToggle
isHostCollapsed
isFullscreen
onToggleFullscreen
```

它不拥有：

- width
- fullscreen
- collapse
- tab persistence
- canonical target body
- Run/Skill/Context truth

它只是：

```text
right-slot content arbitration
```

---

# 9. WorkView session owner：优先 CanvasPage scoped React state/context

当前不建议：

```text
new global Zustand WorkViewStore
```

优先顺序：

```text
CanvasPage local reducer/state
→ only if non-adjacent LCOS triggers need it:
   CanvasPage-scoped React Context
```

理由：

- 生命周期正好覆盖 current project/canvas work session；
- 不进入 per-canvas PreviewWorkspace store；
- 不进入 app-global persistence；
- 切 child canvas / same route parameter 时可连续；
- CanvasPage unmount 结束当前 UI work session，符合当前冻结范围。

只有真实跨 CanvasPage lifecycle requirement 出现后，再往上 hoist。

---

# 10. web-gen2 typed client 当前缺口

当前 `apps/web-gen2/src/backend` 只有：

```text
artifacts.ts
client.ts
coreTypes.ts
projects.ts
relations.ts
search.ts
sqliteBindingStore.ts
```

缺：

- Run
- Assembly
- Context
- Skill
- Workflow

`Gen2Host` 当前刻意只组合：

```text
projects
artifacts
relations
search
projection/reconciliation
```

它不应扩成 Phase-C mega facade。

因此新增能力 client 应平行存在，而不是塞入 Gen2Host。

---

# 11. HttpClient 边界保持不动

当前：

```text
apps/web-gen2/src/backend/client.ts
```

明确：

```text
NEVER holds business state / selection / cache / UI mode
```

因此它继续只做：

- base URL
- auth
- JSON/text/blob
- error normalization
- AbortSignal

T4 新 client 只是：

```text
typed route methods around HttpClient
```

---

# 12. 新 client 候选

## 12.1 `apps/web-gen2/src/backend/assembly.ts`

只映射稳定能力：

```text
GET  /projects/:id/warehouse
POST /projects/:id/assembly/apply
```

类型直接复用：

```text
WarehouseQueryV1
WarehouseSnapshotV1
AssemblyApplyRequestV1
AssemblyApplyResultV1
```

不因后端文件叫 `f6-assembly.ts` 就建：

```text
F6AssemblyClient
```

历史施工批次名不能污染产品架构。

---

## 12.2 `apps/web-gen2/src/backend/runs.ts`

候选映射：

```text
GET  /projects/:id/runs
POST /projects/:id/runs
GET  /runs/:id/review
GET  /runs/:id/events?after=
POST /runs/:id/dispatch
POST /runs/:id/recover
POST /runs/:id/sync
POST /runs/:id/cancel
GET  /runs/:id/input-request
POST /runs/:id/input-request
GET  /runs/:id/recipe
```

ArtifactReturn decisions：

```text
POST /artifact-returns/:id/accept
POST /artifact-returns/:id/reject
POST /artifact-returns/:id/retry
```

可独立放：

```text
CoreRunClient
```

或非常薄的：

```text
CoreRuntimeReviewClient
```

最终按方法规模决定，不提前拆 manager/service。

---

## 12.3 `apps/web-gen2/src/backend/context.ts`

首先映射已有 ContextSnapshot：

```text
GET  /projects/:id/context-snapshots
POST /projects/:id/context-snapshots
POST /projects/:id/context-snapshots/:sid/compare
POST /projects/:id/context-snapshots/:sid/branch
```

Context Structure / Relationship 不重复造数据 API：

- structure 优先从已有 Project/Scope/Presentation truth；
- relationship 复用 CoreRelationClient；
- provenance 复用已有 artifact/resource/provenance read owner。

也就是说：

```text
CoreContextClient
```

主要是 Snapshot/Evolution 能力，不做“万能 Context API”。

---

## 12.4 `apps/web-gen2/src/backend/skills.ts`

当前 Core 已有：

```text
GET /projects/:id/skills
GET /projects/:id/skills/:skillId
Skill CRUD
update
version-bump
rename
install
disable
enable
Skill proposal / author routes
```

前端 client 应按现有 route 一一映射。

类型复用：

```text
SkillPackageV1
SkillCatalogEntryV1
SkillCatalogReadV1
SkillProposalV1
...
```

禁止复制：

```text
WebSkill
WorkViewSkillModel
LibTVSkillSchema
```

---

## 12.5 `apps/web-gen2/src/backend/workflow.ts`

当前 Core workflow route 主要：

```text
GET  /projects/:id/workflow/export
POST /projects/:id/workflow/import
```

真实执行仍走 Run。

因此：

```text
CoreWorkflowClient
```

只做 import/export 等 Workflow artifact mechanics。

不要把 Run methods 再复制一遍。

---

# 13. `apps/web-gen2/src/index.ts`

新增 client 后：

```text
只导出新 client + 必要 route types
```

不改：

```text
Gen2Host
```

不建：

```text
CoreWorkViewFacade
PhaseCFacade
WorkbenchMegaClient
```

---

# 14. Assembly 最新 ExactFile 方向

## KEEP

```text
apps/local-core/src/assembly-apply-service.ts
apps/local-core/src/routes/f6-assembly.ts
packages/contracts/src/assembly.ts
```

当前正确点：

- SourceRef/TargetRef typed
- canonical service routing
- placement 与 semantic membership 分层
- no mutation truth ownership

---

## ADD / WRAP

```text
apps/web-gen2/src/backend/assembly.ts
huabu/apps/web/src/lcos/assembly/AssemblyWorkViewBody.tsx
```

可能再加非常薄的：

```text
assemblySourceAdapter.ts
```

把：

```text
WarehouseEntity → AssemblySourceRefV1
```

显式转换。

---

## BODY SUPPLIERS

```text
react-virtuoso
existing dnd-kit
```

Lovart 只提供 morphology / interaction evidence。

---

## DO NOT ADD

```text
AssemblyStore as warehouse cache
AssemblyDatabase
AssemblySelectionTruth
second Drop framework
```

---

# 15. Skill → Assembly gap 的正式分类

当前 contract：

```text
AssemblySourceRefV1 includes kind:'skill'
```

说明：

```text
Skill Source identity = already canonicalized
```

但：

```text
AssemblyApplyService
skill source → unsupported
```

因此 GAP 是：

```text
canonical apply semantics missing
```

不是：

```text
frontend source modeling missing
```

这条必须交叉 T6 裁决：

- Skill dropped to Conversation = Reference?
- Skill dropped to Workflow = capability/reference?
- Skill dropped to Composer = ordered reference?
- Skill dropped to RunRecipe = dependency?

禁止 T4：

```text
SkillBinding
fake frontend apply
local-only success
```

---

# 16. Context donor ExactFile 方向

## Structure

Supplier：

```text
react-arborist 3.16.0
```

建议新增：

```text
huabu/apps/web/src/lcos/context/ContextStructureBody.tsx
apps/web-gen2/src/presentation/contextStructureProjection.ts
```

首版：

```text
disableDrag
disableDrop
```

只收：

- virtual tree
- selection
- expand/collapse
- filtering

避免内部 react-dnd 与 Huabu world DnD 冲突。

---

## Evolution

Supplier：

```text
vis-timeline 8.5.4
```

建议：

```text
huabu/apps/web/src/lcos/context/ContextEvolutionBody.tsx
apps/web-gen2/src/presentation/contextEvolutionProjection.ts
apps/web-gen2/src/backend/context.ts
```

Truth：

```text
ContextSnapshot
```

---

## Relationship

Supplier：

```text
Cytoscape.js stable 3.34.2
```

建议：

```text
huabu/apps/web/src/lcos/context/ContextRelationshipBody.tsx
apps/web-gen2/src/presentation/contextRelationshipProjection.ts
```

Truth：

```text
CoreRelationClient
```

不新增 relationship store。

---

## Source / Provenance

Supplier：

```text
native React / react-virtuoso
```

不新增大型 engine。

---

# 17. Skill Builder ExactFile 方向

Truth：

```text
SkillPackageService
SkillProposalService
SkillAuthorDispatchService
```

Bodies：

```text
SkillOutlineBody     → react-arborist
SkillMindMapBody     → Mind Elixir
```

共享：

```text
SkillBuilderProjection
```

候选：

```text
apps/web-gen2/src/presentation/skillBuilderProjection.ts
huabu/apps/web/src/lcos/skill/SkillBuilderWorkViewBody.tsx
huabu/apps/web/src/lcos/skill/SkillOutlineBody.tsx
huabu/apps/web/src/lcos/skill/SkillMindMapBody.tsx
apps/web-gen2/src/backend/skills.ts
```

---

# 18. Mind Elixir 必须是 sealed interaction island

Mind Elixir 自己有：

- drag
- editable
- context menu
- toolbar
- keyboard
- wheel
- pointer interactions

所以 wrapper 必须：

```text
明确 DOM focus boundary
内部快捷键不泄漏到 Canvas
内部 pointer 不触发 world recognizer
Esc 遵循 overlay/menu/editor priority
```

但不要因此新建全局 pointer framework。

---

# 19. LibTV Skill direct vendor 候选

许可证：

```text
MIT
```

结构：

```text
SKILL.md
scripts/
```

与 LCOS SkillPackage 天然兼容。

候选 direct vendor：

```text
packages/skills/libtv-skill/
```

要求：

- 保留 LICENSE / attribution；
- 原始 donor 文件尽量少改；
- LCOS-specific adaptation 放 wrapper/adapter；
- 不发明 LibTV-specific schema；
- provider credential / session integration 交 T6。

---

# 20. Workflow ExactFile 方向

Spatial Action Path：

```text
继续 Huabu Canvas / @xyflow/react
```

Run/Review：

```text
apps/web-gen2/src/backend/runs.ts
huabu/apps/web/src/lcos/workflow/RunReviewWorkViewBody.tsx
```

长事件/结果：

```text
react-virtuoso
```

禁止：

```text
second ReactFlow
BPMN engine
DAG execution truth
frontend Run event truth
```

---

# 21. WorkView 旧文件 KEEP / SHRINK / RETIRE

| 旧规划文件 | 新裁决 | 说明 |
|---|---|---|
| `apps/web-gen2/src/presentation/workViewModel.ts` | SHRINK / MAY MOVE TO HUABU-SCOPED CONTEXT | 不再保存 mode/dockWidth |
| `apps/web-gen2/src/presentation/workViewRegistry.ts` | RETIRE | explicit body resolver enough |
| `huabu/apps/web/src/lcos/workview/workViewStore.ts` | RETIRE | 不建 global Zustand |
| `WorkViewHost.tsx` | RETIRE / MERGE | 宿主能力由 CanvasPage + LcosRightSurfaceHost |
| `WorkViewFocusLayer.tsx` | RETIRE | Focus/Camera existing |
| `WorkViewDock.tsx` | RETIRE | MainLayout right slot existing |
| `WorkViewImmersive.tsx` | RETIRE | MainLayout fullscreen mechanics existing |
| `WorkViewRendererRegistry.tsx` | RETIRE | 不建 giant registry |
| `safeRegion.ts` | RETIRE AS OWNER | 只能有 rect signal adapter，不建 truth |
| `lcos-seam/shellTypes.ts` | RETIRE unless exact seam need proven | 不为 LCOS shell 扩中立 canvas seam |
| `LcosRightSurfaceHost.tsx` | KEEP / SHRINK HARD | 只做 right-slot mux |
| `MainLayout.tsx#thin-rect-policy` | DEFER TO T1 CROSS-TRACE | 不由 T4 自造 safe-area |
| `CanvasPage.tsx#right-host` | KEEP / MODIFY | runtime lifecycle + right mux |
| `CenterArea.tsx#safe-rect` | RETIRE | CenterArea 不做 safe-area owner |

---

# 22. 第一阶段最小 ExactFile 候选

## MODIFY

```text
huabu/apps/web/src/pages/CanvasPage/CanvasPage.tsx
huabu/apps/web/src/pages/CanvasPage/CenterArea.tsx
apps/web-gen2/src/index.ts
```

### `CanvasPage.tsx`

- 把 `useLcosCanvasProps(projectId)` invocation 从 CenterArea 提到这里；
- 保证 fullscreen 时 runtime 不 dispose；
- 挂 thin WorkView session owner；
- 把 rightPanel 换成 `LcosRightSurfaceHost`；
- 不改 MainLayout geometry。

### `CenterArea.tsx`

- 删除内部 runtime hook ownership；
- 从 props 接收 stable hostExtension；
- Canvas 本身行为不变。

### `apps/web-gen2/src/index.ts`

- 导出新增 small clients；
- Gen2Host 不扩。

---

## ADD

```text
huabu/apps/web/src/lcos/LcosRightSurfaceHost.tsx
huabu/apps/web/src/lcos/workview/workViewSession.tsx   # scoped context/reducer, only if callbacks require non-adjacent access
apps/web-gen2/src/backend/assembly.ts
apps/web-gen2/src/backend/runs.ts
apps/web-gen2/src/backend/context.ts
apps/web-gen2/src/backend/skills.ts
apps/web-gen2/src/backend/workflow.ts
```

注意：

`workViewSession.tsx` 不预设一定新增。

施工前先尝试：

```text
CanvasPage local state + direct props
```

只有 Action Arc / non-adjacent consumers 真正需要调用时，再加 CanvasPage-scoped Context。

---

## NO MODIFY FIRST

```text
huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
huabu/apps/web/src/store/panelStore.ts
huabu/apps/web/src/store/canvasStore.ts
huabu/apps/web/src/components/Common/CanvasFloatingPopover.tsx
huabu/apps/web/src/store/previewWorkspace/*
apps/web-gen2/src/host/projectionFacade.ts
apps/local-core/src/*
```

这是这一轮最重要的减法。

---

# 23. 为什么 panelStore 暂时不改

当前已经有：

```text
isRightCollapsed
isPreviewFullscreen
toggleRightPanel
setPreviewFullscreen
togglePreviewFullscreen
```

虽然命名是 `Preview`，但命名不漂亮不是具体失败。

没有必要现在为了“语义整洁”做全仓 rename：

```text
isRightSurfaceFullscreen
```

先复用 existing actions。

只有未来出现：

```text
Preview 与 WorkView 必须同时拥有独立 fullscreen state
```

才证明需要改 owner。

当前 one dominant right Work Layer 并不要求。

---

# 24. 为什么 MainLayout 暂时不改

因为当前它已经能：

- right slot resize
- collapse
- fullscreen
- motion
- restore center
- inject props into right panel

`LcosRightSurfaceHost` 可直接成为：

```text
rightPanel
```

如果这条真实接线能通过：

```text
MainLayout.tsx = NO MODIFY
```

这会比旧计划小很多。

---

# 25. occupied rect / activeSpatialViewport 的责任

L0 原文要求：

```text
Work View publishes occupied rect
activeSpatialViewport consumes it
```

但当前 main 源码里，原文点名的历史 anchor：

```text
spatialOverlayEnvironment.ts
fitSpatialBounds
CanvasMiniMap.safeInsets
edgeScrollDelta
```

并不能全部在当前 T4 source trace 中确认。

因此第四路不能写：

```text
新增 safeRegion.ts
然后让所有 HUD 来读它
```

正确 cross-thread 边界：

```text
T4:
publish current WorkView occupied rect signal

T1:
identify current geometry/HUD/navigation owner
consume rect into existing active spatial viewport path
```

在 T1 current exact path 没确认前：

```text
T4 DOES NOT OWN activeSpatialViewport
```

---

# 26. 浏览器级必须测的具体场景

这些是因为真实 unmount / event ownership / donor coexistence 会出错，普通 unit/typecheck 不足。

## WorkView

```text
1. Open target → Floating
2. Floating → Dock
3. resize dock，camera transform不变
4. Dock → Immersive
5. Immersive期间 runtime 未 dispose
6. Escape → restore
7. target / body state still same
8. PreviewWorkspace state resumes after WorkView close
9. switch child canvas / Surface → WorkView remains
```

## IMMERSIVE

特别断言：

```text
reconciler still live
ProjectionBinding still resolves
Reference index still resolves
Camera restored from canvasStore
```

## Arborist

```text
disableDrag/disableDrop
tree selection works
canvas DnD still works outside
pointer capture no leak
```

## Mind Elixir

```text
wheel inside mindmap != canvas zoom
drag inside mindmap != canvas drag
keyboard edit != canvas shortcut
context menu != canvas context action
Escape priority correct
```

---

# 27. 当前不新增任何 gate/hash/baseline

本轮没有理由新增。

唯一强制行为是：

```text
真实 browser execution / measurement
```

因为：

- React component unmount lifecycle；
- pointer/event propagation；
- independent DnD backend coexistence；
- viewport restore；

这些具体失败不是 Git/version/type/unit test 单独能证明的。

这不是“加门禁”，而是对真实 runtime behavior 做验收。

---

# 28. 当前状态

```text
WorkView shell supplier trace:
HIGH CONFIDENCE

runtime owner bug:
CONFIRMED

right-slot mux feasibility:
HIGH CONFIDENCE

Core typed port gap:
CONFIRMED

Assembly truth boundary:
HIGH CONFIDENCE

Skill→Assembly semantic gap:
CONFIRMED / CROSS-T6

Context donors:
HIGH CONFIDENCE, wrapper API still to audit

Skill donors:
HIGH CONFIDENCE, interaction isolation still to prototype

activeSpatialViewport exact current owner:
CROSS-T1 UNRESOLVED

FINAL T4 EXACTFILE CONSTRUCTION PLAN:
NOT YET LOCKED
```

---

# 29. 下一轮继续深挖

继续做：

```text
A. CoreAssemblyClient exact method table
B. CoreRunClient exact method/contract table
C. CoreContextClient snapshot types + projection
D. CoreSkillClient CRUD/proposal/author exact table
E. donor wrapper API / CSS / lifecycle audit
F. CanvasPage runtime-hoist test design
G. LcosRightSurfaceHost no-MainLayout-change proof
H. T1 occupied-rect handoff table
I. T6 Skill apply/provider handoff table
```

最终再收成：

```text
Exact File
→ Symbol
→ Current Owner
→ Supplier
→ Action
→ Files NOT Touched
→ Test
→ Failure Blast Radius
→ Cross-thread dependency
```

才进入第四路施工正本。
