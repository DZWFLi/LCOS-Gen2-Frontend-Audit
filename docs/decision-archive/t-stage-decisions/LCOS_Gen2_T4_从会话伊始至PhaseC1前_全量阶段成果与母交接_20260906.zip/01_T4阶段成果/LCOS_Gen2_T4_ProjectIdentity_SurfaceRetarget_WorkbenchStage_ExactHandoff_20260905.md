# LCOS Gen2 · T4 第四路
## Project Identity → Surface Retarget → Professional Workbench Stage · Exact Handoff

日期：2026-09-05  
源码锚点：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`

状态：
```text
SOURCE-LEVEL PREPLAN
EXACT HANDOFF / OWNER BOUNDARY
NOT FINAL CONSTRUCTION PLAN
NO PRODUCTION PATCH AUTHORIZED
```

## 0. 本轮核心纠偏

此前 `Project identity / Project Launcher incomplete` 太粗。current source 应拆为：

```text
CORE PROJECT IDENTITY / CATALOG      FOUND_CURRENT
CORE PROJECT CREATE / OPEN ROUTES    FOUND_CURRENT
CORE PROJECT SUMMARY                 FOUND_CURRENT
CORE PROJECT VISUAL PROFILE          FOUND_CURRENT

WEB-GEN2 PROJECT READ CLIENT         FOUND_PARTIAL
SURFACE REGISTRY CONTRACT            FOUND_CURRENT
SURFACE REGISTRY PRODUCT CONSUMER    NOT WIRED

HUABU ACTIVE PROJECT SESSION         NOT WIRED
HUABU PROJECT LAUNCHER               NOT WIRED
CENTERAREA PROJECT_ID ENV FALLBACK   TEMPORARY BRIDGE / MUST RETIRE
```

真正缺口不是再造 Project 模型，而是把已经存在的 Core Project identity 接成 Huabu Active Project Session 的唯一 producer。

---

## 1. Core Project truth 已存在

### Project Catalog
`apps/local-core/src/project-catalog.ts`

已有 `ProjectCatalog` / `ProjectCatalogEntry`，返回 id/name/rootPath/graphVersion，duplicate id fail-close。

裁决：
```text
KEEP
NO ProjectCatalogV2
NO frontend ProjectIdentityStore truth
```

### Project Routes
`apps/local-core/src/routes/projects.ts`

已有：
```text
GET    /projects
POST   /projects
DELETE /projects/:id
GET    /projects/:id/graph
PUT    /projects/:id/graph
POST   /projects/:id/graph
GET/PUT /projects/:id/view-rail-order
```

`POST /projects` 已处理 create/open intent、root validation、canonical projectId、metadata persistence、lastOpenedAt、optional indexing。

Launcher 不得自己生成 projectId。

### Project Summary
`apps/local-core/src/project-summary-service.ts`

源码已明确：`ProjectSummary——Launcher 的项目卡片数据源`，pure read projection，zero new table。

字段：
```text
projectId
name
objectCount
objectCountDetail
lastMeaningfulEditedAt?
```

objectCount 当前为 artifacts + notes + resources。内部 row/revision/runtime event/conversation 不计。

Launcher 直接消费，前端不重新统计。

### Project Visual Profile
`apps/local-core/src/routes/f6-assembly.ts`

已有：
```text
GET /projects/:id/visual-profile
PUT /projects/:id/visual-profile
```

presentation-only + CAS，已有 tint / glyth mark repertoire。

因此最新 Launcher 的 Tinted Liquid Glass Project Portal / Floating Project Glyth Mark 有现成 Core-backed projection，不得 localStorage 冒充 truth。

---

## 2. web-gen2 Project client：有，但只接了 G0

`apps/web-gen2/src/backend/projects.ts`

已有：
```ts
CoreProjectClient.listProjects()
CoreProjectClient.getProjectGraph(projectId)
```

所以后续应 `EXTEND EXISTING CoreProjectClient`，不要新增 ProjectLauncherClient / ProjectApiV2 / ProjectManagerClient。

薄扩展候选：
```ts
getProjectSummary(projectId)
getProjectVisualProfile(projectId)
createOrOpenProject(input)
```

是否同阶段接 delete/updateVisualProfile 由 Launcher 施工单决定。

HTTP client 仍只做 transport，不保存 active project/business cache。

---

## 3. Huabu workspaceId 绝不能冒充 LCOS projectId

`huabu/apps/web/src/store/workspaceStore.ts` 中 workspaceId 的语义是 Huabu filesystem/workspace identity、canvas list、workspace activation、World canvas。

明确禁止：
```ts
projectId = workspaceId
projectId = canvasId
projectId = worldCanvasId
```

ID 都是 string 不是理由。字符串这种东西看起来都一样，语义可完全不同。

---

## 4. CenterArea 的 env Project 必须退出 production owner

current `CenterArea.tsx` 仍然：
```ts
const lcosProjectId =
  import.meta.env.PROJECT_ID
  ?? 'disposable-mvp-sample'

useLcosCanvasProps(lcosProjectId)
```

只能视为 Phase A/G0 bridge。

RETIRE：
```text
import.meta.env.PROJECT_ID as production selector
'disposable-mvp-sample' as normal runtime fallback
CenterArea owning ProjectSession runtime creation
```

---

## 5. ProjectSession 最小输入 contract

Router exact URL 目前没有被 latest freeze/current source 锁死，因此 T4 不擅自发明 `/projects/:projectId/main`，也不把当前 `/canvas/:canvasId` 升格为 product Project route。

只冻结：
```ts
interface ActiveProjectSessionInput {
  projectId: string
  surface: 'main' | 'context' | 'workflow'
}
```

`projectId` = Core canonical Project id。  
`surface` = LCOS product Surface key。  
`canvasId` 不由 Launcher 猜。

---

## 6. canvasId 唯一解析路径

```text
ActiveProjectSessionInput
       │
       ├─ projectId
       └─ surfaceKey
              │
              ▼
      SurfaceRegistry.current(surfaceKey)
              │
              ▼
           canvasId
```

生产 consumer 禁止字符串硬拼 `${projectId}-main-canvas`。

---

## 7. SurfaceRegistry 已成熟，不再造 SurfaceManager

current：
```text
apps/web-gen2/src/spatial/surfacePort.ts
apps/web-gen2/test/surfacePort.test.ts
```

已证明：
```text
same project
main/context/workflow
distinct canvasId
one runtime family
surface collision fail-close
same artifact can project across surfaces
```

当前状态：
```text
CONTRACT       FOUND_CURRENT
UNIT TEST      FOUND_CURRENT
PRODUCT CONSUMER MISSING
```

后续是 WIRE，不是设计新 Surface 系统。

---

## 8. ProjectSession Provider 正确 owner

当前错误层级：
```text
CenterArea
└─ useLcosCanvasProps(projectId)
   └─ runtime
```

CenterArea/Canvas subtree 可因 route / presentation / Surface navigation 卸载，而 hook cleanup 会 runtime.dispose()。

正确概念结构：
```text
Active Project Shell
└─ LcosProjectSessionProvider(projectId)
   ├─ ONE LCOS runtime object
   ├─ ONE SurfaceRegistry
   ├─ ONE stable hostExtension/seam
   ├─ ONE ProfessionalWorkbench manager
   └─ Protected Canvas host
      └─ current Surface canvas
```

RootLayout 是 never-unmounting shell，但 Setup/Launcher/playground 没有 active project，因此不要全局强行常驻 Project runtime。

应是：
```text
RootLayout page-area
├─ non-project routes → no LCOS runtime
└─ ActiveProjectShell
   └─ LcosProjectSessionProvider(projectId)
      └─ ProfessionalWorkbenchStage
```

具体 route shape 仍标 `OPEN`。

---

## 9. Surface 切换 exact state machine

Main → Context：

```text
1. active surfaceKey = context
2. SurfaceRegistry.current('context')
3. resolve context canvasId
4. Huabu loadCanvas/switchCanvas(canvasId)
5. wait:
   store.canvasId === expectedCanvasId
   && isLoading === false
6. runtime.retarget({canvasId})
7. reconcile current host projection
8. refresh ProjectionBinding-derived reference cache
9. Workbench remains mounted
10. professional panels remain unless target invalid
```

---

## 10. current retarget 的真实成本

`createLcosHostRuntime.ts` 当前 `retarget({canvasId})` 会：
```text
disposeHost(oldHost)
build(new host for new canvas)
```

所以：
```text
runtime object stable
host object changes
```

current test 也明确验证 canvas retarget 会 rebuild host once + dispose old reconciler once。

这不是 T4 必须顺手重构的问题。

产品连续性要求的是：
```text
ProjectSession
stable seam/hostExtension
Workbench panels
canonical refs
body local state
```

不是 JavaScript host object identity。

---

## 11. stable hostExtension 直接 LIFT current mature pattern

current `useLcosCanvasProps`：
```ts
createHostSeam(() => rt.host, ...)
```

seam getter 总是读取 runtime 当前 host。

因此：
```text
same seam
same hostExtension
retarget can swap underlying host
```

ADOPT：
```text
lift current seam/runtime mechanics upward into ProjectSessionProvider
```

禁止每 Surface 再造 hostExtension。

---

## 12. Reconcile trigger current fact

current：
```text
'project-open' | 'mutation' | 'reconnect' | 'periodic'
```

没有 `surface-open`。

current canvas ready/retarget 后调用：
```ts
rt.host.reconcile('project-open')
```

T4 第一阶段 KEEP 现有 trigger contract，不自行增加 surface-open/workview-open/dock-open。

记录 semantic debt：
> 同 Project Surface retarget 当前复用 `project-open` 名称，命名不精确但不阻塞。

---

## 13. 防重复 reconcile

只在 ready canvas transition 上做一次：
```text
expectedCanvasId changed
→ Huabu loads
→ actual canvas matches
→ isLoading false
→ retarget/reconcile once
```

不能 surfaceKey effect + canvasId effect + panel mount 各来一次。

可用本地 effect 去重 ref：
```text
lastReconciledTarget = {projectId, canvasId}
```
它不是 business truth。

---

## 14. Project change 与 Surface change 分离

Surface change：
```text
same projectId
different canvasId
same ProjectSession
same Workbench
runtime.retarget(canvasId)
```

Project change：
```text
different projectId
dispose old ProjectSession/runtime
drop old Workbench presentation session
create new SurfaceRegistry/runtime
```

虽然 runtime API 支持 projectId retarget，产品 ProjectSession boundary不应继续携带 Project A 的 Workbench panels。

---

## 15. Workbench 与 Surface 解耦

V2 后：
```text
Surface != Workbench layout
```

Main → Context 不能默认关闭 Project-global Assembly / Conversation Preview / Run Review。

只有 target 本身失效的 region 才关闭或进入 unavailable state。

Protected Canvas panel id保持：
```text
lcos:spatial-canvas
```

Surface switch 只换内部 Huabu canvasId。

---

## 16. Router current fact / OPEN item

current Huabu route：
```text
/canvas/:canvasId
```

它只表达 Huabu canvas，不包含 Core projectId / SurfaceKey。

因此 deep reload 仅凭当前 URL 无法完整恢复 LCOS Product Session。

状态：
```text
PRODUCT ROUTER CONTRACT = OPEN / NAVIGATION THREAD DEPENDENCY
```

T4 不发明 URL，但总施工必须保证：
> deep-link/reload 能恢复 canonical projectId + active Surface，不能依赖 env 或 ephemeral router state。

---

## 17. Project Launcher → ProjectSession 最小 handoff

Launcher：
```text
list Core projects
show Project Summary
show Visual Profile
create/open via Core
select canonical projectId
```

Launcher 不负责：
```text
string-guess Surface canvasIds
create LCOS runtime
create Workbench
duplicate Project graph cache
```

进入项目后交给 ActiveProjectShell/LcosProjectSessionProvider。

---

## 18. Exact file action table

| File | Action | Reason |
|---|---|---|
| `apps/local-core/src/project-catalog.ts` | KEEP / NO TOUCH | canonical catalog exists |
| `apps/local-core/src/project-summary-service.ts` | KEEP / NO TOUCH | Launcher summary exists |
| `apps/local-core/src/routes/projects.ts` | KEEP / NO TOUCH from T4 | canonical routes exist |
| `apps/local-core/src/routes/f6-assembly.ts` | KEEP / NO TOUCH from T4 | summary/profile routes exist |
| `apps/web-gen2/src/backend/projects.ts` | MODIFY THINLY | extend existing Project client |
| `apps/web-gen2/src/index.ts` | MODIFY | export thin additions |
| `apps/web-gen2/test/core-clients.test.ts` | MODIFY | typed contract coverage |
| `apps/web-gen2/src/spatial/surfacePort.ts` | KEEP | mature pure contract |
| `apps/web-gen2/test/surfacePort.test.ts` | KEEP | unit semantics solid |
| `apps/web-gen2/src/host/createLcosHostRuntime.ts` | KEEP for T4 | current retarget tested |
| `apps/web-gen2/src/host/lifecycleReconciler.ts` | KEEP for T4 | no invented trigger |
| `huabu/apps/web/src/lcos/useLcosCanvasProps.tsx` | RETIRE AS OWNER / LIFT LOGIC | move runtime lifetime up |
| `huabu/apps/web/src/pages/CanvasPage/CenterArea.tsx` | MODIFY | consume stable hostExtension |
| `huabu/apps/web/src/pages/CanvasPage/CanvasPage.tsx` | MODIFY | surface/canvas readiness handoff |
| `huabu/apps/web/src/App.tsx` | MODIFY CANDIDATE | ActiveProjectShell once router freezes |
| `huabu/apps/web/src/lcos/session/LcosProjectSessionProvider.tsx` | ADD CANDIDATE | project-scoped lifecycle coordinator |
| `huabu/apps/web/src/lcos/workbench/ProfessionalWorkbenchStage.tsx` | ADD CANDIDATE | N-region presentation |
| `huabu/apps/web/src/lcos/workbench/ProtectedCanvasPanel.tsx` | ADD CANDIDATE | stable canvas host |
| `huabu/apps/web/src/store/workspaceStore.ts` | NO SEMANTIC REUSE | workspaceId != projectId |

---

## 19. Provider candidate API

```ts
interface LcosProjectSessionValue {
  projectId: string
  surface: SurfaceKeyName
  surfaceRegistry: SurfaceRegistry
  hostExtension?: CanvasHostExtension

  activateSurface(surface: SurfaceKeyName): void
  openProfessionalRegion(descriptor: ProfessionalRegionDescriptor): void
}
```

这只是 lifecycle/UI coordinator API，不是新 Domain contract。

Provider绝不能吞进：
```text
ProjectGraph duplicate cache
Artifact repository
Context history
Workflow engine
Run truth
Assembly warehouse truth
Skill binding truth
Camera
Node geometry
Dockview JSON as Core truth
```

---

## 20. 推荐施工顺序

```text
P0  Extend existing CoreProjectClient only as needed
P1  Project Launcher consumes current Core Project routes
P2  Create ActiveProjectShell / LcosProjectSessionProvider
    move runtime/seam ownership out of CenterArea
P3  Wire SurfaceRegistry product consumer
P4  Protected Canvas + ProfessionalWorkbenchStage prototype
P5  Wire professional bodies
P6  Apply final router/deep-link contract from navigation thread
```

不能先把 Dockview 窗户搭满，再让窗户猜项目是谁。

---

## 21. Acceptance matrix

```text
Project identity:
GET /projects → choose A
ProjectSession.projectId === A.id
workspaceId !== projectId
canvasId !== projectId

Project change:
A → B
old runtime disposed exactly once
old Workbench session removed
new session projectId === B

Surface switch:
A/Main → A/Context
projectId unchanged
canvasId changed
Workbench unchanged

Surface collision:
two surfaces same canvasId
→ fail closed

Runtime:
same {projectId,canvasId} → no rebuild
same project/new canvasId → one host rebuild
new project → new ProjectSession

Reconcile:
one ready canvas transition → one reconcile

Workbench continuity:
Assembly open
Main → Context → Workflow
Assembly region retained
canonical truth unchanged

Deep reload:
restore projectId + Surface
never normal-fallback to disposable-mvp-sample
```

---

## 22. RED / YELLOW / GREEN after this round

```text
GREEN
- Core Project identity/catalog
- Project list/create/open
- Project Summary
- Project Visual Profile
- web-gen2 listProjects/getProjectGraph
- SurfaceRegistry contract/tests
- runtime retarget lifecycle
- stable seam provider pattern

YELLOW
- CoreProjectClient summary/profile/create/open typed adoption
- Surface retarget still named 'project-open' reconcile
- canvas retarget rebuilds internal host (allowed but must be understood)

RED
- Huabu Product Project Launcher
- Active Project Session producer
- SurfaceRegistry real product consumer
- project-aware deep-link/reload
- env PROJECT_ID retirement
```

---

## 23. 责任边界

```text
Core
= Project 是谁

Project Launcher
= 用户选哪个 Project

ProjectSession
= 这个 Project 当前活着的一次前端工作会话

SurfaceRegistry
= Main / Context / Workflow 分别去哪张 Huabu canvas

Huabu
= 那张 canvas 的空间事实

ProfessionalWorkbench
= 当前 Project session 开着哪些 screen-space 专业工作区
```

一层都不能偷偷代替另一层。

---

## 24. 本轮一句话

> **Project 已经在 Core 里存在了；缺的是把它真正接进前端会话。SurfaceRegistry 已经存在了；缺的是让产品导航真正消费它。**

所以两个看起来像“大功能没做”的问题，已经收敛成两条 consumer wiring：

```text
Core Project → ActiveProjectSession
SurfaceRegistry → Huabu canvas retarget
```

这才符合 Gen2 的 donor-first / thin increment 原则。
