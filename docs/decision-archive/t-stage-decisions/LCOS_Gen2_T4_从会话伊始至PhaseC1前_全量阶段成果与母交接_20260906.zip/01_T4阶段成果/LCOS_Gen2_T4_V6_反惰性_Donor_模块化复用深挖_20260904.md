# LCOS Gen2 · T4 第四路
## V6 反惰性更新 × Donor 深挖 × 模块化直接复用审计
### Unified Work View / Assembly / Context / Workflow / Skill

日期：2026-09-04  
状态：`DEEP_AUDIT_IN_PROGRESS / ARCHITECTURE_DIRECTION_CANDIDATE`  
不是最终施工正本；最终源码级施工计划仍受 V6 五轮以上审计与 Completion Table 约束。

---

# 0. 结论

这轮资料补齐后，T4 的方向已经发生一个很重要的收敛：

> **Gen2 不应该继续为 WorkView / Assembly / Context / Workflow / Skill 各自造一套“LCOS 专用工作台”。**
>
> 更合理的架构是：
>
> **Core 保持 canonical truth → Huabu 保持 spatial/placement mechanics → T4 只增加很薄的 project-session semantic layer → 各专业工作视图通过可替换 donor body/adapters 接入。**

这里的“模块化”不是多建几个 `store / registry / manager / framework` 文件。

V6 已明确要求：

> 模块化的目标是 **缩小失败爆炸半径**。

也就是说：

- WorkView 做坏了，只换 WorkView host/placement/chrome；
- Context Timeline donor 做坏了，只换 Timeline adapter/body；
- Skill Mind Map donor 做坏了，只换 Mind Map body；
- Assembly Source Bay 做坏了，不碰 Warehouse/Core truth；
- LibTV provider/skill donor 做坏了，不污染 LCOS canonical Run/Session identity。

这轮最重要的成果不是“又找到几个库”，而是已经能明确删掉旧规划里一批本来准备自造的层。

---

# 1. 前一轮 blocker 状态

上一轮 T4 因 9 份 Mandatory raw original 缺失停在 Round 1。

本轮 `Library补充(2).zip` + File Library recovery 已基本关闭这个 blocker：

已恢复：

1. `LCOS_v015_原文到后续施工计划_差分审计_20260831.md`
2. `LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md`
3. `LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md`
4. `LCOS_v0.15_R3D_SkillArtifact_SkillBuilder_CrossSurface_Freeze_20260830.md`
5. `LCOS_v015_Context_Workflow_Component_CameraFocus_审判与收敛_20260831.md`
6. `LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md`
7. `LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md`
8. `LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md`
9. `LCOS_三大视图组件体系筛选表_v01_20260821.md`

因此：

```text
OLD BLOCKER = CLOSED
```

但 V6 要求重新建立 Mandatory Completion Table，因此当前仍不能把“原文已找到”直接写成“最终五轮审计完成”。

---

# 2. V6 对 T4 最重要的新法条

## 2.1 Spatial 情报版本

当前：

```text
Spatial v3 = SUPERSEDED_BY_V4
Spatial v4 = CURRENT
```

Spatial v4 新增：

- AX runtime/window evidence
- symbols
- data model
- sqlite/model evidence
- recordings
- MD6 spatial interactions

因此 T4 后续引用 Spatial 只能以 v4 为当前证据。

同时必须避免一个常见错误：

> 不能因为 LCOS 自己叫 Minimap / EdgePin / Beacon / Locator，就反向把这些词投射到 Spatial 产品上。

Spatial 只作为：

- 行为证据；
- UI morphology；
- 交互组织；
- spatial → focus；
- capture/import → canvas；
- stable layout；

而不是 LCOS 术语的“来源证明”。

---

## 2.2 LibTV 有一个真正的 Direct-Use 例外

V6 明确区分：

### `libtv-skills`

```text
libtv-skills/libtv-skills-main/
```

许可证：

```text
MIT
```

因此它不是只能“看行为”的 proprietary evidence，而是：

```text
DIRECT IMPLEMENTATION DONOR CANDIDATE
```

必须深读：

- `LICENSE`
- `README.md`
- `skills/libtv-skill/SKILL.md`
- `_common.py`
- `create_session.py`
- `query_session.py`
- `change_project.py`
- `upload_file.py`
- `download_results.py`

### LibTV product bundle

`inflated/*.js`

仍然属于：

```text
PROPRIETARY BUNDLE EVIDENCE
```

这里只能：

- 做 wheel provenance census；
- 找 ReactFlow / Radix / AntD / Zustand / Leva 等上游来源；
- 再去官方 OSS upstream 核；
- 不能直接 copy bundle。

---

## 2.3 模块化 = failure blast radius

V6 P14/P15 的实际意思：

每个未来施工项都必须回答：

```text
Canonical Owner
Current Consumer
Adopted Supplier
Files Touched
Files NOT Touched
Replacement Boundary
Maximum Failure Blast Radius
Recovery / Rollback
Evidence Level
```

因此“组件化”不再是：

```text
WorkViewStore
WorkViewManager
WorkViewRegistry
WorkViewFramework
...
```

而是：

```text
当 donor 或 body 被替换时，
Core / Spatial / Project identity / Run truth 是否完全不需要动？
```

如果答案是否定的，说明模块边界设计失败。

---

## 2.4 V6 明确 DON'T BUILD

T4 相关禁止项：

- 第二套 Project truth
- 第二套 Surface truth
- 第二套 Projection truth
- 第二套 Canvas geometry
- 第二套 Selection
- 第二套 Drop framework
- 自研 dock/split/fullscreen framework
- 第二套 Run truth
- 第二套 Conversation truth
- 第二套 Preview host
- 第二套 Search taxonomy
- WorkView-owned Camera
- Assembly 第二 Warehouse
- Skill-specific Binding
- Context 自研 Tree/Timeline/Graph engine（在 donor census 之前）
- Workflow BPMN/DAG execution engine

---

# 3. 当前 GitHub 动态基线

当前 LCOS：

```text
DZWFLi/LCOS_Gen2
main =
c2ff890a867922a1256572199458438572eb0a8c
```

当前 vendored Huabu pin：

```text
58339e269b784728d67730c70bfe7792cae2457d
```

Huabu upstream：

```text
microsoft/Huabu
main =
dc128fff2d37b5481ec305070a7e86d3de85f7d2
```

比较：

```text
upstream ahead_by = 19
behind_by = 0
```

其中已经确认与 T4 有直接关系的 upstream delta：

- Cross-Space Move
- MoveSelectionModal
- `space-move-plan`
- `space-move.service`
- `space-move` shared schema
- Space ownership / storage alignment
- Preview Workspace related changes

---

# 4. Current Source Trace：WorkView

---

## 4.1 当前页面结构已经天然是 sibling slots

当前 Huabu：

```text
CanvasPage
└── MainLayout
    ├── leftPanel
    ├── center Canvas
    └── right PreviewWorkspace
```

这很关键。

意味着 LCOS 没必要先造：

```text
LcosDockFramework
WorkViewLayoutEngine
WorkViewSplitManager
```

MainLayout 已经提供成熟的：

- 左右 panel slot
- resize
- collapse
- right panel motion
- fullscreen preview
- restore
- center canvas layout

---

## 4.2 PreviewWorkspace 已经白送了一整套 tab/split mechanics

当前 PreviewWorkspace 的 pure model 已经有：

- PreviewTarget
- transient/permanent tab
- 单 target 唯一 tab
- activate
- close
- move
- open-to-side
- 两组 split
- deterministic activation order
- split ratio

当前 UI 已经：

- 使用 `dnd-kit`
- tab drag
- keyboard drag
- pointer separator resize
- keyboard separator resize
- ratio clamp 20–80%

所以：

```text
react-resizable-panels
```

至少不应该作为 T4 WorkView/Assembly 一级布局的默认新依赖。

旧 donor census 中它的优先级应明显下降。

---

## 4.3 但 PreviewWorkspace store 不能直接升格成 WorkView truth

当前 PreviewWorkspace persistence 明确：

```text
per Canvas
readWorkspace(canvasId)
writeWorkspace(canvasId)
```

而 LCOS 冻结 WorkView 是：

```text
project-session owner
cross Main / Context / Workflow
same target/session continuity
```

因此正确复用方式：

```text
REUSE:
- pure topology
- tab mechanics
- split mechanics
- resize mechanics
- DnD mechanics

DO NOT REUSE AS CANONICAL OWNER:
- per-canvas persistence
- node/chat-only PreviewTarget identity
```

也就是：

> 复用机械，不继承错误责任。

---

# 5. WorkView project-session owner：不新建全局状态怪兽

当前 LCOS 已经有：

```text
createLcosRuntime()
createLcosHostRuntime()
```

并且当前生产路径已经遵守：

```text
ONE Gen2HostRuntime per project session
```

问题是：

当前这个 runtime 的 React lifecycle 仍挂在：

```text
CenterArea
└── useLcosCanvasProps(projectId)
```

因此 right-panel sibling WorkView 并不能天然共享这个 owner。

而 Huabu `App.tsx` 已经有一个非常适合的生命周期位置：

```text
RootLayout
```

它设计上就是：

```text
never-unmounting app/router root
```

这给 T4 一个明显更薄的方向：

## 候选

把当前已经存在的：

```text
createLcosRuntime
```

**hoist 到 project/session-level provider/controller**。

不是新建：

```text
GlobalWorkViewStore
GlobalSessionRegistry
GlobalProjectManager
```

而是：

```text
把已经正确存在的 owner 放到正确生命周期层级
```

然后：

```text
CenterArea
Preview/WorkView right slot
Context
Workflow
Assembly
Skill Builder
```

都消费同一个 project-session owner。

---

# 6. 建议的 WorkView 极薄状态

不要从旧计划继续扩：

```text
WorkViewStore
WorkViewRegistry
WorkViewManager
WorkViewRendererRegistry
```

建议把 WorkView 自己拥有的状态压缩为纯 feature state：

```ts
type WorkViewTarget = ...
type WorkViewMode =
  | 'floating'
  | 'docked'
  | 'immersive'

type WorkViewSession = {
  target
  body
  mode
  restoreAnchor?
}
```

其中：

- target 指向 existing Core identifier；
- body 是 presentation choice；
- mode 是 placement；
- restoreAnchor 只恢复 presentation/session continuity。

绝不存：

- Artifact body truth
- Run truth
- Context snapshot truth
- Relation truth
- Skill package truth
- Warehouse truth
- Canvas camera truth

---

# 7. WorkView lifecycle 应该由现成 mechanics 拼出来

冻结生命周期：

```text
SPATIAL
→ FOCUS
→ FLOATING
→ DOCKED
→ IMMERSIVE
→ RESTORE
```

不需要六套 implementation。

---

## SPATIAL

继续走 Huabu spatial canvas。

---

## FOCUS

继续走 existing same-canvas camera focus。

T4 不拥有 Camera。

这和产品冻结完全兼容：

- 双击对象 Focus 可以移动 Camera；
- 打开/resize WorkView 不移动 Camera。

两者不是冲突。

---

## FLOATING

应优先复用当前成熟 popover/overlay positioning primitive。

当前 Parallel Audit 已记录 `CanvasFloatingPopover`，但本轮 GitHub exact-path 尚未重新确认。

因此最终源码施工正本前：

```text
FLOATING exact supplier path = MUST RESOLVE
```

禁止先自己写 floating geometry。

---

## DOCKED

直接复用：

```text
MainLayout.rightPanel slot
```

不另造 Dock framework。

---

## IMMERSIVE

优先复用：

```text
MainLayout preview fullscreen mechanics
```

但这里有一个真实风险：

当前 Preview fullscreen 会：

```text
unmount Canvas
```

LCOS WorkView IMMERSIVE 是否可以安全复用这一行为，必须做浏览器级恢复测试：

- Selection 是否回来；
- Camera 是否回来；
- Projection bindings 是否恢复；
- Reference state 是否恢复；
- Run/WorkView session 是否连续。

如果测试失败，再最小改 fullscreen mounting policy。

不能因为“感觉可能有问题”提前另造第二个 Immersive framework。

---

## RESTORE

restore 的 owner 应是同一个 WorkView session。

不是 reopen 新 target。

---

# 8. 旧 B06e/C06e WorkView 规划：KEEP / SHRINK / RETIRE

旧计划曾准备：

```text
workViewModel.ts
workViewRegistry.ts
workViewStore.ts
WorkViewHost.tsx
WorkViewFocusLayer.tsx
WorkViewDock.tsx
WorkViewImmersive.tsx
WorkViewRendererRegistry.tsx
safeRegion.ts
shellTypes.ts
LcosRightSurfaceHost.tsx
```

V6 之后建议：

| 旧项 | 新裁决 | 原因 |
|---|---|---|
| `workViewModel.ts` | SHRINK | 只保留最薄 target/session/mode |
| `workViewRegistry.ts` | RETIRE | 不建大 registry；explicit resolver 足够 |
| `workViewStore.ts` | RETIRE | 不建独立 global Zustand；hoist existing project runtime |
| `WorkViewHost.tsx` | SHRINK | 只做 body ↔ placement bridge |
| `WorkViewFocusLayer.tsx` | RETIRE | Camera Focus 属现有 spatial/camera |
| `WorkViewDock.tsx` | RETIRE | MainLayout 已提供 right slot |
| `WorkViewImmersive.tsx` | RETIRE/SHRINK | 复用 MainLayout fullscreen mechanics |
| `WorkViewRendererRegistry.tsx` | RETIRE | 避免巨型 registry |
| `safeRegion.ts` | SHRINK | occupied/safe rect 应派生，不做 truth store |
| `LcosRightSurfaceHost.tsx` | SHRINK | 如需只做极薄 slot arbitration，不做第二 host |

这轮最明显的减法就在这里。

---

# 9. Assembly：不要造第四个数据系统

当前 `AssemblyApplyService` 的设计反而已经很对：

```text
SourceRef + TargetRef
→ existing canonical services
```

它明确声明：

```text
本 service 不拥有 mutation truth
```

当前支持：

- Capture materialize
- ArtifactView → Main/Context/Workflow
- ArtifactView → Workspace/Scene
- Note / Context / Workflow / Collection / Scene → Surface
- Resource → canonical ArtifactView
- Conversation context relation
- placement + semantic membership

这就是 Assembly 应该继续坚持的模式。

---

# 10. Assembly Source Bay 模块化候选

建议：

```text
Core Warehouse
    ↓
Warehouse read adapter
    ↓
SourceRef projection
    ↓
WorkView Source Bay
    ↓
existing dnd-kit
    ↓
AssemblyApplyService
    ↓
canonical mutation service
    ↓
Huabu projection
```

---

## Source Bay 不拥有

- Warehouse DB
- Resource identity
- Membership truth
- Artifact body
- Relation truth

---

## Source Bay 只拥有

- 当前浏览 query
- current filter
- visual grouping
- transient selection
- drag gesture
- target highlight

---

# 11. Lovart 给 Assembly 的真正价值

Lovart proprietary bundle 不可直接 copy。

但它的结构证据非常清楚：

```text
SKILL
ASSET_LIBRARY
canvas reference
history
publish
abort
```

这些是分离的 responsibility。

它同时提供：

- reference browsing
- asset browsing
- Masonry morphology
- canvas selection/reference insertion

对 LCOS 的启发不是：

```text
抄 Lovart Asset Store
```

而是：

> Assembly Source Bay 只负责浏览 canonical Warehouse/Resource，并把 typed SourceRef 投递到已有 Composer/AssemblyApply。

---

## Masonry 不需要新造

Huabu 已经依赖：

```text
react-virtuoso
```

因此大量素材/图片的 Source Bay：

优先：

```text
VirtuosoGrid / existing virtualization
```

而不是先加另一套 Masonry engine。

Lovart 只保留 morphology/interaction evidence。

---

# 12. Spatial v4 对 Assembly / WorkView 的行为证据

录像中高价值部分：

### Capture/import → canvas

表现：

```text
browser/content source
→ capture
→ canvas
→ nearby source/list surface
→ bottom transient actions
```

支持 LCOS：

```text
Source / Assembly / current target
```

是邻接式、上下文式工作，不是“打开一个第四数据应用”。

---

### Spatial → Focus

表现：

```text
grouped spatial view
→ readable focused object
→ return
```

支持 LCOS 已冻结：

```text
same-canvas FOCUS
```

而不是 portal fullscreen。

---

# 13. Context：四个专业 Instrument，四个 donor body，不是四个 app

冻结：

```text
Context Surface
├── Structure
├── Versions / Evolution
├── Relationship
└── Source / Provenance
```

共同原则：

```text
Core truth
→ projection adapter
→ donor body
→ intent callback
→ Core
```

donor body 不能拥有 canonical data。

---

# 14. Context Structure → react-arborist

当前 upstream：

```text
react-arborist 3.16.0
MIT
```

适合：

- hierarchical structure
- virtualization
- selection
- expand/collapse
- filter
- optional tree DnD

建议：

```text
DIRECT_USE_WITH_WRAPPER
```

但要注意：

react-arborist 内部使用：

```text
react-dnd
```

而 Huabu 当前已经使用：

```text
dnd-kit
```

因此必须把 Arborist DnD 严格限制在 WorkView DOM instrument 内。

如果 Context Structure 当前只需要：

- browse
- focus
- select
- reorder intent

甚至可以先关掉它的内部 drag 能力。

不能让它接管：

- world-space drop
- Semantic Drop
- Canvas pointer router

---

# 15. Context Evolution → vis-timeline

当前：

```text
vis-timeline latest release: 8.5.4
2026-08-12
license: Apache-2.0 OR MIT
```

非常适合：

- snapshot/version ranges
- time axis
- grouped events
- zoomed temporal inspection
- selection

LCOS 当前已经有：

```text
ContextSnapshot
create
compare
branch
```

因此正确结构：

```text
ContextSnapshot Core truth
→ Evolution projection adapter
→ vis-timeline
```

而不是：

```text
vis-timeline state
→ 第二套版本历史数据库
```

---

# 16. Context Relationship → Cytoscape.js

当前 stable release：

```text
Cytoscape.js 3.34.2
2026-08-25
MIT
```

推荐 stable，不跟 `unstable` branch。

适合：

- relationship graph
- graph selection
- graph layout
- filtered neighborhood
- edge/entity inspection

LCOS Relation truth 仍然在 Core。

Cytoscape element id 只能映射 canonical relation/entity ref。

禁止：

```text
Cytoscape graph = canonical relationship DB
```

---

# 17. Context Source / Provenance → 不加大引擎

Source/Provenance 主要需要：

- provenance row
- source chain
- revision/source label
- inspection
- jump/focus

优先：

- native React/Huabu list
- `react-virtuoso`

不需要为了“四个 Instrument 看起来对称”再找第四个重量级库。

---

# 18. Workflow：继续坚持不是 BPMN/DAG builder

产品冻结：

> Workflow 是 Action Worksite，不是流程建模软件。

当前 Core 的 `workflow.ts` 主要是：

```text
.lcos-workflow.zip
import/export
```

而真实执行依然走：

```text
Run
RuntimeDispatch
RuntimeBinding
RuntimeReview
ArtifactReturn
```

这说明现有系统边界其实与冻结语义一致。

---

# 19. Workflow Action Path 不应该另建 React Flow

Huabu 已经拥有：

```text
@xyflow/react
Canvas
edges
node placement
world interaction
```

所以：

```text
Action Path / Step / Checkpoint / Review marker
```

应该继续作为 Huabu spatial presentation。

不要在 WorkView 里再建：

```text
WorkflowGraph ReactFlow
```

否则会得到第二套：

- pan/zoom
- selection
- edge
- drag
- node identity
- graph state

纯属花钱养重复 bug。

---

# 20. TapNow 对 Workflow/Run 的价值

TapNow 大包里最有价值的不是视觉，而是状态责任拆分：

```text
conversationId
runId
lastEventId
streamState
contextNodeIds
pending confirmations
queue
```

Run event reconnect 通过：

```text
Last-Event-ID
```

恢复。

LCOS Core 当前已经有：

```text
GET /runs/:id/events?after=N
dispatch
recover
sync
cancel
input-request
review
```

因此 TapNow 给 T4 的结论是：

> Run WorkView 只做 Core Run/Event 的 projection；不要再造前端 Run event truth。

---

# 21. Workflow Run/Review WorkView

建议：

```text
Core Run
Core RunEvents
Core RuntimeReview
Core ArtifactReturn
    ↓
RunReview adapter
    ↓
WorkView body
    ↓
react-virtuoso for long event/result lists
```

UI 只拥有：

- scroll
- selected result
- current tab
- expanded section
- transient confirmation UI

不拥有：

- Run status
- external task identity
- retry truth
- completion truth

---

# 22. Skill：这轮出现了最强的直接复用机会

LCOS 当前 Skill 本来就是目录型：

```text
SKILL.md
references/
scripts/
...
```

系统层：

```text
packages/skills/
```

用户层：

```text
<project>/.creative-os/skills/
```

`SkillPackageService.install()` 当前已经会：

```text
recursive copy system skill → project skill
```

Skill Catalog 也直接复用同一 layered skill reader。

---

# 23. LibTV Skill 与 LCOS Skill 结构天然接近

LibTV：

```text
skills/libtv-skill/
├── SKILL.md
└── scripts/
```

LibTV SKILL frontmatter 已有：

```text
name
description
metadata
```

LCOS 当前 validation 硬要求：

```text
name
description
```

缺：

```text
version
role
```

只是 warning。

额外 metadata 当前不会导致 invalid。

因此高置信度结论：

> **不要发明 `LibTVSkillSchema`。**

最薄的直接复用方式：

```text
vendor LibTV MIT skill package
→ packages/skills/libtv-skill/
→ 保留原 LICENSE / attribution
→ 现有 SkillCatalogService 直接读取
→ 现有 SkillPackageService install
→ Skill Builder 直接把它当普通 Skill Artifact
```

这是这轮最值得真正“copy/adopt implementation”的 donor。

---

# 24. LibTV 执行脚本也有可复用价值，但要分层

LibTV scripts 已经提供：

- create session
- query session
- change project
- upload file
- download results
- incremental query cursor
- Bearer auth/env

它展示了一个成熟的：

```text
Skill Artifact
→ external provider/session
→ incremental result
→ output/download
```

路径。

但不能因此把：

```text
LibTV sessionId
LibTV projectUuid
```

变成 LCOS canonical identity。

---

# 25. LibTV general Runtime Provider 集成不是 T4 可以单独裁决的

当前 LCOS Run provider type 仍然明显收窄为：

```text
workbuddy
codex
auto
```

BridgeTaskEnvelope 也按：

```text
workbuddy | codex
```

建模。

因此：

## T4 可以做

```text
DIRECT_USE:
LibTV MIT System Skill package
```

## T4 不自行做

```text
Run.provider += libtv
```

general provider-native integration 必须：

```text
REPORT_TO_T6
```

由 Runtime/Core 线程判断：

- provider registry
- bridge envelope
- credentials
- external session binding
- recovery
- result ingestion
- provider status

T4 不能为了把 donor 接进来，顺手扩 Core canonical union。

---

# 26. Skill Builder：两个 body，共用一套 truth

冻结要求：

```text
Outline + Mind Map
```

不是两套 Skill。

---

## Outline

候选：

```text
react-arborist
```

---

## Mind Map

当前 Mind Elixir：

```text
v5.15.1
2026-08-05
MIT
```

适合：

- mind map editing
- hierarchy
- expand/collapse
- layout
- DOM-native presentation

建议：

```text
DIRECT_USE_WITH_WRAPPER
```

---

## 共同 adapter

```text
SkillPackageV1 / SkillDraft
→ SkillBuilderProjection
    ├── Outline body
    └── MindMap body
```

两者 emit 的都应该是：

```text
Skill edit intent
```

最终保存还是：

```text
SkillProposalService
SkillPackageService
```

不能：

```text
Arborist state = Skill truth
MindElixir state = Skill truth
```

---

# 27. Skill Author 当前边界本身是正确的

当前 `SkillAuthorDispatchService` 已经明确：

```text
dispatch
ingest
semantic
```

只做 semantic execution seam。

而：

```text
proposal review
accept
install
```

继续走：

```text
SkillProposalService
SkillPackageService
```

这与产品冻结：

```text
Skill Builder ≠ Harness Run
```

完全一致。

因此不要重写它。

---

# 28. Assembly 当前一个明确 GAP：Skill source

当前 `AssemblyApplyService` 对：

```text
sourceRef.kind === skill
```

仍是：

```text
unsupported
Skills are read-only in v0.15
usage-binding deferred
```

但后续冻结已经要求 Skill 可跨 Surface 作为能力/Reference 使用。

这是一个真实 current-reality gap。

必须：

```text
REPORT_T4↔T6
```

不能前端做：

```text
if skill then local fake apply
```

也不能 T4 自己偷偷创造：

```text
SkillBinding
```

---

# 29. Huabu upstream Cross-Space Move 应该收，但不要拿它替代 Assembly

upstream 已经有成熟的：

```text
MoveSelectionModal
space-move-plan
space-move.service
space-move schema
expectedSourceVersion
source preview
destination version
boundary edge handling
conversation handling
conflict/error protocol
```

这对真正的：

```text
Spatial Rehome / Move
```

很有价值。

建议：

```text
ADOPT_UPSTREAM_WHEN_PIN_REFRESHED
```

但：

```text
Cross-Space Move != AssemblyApply
```

因为 AssemblyApply 可以：

- reference
- membership
- materialize
- relation
- target apply

而 Move 是：

- entity spatial rehome

两条语义不能合并。

---

# 30. Presentation donor matrix

| T4 能力 | Canonical Truth | Body/Mechanics Supplier | 结论 |
|---|---|---|---|
| WorkView Dock | project session + Core target | Huabu MainLayout | DIRECT REUSE |
| WorkView Split/Tabs | WorkView feature state | Huabu Preview pure model | REUSE MECHANICS |
| WorkView Immersive | WorkView mode | Huabu fullscreen mechanics | REUSE + RECOVERY TEST |
| WorkView DnD | SourceRef/intent | existing dnd-kit | DIRECT REUSE |
| Assembly large list/grid | Warehouse truth | react-virtuoso | DIRECT REUSE |
| Context Structure | Core Context/Entity | react-arborist | DIRECT_USE_WITH_WRAPPER |
| Context Evolution | ContextSnapshot | vis-timeline | DIRECT_USE_WITH_WRAPPER |
| Context Relationship | Core Relation | Cytoscape.js stable | DIRECT_USE_WITH_WRAPPER |
| Context Provenance | Core provenance | native/virtuoso | NO NEW ENGINE |
| Workflow spatial Action Path | Core/Presentation | Huabu Canvas/xyflow | DIRECT REUSE |
| Workflow Run/Review | Core Run/Review/Event | WorkView + virtuoso | THIN BODY |
| Skill Outline | Skill package/draft | react-arborist | DIRECT_USE_WITH_WRAPPER |
| Skill Mind Map | Skill package/draft | Mind Elixir | DIRECT_USE_WITH_WRAPPER |
| LibTV Skill | LCOS SkillPackage | libtv-skills MIT | DIRECT VENDOR CANDIDATE |
| True Cross-Space Move | Huabu spatial truth | latest Huabu upstream | ADOPT UPSTREAM |
| Lovart Masonry morphology | Warehouse truth | proprietary evidence only | TRACE / RECREATE USING EXISTING PRIMITIVES |
| TapNow Run resume morphology | Core RunEvents | proprietary evidence only | BEHAVIOR EVIDENCE |

---

# 31. 为什么现在不推荐 react-resizable-panels

旧 donor census 有它。

但 current Huabu 已经有：

- right panel resize
- panel collapse
- fullscreen
- split preview
- keyboard separator
- DnD tab

继续再装一套 resize framework 的收益已经很小。

同时会增加：

- layout owner
- pointer handling
- persistence
- CSS sizing rules

因此当前裁决：

```text
REJECT AS FIRST PATH
```

只有未来 Huabu mechanics 明确无法满足某个具体产品需求时再复核。

---

# 32. 为什么 Workflow 不再找一套 DAG framework

因为现在 source-level evidence 已经足够说明：

- Huabu 有 world canvas；
- Huabu 有 edges；
- LCOS Core 有 Run；
- Workflow 是 action worksite；
- Run 是 execution truth。

再加 DAG framework，只会制造：

```text
第二 Canvas
第二 edge state
第二 selection
第二 node position
第二 zoom
第二 run/execution mental model
```

因此：

```text
NO BPMN
NO generic workflow DAG engine
NO second ReactFlow canvas
```

---

# 33. 推荐的层级结构

```text
L1 Canonical Domain Truth
   Core
   Run / Artifact / ContextSnapshot / Relation / SkillPackage / Warehouse

L2 Spatial Port
   Huabu
   ProjectionBinding
   RFS / CanvasHostExtension

L3 Feature Semantic Module
   WorkView session
   Assembly SourceRef adapter
   Context projection adapter
   Workflow review adapter
   Skill Builder projection adapter

L4 Presentation Body
   AssemblyBody
   ContextStructureBody
   ContextEvolutionBody
   ContextRelationshipBody
   RunReviewBody
   SkillOutlineBody
   SkillMindMapBody

L5 Placement / Chrome
   Huabu MainLayout
   Preview Workspace mechanics
   Floating popover/overlay
   fullscreen
   safe/occupied rect signal

L6 Donor Component
   react-arborist
   vis-timeline
   Cytoscape
   Mind Elixir
   react-virtuoso
   dnd-kit
   libtv-skills
```

核心目标：

```text
L6 换掉
→ L1/L2 不动

L5 换掉
→ L1/L2/L3 不动

L4 做坏
→ 只换 body

L3 做坏
→ Core truth 仍完整
```

这才是真正模块化。

---

# 34. 当前建议的数据流

## WorkView

```text
Core Entity/Run/Skill identifier
→ WorkViewTarget
→ WorkViewSession
→ body resolver
→ placement resolver
→ Huabu shell
```

---

## Assembly

```text
Warehouse
→ SourceRef projection
→ Source Bay
→ dnd-kit
→ AssemblyApplyService
→ canonical mutation
→ Projection
```

---

## Context

```text
Context canonical truth
├─ structure projection → Arborist
├─ snapshot projection → vis-timeline
├─ relation projection → Cytoscape
└─ provenance projection → native/Virtuoso
```

---

## Workflow

```text
Huabu Action Path
+
Core Run / RunEvent / RuntimeReview
→ Run Review WorkView
```

---

## Skill

```text
SkillPackage / Proposal
→ SkillBuilderProjection
├─ Arborist Outline
└─ MindElixir Map

Run
→ Skill Author
→ Proposal
→ Review
→ SkillPackageService
```

---

# 35. 模块 failure blast radius

## WorkView placement 出错

最大影响：

```text
WorkView visibility / placement / restore
```

不应影响：

- Core truth
- Run truth
- Huabu graph
- Context history
- Skill package

---

## Arborist 出错

最大影响：

```text
Context Structure / Skill Outline body
```

换掉 donor 即可。

---

## vis-timeline 出错

最大影响：

```text
Evolution rendering
```

ContextSnapshot truth 完整保留。

---

## Cytoscape 出错

最大影响：

```text
Relationship visualization
```

Relation truth 完整保留。

---

## MindElixir 出错

最大影响：

```text
Skill Mind Map
```

Skill Package/Proposal 不受影响。

---

## LibTV donor 出错

如果按 system skill vendor：

```text
disable/remove vendor skill
```

即可。

不能要求：

```text
Core migration
Run identity repair
Project migration
```

---

# 36. 当前 Cross-Boundary 反证清单

V6 Round 5 至少要求 10 个 second-truth 问题。

T4 当前已经有：

1. WorkView session 是否复制 Huabu PreviewWorkspace store？
   - 不允许。

2. WorkView 是否拥有 Camera？
   - 不允许。

3. right-panel mux 是否变成第二 Preview host？
   - 不允许。

4. Assembly Source Bay 是否缓存第二套 Warehouse truth？
   - 不允许。

5. Huabu Cross-Space Move 是否被误当 Assembly apply？
   - 不允许。

6. Context Evolution 是否建立第二 history store？
   - 不允许。

7. Cytoscape 是否拥有 canonical Relation identity？
   - 不允许。

8. Workflow WorkView 是否建立第二 Run domain？
   - 不允许。

9. TapNow 的 `lastEventId` 模式是否诱导前端 event truth？
   - 不允许；只映射 Core event cursor。

10. Skill Builder 是否本地保存第二套 Skill truth？
    - 不允许。

11. LibTV sessionId 是否变成 LCOS sessionId？
    - 不允许。

12. Arborist react-dnd 是否干扰 Huabu world pointer/dnd-kit？
    - 必须隔离并浏览器测试。

13. MindElixir 自身 pan/zoom 是否与 Canvas Camera 竞争？
    - 必须限制在 WorkView DOM viewport。

14. IMMERSIVE unmount Canvas 是否破坏 restore/projection/reference？
    - 必须真实测试。

15. occupiedRect/safeRect 是否被持久化成第二 geometry truth？
    - 不允许，应派生。

16. LibTV SKILL metadata.requires 是否被 LCOS runtime 正确理解？
    - 尚未验证，需 T6。

17. Skill SourceRef 当前 AssemblyApply unsupported 是否被前端 fake 掉？
    - 禁止。

18. WorkView renderer mapping 是否膨胀成 giant registry？
    - 禁止。

---

# 37. 当前几个真正需要继续深挖的 gap

这些不是要求用户再补文件，而是 T4 接下来自己要查清的审计项。

---

## G1. FLOATING exact supplier path

Parallel Audit 指向：

```text
CanvasFloatingPopover
```

但本轮 current GitHub exact path 尚未重新锁定。

最终 plan 前必须找到实际 current source。

---

## G2. IMMERSIVE Canvas unmount recovery

当前 MainLayout preview fullscreen：

```text
unmount Canvas
```

必须做：

- browser run
- open target
- fullscreen
- restore
- inspect selection/camera/projection/reference/session

不能只读代码猜。

---

## G3. LibTV metadata.requires

LibTV SKILL 里有环境要求。

LCOS 当前 Skill parser 主要提取简单 frontmatter。

必须确认：

- raw metadata 是否会完整保留给执行 harness；
- capability/credential readiness 是否已有 Core owner；
- 是否需要 T6 adapter。

T4 不自行造 schema。

---

## G4. Skill → Assembly target semantic gap

当前 Core 明确 unsupported。

需 T4/T6 联审：

```text
Skill 作为 Reference？
Skill 作为 capability？
Skill 作为 RunRecipe dependency？
```

然后接已有 owner。

禁止 SkillBinding。

---

## G5. react-arborist DnD coexistence

需要最小实际 prototype/test：

```text
Arborist nested in WorkView
+
Huabu/dnd-kit world canvas
```

验证 pointer capture/backend 无冲突。

---

# 38. 建议后续施工阶段候选

注意：

> 以下是 architecture direction candidate，不是最终 ExactFile 施工正本。

---

## T4-0 · Context closeout

重新生成：

```text
Mandatory Exact Read Completion Table
```

把 V6 新增 source/donor 也纳入。

---

## T4-1 · Project-session owner hoist

目标：

```text
复用现有 createLcosRuntime
把 owner 从 CenterArea 局部 lifecycle 提升到 project/session lifecycle
```

验收：

- 仍只有 ONE runtime；
- Canvas 不建第二 host；
- right WorkView 可消费同 session；
- project/canvas retarget 正常；
- dispose 正常。

---

## T4-2 · WorkView placement shell

只做：

```text
target/session
body
mode
restore
```

复用：

- existing Focus
- existing floating primitive
- MainLayout right slot
- MainLayout fullscreen

不建：

- Dock framework
- Camera
- layout engine
- giant registry

---

## T4-3 · Assembly Source Bay

复用：

- Core Warehouse
- AssemblyApply
- dnd-kit
- react-virtuoso

Lovart/Spatial 只提供 morphology。

---

## T4-4 · Context Instruments

四个 adapter：

```text
Structure → Arborist
Evolution → vis-timeline
Relationship → Cytoscape stable
Source → native/Virtuoso
```

---

## T4-5 · Workflow Run/Review

复用：

- existing Huabu Action Path
- Core Run
- Core RunEvents
- RuntimeReview
- ArtifactReturn
- Virtuoso

---

## T4-6 · Skill Builder

复用：

```text
SkillPackageService
SkillProposalService
Arborist
MindElixir
```

并加入：

```text
LibTV MIT system skill donor
```

LibTV native provider integration另交 T6。

---

## T4-7 · Cross-Surface recovery

真实 browser tests：

```text
Main → Context → Workflow
同一个 WorkView target/session
Docked → Immersive → Restore
Run waiting_input → answer → resume
Assembly apply → reload
Context snapshot → timeline → compare
Skill edit → proposal → accept → reopen
```

---

# 39. 本轮最重要的“不要做”

```text
DO NOT:
- new WorkView global Zustand
- new WorkView mega registry
- new Dock framework
- new fullscreen framework
- new Split framework
- WorkView camera
- Assembly DB/cache truth
- Context history DB
- Context custom tree engine
- Context custom timeline engine
- Context custom graph engine
- Workflow DAG engine
- second ReactFlow workflow canvas
- frontend Run event store
- Skill-specific Binding
- LibTV-specific Skill schema
- LibTV session as LCOS identity
- copy Lovart/TapNow proprietary bundle
```

---

# 40. 本轮最值得真正收编的东西

按优先级：

## A. 已经在 Huabu 里的成熟 mechanics

最高优先：

- MainLayout
- PreviewWorkspace pure model
- Preview split
- dnd-kit
- react-virtuoso
- xyflow
- panel/fullscreen mechanics

因为它们已经在 construction host 里，成本最低。

---

## B. LibTV MIT Skill

目前最强的外部 direct-use donor：

```text
libtv-skills
```

它甚至与 LCOS 当前目录型 Skill Package 几乎天然对齐。

---

## C. Context 专业 donor

- react-arborist
- vis-timeline
- Cytoscape stable

都只作为 body。

---

## D. Skill Builder donor

- react-arborist
- Mind Elixir

双 projection，同一 truth。

---

## E. Huabu latest Cross-Space Move

在 pin refresh 时收编其真正 spatial move 能力。

---

# 41. 当前总体判断

V6 之后，T4 的正确施工路线应该比旧 Phase C/B06e 明显更薄。

过去倾向：

```text
LCOS WorkView Framework
+ WorkView Store
+ Registry
+ Dock
+ Immersive
+ Renderer Registry
+ Context engines
+ Skill UI
+ Workflow UI
```

现在更合理：

```text
existing project runtime owner
+ very thin WorkView session
+ existing Huabu placement mechanics
+ canonical Core clients
+ replaceable donor bodies
```

这会让 Gen2 更像：

```text
LCOS semantics
on top of mature mechanics
```

而不是：

```text
LCOS重新实现一遍所有成熟桌面产品 primitive
```

这正符合当前反惰性规划的目的：

> 不允许“因为规划写得详细，所以顺手把所有东西都自己造了”。

---

# 42. 当前状态

```text
ROUND 1:
raw recovery blocker substantially closed
formal completion table refresh pending

ROUND 2:
current owner / consumer / runtime trace
substantial progress

ROUND 3:
historical pain / supersession
substantial progress

ROUND 4:
supplier / donor / upstream
substantial progress, ongoing

ROUND 5:
contradiction / recovery
started, 18 contradiction checks logged

FINAL EXACTFILE PLAN:
LOCKED
```

下一步继续做的不是加架构，而是：

```text
1. 补齐 exact current supplier path
2. 做 runtime/placement browser proof
3. 做 donor coexistence proof
4. 做 Skill/Assembly 与 T6 边界联审
5. 重新收敛为 KEEP / ADOPT / WRAP / RETIRE exact-file table
```

只有这些证据过关之后，再写第四路最终源码级施工正本。
