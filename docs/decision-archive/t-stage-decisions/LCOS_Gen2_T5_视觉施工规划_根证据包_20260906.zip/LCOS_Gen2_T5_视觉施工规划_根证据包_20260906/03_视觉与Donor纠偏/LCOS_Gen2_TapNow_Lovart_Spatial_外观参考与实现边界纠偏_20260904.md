# LCOS Gen2 · TapNow / Lovart / Spatial 外观参考与实现边界纠偏


# TapNow / Lovart / Spatial · 外观参考与实现边界校准

## 1. 三类 donor 必须分开

### A. Implementation Supplier
可以连机制/代码一起优先收编：

- Huabu current/vendor
- Huabu upstream
- 许可证兼容、维护成熟的开源 donor
- LCOS 自己 current Core/Gen1 中仍正确的 semantic/test asset

### B. Visual / UX Evidence Donor
主要用于回答“长什么、怎么动、何时出现、层级怎么组织”：

- TapNow production build
- Lovart production build
- Spatial app behavior / recording / symbols（除非只是研究内部机制）
- 竞品视频/截图/抽帧

这类材料可以做：
- visual anatomy
- spacing/density
- state appearance
- interaction timing
- transition feeling
- information hierarchy
- entry/toolbar/menu morphology
- user-flow comparison

但默认**不作为实现代码 donor**。

### C. Architecture / Responsibility Evidence
TapNow/Lovart/Spatial 暴露的：
- RAG/Search
- DB/cache
- Agent Thread
- Conversation/Run
- memory/tool
- Reference/Asset input
- recovery/event
- protocol/API

只用于：
- 比较成熟产品如何分责任
- 发现 LCOS 缺失 capability
- 验证 owner 是否合理
- 形成 KEEP / REJECT / ADOPT_PATTERN

除非对应实现本身来自可合法复用的成熟开源 supplier，否则：
**不得从 proprietary/minified implementation 直接抄代码、协议、schema、框架。**

---

## 2. TapNow / Lovart 的“拆包源码”价值是什么

它们的构建产物让我们能把原来只凭视频判断的东西变成更可靠的证据：

```text
Feature 名称
真实 UI state
真实菜单/工具栏层级
真实 panel/tab 存在性
真实交互入口
真实状态字段
真实 API responsibility
```

价值是：
> 证明“这个产品真的这样组织”，而不是让 LCOS import 它的框架。

例如：
- TapNow tldraw/Fabric/Three/tool_event/persistence 不算 LCOS 资产
- Lovart tldraw 二开/AI 定制层/Ant Design 实现不算 LCOS 资产
- Spatial AppKit/CoreData/private MCP 不算 LCOS implementation donor

---

## 3. 外观“抄”的正确工程化定义

用户所说“抄外观”，在施工表里必须翻译成：

```text
OBSERVE exact visual/interaction anatomy
→ extract measurable appearance/behavior requirement
→ find compatible mature reusable component/mechanic
→ tune color/size/duration/intensity
→ preserve LCOS own semantics
```

不是：

```text
copy proprietary source
copy proprietary assets
clone entire framework/protocol/schema
```

---

## 4. TapNow Color Pin · 典型范例

TapNow build 已经暴露：

```text
color_pins
six colors
togglePinOnNode
pin toolbar
color chips
pin group
filteredGroupId
```

它与 LCOS Colour Pin 是“同物种但不同核心语义”。

### TapNow
更偏：
- color tag
- grouping
- filtering

### LCOS
冻结为：
- persistent user navigation anchor
- visible pin
- offscreen edge locator/waypoint handoff
- 与 Search / Focus 分离

因此施工分类：

```text
TapNow color_pins
= VISUAL_UX_REFERENCE

TapNow grouping/filter semantics
= REFERENCE_ONLY

LCOS Colour Pin semantic owner
= KEEP

Spatial mechanics
= Huabu

Visual body
= compatible mature donor / preset
```

可借鉴外观：
- compact colored dot/button
- six-color family
- node-adjacent color indication
- pin group visual strip if LCOS product meaning成立
- hover/press/transition cadence

不得直接继承：
- `filteredGroupId` 作为 LCOS Pin 核心逻辑
- TapNow persistence/schema
- TapNow canvas framework

---

## 5. RAG / DB / Agent 流程仍然要看，但用途不同

三包暴露的非前端流程仍是高价值证据。

T6 必须研究它们，是为了回答：

```text
成熟产品把 Search / Conversation / Run / Memory / Cache / Reference
分别放在哪里？
LCOS 自己的 owner 是否合理？
哪些 capability 我们漏了？
哪些状态绝不能塞进同一个 Mega Context Service？
```

不是为了：
> 找到 TapNow/Lovart 的 DB/协议然后移植。

因此所有 T6 adoption matrix 对 proprietary package 只能使用：

- ADOPT_PATTERN
- RESPONSIBILITY_REFERENCE
- UX_REFERENCE
- REJECT
- NOT_RELEVANT

不得写：
- DIRECT_COPY
- ADOPT_IMPLEMENTATION

除非该段实现明确来自独立、可兼容许可的第三方开源依赖，并且单独回到其 upstream 做许可和源码审计。

---

## 6. Spatial 特殊处理

Spatial 的价值主要是：
- hand feel
- zoom/presentation
- stack/layout
- transition
- object morphology
- information hierarchy

其 CoreData/SearchIndex/MCP 可以作为 architecture evidence。

但：
- macOS/AppKit implementation 不照搬
- private schema 不照搬
- private MCP 不照搬

真正落地仍优先：
Huabu + Core + compatible mature donor。

---

## 7. 六线程共同门禁

看到 TapNow/Lovart/Spatial 某段实现时，先问：

1. 我现在是在学习“外观/行为”，还是打算“采用实现”？
2. 如果采用实现，它是否来自可兼容许可的独立开源 supplier？
3. 如果不是，是否能把需求转成 measurable appearance/interaction spec？
4. Huabu 已有机械吗？
5. 我们 donor 库已有 mature component 吗？
6. LCOS semantic owner 是否保持不变？

没有回答完，禁止进入施工建议。
