# LCOS Gen2 · T4 第四路
## Assembly × Project Identity × SurfaceRegistry × Skill Usage Binding · Exact Handoff 审计

日期：2026-09-04  
当前 LCOS 源码锚点：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`  
Huabu vendor pin：`58339e269b784728d67730c70bfe7792cae2457d`  
Huabu upstream observed HEAD：`dc128fff2d37b5481ec305070a7e86d3de85f7d2`

状态：

```text
INTERIM SOURCE-LEVEL AUDIT / EXACT HANDOFF
NOT FINAL CONSTRUCTION PLAN
NO PRODUCTION PATCH AUTHORIZED
```

本文继续遵守 T4 V6 审计优先 SOP，只做 current source truth、latest product freeze 对照、owner/consumer/gap、exact cross-thread handoff 与文件级候选。它不绕过 Mandatory Read Completion，也不把当前缺失 Core semantics 用前端“先做一个”糊过去。

---

# 0. 本轮结论

1. **Project identity 的 Core truth 已存在；缺的是 Huabu Shell → ProjectSession 的产品 wiring。**
2. **SurfaceRegistry 已有纯逻辑 contract + test，但没有 production consumer。**
3. **Assembly current contract / route / service / tests 已重新按同一 commit 对齐。**
4. **Assembly UI 应统一 Source Bay，不应统一成一个新 Warehouse truth。**
5. **Skill Assembly 当前确实是 Core gap；现有 Relation 也不能直接承载 Skill usage。**
6. **MainLayout / safe-region 的 exact test 与 handoff 已找到，不需要第二套 layout runtime。**

---

# 1. 重要纠错：前一轮 Assembly contract 串版结论废止

前一轮审计中曾短暂引用另一套 `artifact-view / viewId / root-result-slot / artifactView capability target` 等形状。重新按 current commit `c2ff890...` 对齐：

```text
packages/contracts/src/assembly.ts
apps/local-core/src/assembly-apply-service.ts
apps/local-core/src/routes/f6-assembly.ts
apps/local-core/tests/*
```

后，确认 current production 使用本文下述 contract。

```text
PREVIOUS MIXED-VERSION ASSEMBLY CONTRACT ASSUMPTION
= SUPERSEDED
```

最终 T4 正本不得再引用那套混合形状。

---

# 2. current AssemblySourceRefV1

源码：`packages/contracts/src/assembly.ts`

```ts
type AssemblySourceRefV1 =
  | { kind: 'artifactView'; id: string }
  | { kind: 'capture'; id: string }
  | { kind: 'resource'; id: string }
  | { kind: 'conversation'; id: string }
  | { kind: 'context'; id: string }
  | { kind: 'workflow'; id: string }
  | { kind: 'scene'; id: string }
  | { kind: 'collection'; id: string }
  | { kind: 'skill'; id: string; source: 'system' | 'user' | 'merged'; version?: string }
  | { kind: 'note'; id: string }
```

这些都是 canonical refs。Assembly 不拥有 artifact body、skill package copy、conversation copy、scope copy 或 scene copy。

# 3. current AssemblyTargetRefV1

```ts
type AssemblyTargetRefV1 =
  | { kind: 'project'; id: string }
  | { kind: 'main' }
  | { kind: 'workspace'; id: string }
  | { kind: 'conversation'; id: string }
  | { kind: 'context'; id: string }
  | { kind: 'workflow'; id: string }
  | { kind: 'scene'; id: string }
```

Core target union 不等于用户必须看到 7 个 Assembly target tab。Core contract 是底层 capability vocabulary，GUI taxonomy 服从 latest product freeze。

# 4. latest product-facing Assembly taxonomy

2026-09-02 全功能冻结明确用户类别：

```text
Artifacts
Context
Workflow
Skills
Collections
Conversations
Workspaces
```

分类只是 index / presentation，不新增 category entity。

# 5. Assembly 三种 GUI 形态

```text
Dedicated Workspace
Docked Source Bay
Quick Tray
```

三者共享同一个 Project Assembly registry、source identity、target grammar、apply contract；不同的只是 presentation/navigation。禁止 Dedicated Assembly DB、Glyth private Assembly、Context private Assembly、Workflow private Assembly。

---

# 6. current Source Bay 是多个成熟 feed 的组合

## A. Warehouse feed

```http
GET /projects/:projectId/warehouse
```

覆盖 artifact、note、conversation、resource、context、workflow、scene、collection，支持 search/kinds/provenance/usedHereTarget/limit/cursor。

## B. Capture feed

Assembly contract 使用 `{ kind:'capture', id }`。apply service 会 `capture → materializeToProject() → canonical artifact/view → membership`，不建立 Capture Canvas truth。

## C. Skill feed

```http
GET /projects/:projectId/skills
GET /projects/:projectId/skills/:skillId
```

`SkillCatalogService` 负责 catalog read，`SkillPackageService` 负责 package write，Assembly 不能成为第二 Skill writer。

推荐 web projection：

```text
AssemblySourceBay
├─ WarehouseFeedAdapter
├─ CaptureFeedAdapter
└─ SkillCatalogFeedAdapter
```

最后统一成只读 `AssemblySourceItemViewModel`，只承载 title/kind/native morphology/preview/provenance hint/usedHere/canonical ref，不复制 canonical content 或 usage truth。

---

# 7. 用户类别与 feed 的映射

```text
Artifacts      → Warehouse artifact/note/resource
Context        → Warehouse context
Workflow       → Warehouse workflow
Skills         → SkillCatalog
Collections    → Warehouse collection
Conversations  → Warehouse conversation
Workspaces     → Warehouse scene/workspace projection
Capture        → Assembly 内 material flow/source entrance
```

不要让底层 `capture/resource/note/scene` 每项都机械变成一个顶层用户 tab。

---

# 8. current unified mutation endpoint

```http
POST /projects/:projectId/assembly/apply
```

```ts
interface AssemblyApplyRequestV1 {
  schemaVersion: 1
  projectId: string
  sourceRefs: readonly AssemblySourceRefV1[]
  targetRef: AssemblyTargetRefV1
  placementBySource?: Record<string, { x: number; y: number }>
}
```

`AssemblyApplyService` 自己明确不拥有 mutation，只路由到现有 canonical services：

```text
CaptureSpaceService
CurationCommandService
MutationSafetyService
Relation truth
PresentationApplicationService
```

因此 GUI 禁止再复制一套 `dropXToY()` mutation universe。

---

# 9. current Source × Target Matrix

说明：

```text
PRESENTATION = presentation membership / memberEntityRefs
WORKING_SET  = workspace/scene membership
RELATION     = conversation_context
MATERIALIZE  = capture materialize
U            = current explicit unsupported
```

| Source | Project | Main | Context | Workflow | Workspace | Scene | Conversation |
|---|---|---|---|---|---|---|---|
| capture | MATERIALIZE | MATERIALIZE→PRESENTATION | MATERIALIZE→PRESENTATION | MATERIALIZE→PRESENTATION | MATERIALIZE→WORKING_SET | MATERIALIZE→WORKING_SET | U |
| artifactView | U | PRESENTATION(view) | PRESENTATION(view) | PRESENTATION(view) | WORKING_SET(view) | WORKING_SET(view) | RELATION |
| resource | U | canonical view→PRESENTATION | canonical view→PRESENTATION | canonical view→PRESENTATION | canonical view→WORKING_SET | canonical view→WORKING_SET | canonical view→RELATION |
| note | U | PRESENTATION(entity) | PRESENTATION(entity) | PRESENTATION(entity) | WORKING_SET(entity) | WORKING_SET(entity) | RELATION |
| context | U | PRESENTATION(entity) | PRESENTATION(entity) | PRESENTATION(entity) | U | U | RELATION |
| workflow | U | PRESENTATION(entity) | PRESENTATION(entity) | PRESENTATION(entity) | U | U | RELATION |
| collection | U | PRESENTATION(entity) | PRESENTATION(entity) | PRESENTATION(entity) | U | U | RELATION |
| scene | U | PRESENTATION(entity) | PRESENTATION(entity) | PRESENTATION(entity) | U | U | RELATION |
| conversation | U | U | U | U | U | U | U |
| skill | U | U | U | U | U | U | U |

这张表只表示 current `c2ff890...` service behavior，不等于 latest product final matrix。

---

# 10. Main / Context / Workflow / Scene 的 current 语义

Main 是 root scope 的 context presentation：

```text
presentation:context:<rootScopeId>
```

不是 active Workspace alias。

Context / Workflow 的普通 material drop 是 presentation membership。current test 明确证明：

```text
artifactView → workflow blank
→ material/reference membership
→ workflowActions stays empty
→ workflowActionEdges stays empty
```

即“拖材料进入 Workflow Surface”不会自动创建 Action/Step。

Scene / Workspace 对 artifactView 使用 ChangeSet-backed working-set membership；note 使用 canonical note entity membership，不伪造 view、不复制正文。current tests 已覆盖 restart/revert/reapply/idempotence。

placement 也已分层：新 membership 的初始位置与语义提交协同；already-member 的纯位置更新不制造新 semantic ChangeSet。

---

# 11. Conversation Context Mapping current owner

`targetRef.kind === 'conversation'` 时走 `conversation_context` Relation truth，不是 spatial proximity，也不是 per-run Reference。

current target endpoint 支持 view/note/scope/workspace。

`skill` 当前不能进入该 relation。

---

# 12. Skill usage 是真实 Core gap

latest product freeze 要求：

```text
Skill → Workflow Step
Skill → Composer
Skill → Glyth
Skill → ordinary capability target
```

并要求全部引用同一个 `skillId/version`，默认不复制 package。

current source却是：

```text
skill source → ANY Assembly target
= unsupported
```

current test也明确锁定：

```text
skill → main
= skipped / unsupported
```

因此：

```text
CURRENT_SOURCE: SKILL_USAGE_BINDING_MISSING
LATEST_PRODUCT: SKILL_ASSEMBLY_REQUIRED
CLASSIFICATION: REAL CORE GAP
```

---

# 13. SkillCompositionV1 不能冒充 usage binding

`SkillCompositionV1` 负责 Root Skill/Subskill/composition/capabilities/cycle rules，是 Skill 内部结构，不是 Skill 被外部对象使用的关系。

禁止：

```text
Workflow uses Skill → mutate SkillComposition
Glyth uses Skill    → mutate SkillComposition
Composer uses Skill → mutate SkillComposition
```

---

# 14. generic Relation 也不能直接顶 Skill usage

current Relation endpoint仅允许：

```text
artifact
note
scope
view
workspace
```

没有 Skill。

如果 T6/Core 最终决定复用 Relation，必须一起处理：

```text
Domain RelationEntityType += skill
project membership validation
route validation
MutationSafety / ChangeSet
recovery
search/index
projection consumers
delete/disable behavior
version pin semantics
```

T4 不能直接 POST 一个 `kind:'skill_usage'` 然后假装 Core 已经理解。

---

# 15. T6/Core 必须裁决的四类 Skill usage

## Workflow
必须回答绑定到 Workflow Scope 还是具体 Action/Step；version pin 在哪里；Step 删除、Skill 升版如何处理。

## Composer / Run
latest freeze要求 Composer attach existing Skill/version。要明确 Run draft/snapshot canonical field、version pin、历史 Run 回看原版本的语义。

## Glyth / Conversation
必须决定 durable conversation capability/context 的 canonical owner，是扩 Relation 还是专用 capability binding，以及 disable/delete/rename/version-bump 的恢复行为。

## Ordinary target
必须决定哪些 canonical object 能接、admission 谁算、binding truth 谁存。

T4 在 canonical usage落地前只允许做：

```text
Skills category
catalog read/search
preview
drag preview
admission failure reason
```

Commit 必须 fail-close，禁止 local array/Zustand/localStorage/fake toast success/package copy。

---

# 16. Skill Builder 与 Skill Assembly 要分开 readiness

current Core 已有：

```text
SkillCatalogService
SkillPackageService
SkillCompositionV1
SkillProposalService
SkillAuthor proposal flow
version bump
rename
install
disable/enable
validate
```

因此：

```text
Skill Builder Domain adapter = READY / THIN-WRAP
Skill external Assembly usage = HOLD on Core binding verdict
```

不能因为 usage gap 就把整个 Skill 功能一起冻死。

---

# 17. Project identity · Core truth 已存在

current Core 已有 project list/create/open/read 等 route，web-gen2 已有 `CoreProjectClient.listProjects()` 与 `getProjectGraph(projectId)`，Gen2Host 已消费 `CoreProjectClient`。

所以：

```text
NO NEW ProjectRepository
NO NEW ProjectIdentity canonical store
```

真正缺的是：

```text
Project Launcher / Portal
→ selected canonical projectId
→ LcosProjectSessionProvider
```

current `CenterArea.tsx` 仍从 `import.meta.env.PROJECT_ID` 读取并 fallback 到 `disposable-mvp-sample`，只能作为 development/migration bridge，不能固化成最终产品 owner。

---

# 18. SurfaceRegistry current status

已有：

```text
apps/web-gen2/src/spatial/surfacePort.ts
apps/web-gen2/test/surfacePort.test.ts
```

定义 main/context/workflow，同 project 下 distinct canvasId，并靠不同 Huabu canvas identity 隔离 camera/selection/history。

但 current production仍是：

```text
/canvas/:canvasId
→ CanvasPage
→ CenterArea
→ useLcosCanvasProps
```

尚没有完整：

```text
Surface navigation
→ SurfaceRegistry.current(surface)
→ runtime.retarget(surface.canvasId)
```

因此：

```text
SurfaceRegistry = FOUND / TESTED
Production Surface consumer = MISSING / UNWIRED
```

施工方向是 LIFT existing contract + wire real consumer，不新增第二 Surface model。

---

# 19. WorkView / ProjectSession / Surface 的最终 owner 分层

```text
ProjectSession
├─ ONE LCOS runtime
│  └─ retarget(current Surface.canvasId)
├─ ONE WorkViewSession
│  └─ survives Surface switch
└─ current Surface
   └─ independent Huabu canvas/camera/selection/layout/history
```

WorkView 不复制 Surface state，也不存 camera。

---

# 20. MainLayout exact tests

现有：

```text
huabu/apps/web/src/pages/CanvasPage/MainLayout.test.tsx
```

已经覆盖 420px default right width、right resize > half viewport、fullscreen unmount Canvas、two-frame restore。

WorkView controlled width直接扩同一测试：

```text
controlled width respected
controlled resize emits callback
ordinary Preview still 420px
fullscreen behavior unchanged
WorkView close restores Preview own width
resize causes no camera mutation
```

Stable `WorkViewPresentationLayer` 另测 body identity：

```text
FLOATING→DOCKED same instance
DOCKED→IMMERSIVE same instance
IMMERSIVE→basePlacement same instance
Surface retarget same WorkView body
target change may create a new body
```

---

# 21. T1 safe-region exact handoff

旧成熟 A25 已有：

```text
activeSpatialViewport.ts
useObservedActiveSpatialViewport.ts
```

generic protocol：

```html
data-spatial-viewport-occupant="left|right|top|bottom"
```

T4 `WorkViewDockSlot` 只需：

```html
data-spatial-viewport-occupant="right"
```

T1 负责 LIFT active viewport aggregate。T4 不建 `safeRegion.ts`、`workViewOccupiedStore.ts`、`hudInsetStore.ts`。

Floating WorkView 不缩 active viewport，只参与 overlay collision；否则 safe viewport 会跟自由窗口一起乱跳。

---

# 22. Assembly WorkView 与 stable layer

Dedicated Workspace / Docked Source Bay / Quick Tray 必须共享 source/target identity。Docked→Immersive、Docked→Floating 都保留同一个 body/session。

不要创建：

```text
AssemblyDocked.tsx
AssemblyImmersive.tsx
AssemblyFloating.tsx
```

各自持有 state。

---

# 23. Product target → Core target 需要薄 adapter

产品 target 不等于 backend union原样暴露。

示例：

```text
Main Surface        → { kind:'main' }
Context Surface     → { kind:'context', id: scopeId }
Workflow Surface    → { kind:'workflow', id: scopeId }
Glyth/Conversation  → { kind:'conversation', id: connectedConversationId }
Saved worksite      → current Core workspace/scene compatible ref
```

最终 Workspace vs Scene 的用户命名继续服从最新冻结，不由 Assembly service 决定。

---

# 24. ExactFile 候选

## MODIFY

```text
huabu/apps/web/src/App.tsx
huabu/apps/web/src/pages/CanvasPage/CenterArea.tsx
huabu/apps/web/src/pages/CanvasPage/CanvasPage.tsx
huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
huabu/apps/web/src/pages/CanvasPage/MainLayout.test.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
```

## ADD · T4

```text
huabu/apps/web/src/lcos/session/LcosProjectSessionProvider.tsx
huabu/apps/web/src/lcos/workview/WorkViewPresentationLayer.tsx
huabu/apps/web/src/lcos/workview/WorkViewDockSlot.tsx
huabu/apps/web/src/lcos/workview/workViewModel.ts
huabu/apps/web/src/lcos/LcosRightSurfaceHost.tsx
```

`LcosRightSurfaceHost = mux only ≠ WorkView body owner`

## ADD · Assembly web seam

current `apps/web-gen2/src/backend/assembly.ts` 不存在，因此可新增薄 `CoreAssemblyClient`，只封：

```text
GET warehouse
POST assembly/apply
```

不要塞 Skills/Capture/Relation/Presentation mutation，已有 owner 继续存在。

---

# 25. Cross-thread exact handoff

## T4 → Shell/Project Launcher

需要：

```text
canonical selected projectId
```

不需要新 Project schema/backend/catalog truth。

## T4 → T6/Core

需要：

```text
Workflow Skill usage owner
Composer/Run Skill selection owner
Glyth/Conversation Skill durable binding owner
ordinary target capability binding owner
```

并明确 identity/version/mutation/ChangeSet/recovery/disable-delete-update/cross-project。

在这个 handoff完成前：

```text
T4 Skill Assembly Commit = BLOCKED
```

## T4 → T1

```text
T1 LIFT A25 activeSpatialViewport
T4 WorkViewDockSlot emits right occupant
```

双方不新增第二 safe-region truth。

## T4 → T3/T5

T3/T5负责 Action Arc visual/open action；T4只提供 `openWorkView(target, projection)` / `openAssembly(target)`，Action Arc 不知道 MainLayout width、DockSlot、Motion rect 或 CoreAssemblyClient。

---

# 26. Current E2E readiness

## Non-Skill Assembly · READY candidate

```text
select target
→ Action Arc Assembly
→ Docked Source Bay
→ query Warehouse/Capture
→ hover preview
→ drag supported source
→ target admission
→ POST assembly/apply
→ Core ChangeSet/relation/membership
→ projection reconcile
→ restart
→ remains applied
```

## Skill Assembly · HOLD

current最多真实做到：

```text
open Assembly
→ Skills
→ query catalog
→ preview Skill/version
→ drag toward target
→ truthful unsupported/admission state
```

最终产品 E2E：

```text
drag Skill
→ canonical durable usage
→ restart
→ still bound
→ pinned version visible
```

必须等 T6/Core closure。

## Project continuity · PARTIAL

目标链：

```text
Launcher
→ CoreProjectClient.listProjects
→ selected projectId
→ ProjectSessionProvider
→ SurfaceRegistry main canvas
→ runtime retarget
→ WorkView open
→ Context
→ Workflow
→ Main
→ WorkView survives
→ each Surface restores own camera
```

当前缺 Launcher/Shell production wiring 与 SurfaceRegistry production consumer。

---

# 27. Anti-second-truth checklist

```text
WorkView owns Project catalog?                 NO
SurfaceRegistry owns camera?                  NO
Assembly owns Warehouse truth?                NO
Skills copied into Warehouse table?           NO
Skill usage stored in localStorage/Zustand?   NO
Conversation Context inferred by proximity?   NO
Workflow material drop auto-creates Action?   NO
Workspace and Main merged into one target?    NO
Assembly category becomes Core entity?        NO
Floating WorkView becomes right safe inset?   NO
Docked WorkView creates new safe-region store? NO
SkillComposition doubles as usage binding?    NO
```

---

# 28. Readiness

## READY / STRONGLY CONVERGED

```text
Project Core catalog truth
ProjectSession ownership direction
SurfaceRegistry contract reuse
Assembly Warehouse feed
Capture feed
Skill catalog read
AssemblyApply thin web client
non-Skill Source×Target matrix
MainLayout controlled-width seam
DockSlot safe-region protocol
WorkView stable body owner
```

## HOLD

```text
Skill external usage binding
Project Launcher product wiring
SurfaceRegistry production navigation wiring exact file
final Workspace vs Scene user-facing naming
```

---

# 29. Final plan 仍 STOP

T4 最终正本仍受 Mandatory Read Completion 约束。目前仍缺 exact raw originals：

```text
LCOS_v015_原文到后续施工计划_差分审计_20260831.md
LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md
LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md
LCOS_三大视图组件体系筛选表_v01_20260821.md
LCOS_v0.15_R3D_SkillArtifact_SkillBuilder_CrossSurface_Freeze_20260830.md
LCOS_v015_Context_Workflow_Component_CameraFocus_审判与收敛_20260831.md
LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md
LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md
LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md
```

因此不能宣称 `FINAL SOURCE-LEVEL CONSTRUCTION PLAN`。

---

# 30. 下一轮最值得继续的审计

```text
1. SurfaceRegistry → production navigation exact wiring
2. Project Launcher / Portal 的 Gen1 + current Core consumer
3. Assembly Workspace / Source Bay 与 current Huabu shell exact composition
4. Context four instruments exact read/write adapters
5. Workflow canonical mutation owner
6. Skill usage binding 等待 T6/Core或继续排查可复用现存对象
7. Mandatory Read Completion ledger
```

一句话裁决：

> T4 已经不需要设计“一套新的 Assembly 架构”。Core 已经给了 canonical refs、Warehouse、Capture、Skill Catalog、统一 apply router、ChangeSet、Presentation membership、Working-set membership 与 Conversation Context relation。第四路真正要做的是把这些 truth 接成同一个连续 WorkView Source Bay，并在 Skill usage truth 缺失处诚实停住，而不是替 Core 编一个成功故事。
