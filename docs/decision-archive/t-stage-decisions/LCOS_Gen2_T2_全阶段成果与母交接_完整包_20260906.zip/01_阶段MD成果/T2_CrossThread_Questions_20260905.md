# LCOS Gen2 · T2 Cross-Thread Questions I Must Not Decide

日期：2026-09-05  
线程：T2 · Navigation / Railway / Arrival / Focus

> 这些不是“没做完”，而是 T2 按六路职责主动拒绝越权。

---

# Q1 · Long-term Worksite / Child Canvas 的 canonical contract 到底是什么？

**问题：**  
Gen2 中“一份以后还能回来继续的长期工作现场”以及真正有独立 canvas identity / camera / layout / history 的 Child Canvas，最终由哪个 Core contract 承接？

**为什么不属于我：**  
T2 负责 Enter / Return / Railway / Arrival UX，不负责 canonical identity/schema。

**我已经确认的局部事实：**

- 08-14 Workspace / Current Scene 已经表达长期可恢复现场；
- 09-05 Long-term Worksite / Child Canvas 继续保留此产品心智；
- old Workspace runtime 带 scopeId/camera/focusedViewIds 等过载字段；
- Huabu-first 禁止 old workspace viewport 成为 Gen2 spatial truth。

**需要谁回答：**  
T6 + Coordinator。

**我明确不会做的假设：**

```text
child canvas == old Workspace interface
```

---

# Q2 · 当前 Core WorkspaceState / WorkspaceMembership API 的历史状态是什么？

**问题：**  
现有 `workspace-state-service.ts`、`routes/workspace-states.ts` 应标 CURRENT_TRUTH、LEGACY_COMPAT、migration substrate 还是未来退休？

**为什么不属于我：**  
这是 Core persistence / migration / truth ownership。

**我已经确认的局部事实：**

- Core routes/service 当前仍存在；
- current web-gen2 没找到可靠 workspace-state typed consumer；
- `backend/projects.ts` 明确 legacy workspace geometry 只能读，不能成为 Huabu spatial truth。

**需要谁回答：**  
T6。

**我明确不会做的假设：**

- “没找到 web consumer = API 已死”；
- “API 还活着 = 就是 Gen2 Long-term Worksite owner”。

---

# Q3 · `/view-rail-order` 如何迁移到 Gen2 Railway ontology？

**问题：**  
当前 durable order 机制值得保留，但 item kind 仍是 `scene|collection|context|workflow`。Gen2 如何表示 Main/Context/Workflow + long-term worksite + compatibility item？

**为什么不属于我：**  
T2 定义 Railway UX，不定义 Core durable schema / migration。

**我已经确认的局部事实：**

- CAS/restart/dedupe 机制成熟；
- old flat ontology 已被产品冻结推翻；
- Collection/Scope 不自动成为 Rail item。

**需要谁回答：**  
T6 + Coordinator。

**我明确不会做的假设：**  
直接新增 `worksite` 字段或新表。

---

# Q4 · Context / Workflow 什么时候 materialize 成 long-term nested worksite？

**问题：**  
Context 时间块、事情块、Workflow 当前工作区域，在什么明确用户动作后才成为长期可返回 worksite？

**为什么不属于我：**  
这是 Context/Workflow 产品语义 + canonical materialization。

**我已经确认的局部事实：**

- Context 时间块点击只临时查看，不自动建 worksite；
- Workflow 是否独立由用户决定，不自动 materialize；
- materialized 后 T2 可以负责 Rail entry / enter / back。

**需要谁回答：**  
T4 + T6 + Coordinator。

**我明确不会做的假设：**  
节点数量、停留时长、首次点击等隐式规则自动创建 worksite。

---

# Q5 · Child Worksite 的 projection / placement 创建规则是什么？

**问题：**  
对象通过 Railway / portal 给到 child worksite 时，目标空间增加 same canonical object projection 的具体 geometry、placement、membership contract 是什么？

**为什么不属于我：**  
T2 负责 remote destination UX；T1 负责 spatial placement，T6 负责 truth/projection。

**我已经确认的局部事实：**

- remote worksite target 更适合 semantic transfer / target projection + source home；
- no clone；
- Huabu owns geometry。

**需要谁回答：**  
T1 + T6。

**我明确不会做的假设：**  
Railway Drop = move canonical entity / delete source projection。

---

# Q6 · Back stack 的 durable 范围是什么？

**问题：**  
parent↔child / long-term worksite navigation 的 Back stack 是 session-only、project presentation state，还是可持久恢复？

**为什么不属于我：**  
T2 可以定义 UX，但不能决定 durable state ownership。

**我已经确认的局部事实：**

- Back 产品动作历史长期存在；
- old `Scope.parentScopeId` owner 已过时；
- Enter 与 Locate 必须区分。

**需要谁回答：**  
T6 + Coordinator。

**我明确不会做的假设：**  
复活 `scopePath` / `parentScopeId`。

---

# Q7 · Work View occupiedRect / safeRect 的公共 contract 谁提供？

**问题：**  
Work View Float/Dock/Resize 后，T2 的 Search/Focus/Pin/Locator/Minimap 通过什么 public seam 获得 occupiedRect / safeRect？

**为什么不属于我：**  
T4 owns Work View lifecycle；T1/Huabu owns spatial viewport mechanics；T2 是 consumer。

**我已经确认的局部事实：**

- open/resize 不自动 Camera move；
- HUD 必须避让；
- explicit Focus/Locate 才 safeRect-aware reframe。

**需要谁回答：**  
T4 + T1（必要时 Coordinator）。

**我明确不会做的假设：**  
通过 DOM query / hardcoded right-panel width 偷读布局。

---

# Q8 · Old Workspace restore 中 membership side effect 是否继续有效？

**问题：**  
旧 `WorkspaceStateService.restore()` 会恢复 memberships。这种“恢复现场同时修改 membership”的行为在 Gen2 语义下是否仍合法？

**为什么不属于我：**  
属于 Core truth / recovery semantics。

**我已经确认的局部事实：**

- 最新产品把 membership、projection、worksite 明确拆层；
- old Workspace runtime 曾把它们混在一起。

**需要谁回答：**  
T6 + Coordinator。

**我明确不会做的假设：**  
“恢复 worksite”天然等价于“重写 canonical membership”。

---

# Q9 · Archived object 的 Focus / Locate 应该定位什么？

**问题：**  
Archive 已释放 Main 旧 x/y。用户 Search/Focus 到 archived object 时，T2 应显示哪种 location/restore affordance？

**为什么不属于我：**  
Archive truth/lifecycle 和 archived projection availability 不归 T2。

**我已经确认的局部事实：**

- archived object 仍 Searchable / Referenceable；
- old Main x/y 明确不保留；
- Locator 不能指向幽灵坐标。

**需要谁回答：**  
T6 + T4 + Coordinator。

**我明确不会做的假设：**  
自动 Restore 或复用 archive 前旧位置。

---

# Q10 · SurfaceDock 与 Railway 是否都允许切 Main/Context/Workflow？

**问题：**  
历史上 SurfaceDock 是一级三视图切换，Railway 也能表示当前 Surface/Scene。Gen2 最终是否两处都允许直接切三 Surface，还是 Railway 只做 identity/receiving？

**为什么不属于我：**  
这是跨产品导航一致性，T2可以提出最佳 UX，但需 Coordinator 确认避免双入口心智冲突。

**我已经确认的局部事实：**

- Gen1 两者长期共存；
- 08-21 SurfaceDock 明确是一级 Surface switcher；
- Railway 是持续项目级 navigation skeleton；
- 当前 HTML 双入口只是验证，不应自动冻结。

**需要谁回答：**  
Coordinator（T2 提方案，T5 最终视觉复核）。

**我明确不会做的假设：**  
因为两个入口都能技术实现，就一定都保留同等交互权重。

---

# Q11 · Huabu Canvas Tools 哪些可以纯手势/快捷键，哪些必须保留显式 secondary UI？

**问题：**  
Select / Pan / Lasso / Frame / Note / Text / Sketch / Question / Resources 的最终入口策略是什么？

**为什么不属于我：**  
T2负责 Chrome placement；工具自身 gesture/interaction owner 不全在 T2。

**我已经确认的局部事实：**

- V2 禁止为实现方便制造模式；
- Gen1 SurfaceDock 已明确 bottom-center 优先给三视图；
- current Huabu toolbar mechanics成熟，但 presentation不应自动成为 LCOS 一级 Chrome。

**需要谁回答：**  
T1 / T3（tool gesture）+ T2（placement）+ T5（final visual）。

**我明确不会做的假设：**  
“压进次级入口”= 直接删除所有显式入口。

---

# Q12 · Grid Snap / Lock 是否最终属于 Spatial Navigator？

**问题：**  
Gen1 MiniMap曾包含 Grid Snap，Huabu current Controls 又有 interactivity Lock。最终 Spatial Navigator cluster 应吸收哪些 current-view controls？

**为什么不属于我：**  
T2能定义 cluster UX，但 Lock/Snap 对 pointer/interaction 的具体含义归 T1/Huabu tool owner。

**我已经确认的局部事实：**

- Zoom/Fit/100% 与 Minimap 同属“怎么看这里”，历史已验证；
- Grid Snap / Lock 更接近 interaction policy，不能仅因位置相邻就合并。

**需要谁回答：**  
T1 + T2；T5 final visual。

**我明确不会做的假设：**  
所有左下控件都必须机械塞进 Minimap。

---

# 收口

T2 阶段 A 可以在以上 OPEN 项未最终裁决时继续完成：

- UX 场景；
- donor / presentation 选择；
- owner 边界；
- exact target source 的 consumer audit。

但不能把任何 OPEN 项写成 canonical施工事实。

