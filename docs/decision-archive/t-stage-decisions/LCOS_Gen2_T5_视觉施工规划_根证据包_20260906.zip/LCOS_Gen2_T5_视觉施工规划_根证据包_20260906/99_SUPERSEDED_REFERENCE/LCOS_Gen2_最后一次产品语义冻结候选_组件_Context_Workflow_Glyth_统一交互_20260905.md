# LCOS Gen2 · 最后一次产品语义冻结候选
## 组件 / Context / Workflow / Glyth / Collection / Scope / 子画布 / 统一输入与拖放
日期：2026-09-05

> 目标：作为 Gen2 最后一次产品语义收敛候选。
> 原则：冻结“用户怎么理解、怎么操作、屏幕发生什么”，不冻结 Gen1 当时糟糕的代码实现。
> 后续 T1-T6 与 T5 视觉打磨只能在这些语义边界内工作，不能再反向改产品心智。

---

# 0. 总原则

LCOS 尽量只让用户做天然动作：

- 看到 → 点
- 想拿 → 拖
- 想给另一个东西用 → 拖过去
- 只想借过去用、不想搬 → 右拖
- 想建立明确关系 → 拉连接
- 想说一句话 → 点到文字位置直接打
- 想让 Agent 做复杂事情 → 把相关东西给它，再用自然语言说明目标

复杂的 SQL、JSON、Markdown、上下文整理、工作流定义、API 调用等，优先交给本地 Agent / 外部 Agent / API 执行。

LCOS 固定代码负责身份、保存、关系、投影、拖放、导航、Run/Result、Undo/Recovery。
需要语义理解的判断尽量交给 Agent。

---

# 1. 组件在 Gen2 中的最终地位

组件不再等于“画布里的一张小功能卡”。

分两类：

## 1.1 空间整理工具

例如：
- Stack
- Gallery
- Grid
- Masonry
- Arrange
- Frame / Region
- Align / Distribute

它们就是画布工具，可以长期保持画布内形态。

## 1.2 专业工作工具

例如：
- Context Atlas
- 时间演进查看
- 关系查看
- 来源追踪
- Workflow 查看/整理
- Skill Builder
- Web / PDF / HTML 深度查看
- Conversation 深度查看

它们不是新的项目内容，而是“查看、整理、操作已有项目内容的方法”。

同一个专业工具可以有多种工作深度：

画布轻量形态
→ 拿近看
→ 停靠工作
→ 沉浸/大工作区
→ 关闭后回原现场

同一个对象只保留一个身份。不能因为查看方式不同就复制出多份对象。

---

# 2. T5 的最终边界

产品逻辑冻结后，T5 可以调整：

- 外观
- 图标
- 圆角
- 透明度
- 材质
- 颜色
- 阴影
- 动效
- 呼吸
- 反馈
- 比例
- 面板占比
- HUD 避让
- LOD 外形

但 T5 不允许再改变：

- Context 是什么
- Workflow 是什么
- Glyth 是什么
- Collection 是什么
- 什么时候进入子画布
- 一个 Drop 到底是什么意思
- 是否创建第二份数据

一句话：
**T5 可以改“长什么样”，不能再改“为什么存在”。**

---

# 3. 三个一级工作空间

只保留：

- Main：项目真实材料与自由工作的总现场
- Context：这个项目目前到底“知道了什么”
- Workflow：这件事接下来到底“怎么继续做”

三者继续共用同一套基本操作：
选择、多选、拖动、搜索、定位、Pin、Composer、Work View、右键、返回。

不能让用户感觉进入三个不同的软件。

---

# 4. Context 最终结构

## 4.1 默认按时间分区

Context 的默认总览按时间组织。

用户可以改变每块代表的时间长度，例如：
- 6 小时
- 12 小时
- 24 小时
- 1 天
- 3 天
- 1 周

项目只用了四天时，可以看到四个日区。
项目用了几周，可以按周看，也可以重新放大到天。

区域大小可随该时间段内容量变化。
具体视觉强弱和形态由 T5 决定。

产品逻辑只冻结：
**区域首先表示一段时间。**

## 4.2 第二种地图：按“事情”分

项目里自然会出现一件一件长期工作：

开始讨论
→ 计划
→ 尝试
→ 执行
→ 中断 / 完成
→ 复盘

即使跨很多天，本质上仍然是一件事。

因此 Context 还允许“按事情 / 主题”查看。

这不靠死规则计算，由本地 Agent 根据：
Conversation、Artifact、Run、Decision、Result、时间、引用关系、语义连续性
判断哪些内容属于同一件事。

## 4.3 时间地图与事情地图的关系

它们不是两套 Context，只是同一批项目内容的两种看法：

Context
├── 按时间看
└── 按事情看

默认按时间，因为时间稳定、确定。

“按事情”是 Agent 生成的整理视图。
Agent 的自动归类默认不能偷偷改变项目结构。

如果用户觉得某个事情值得长期保存，可以显式：
- 固定为集合
- 整理为 Workflow
- 建立长期工作区

---

# 5. Context 的“面 / 线 / 点”

## 面
整个项目的 Context 总览地图。
默认按时间，也可以切换 Agent 的事情地图。

## 线
看某件事情 / 某个判断怎么演进：
最早怎么想
→ 中间怎么改
→ 哪次对话推翻了什么
→ 哪次执行产生新结论
→ 最后稳定成什么

## 点
进入某个具体范围继续整理和工作，仍然是自由空间。

一句话：
**面看全局，线看变化，点做细活。**

Context 不按 GPT / Codex / WorkBuddy 分区。
Agent / Conversation 只作为来源、贡献者、历史参与者出现。

---

# 6. Context 区域点击与长期工作区

点击时间区域或事情区域：
→ 先聚焦 / 查看这一块。

进一步打开：
→ 进入该时间段 / 事情的详细 Context 工作现场。

这个详细现场默认可以先是临时查看。

只有用户明确说：
“这块我要长期单独做”
才正式成为长期工作区。

这样不会随着项目使用变久自动生成几百个子画布。

---

# 7. Workflow 最终定义

Workflow 不是流程图软件，不是 BPMN、n8n、DAG Builder、Step Form。

Workflow 是：
**从真实项目现场里抽出来的一段“值得单独继续做”的工作。**

它仍然是自由画布。

最自然的来源：
- Main
- Context
- Conversation
- 某个集合
- 某个当前工作区域

用户选中一批东西，然后“整理为 Workflow”。

不是：
新建空白 Workflow → 再回去一个个找材料。

---

# 8. 多选 → 整体 Drop → 形成集合

Gen1 / J1 之前这条产品语义本身保留。

用户多选 A/B/C/D，整体拖到对应接收入口，可以形成一个长期内容集合。

重要：
- A/B/C/D 仍然属于整个 Project；
- 它们同时属于这个 Collection；
- 不是复制四份对象；
- Collection 不等于子画布；
- Collection 不自动制造独立 camera/history。

之前失败的是实现，不是这条语义。

---

# 9. Collection / Scope / 子画布彻底区分

## Collection

最白话：
**这些东西长期算一组。**

它是一种长期内容归类。

对象加入后：
仍属于整个项目 + 同时属于这个集合。

Collection 本身不必有独立画布。

## Scope

最白话：
**我现在这次工作，只看 / 只处理这一范围。**

它更像当前工作边界。

Scope 不意味着：
- 新归属
- 新项目
- 新数据库
- 新长期实体

它首先是一个工作范围。

## 子画布 / 长期工作区

最白话：
**这件事我要单独开一个长期桌面继续干。**

只有用户明确需要：
- 自己的视野
- 自己的布局
- 自己的历史
- 长期成员
- 下次回来继续

才形成长期工作区。

Collection、Scope、子画布是三件事。

---

# 10. Collection / Workflow 什么时候独立成长期工作区

不是代码偷偷判断，也不是内容达到某个数量自动生成。

核心规则：
**用户决定。**

Agent 可以建议：
“这批东西积累很多了，要不要整理成集合 / Workflow / 长期工作区？”

但不自动执行。

用户可以直接语义指挥本地 Agent：
“帮我把这些整理成一个 Workflow。”

Agent 负责识别材料、结果、参与 Conversation 和建议结构。
用户采用后才成为正式结构。

---

# 11. Workflow 里的动作到底要多显性

动作要看得见，但不能比材料和结果更抢眼。

用户真正关心：
- 我拿了什么
- 做了什么关键事情
- 现在做到哪
- 谁在做
- 出了什么结果

不是系统内部调用了多少工具。

## 三级显示

### 一级：默认只显示关键动作

例如：

参考图 / 竞品链接
→ [整理视觉方向]
→ [生成初稿]
→ 初稿.md
→ [Review]
→ 最终稿.md

“整理视觉方向 / 生成初稿 / Review”可以只是短标签、小图标或动作锚点，不做巨大卡片。

### 二级：选中 / Hover 才展开必要信息

例如：
- 谁执行
- 使用哪个 Skill
- 状态
- 输入
- 输出

默认不常驻。

### 三级：真正审计时才打开深度工作区

查看：
- Run 日志
- Tool call
- 参数
- Provider
- 失败重试
- 原始输出

这些不污染 Workflow 主画面。

---

# 12. Workflow 主画面

不是：

Step1 → Step2 → Step3 → Step4

更像：

材料 A / 网页 B / Context C
        ↓
    [关键动作]
        ↓
      结果 D
        ↓
     [Review]
        ↓
      结果 E

旁边有当前承接的 Glyth。

自由摆放。
必要关系可见。
不强制左到右。
不强制 DAG。

---

# 13. Workflow 与 Glyth

冻结成一句：

**Workflow 是“这件事怎么做、做到哪了”。  
Glyth 是“现在谁来接着做”。**

一个 Workflow 可以先交 GPT，后来换 Codex，再后来交 WorkBuddy。

Workflow 不复制，只是当前承接者变化。

Workflow 可以提炼成 Skill，但 Workflow ≠ Skill。

---

# 14. Glyth 的局部交互

Glyth 是 Conversation 的空间身份，不是 Agent 信息卡。

## 第一次点
→ 选择 Glyth。

## 已经选中后再点
→ 出现通用 Action Arc + Compact Composer。

## 双击
→ 进入同一段 Conversation 的深度工作状态。

---

# 15. Glyth 双击后的深度工作状态

不是一个死板固定页面。

允许三种工作区域同时存在：

- Conversation 子画布
- Conversation / Glyth 深度预览
- Assembly 装配

例如屏幕暂时分成三块。

用户可以：
- 关 Assembly
- 关 Conversation 预览
- 两个都关
- 只留子画布
- 之后再重新打开其中任意一块

这不是三个不同页面，而是同一 Conversation 深度工作现场里的三个可组合区域。

具体占比、排布、浮动、Dock、动效、视觉交给 T5/T4。

产品只冻结：
**三者可以并存、可独立开关、共享同一 Conversation identity。**

---

# 16. 多选后的 Composer

冻结：
**多选完成后，不自动弹 Composer。**

用户可能只是：
- 整理布局
- 移动
- 对齐
- 形成集合
- 批量拖放

正确：
多选 → Selection 保持  
需要 AI Work → 用户再点 Composer / AI Work。

同理：
- Drag 不自动打开 Composer；
- Right-drag 不自动打开 Composer；
- Move 不自动触发 AI。

---

# 17. 大工作区已经打开时，本地 UI 怎么共存

冻结：
**不动 Canvas。**

打开 / resize 大工作区：
- Canvas camera 不自动移动；
- Canvas world 不重新布局。

变化的是屏幕上的 HUD / 浮动 UI，例如：
- Action Arc
- Composer
- Locator
- Minimap launcher
- Focus feedback

它们根据剩余可用屏幕区域重新避让。

空间太小时：
- 收紧
- 折叠
- 换边
- 暂时隐藏低优先级 UI

但不要为了 UI 自动移动用户画布。

---

# 18. 所有有身份的东西默认都能拖

包括：
- Artifact
- File
- Image
- Web
- Conversation / Glyth
- Context item
- Workflow
- Skill
- Collection
- Result
- Reference-capable object

可以：
- 拖出去
- 拖进来
- 拖到另一个对象
- 拖到 Rail
- 拖到 Assembly
- 拖到 Composer Reference

工具按钮本身不是项目内容，不要求当作数据对象拖。

---

# 19. 统一拖动语言

## 左拖到空白
= 搬。对象留下。

## 左拖碰到有明确接收语义的目标
= 给 / 加入 / 使用。

例如：
- Artifact → Glyth = 给这段 Conversation 长期使用
- Artifact → Collection = 加入集合
- Artifact → Workflow = 加入这段工作
- Skill → Workflow = 给它使用这个 Skill

如果语义不是 Move，原对象回到原来的空间位置。

## 右拖
= 借过去用，但别动原对象。

拖 ghost / proxy，原对象从头到尾不移动。

## 拉 Relation handle
= 明确建立项目关系。

---

# 20. 所有文字输入都应该有同一种感觉

能直接打字的地方，就直接点进去打字。

用户看到光标闪烁就可以输入。

不要：
点文字 → 弹 Modal → 选字段 → 开表单 → 确认。

普通输入统一：
- inline
- caret
- direct typing
- Enter / blur 完成
- Esc 撤销当前编辑

视觉由 T5。

---

# 21. 不为复杂内容造一堆专用编辑器

例如：
- SQL
- JSON
- Context 文件
- Workflow spec
- Prompt config
- 转换脚本

LCOS 默认不是让用户亲手维护这些。

更自然：

把相关对象给本地 Agent + 说：
“这个 SQL 应该用这些数据，帮我整理。”

Agent 生成 SQL / MD / JSON / API 调用结果，再作为 Artifact 返回 LCOS。

如果确实需要专业编辑，再进入原生 / 专业 Work View。

主 LCOS GUI 不要变成代码 IDE、JSON Form Builder 和数据库客户端的集合。

---

# 22. Context / Workflow 同样由 Agent 负责复杂整理

Context：
用户选中这些 → 告诉 Agent“这些属于这件事，帮我整理”。

Agent 可返回：
- Markdown
- JSON
- 摘要
- 结构化 Context
- 关系建议

Workflow：
用户表达：
- 这些是输入
- 这件事要做到什么
- 谁来做
- 结果回来哪里

机器执行 DSL、API 节点、SQL 等交给 Agent / Skill / API。

---

# 23. 最终操作哲学

所有新功能先问：

用户能不能通过：
**点、拖、丢、直接打字、说一句自然语言**
完成？

如果可以：
不增加向导、模式切换、表单、Chooser。

只有目标真的存在歧义时，才出现一次非常轻的临时选择。

---

# 24. 后续不得再反复的冻结项

1. 只有 Main / Context / Workflow 三个一级空间。
2. Context Atlas 是 Context 首页，不是第四个一级空间。
3. Context 默认按时间分区。
4. 时间颗粒度可调。
5. Agent 可提供“按事情”的第二种 Context 地图。
6. Agent 事情地图默认是派生视图，不自动改项目真相。
7. Context 面看全局、线看演进、点做细活。
8. Context 不按 Agent 分区。
9. Workflow 是从真实工作中抽出来的一段独立工作，不是流程图软件。
10. Workflow 继续是自由画布。
11. Workflow 动作默认只显示关键动作，不显示底层执行细节。
12. Workflow 可从 Main / Context / Conversation / Collection 整理出来。
13. 是否独立成 Workflow / 长期工作区由用户决定；Agent 只能建议。
14. Workflow 可换 Glyth 承接，但不属于某个 Glyth。
15. Workflow 可提炼 Skill，但 Workflow ≠ Skill。
16. Collection = 长期内容分组。
17. Scope = 当前工作范围，不是长期归属。
18. 子画布/长期工作区 = 用户明确要独立长期工作时才出现。
19. Collection 不自动等于子画布。
20. 多选后不自动弹 Composer。
21. Drag / Right-drag 不自动弹 Composer。
22. Glyth 第一次点 = Select。
23. 已选中 Glyth 再点 = Arc + Composer。
24. 双击 Glyth = 进入同一 Conversation 的深度工作现场。
25. Glyth 深度现场可同时容纳子画布 / Conversation 预览 / Assembly，三者可独立开关。
26. Work View 打开后不移动 Canvas camera。
27. HUD / local UI 根据剩余屏幕区域避让。
28. 所有有身份的项目对象默认可拖。
29. 左拖空白 = 搬。
30. 左拖明确目标 = 给 / 加入 / 使用。
31. 右拖 = 借过去用但原对象不动。
32. Relation handle = 连。
33. 能直接输入文字的地方统一 inline caret 输入。
34. 不为 SQL / JSON / Context / Workflow DSL 默认造专用复杂编辑器。
35. 复杂语义整理优先交给本地 Agent / 外部 Agent / API。
36. LCOS 首要目标是直觉化操作与最少操作步骤。

---

# 25. 还需要继续确认的少数问题

如果以上冻结成立，真正还值得继续产品讨论的只剩：

1. Context 时间区域进入后，默认先是临时详细视图，还是立即长期 worksite。
   - 本稿倾向：先临时，用户明确保存后才长期。

2. Agent 的“事情地图”如何让用户修正错误归类。
   - 倾向：简单拖动、合并、拆分，再让 Agent 重新理解；不做复杂 taxonomy editor。

3. Workflow “关键动作”最低显示到什么粒度。
   - 倾向：只显示用户能理解的工作动作；Tool Call / 底层步骤进入深度视图。

4. Glyth 三块深度工作区域默认初始布局。
   - 这是视觉/空间施工问题，交给 T5/T4，不再改语义。

除此之外，不建议继续扩大产品讨论面。

---

# 26. 最白话总结

Main：
东西都在这里。

Context：
这个项目到现在知道了什么。默认按时间看，也可以让 Agent 按一件一件事情整理。

Workflow：
把项目里一段值得继续做的工作单独拿出来。

Collection：
这些东西长期算一组。

Scope：
这次只处理这些。

子画布：
这件事我要单独开桌长期干。

Glyth：
这段持续 Conversation / 这个一起干活的人。

Assembly：
我要给当前工作拿什么材料和能力。

组件：
不是新内容，是看和操作这些内容的工具。

最后只坚持一个目标：

> 用户尽量只需要点、拖、丢、直接打字、说一句话。
> 复杂结构让 Agent 和成熟工具去处理。
