# LCOS Gen2 · T4
## Assembly Source Bay · Canonical Apply · Skill Binding Gap Matrix

日期：2026-09-05  
源码锚点：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`

状态：
```text
SOURCE-LEVEL GAP MATRIX
NOT FINAL CONSTRUCTION PLAN
```

## 0. 总结

Assembly 并不是“后端没做”。

current source 已经有三层成熟能力：

```text
1. Assembly Source/Target canonical ref contract
2. Warehouse read model + Skill Catalog read model
3. AssemblyApply unified canonical routing
```

真正剩余的大缺口集中在：

```text
Skill usage-binding mutation
+
部分 contract/query 与 current HTTP parser 的覆盖差
```

所以第四路不能重做 Assembly domain，只需要把已有 read/write seam 吃干净，并把 Skill gap 明确交给 Core/T6。

---

## 1. AssemblySourceRefV1 已覆盖 Source Bay 四来源

current `packages/contracts/src/assembly.ts` 明确说明 Source Bay 四来源：

```text
Project
Capture
Sources
Skills
```

统一 source ref 包括：

```text
artifactView
capture
resource
conversation
context
workflow
scene
collection
skill
note
```

Skill ref 已经有：

```ts
{
  kind: 'skill'
  id: string
  source: 'system' | 'user' | 'merged'
  version?: string
}
```

因此 UI 不应再定义另一个 `AssemblySkillItemV2` identity。

---

## 2. Target contract 已覆盖主要 Assembly 入口

`AssemblyTargetRefV1`：

```text
project
main
workspace
conversation
context
workflow
scene
```

其中源码已明确：
```text
main = Project Main Presentation
不是 active Workspace 别名

scene.id = workspaceId
通过 working-set membership
```

前端不得把 Main 与当前 Huabu canvas/workspace 混为一谈。

---

## 3. Warehouse 是 Project material read projection，不包含 Skill truth

`WarehouseEntityKindV1` 当前只有：

```text
artifact
note
conversation
resource
context
workflow
scene
collection
```

没有：
```text
skill
capture
```

这是正确设计，不是漏字段。

因为 Source Bay 的四来源并不是一张 warehouse table。

正确组合：

```text
Project material
→ WarehouseService

Capture
→ Capture staging source

Sources
→ Resource / connector projections

Skills
→ SkillCatalogService
```

Assembly UI 可以把它们视觉上放进同一个 Source Bay，但数据 owner 仍分开。

---

## 4. Warehouse current route

current：
```text
GET /projects/:id/warehouse
```

支持：

```text
search
kinds
provenance
limit
cursor
```

`WarehouseQueryV1` contract 还定义：

```ts
usedHereTarget:
  workspace
  | scope
  | conversation
```

但 current HTTP parser 只真正接受：

```text
workspace:<id>
```

所以状态：

```text
CONTRACT:
workspace / scope / conversation

CURRENT ROUTE:
workspace only
```

前端 typed client 第一阶段不能声称 scope/conversation usedHere 已可用。

---

## 5. AssemblyApply 是统一路由，不拥有 mutation

current `AssemblyApplyService` 源码明确：

> sourceRef + targetRef → existing canonical services

它自己不拥有第二套 membership。

已有 canonical routes：

```text
capture
→ materializeToProject
→ optional surface membership

artifactView
→ workspace/scene
→ working-set membership + ChangeSet

artifactView
→ main/context/workflow
→ presentation membership + ChangeSet

note/context/workflow/collection/scene
→ surface entity membership

resource
→ canonical descriptor
→ artifact view
→ existing membership route

source
→ conversation
→ conversation_context relation
```

这正是 Gen2 应该直接收编的薄路由。

---

## 6. placement 与 semantic membership 已正确分层

`AssemblyApplyRequestV1` 已有：

```ts
placementBySource?: Record<
  sourceId,
  { x: number; y: number }
>
```

current contract 冻结：

```text
新 member:
semantic membership + placement
可进入同一 ChangeSet

already-member:
纯位置更新
不制造新的 semantic ChangeSet
```

因此 T4 不需要另起：

```text
AssemblyDropGeometryService
```

空间 placement 最终仍由 Huabu/Presentation projection承接，semantic truth由 Core mutation承接。

---

## 7. Skill 当前是“三层一绿一红”

### GREEN 1 · Contract

`AssemblySourceRefV1` 已支持 skill。

### GREEN 2 · Read Catalog

current route 已有：

```text
GET /projects/:id/skills
GET /projects/:id/skills/:skillId
```

SkillCatalogService 提供 list/read。

### GREEN 3 · Source Bay UI 可浏览

因此 Assembly 的 Skills source category 有真实 data source。

### RED · Apply / Usage Binding

current `AssemblyApplyService` 明确：

```text
skill → unsupported
```

源码旧裁决文字：
```text
Skills are read-only in v0.15
usage-binding deferred
```

但最新 2026-09-05 产品冻结已经要求：

```text
同一个 Skill
可用于 Workflow Step
Composer
Glyth
ordinary capability target
保持同 skillId/version
不复制 package
```

因此：

```text
CURRENT SOURCE BEHAVIOR
≠ LATEST PRODUCT FREEZE
```

产品冻结优先。

---

## 8. Skill gap 的正确归属

T4 禁止做：

```ts
onDropSkill(() => {
  localStore.bindSkill(...)
})
```

也禁止：

```text
把 Skill copy 成 Artifact
把 Skill package复制进 target
新增 frontend SkillBinding truth
```

需要 T6/Core 明确 canonical usage-binding semantics。

最低需要回答：

```text
binding identity是什么
target types有哪些
skillId/version/source如何持久化
同一Skill多目标使用如何表示
删除目标是否删除Skill本体
version更新是否自动跟随
Run/Composer如何读取binding
```

T4 只消费最终 canonical mutation。

---

## 9. Assembly UI 的真实 Source Bay adapter

候选：

```text
SourceBay
├─ Project
│  └─ Core Warehouse
│
├─ Capture
│  └─ Capture staging read source
│
├─ Sources
│  └─ Resource/connector read projections
│
└─ Skills
   └─ Skill Catalog
```

UI 可以统一卡片/瀑布流视觉，但不要统一成一个 fake database。

---

## 10. Lovart donor 正确使用点

Lovart 适合借：

```text
Masonry density
material browser
thumbnail hierarchy
Source Bay visual grouping
drag affordance
search/filter visual hierarchy
```

不借：
```text
proprietary source code
其内部业务 taxonomy
其持久化模型
```

工程数据流仍走 LCOS canonical read models。

---

## 11. T4 typed client 建议

ADD：
```text
apps/web-gen2/src/backend/assembly.ts
apps/web-gen2/src/backend/skills.ts
```

`assembly.ts` 只负责：
```text
queryWarehouse(projectId, supported params)
applyAssembly(request)
```

`skills.ts` 只负责：
```text
listSkills(projectId, search?)
readSkill(projectId, skillId)
```

在 Skill mutation landing 之前：
```text
NO applySkillBinding()
```

不得写一个调用不存在 route 的“未来 client method”。

---

## 12. Fail-close UX

如果用户拖 Skill 到 target，而 canonical Skill binding 尚未落地：

```text
前端必须 fail-close
```

不能：
```text
假装成功
只在 UI 显示已安装
稍后再说
```

施工阶段可以隐藏/disable该 mutation affordance，或者明确开发态 unsupported；最终产品上线前必须由 Core gap收口。

---

## 13. Exact status matrix

| Source | Read | Canonical Ref | Apply to Main/Context/Workflow | Apply to Scene | Apply to Conversation |
|---|---|---|---|---|---|
| Artifact/View | GREEN | GREEN | GREEN | GREEN | GREEN |
| Resource | GREEN | GREEN | GREEN via canonical view | GREEN via canonical view | GREEN via canonical view |
| Capture | GREEN/other source | GREEN | GREEN after materialize | GREEN after materialize | current unsupported |
| Note | GREEN | GREEN | GREEN | GREEN | GREEN |
| Context/Workflow/Collection/Scene aggregate | GREEN | GREEN | GREEN | partial/by ruled combinations | GREEN |
| Conversation source | GREEN | GREEN | unsupported direct membership | unsupported | target semantics only |
| Skill | GREEN Catalog | GREEN | **RED usage-binding** | **RED usage-binding** | **RED usage-binding** |

---

## 14. Blocker classification

```text
Assembly browsing:
READY

Assembly Project material:
READY

Assembly Capture:
MOSTLY READY

Assembly Sources/resources:
READY

Assembly canonical apply:
MOSTLY READY

Assembly Skills browsing:
READY

Assembly Skill use/install:
BLOCKED ON CORE CANONICAL USAGE-BINDING
```

---

## 15. 本轮一句话

> **Assembly 不是一个新仓库，它是多个 canonical source 的统一操作面。Warehouse 只是一种 source；Skill Catalog 是另一种 source；真正缺的只有 Skill “怎么被使用”的 canonical 写入语义，不是 Skill “怎么被看到”。**
