# LCOS v0.15 / Gen2
## Context × Workflow × Glyth × Assembly × Railway 重新收敛总稿
### 旧冻结恢复、2026-09-05 新讨论整合与总规划拆单输入

**日期：2026-09-05**  
**文档性质：产品架构/UX 收敛候选 + 跨线程交接，不是最终施工正本**  
**用途：交给总规划线程，用于重新拆分 Context、Workflow、Glyth、Assembly、Railway、Semantic Drop 与三 Surface 的施工责任。**

---

# 0. 先给总判断

这一轮不是单独改 Context，也不是单独改 Workflow。

真正需要重新收敛的是以下几件事之间的关系：

```text
Main
Context
Workflow
Glyth / Conversation
Assembly
Unified Work View
左侧 WorkspaceRail / Railway
Scope / Collection / 子画布 / 长期 Workspace
Semantic Drop
Skill
```

本轮建议形成的总产品心智是：

```text
Main
= 整个项目真实材料与自由工作的总现场

Context
= 把来自所有 Conversation / Agent / Material 的上下文
  从“分散在不同会话里”抽出来，形成项目级统一理解

Workflow
= 从 Main / Context / Conversation 中抽出
  一段具有独立价值、可以继续工作、转交、复用、提炼 Skill 的工作现场

Glyth
= Conversation / Agent 在项目空间里的身份
  它不是 Context 本身，也不是 Workflow 本身

Assembly
= 项目共享仓库 / 来源与目标之间的装配工作区
  可以给 Main / Context / Workflow / Glyth / Skill 等目标装配材料和能力

Railway
= 三大 Surface、长期工作现场、Receiver 和跨 Surface 拖放的持续导航骨架
```

最关键的新变化：

> **Context 不再考虑“围绕某一个 Glyth 建整个世界”。**

相反：

> **Context 的价值恰恰是把不同 Glyth / Conversation / 本地 Agent 中分散的 Context 抽出来，变成一个统一可管理的项目 Context。**

而：

> **Workflow 可以比以前更强地围绕 Glyth / Conversation / Receiver 工作。**

因为 Workflow 描述的是：

> 这一段工作是什么、谁来接、怎么继续、是否值得独立保存、是否能提炼成 Skill。

这和 Conversation / Agent 的“承接者”身份天然更接近。

---

# 1. 先恢复旧冻结：之前到底是什么状态

## 1.1 三个 Surface 从来不是三个不同软件

最新冻结一直要求：

```text
Main
Context
Workflow
```

是三个独立工作现场。

它们各自拥有：

```text
surfaceId
canvasId
camera
selection
layout
history
```

但共用：

```text
同一 Huabu 空间物理
同一 Selection
同一 Drag / Drop
同一 Pointer grammar
同一 Orbit / Action Arc
同一 Composer
同一 Search / Focus / Pin
同一 Work View lifecycle
```

因此：

> 三个 Surface 的差异来自“工作语义”，不是三个完全不同的 UI 世界。

这条本轮继续保留。

---

# 2. 之前 Context 并不是“整个围绕 Glyth”

用户本轮回忆中有一部分是对的，但需要区分两个历史概念。

## 2.1 后来冻结的 Context Surface

截至 2026-09-02，Context 的最新冻结是：

> “理解项目”的自由空间。

主要能力是：

```text
Structure
Evolution
Relationship
Source / Provenance
```

也就是说：

```text
Context
= 项目理解现场
```

不是：

```text
Context
= 某一个 Conversation 的附属页面
```

Glyth 可以出现在 Context，但不是整个 Context Surface 的唯一中心。

---

## 2.2 为什么会记得“围绕 Glyth”

此前确实有过一个非常强的 Glyth / Conversation scene 设想。

Glyth 是：

> Conversation / Agent 的空间身份。

单击 Glyth：

```text
Select + Orbit
```

双击 / Enter：

```text
进入 Conversation scene / 对话工作现场
```

进入这个 Glyth 的长期工作现场后，可以看到：

```text
它自己的 Artifact
它引用的材料
它产生的 Context
它参与 / 产生的 Workflow
历史产出
Run / Review
详细关系
```

所以历史上确实存在：

> “围绕一个 Glyth 看它自己的项目世界”

但它准确来说属于：

```text
Conversation / Glyth 子画布 / 长期工作现场
```

不是整个项目级 Context Surface。

---

# 3. 本轮新建议：把这两个旧方向重新放到正确位置

现在可以重新整理成：

```text
Project
│
├── Main
│   └── 项目真实材料与自由组织
│
├── Context
│   ├── Context Atlas
│   ├── Evolution Wave
│   └── Context Spatial Canvas / 子现场
│
├── Workflow
│   ├── Workflow Worksite A
│   ├── Workflow Worksite B
│   └── ...
│
└── Conversations
    ├── Glyth A
    ├── Glyth B
    └── Glyth C
```

其中：

- Context 汇总所有 Glyth / Conversation / Agent / Material 的 Context；
- Workflow 可以有明确的 Glyth / Receiver / participants；
- Conversation 子画布仍然可以查看“这个 Glyth 自己参与了什么”；
- 三者使用同一 Project identity，不复制项目对象。

---

# 4. Context 新主 UX：Atlas + Wave + Spatial Canvas

上一轮已经形成新的 Context 候选：

```text
面 = Context Atlas
线 = Evolution Wave
点 = Context Spatial Canvas
```

这轮进一步建议：

> **Context Atlas 不必硬塞成自由画布中的一块小 Component。**

它可以成为：

> Context Surface 的“总览工作态 / Context Home”。

体验上可以接近 Assembly Dedicated Workspace：

- 使用整个主要可用区域；
- 可平移 / 缩放；
- 可下钻；
- 可以打开 Work View；
- 可以选一个区域后跳到对应 Context 子画布；
- 保持左 Railway、导航、Search、Focus、Pin 等 LCOS 外壳；
- 不成为第四 Surface。

---

# 5. Context Atlas 不是第四 Surface

这一点必须明确。

不建议新增：

```text
Main
Context
Workflow
Atlas
```

四个一级 Surface。

正确关系更像：

```text
Context Surface
│
├── Context Home / Atlas
│
├── Context scope worksite A
├── Context scope worksite B
└── ...
```

Atlas 是：

```text
Context 的项目级总览 projection / instrument
```

而不是新的 domain world。

---

# 6. Atlas 选中区域后怎么进入自由画布

用户本轮提出：

> 在总 Context Map 中选中某一区域后，自由跳到对应自由画布上的子画布。

这个方向和现有“长期工作现场 / 子画布”的冻结非常兼容。

建议逻辑：

```text
Atlas region click
→ Focus region

Atlas region open / double click / Enter
→ resolve target Context scope

若已有长期 Context worksite
→ 进入对应 canvasId

若没有，但该 scope 确实需要独立：
→ materialize 一个长期 Context worksite
```

只有满足以下条件才应该创建独立子画布：

```text
需要独立 camera
需要独立 layout
需要独立 history
需要长期成员 / context
```

不能：

> 每点一个 Treemap 小块就自动创建一个新 Canvas。

否则一个项目十分钟后拥有 387 个“长期工作现场”，人类文明又多一种文件夹灾难。

---

# 7. 点 / 线 / 面到底是不是 Component

本轮建议重新定义 Component / Instrument 的产品边界。

以前容易形成：

> Component = 拖进画布的一块东西。

这太窄。

更合理的是：

> **Instrument 是一套针对同一 target / scope 的专业观察或编辑能力。**

它可以拥有不同 presentation state：

```text
SPATIAL
→ 在自由画布里作为局部 Instrument

FOCUS
→ 拿近看

DOCKED
→ 持续工作

IMMERSIVE / DEDICATED
→ 大面积专业工作界面

RESTORE
→ 回到原空间
```

也就是说：

> Component / Instrument 不需要永远被关在自由画布的小矩形里。

---

# 8. 这解决了过去 Surface Component “很无聊”的问题

此前 Component 之所以逐渐显得没用，是因为它经常变成：

```text
自由画布
+
一块小白卡
+
里面放一个迷你 SaaS
```

用户本轮判断是对的：

如果 Component 永远只能是一块 Canvas widget，

那么除了：

```text
Stack
Gallery
Arrange
```

这类空间整理工具以外，大量专业功能都没有必要存在。

因此建议：

## 8.1 纯空间 Component

继续留在画布：

```text
Stack
Gallery
Arrange
Frame / Region 等真实必要空间 primitive
```

## 8.2 专业 Instrument

允许：

```text
Spatial body
+
Dedicated / Work View renderer
```

例如：

```text
Context Atlas
Evolution Wave
Relationship Inspector
Source / Provenance Inspector
Workflow Inspector
Skill Builder
```

它们不需要硬塞进一张小白卡。

---

# 9. Web / PDF / HTML 等对象也应遵守相同原则

用户本轮提出：

> 网页等对象也应该同时拥有画布节点方式和更自由 / 专业的查看方式。

这其实与既有冻结一致，可以进一步统一为：

```text
同一个 Entity
│
├── Spatial Body
├── Focus View
├── Docked Work View
└── Immersive / Native / Live View
```

例如 Web Artifact：

```text
远距
→ identity / concise body

正常
→ page preview / card / live thumbnail

Focus
→ 更大的可读网页

Work View / Immersive
→ 完整 live web / source / fragment / provenance
```

身份不变。

不建立：

```text
WebNode
WebViewerObject
WebWorkbenchObject
```

三份对象。

---

# 10. Assembly 在新体系里的角色

Assembly 原有冻结继续成立：

> **Assembly 是项目级共享仓库，不是第四 Surface，也不是所有 Component 的父容器。**

它已经有三种形态：

```text
Dedicated Workspace
Docked Source Bay
Quick Tray
```

Source Bay 可以浏览：

```text
Artifacts
Context
Workflow
Skills
Collections
Conversations
Workspaces
```

它表达的是：

> 从项目现有内容和能力里找东西，然后装到当前 target。

---

# 11. 不应该把“所有大 Instrument”都叫 Assembly

本轮可以借 Assembly 的：

```text
大工作界面形态
自由 resize
docked / dedicated
material browsing
drag / drop
target continuity
```

但不要语义偷懒，最后变成：

```text
Context Atlas = Assembly
Workflow Editor = Assembly
Web View = Assembly
```

正确方式是：

> 复用 Unified Work View / Dedicated Workspace 的机械能力，不复用 Assembly 的领域语义。

---

# 12. Glyth 与 Assembly：旧裁决继续保留

已有明确冻结：

```text
选择 Glyth
→ Orbit / Action Arc
→ Assembly
→ Docked Source Bay
```

当前 target 是：

```text
这个 Glyth / Conversation
```

从 Source Bay 拖：

```text
Artifact / Fragment / Context / Workflow / Skill
→ Glyth
```

可以形成持久的：

```text
Conversation Context Mapping
```

但这不是给 Glyth 创建私人仓库。

所有来源仍然来自同一个 Project Assembly registry。

---

# 13. Context 与 Glyth 的新关系

本轮建议正式从：

```text
Context 围绕 Glyth
```

改成：

```text
Context 汇总并显示 Glyth 来源
```

原因就是 LCOS 的根本价值之一：

> 把分散在 ChatGPT、本地 Agent、网页 Chat、Codex、WorkBuddy 等 Conversation 中的 Context 抽出来，形成一个项目级统一 Context。

因此 Context 里的材料可以显示：

```text
来源 Glyth / Conversation
```

但不要做信息卡。

更适合：

```text
Glyth silhouette / identity glyph
+
极短 Conversation name
```

例如：

```text
● GPT · Gen2重构
● Codex · Renderer Audit
● Buddy · Donor Census
```

这是 provenance / ownership cue。

不是：

```text
一张 Conversation Info Card
```

---

# 14. 一个 Context 对象可以来自多个 Glyth

重要：

不能默认：

```text
Context item
→ owner = 一个 Glyth
```

真实情况可能是：

```text
Source A → Glyth 1
Source B → Glyth 2
Decision C → Human
Revision D → Run 7
```

所以 Glyth identity 更像：

```text
origin / contributor / participation
```

而不是 Context hierarchy 本身。

Atlas 可以在 Focus / inspect 时显示：

```text
这个区域主要由哪些 Conversation / Source 贡献
```

但不把 Context 分区直接按 Agent 名字切碎。

---

# 15. Workflow 新方向：它不是一个独立低代码产品

用户本轮对 Workflow 提出了一个更清晰的心智：

> Workflow 是从项目主现场中“抽出一段值得独立存在的工作”。

典型触发：

### 情况 A：一段工作将来可能复用

例如：

```text
竞品收集
→ 视觉归纳
→ 脚本生成
→ Review
```

这段工作本身有复用价值。

### 情况 B：一段工作可以提炼 Skill

Workflow 可以成为：

```text
Skill candidate
```

但 Workflow ≠ Skill。

### 情况 C：Main 太杂，需要把其中一段工作整理出去

Main 某一区域 / Scope：

```text
材料
决策
Agent 对话
产出
Review
```

已经形成独立工作单元。

可以：

```text
Extract / Organize as Workflow
```

### 情况 D：Conversation 中形成了一套稳定做法

某个 Glyth / Conversation：

```text
反复执行同一套工作
```

可以从 Conversation scene 提炼为 Workflow。

---

# 16. Workflow 应继续是一张自由画布

这轮不建议把 Workflow 改成：

```text
BPMN
n8n
DAG Builder
流程表单
```

它继续共享 Main / Context 的空间语法：

```text
自由摆放
选择
拖拽
复制 / 粘贴
关系
Reference
Semantic Drop
Focus
Pin
Composer
Work View
```

区别是：

> Workflow Surface 的默认工作对象是“一段正在被组织成行动的工作”。

---

# 17. Workflow 中什么最重要

建议把视觉层从过去的：

```text
Step
Step
Step
线
Step
```

重新转成：

```text
工作材料
+
关键 Action
+
决定 / Checkpoint
+
Run / Result
+
Review
+
Glyth / Receiver
+
可提炼 Skill
```

Action Path 仍可以存在。

但它只是：

> 把真实 Action / intent / execution record 连接成工作骨架。

不是整个 Workflow 产品的唯一视觉母题。

---

# 18. Workflow 与 Main 的关系：Extract，不是“重新搭”

这是本轮很重要的新方向。

用户不应该为了创建 Workflow：

1. 新建空白 Workflow；
2. 再回 Main 找材料；
3. 一个一个拖进去；
4. 再重新接一遍。

应该允许：

```text
Main Selection / Scope / Region
→ Organize / Extract as Workflow
```

或：

```text
Agent proposal:
“这一片已经形成一段独立工作，是否整理为 Workflow？”
```

用户 Preview：

```text
采用哪些材料
采用哪些 Action
保留哪些 Relation
哪些只是空间邻近
哪个 Conversation / Glyth 参与
有哪些 Result / Review
```

确认后创建 / 更新 Workflow。

---

# 19. Agent 可以帮用户整理，但不能偷偷改 truth

用户本轮提出：

> 让 Bot / Agent 帮忙把 Main 或子画布里冗杂内容整理成 Workflow。

这与已有 Reorganize / Proposal / Review 原则兼容。

建议：

```text
Selection / Scope
→ Ask Agent: Organize as Workflow

Agent
→ Workflow Proposal

Preview
→ 用户删 / 加 / 调整

Commit
→ Core Workflow truth + projections
```

Agent 不应该：

> 看到几个节点靠得近，就擅自宣布“恭喜，它们已经是 Workflow”。

---

# 20. Workflow 与 Glyth 应该比 Context 更强关联

本轮认为这是一个非常有价值的重分工。

可以用一句话：

> **Workflow 是“做什么”；Glyth 是“谁接这段工作”。**

Workflow 可以有：

```text
Primary Receiver
Participants
Origin Conversations
Recent Runner
Review / handoff targets
```

但 Workflow 本身不归属于某一个 Glyth。

---

# 21. Workflow 可以创建新 Glyth 或接回已有 Glyth

用户提出：

> 可以新建一个 Glyth 接管 Workflow，也可以把 Workflow 重新接到项目里已经链接过的 Conversation。

这个方向与已有 canonical Receiver 设计非常匹配。

候选 UX：

```text
Workflow
→ Assign / Continue with...

[ Existing Conversation / Glyth ]
[ New Conversation ]
[ Current Receiver ]
```

选择已有 Glyth：

```text
Workflow target
→ existing Conversation
```

新建：

```text
Create / connect Conversation
→ new Glyth
→ set as receiver / participant
```

重要：

不要复制 Workflow。

只是改变：

```text
receiver / participation / context mapping / run target
```

具体 canonical mutation 需 Core + Agent/Glyth owner 裁决。

---

# 22. Workflow 的 Glyth 不应变成大信息卡

Workflow 现场里，Conversation / Agent 的身份建议仍然使用：

```text
Glyth body / silhouette
+
短名称
+
必要的最高优先状态
```

例如：

```text
◉ GPT · 当前承接
○ Codex · 上次执行
○ Buddy · 贡献来源
```

不需要：

```text
Agent Card
Model
Provider
Token
Run count
Last active
...
```

所有细节进入 Orbit / Work View。

---

# 23. Workflow 与 Skill 的关系

Workflow 可以：

```text
继续作为 Workflow
```

也可以经过显式提炼：

```text
Workflow
→ Teach / Extract Skill
→ Skill Proposal
→ Skill Builder
→ canonical Skill Artifact
```

但不能：

```text
保存 Workflow = 自动变成 Skill
```

因为：

```text
Workflow
= 一段项目工作现场 / 行动结构

Skill
= 可移植、可版本化、可复用的方法包
```

两者强相关，但不是同一个 Entity。

---

# 24. Workflow 与 Assembly 应该强相关，但不能合并

Workflow 天然是一个强 Assembly target。

例如：

```text
Workflow
→ Assembly Source Bay

加入：
Artifact
Context
Skill
Conversation
Collection
已有 Workflow 部分
```

也可以：

```text
Assembly
→ 找到 Workflow
→ 放入 Main / Context / Conversation /另一个 Workflow
```

但 Assembly 仍然是：

> 仓库。

Workflow 仍然是：

> 工作现场。

---

# 25. 可以把 Glyth Assembly 的“角色道具栏”心智更明显地用于 Workflow

此前对 Glyth Assembly 的比喻很像：

```text
项目仓库
↔
角色当前装备 / Context / Skill
```

这个心智在 Workflow 里可能更有价值。

因为 Workflow 本身可以清晰显示：

```text
这段工作有哪些材料
有哪些 Context
使用哪些 Skills
由谁接
有哪些 Outputs
```

所以：

> Glyth / Workflow target 的“当前装备”可以通过 Assembly 更直接管理。

但不要建立：

```text
Workflow 私有仓库
Glyth 私有仓库
```

仍然只有：

```text
Project Assembly
```

---

# 26. 左 Railway：现在应该重新成为整体结构的关键连接器

最新冻结已经明确：

左 Railway 不退休。

它负责：

```text
Main / Context / Workflow
长期 Workspace
当前现场身份
成员 / Conversation preview
Active Receiver
跨 Surface drop
```

本轮建议进一步明确它的层级：

```text
Project
│
├── Main
│   └── pinned / recent Main worksites
│
├── Context
│   ├── Atlas / Context Home
│   └── pinned / recent Context scopes / worksites
│
├── Workflow
│   └── Workflow A / B / C ...
│
└── Receiver / Conversations
    └── 当前 Glyth identity / reachable conversations
```

具体视觉不必做成 Windows Explorer 树。

Rail 仍要保持轻。

---

# 27. Atlas 应该怎么进 Railway

建议：

```text
Context
→ 一级 Surface entry
```

点击 Context：

```text
恢复上次 Context 状态
```

如果是第一次 / 用户主动点 Context Home：

```text
进入 Atlas
```

Atlas 可以作为：

```text
Context 的 Home / overview
```

而不是 Rail 新增第四个一级入口。

---

# 28. Workflow 在 Railway 中怎么表现

Workflow 本身更适合有长期工作项。

例如：

```text
Workflow
├── 冰箱白膜生成
├── Gen2 donor audit
└── Skill extraction
```

这些是：

```text
长期 Workflow worksite / scope
```

不是 UI tab 临时状态。

用户可 Pin / recent / search。

---

# 29. 三 Surface 与 Railway 必须保持导航同构

用户本轮强调：

> Context / Workflow 不能让人感觉进入三个完全不同界面。

继续冻结：

```text
Rail
Search
Focus
Pin
Locator
Minimap / map semantics
Back / Arrival
Portal
Work View
Composer
```

在三个 Surface 中保持同一心智。

差异只来自：

```text
Main = 材料
Context = 理解
Workflow = 行动
```

---

# 30. 最容易混乱的部分：Drop 必须拆成四层

这一轮必须交给总规划重新画一张正式 Semantic Drop matrix。

## 30.1 项目归属

外部材料第一次进入 LCOS：

```text
Web Capture / local file / external source
→ materialize
→ Project canonical object
```

这是：

```text
进入项目
```

---

## 30.2 Surface projection

已有项目对象从 Main 拖到 Context / Workflow：

```text
same canonical object
→ target Surface projection
```

不是复制对象。

这是：

```text
在另一个现场出现
```

---

## 30.3 Scope / Collection membership

项目对象拖进一个 Scope / Collection：

```text
existing project object
+
membership relation
```

对象仍然属于整个 Project。

同时也属于这个 Scope。

所以用户本轮的记忆：

> “拖到子集里以后，它既在项目里，也在这个子集里。”

方向是正确的。

---

## 30.4 Conversation Context Mapping

对象拖到 Glyth body：

```text
Conversation
长期携带 / 可使用这个项目对象
```

这是：

```text
durable Conversation Context Mapping
```

不等于 Scope membership。

---

## 30.5 Per-run Reference

对象拖到 Composer：

```text
只给当前 Run 使用
```

Run 结束后不会自动变成长久 Conversation Context。

---

# 31. Railway drop 应该根据目标类型明确语义

建议总规划重新冻结类似下面的矩阵：

| Drop target | 建议含义 |
|---|---|
| Main root | 在 Main 创建/恢复 projection |
| Context root | 在 Context 当前/默认工作现场创建 projection |
| Workflow root | 进入 Workflow 的 placement / adoption 流程，不能默认造新 Workflow truth |
| 某 Surface worksite | 在那个 canvas 创建 projection |
| Scope / Collection | 添加 membership；必要时同时创建目标 projection |
| Glyth | Conversation Context Mapping |
| Composer | current Run Reference |
| Assembly target | 走 target admission rule |
| 外部 Capture → Rail | 先 materialize 到 Project，再按上述 target intent 处理 |

最终字段 / mutation 以现有 Core contract 为准。

---

# 32. “Drop 到 Context = 进入整个项目 Context”需要修正

这句旧心智容易造成问题。

更准确的说法应该是：

> 对象首先是 Project object。

Context Surface 是：

> 对 Project object 的理解 / Context projection。

Scope 是：

> 项目对象之间的某个正式范围 / membership。

Conversation Context 是：

> 某 Conversation 长期携带什么。

这四层不要再混用“Context”一个词。

---

# 33. Main / Scope / 子画布之间的关系

可以用一个最简单例子：

```text
Project
└── Main
    ├── Artifact A
    ├── Artifact B
    └── Scope X
        ├── A
        └── B
```

A / B：

```text
Project canonical object
```

Scope X：

```text
membership
```

如果 Scope X 需要长期独立工作：

```text
Scope X
→ materialize worksite canvas
```

于是：

```text
Rail
Main
└── Scope X worksite
```

但：

> Scope X 本身和它的 worksite canvas 不是两份 domain entity。

---

# 34. Context Atlas 如何利用这些 Scope

Context Atlas 很适合把：

```text
Project Context scope
Collection
Context grouping
Conversation contribution
Revision density
Relation density
```

投影成区域。

点击某区域：

```text
Focus
```

打开：

```text
Context worksite
```

这就把：

```text
Atlas 总览
↔
自由 Context Canvas
```

自然接起来了。

---

# 35. Workflow 也可以由 Main Scope 提炼

同样：

```text
Main Scope X
```

如果它已经不是单纯“这一堆东西放在一起”，而是：

```text
有明确工作目标
有输入材料
有 Action
有结果
有 Reviewer
有可复用方法
```

用户 / Agent 可以提出：

```text
Extract as Workflow
```

Workflow 不需要等价于原 Scope。

可以引用同一批 canonical objects。

---

# 36. Workflow 不应自动复制 Main 的全部空间布局

提炼 Workflow 时：

需要区分：

```text
Domain adoption
vs
Presentation layout
```

有些 Main 空间位置只是用户临时摆放。

不能因为两个节点相邻：

```text
→ 自动认为 Action 顺序
```

旧冻结也明确：

> Workflow 中位置变化不能偷偷改变执行顺序。

因此 Extract proposal 应明确列：

```text
引用哪些对象
形成哪些 Action / relation
保留哪些材料
哪些 spatial relation 只是 presentation
```

---

# 37. Context / Workflow / Conversation 子画布可以共存

最终结构不需要互斥。

例如一个 Project：

```text
Main
│
├── Scope A
└── Scope B

Context
│
├── Atlas
├── “Gen2前端” Context worksite
└── “Donor审计” Context worksite

Workflow
│
├── “Context donor census”
└── “Phase A smoke”

Conversation
│
├── Glyth GPT
└── Glyth Codex
```

它们都可以引用：

```text
同一个 Artifact
同一个 Skill
同一个 Context scope
同一个 Workflow
```

只是在不同现场拥有不同 spatial projection。

---

# 38. Search / Focus / Pin 继续跨三 Surface

新 Atlas / Workflow worksite 不应发明独立导航系统。

例如：

```text
Cmd/Ctrl+F
→ Search project object

结果在 Context Atlas
→ Focus 对应 region

结果在 Workflow A
→ 可以跳到 Workflow worksite

F
→ 当前 selection “在哪”
```

Pin：

```text
同一 durable wayfinding intent
```

根据当前 Surface 使用合适 projection。

---

# 39. Context Atlas 与 Minimap / Locator 的关系

Atlas 是：

```text
Context 内容的语义地图
```

Minimap / Locator 是：

```text
当前 spatial worksite 的导航工具
```

二者不要合并。

用户可以：

```text
在 Context Atlas 看整个 Context topology
```

同时：

```text
在某 Context worksite 使用普通 LCOS Minimap / Pin / Locator
```

---

# 40. 本轮建议的 Context 新冻结候选

建议总规划重点审判以下 6 条：

### CANDIDATE-C1

> Context 仍然是三个一级 Surface 之一。

### CANDIDATE-C2

> Context Atlas 成为 Context Home / 项目级总览 Instrument，可以使用 Dedicated Workspace 级呈现，但不新增第四 Surface。

### CANDIDATE-C3

> 点 / 线 / 面是同一 Context truth 的不同 projection / 工作尺度，不是三个新 domain object。

### CANDIDATE-C4

> Context 不围绕单一 Glyth；Glyth 在 Context 中作为来源、贡献者、Conversation identity 与可导航对象出现。

### CANDIDATE-C5

> Atlas region 可以进入已有 Context worksite / 子画布；只有确有长期独立 camera/layout/history/context 时才 materialize 新 worksite。

### CANDIDATE-C6

> Structure / Evolution / Relationship / Provenance 不再必须是四个并列大型 App；可重组成 Atlas topology / Wave / overlay / inspection layer。

---

# 41. 本轮建议的 Workflow 新冻结候选

### CANDIDATE-W1

> Workflow 是“一段具有独立工作价值的项目现场”，不是低代码 DAG Builder。

### CANDIDATE-W2

> Workflow 可以从 Main / Context / Conversation / Scope 中 Extract / Organize 得到，不要求用户从空白画布重新搭。

### CANDIDATE-W3

> Workflow 继续是自由画布，并完整继承 Main / Context 的 Spatial、Selection、Drop、Navigation、Composer 与 Work View 语法。

### CANDIDATE-W4

> Workflow 与 Glyth / Conversation 强关联：Workflow 表达“做什么”，Glyth 表达“谁承接”。

### CANDIDATE-W5

> Workflow 可以交给新 Conversation / Glyth，也可以重新连接项目中已有 Glyth；Receiver / participants 是正式关系，但 Workflow 不从属于某一个 Conversation。

### CANDIDATE-W6

> Workflow 可以被提炼成 Skill，但 Workflow ≠ Skill；需要显式 Teach / Extract Skill proposal。

### CANDIDATE-W7

> Workflow 与 Assembly 强相关，是重要 Assembly target/source，但没有 Workflow 私有仓库。

### CANDIDATE-W8

> Workflow 的 Action Path 保留为真实行动骨架，但不再把“Step DAG”当唯一 UI 母题。

---

# 42. Instrument / Component 新冻结候选

### CANDIDATE-I1

> Component 不再被定义为“必须长期塞在画布里的 widget”。

更准确：

```text
Surface Instrument
= 对 target / selection / scope 提供专业能力的一套 projection
```

可以拥有：

```text
SPATIAL
FOCUS
DOCKED
IMMERSIVE / DEDICATED
RESTORE
```

### CANDIDATE-I2

纯布局 Component：

```text
Stack
Gallery
Arrange
```

继续作为 Canvas primitive。

专业 Instrument：

```text
Context Atlas
Evolution
Relationship
Provenance
Workflow detail
Skill Builder
```

允许进入大工作态。

---

# 43. Railway 新冻结候选

### CANDIDATE-R1

Railway 继续是：

```text
Main / Context / Workflow
+
长期 worksite
+
Receiver
+
cross-Surface drop
```

的唯一左侧持续导航骨架。

### CANDIDATE-R2

Context Atlas 不新增第四一级入口。

它是 Context Home。

### CANDIDATE-R3

长期 Context scope / Workflow 可以作为 Context / Workflow 下的 rail item、recent 或 pinned destination。

### CANDIDATE-R4

Glyth / Receiver 应在 Rail 中保持轻量身份可见，但不要把所有 Conversation 变成永远展开的大列表。

---

# 44. Semantic Drop 新冻结候选

总规划必须单独拆出一张 Semantic Drop / Admission plan。

至少区分：

```text
Project materialization
Surface projection
Scope membership
Conversation Context Mapping
Run Reference
Workflow adoption / extraction
Assembly admission
```

它们不能再都叫：

```text
“拖进去”
```

---

# 45. 需要总规划重新分配的责任

## T1 / Spatial Presentation / HUD / LOD / Layout

负责：

- Context Atlas 空间 body；
- 2D / 2.5D；
- world / screen transform；
- fixed-size identity；
- drill-down transition；
- Context / Workflow 与普通 Spatial Canvas 的同构；
- instrument Spatial → Focus 的物理体验；
- Work View occupiedRect；
- layout donor；
- navigation visual placement 的空间边界。

不负责：

- Workflow canonical semantics；
- Conversation receiver mutation；
- Context hierarchy truth。

---

## T4 / Work View / Assembly / Context / Workflow / Skill

这是本轮主要重新拆单 owner。

负责：

- Context Atlas 产品级 workflow；
- Atlas / Wave / Canvas 的 target continuity；
- Context instrument 重组；
- Workflow extract / organize / edit；
- Workflow ↔ Assembly；
- Workflow ↔ Skill；
- dedicated instrument / Work View lifecycle；
- Context / Workflow target adapters。

---

## Agent / Glyth / Conversation owner

需要负责：

- Workflow Primary Receiver；
- new/existing Glyth takeover；
- Conversation participation；
- Conversation Context Mapping；
- Conversation reachability；
- Glyth identity 在 Context / Workflow / Rail 的呈现 input；
- Run receiver。

---

## T2 / Navigation / Railway / Search / Focus / Pin

需要负责：

- Context Home / Atlas 在 Rail 的入口；
- Context/Workflow long-lived worksites；
- cross-Surface navigation；
- Search result → Atlas region / worksite；
- Focus / Where；
- Pin / Locator；
- Active Receiver visibility；
- Arrival / back stack。

---

## Semantic Drop / Composer / Relation owner

必须单独 cross-review：

- Rail drop；
- Surface drop；
- Scope admission；
- Glyth body drop；
- Composer reference；
- Workflow extraction；
- Assembly source → target；
- external Capture → project → target。

---

## Core / 后端

必须回答：

```text
Project object identity
Scope / Collection
Workflow canonical model
Workflow membership / refs
Receiver
Conversation participation
Context hierarchy
ContextSnapshot / Revision
Skill extraction
ChangeSet / Review
Projection Binding
```

哪些已有、哪些缺薄增量。

前端不得为了 UX 方便新造第二 truth。

---

# 46. 当前最值得总规划先解决的 8 个问题

## Q1

Context Atlas 到底是：

```text
Context Home
还是
一个可拖入任意 Context scope 的普通 Instrument
```

本稿倾向：

> 两者可以是同一 Instrument 的不同 projection，但 Context Home 是项目级默认入口。

## Q2

Atlas region 对应：

```text
Scope
Collection
Context derived cluster
还是多种 target 的 projection
```

必须由 Core census 决定。

## Q3

Workflow canonical identity 到底是什么。

不能直接假设旧 `workflow-step` / `active-path` 就是 Workflow 本身。

## Q4

Extract as Workflow 是：

```text
新 Workflow entity
还是已有 workflow scope / relation set
```

需源码审计。

## Q5

Workflow ↔ Glyth：

```text
primary receiver
participants
origin conversation
context mapping
```

分别用现有哪个 canonical relation / field。

## Q6

Rail drop 到 Workflow root 到底表示：

```text
仅 projection
加入当前 Workflow
打开选择 Workflow
还是生成 extraction proposal
```

不可凭 UI 猜。

## Q7

Scope / Collection / Worksite 三者目前 Core 的真实字段关系是什么。

## Q8

Instrument 的 Dedicated View 应完全复用 Unified Work View，还是某些如 Atlas / Assembly 需要 project-level dedicated workspace wrapper。

---

# 47. 本轮明确不要做的东西

在总规划重新拆清楚以前，禁止施工线程擅自新增：

```text
ContextAtlasEntity
ContextMapDB
WaveHistoryDB
WorkflowCanvasEngine
WorkflowPrivateWarehouse
GlythPrivateWarehouse
WorkflowStepEntityV2
AtlasSurface
FourthSurface
ContextAgentOwner
ComponentAppStore
RailMembershipStore
```

如果只是：

```text
projection
presentation
workspace
membership
target adapter
```

就不要升级成新的 canonical entity。

---

# 48. 用最白话重新描述整个 LCOS

如果本轮方向成立，用户看到的 LCOS 可以这么理解：

## Main

> 我的项目桌面。

所有真实材料都可以摊在这里，自由组织。

---

## Context

> 这个项目到底“知道了什么”。

它把各个 GPT、Agent、网页、文件、历史版本里散落的东西汇总起来。

很远：

```text
Atlas
```

想追历史：

```text
Wave
```

想继续整理：

```text
Context Spatial Canvas
```

---

## Workflow

> 这件事到底“怎么继续做”。

从 Main / Context / Conversation 抽出一段独立工作。

我可以：

```text
整理
编辑
换 Agent 接
继续执行
Review
复用
提炼 Skill
```

---

## Glyth

> 谁在项目里和我一起干活。

它代表真实 Conversation / Agent。

---

## Assembly

> 项目的仓库和装配台。

需要什么材料、Context、Skill、Workflow、Conversation，从这里拿。

---

## Railway

> 我现在在哪、还能去哪、谁正在接活。

三个 Surface 与长期工作现场始终使用同一导航。

---

# 49. 最终建议给总规划的拆单顺序

不建议现在马上让六个线程各写 patch。

先由总规划做四张裁决表：

## 表 A · Domain Identity

```text
Project
Scope
Collection
Context scope
Workflow
Worksite
Conversation
Skill
```

哪些是 canonical，哪些只是 projection / product label。

## 表 B · Projection / Workspace

每个对象可以出现在哪里：

```text
Main
Context
Workflow
Conversation worksite
Atlas
Assembly
Work View
Rail
```

以及是否拥有独立 canvasId。

## 表 C · Semantic Drop

完整列：

```text
payload
target
preview
intent
Core mutation
projection result
undo / remove semantics
```

## 表 D · Glyth / Receiver / Workflow

列清：

```text
Origin Conversation
Participant
Primary Receiver
Conversation Context Mapping
Run Receiver
Workflow reference
Skill invocation
```

四张表完成后，再把施工重新分发给：

```text
T1
T2
T4
Agent/Glyth
Semantic Drop/Composer
Core
```

---

# 50. 来源恢复与本轮新提案的界线

## 已有冻结支持

以下来自既有 LCOS 冻结：

- 三 Surface 独立 camera/selection/layout/history、共享同一物理；
- Glyth 是 Conversation/Agent 空间身份；
- Glyth 可进入长期 Conversation scene；
- Glyth Assembly target；
- Conversation Context Mapping 与 per-run Reference 分离；
- Railway 保留 Surface/worksite navigation、Receiver、cross-Surface drop；
- 同一 Artifact 跨 Surface 是 projection，不复制 canonical object；
- Scope/Collection admission 是 membership；
- Assembly 是 project-shared warehouse；
- Assembly 有 Dedicated Workspace / Docked Source Bay / Quick Tray；
- Context 旧冻结为 Structure/Evolution/Relationship/Source；
- Workflow 旧冻结为自由空间 action/material + Active Path/Review/Checkpoint 等已有 truth projection；
- Workflow 不是 BPMN / n8n DAG builder；
- Skill 与 Run 分离；
- Instrument 可 spatial → focus → work view。

## 2026-09-05 本轮新候选

以下是本轮讨论提出、需要总规划重新裁决：

- Context Atlas 作为 Context Home；
- Context 点/线/面统一模型；
- Atlas 选区进入 Context worksite；
- Instrument 不局限为画布 widget；
- Context 与 Glyth 从“中心关系”改成“跨 Conversation 汇总 + 来源 identity”；
- Workflow 改成“从项目里抽出的独立工作现场”；
- Workflow 与 Glyth/Receiver 强绑定；
- Workflow 可新建/重接已有 Glyth；
- Main/Context/Conversation → Extract as Workflow；
- Agent 辅助 Workflow extraction proposal；
- Workflow ↔ Skill 的明确提炼路径；
- Railway 对 Atlas / Workflow worksite 的新层级；
- Drop 的四层/多层语义需要重新总审。

这些不能在没有总规划裁决前被施工线程当成既成事实。

---

# 51. 建议的最终一句话产品口令

```text
Main 摆项目，
Context 汇理解，
Workflow 抽工作，
Glyth 接工作，
Assembly 配资源，
Railway 管去向。
```

如果再加上这一轮 Context 的点线面：

```text
Context：
面看全局，
线追演进，
点做细活。
```

以及 Workflow：

```text
Workflow：
从现场抽出来，
交给人/Agent继续做，
做顺了再提炼成 Skill。
```

这比“Main / Context / Workflow 三个不同功能页”更接近 LCOS 真正应该有的统一产品心智。

---

# 52. 建议总规划最终输出

总规划线程接到本稿后，建议不要直接写代码任务，而是先产出：

1. `Context_Workflow_Glyth_Assembly_Railway_DomainIdentity_Census.md`
2. `Context_Workflow_Projection_Worksite_Matrix.md`
3. `SemanticDrop_Target_Intent_Matrix.md`
4. `Workflow_Glyth_Receiver_Skill_Canonical_关系裁决.md`
5. `Context_Atlas_Wave_Canvas_产品裁决.md`
6. `CrossThread_Replan_Index.md`

完成这六张裁决后，再把 exact-file 施工卡拆回各线程。
