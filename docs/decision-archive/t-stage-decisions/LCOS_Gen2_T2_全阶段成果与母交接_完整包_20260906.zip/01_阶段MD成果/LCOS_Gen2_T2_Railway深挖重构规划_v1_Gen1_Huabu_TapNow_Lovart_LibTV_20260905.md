# LCOS Gen2 · T2 Railway 深挖重构规划 v1

日期：2026-09-05  
状态：规划，不施工

## 核心判断

Gen1 `WorkspaceRailVNext` 已经达到可用阶段，Gen2 不应该把它整块推倒。

Gen1 已经有：真实成员 x/y 归一化缩略布局、无 geometry 时的真实类型/数量 fallback、+N 溢出、Hover 大预览、拖拽重排、source ghost / neighbor shift、direct project-view semantic drop、自动单双列。

问题不是“不能用”，而是：旧 Scene / Collection / Context / Workflow 平级结构已过时；42px 小格承担太多职责；左侧整条垂直空间没有形成层级；真正有用的信息大量被赶进 276px Hover 卡；自动双列只是容量补丁，不是信息设计；Active 渐变条和旧壳不够精致。

---

## 1. Gen2 Railway 的信息结构

Railway 不做 Explorer 树，改成三种物种：

```text
Surface
→ Glyph first

Long-lived Worksite
→ Real Spatial Preview first

Receiver
→ Glyth identity first
```

逻辑区段：

```text
Project identity（极轻）

Main
Context
Workflow

当前 Surface 的 Pinned / Recent Worksites

flexible empty space

Current Receiver
```

没有常驻 `MAIN / CONTEXT / WORKSPACES / RECEIVER` 这些说明字。文字 Hover / Focus 才出现。

---

## 2. 三个 Surface Anchor

Main / Context / Workflow 是固定一级入口。

Rest：只显示 identity glyph，不显示长文字，active 通过 body/glyph/rim 表达。

Hover：短 Tooltip；必要时打开轻 Peek。

不再沿用旧 2px 紫蓝青渐变 active line。最终 exact glyph 继续从 Morphicons / Huabu / TapNow / Lovart 找。

---

## 3. 真正利用 Railway 空间：当前 Surface Worksites

Gen1 最大的可继承资产是：

```text
member x/y
→ normalized mini spatial map
```

Gen2 不把长期 Workflow / Context worksite 画成三个相同图标。

例如当前 Workflow：

```text
Workflow Anchor

[真实空间缩略] 冰箱白膜生成
[真实空间缩略] Gen2 donor audit
[真实空间缩略] Skill extraction
```

Rest 时可以只见缩略图，Hover 才出现名字。

推荐测试：hit target 约 48px；visible body 约 40–46px；worksite preview 本身成为主体；kind glyph 缩成 10–12px 角落 satellite。

这比旧版“大类型图标 + 很小 mini map”更合理。

---

## 4. Collection / Scope 不自动进入 Rail

Collection 是长期 membership，不自动等于长期独立工作现场。

Scope 是“这次只处理这些”，默认 transient。

```text
创建 Collection ≠ 自动 Rail item
创建 Scope ≠ 自动 Rail item
```

只有显式 materialize 成长期独立 worksite / 子画布，才进入 Railway。

---

## 5. Context 的 Railway 行为

Context Anchor：点击恢复上次 Context 状态。

第一次 / explicit Context Home：进入 Atlas。

只有真正长期 materialize 的 Context scope 才成为 worksite preview。不能点一个时间块就多一个 Rail item。

---

## 6. Workflow 的 Railway 行为

Workflow 最适合占 Rail 的长期 worksite 区，因为 Workflow 本身就是“值得单独继续做的一段工作”。

Workflow 下可以自然出现 pinned workflow、recent workflow、current active workflow，全部优先用真实 spatial preview，而不是纯文字列表。

---

## 7. Receiver 放 Rail 底部

底部固定 Current Receiver。

Rest：Glyth silhouette / identity + 极轻 working / waiting state。

Hover：Conversation 名称、“当前承接”、必要状态。

不显示 Agent Card：provider / model / token / run count。

Rail 空间心智：

```text
上：我在哪种现场
中：这个现场有哪些长期桌面
下：现在谁在接
```

---

## 8. Gen1 Hover Preview 保留，但改成 Railway Peek

旧：42px item → Hover → 276px preview card。

Gen2 改成 Railway Peek，只回答：这是哪个现场、大概有什么、要不要过去。

不复制 LayerPanel；不放完整 node tree / filter / canvas-local search / 大量管理按钮。

Donor：
- Huabu：Popover / DropdownMenu / Tooltip 工程 primitive；
- LibTV：compact flyout density、214px-class dropdown、0.5px border、16px blur、12px radius；
- Lovart：low chrome、48px hit / 40px visual core；
- TapNow：small controls、direct switch、Hover / active restraint。

---

## 9. Gen1 两列能力怎么处理

旧：放不下 → 自动双列 → 用户拖 Rail 右缘切一/两列。

Gen2 保留 adaptive packing，倾向退休永久 rail resize handle。

优先级：Pinned > Recent > +N。

Hover Surface Anchor 后的 Peek 如果项目很多，可以两列 preview grid。双列从“默认 Rail 容量补丁”变成“按需展开的信息布局”。

---

## 10. Drag 时 Railway 变成 Receive Map

这是新版 Railway 最应该利用整条左侧空间的时刻。

普通：Rail 很轻。

拖起 Selection：Rail → Receive Mode。

此时非 eligible item 降存在感；eligible Surface / Worksite 变成明确 drop target；Hover Surface 可以进一步展开其长期 worksite。

例如：

```text
拖对象
→ Hover Context
→ Context 进入 receiving state

如果目的地唯一
→ 直接 Drop

如果 Context 下已有多个长期 worksite
→ Hover 约 250–400ms
→ Railway Peek 展开这些 target
→ 继续拖到具体 worksite
```

这比 Drop → Modal → 再选 destination 自然得多。

---

## 11. Gen1 Drop 语义继续保留

Gen1 已经有 `onDirectProjectViewDrop(targetId, sourceIds)`。

这条产品方向继续保留：target 本身就是 destination。

Huabu upstream cross-space move：backend / atomic mechanic ADOPT；MoveSelectionModal REJECT 作为 Railway 主 UX。

---

## 12. Railway Reorder

Gen1 的 source gap、drag float、neighbor shift、约 130ms transition 可以保留手感。

但 Gen2 durable truth：`Core presentationState.viewRailOrder`。

前端不能再有第二 canonical Rail order store。

当前倾向：Main / Context / Workflow 一级顺序固定；pinned / long-lived worksites 可 reorder。

---

## 13. Railway 与 Work View

右侧 Assembly / Conversation / Context / Workflow Work View 打开：Railway 不消失；Camera 不自动移动；Rail permanent width 计入 active safeRect；Rail Peek 使用 overlay，不触发 Camera；空间不足时 Peek 收紧/折叠低优先内容。

右 Work View 不能替代 Railway。

---

## 14. Railway 与 Search / Focus

Railway 不是 Search Result List，但跨 Surface Focus 可以借 Railway 做“换现场”反馈：

```text
Focus occurrence = Workflow B
→ Workflow B / worksite Rail item 短暂提示
→ Surface switch
→ Camera locate
→ Arrival
```

这样用户明确知道不只是镜头动了，也换了工作现场。

---

## 15. Railway 与 LayerPanel

Railway：去哪里。

LayerPanel：当前这里有什么。

所以 Railway Peek 绝不做 node tree。

---

## 16. Railway 四态

R0 REST：Surface glyph + worksite spatial preview + Receiver。

R1 PEEK：identity + larger true preview + short metadata。

R2 RECEIVE：eligible destination map + direct drop。

R3 MANAGE：Right-click / More → rename / reorder / archive / remove。

不需要永久 Expanded Sidebar Mode。

---

## 17. Donor 拼装

Gen1 LCOS 保留：Railway 产品语义、true mini preview、direct semantic drop、reorder、hover preview。

Huabu 负责：pointer / geometry、overlay / popover / tooltip、cross-space move mechanic、current canvas physical mechanics。

TapNow 借：direct navigation、compact control density、restrained hover / active、tooltip rhythm。

Lovart/tldraw 借：48 hit / 40 visual core、low chrome、lightweight panel reveal。

LibTV 借：current identity chip、compact flyout、214px-class density、0.5px border / 16px blur / 12px radius。

Spatial 借：low persistent chrome、workspace switching 的空间连续感。

---

## 18. Source-level 结构

```text
Core / Surface truth
        ↓
Railway Presenter
        ↓
Replaceable Railway Body
        ↓
Huabu shell / overlay primitive
```

绝不新增 RailwayStore / NavigationManager / second Surface store。

Presenter 只生成 derived view model：id / role / active / previewGeometry / previewSummary / pinned/recent / receiverState / dropEligibility。

---

## 19. Gen1 资产裁决

KEEP / LIFT：
- true member x/y mini preview；
- no-geometry truthful fallback；
- +N；
- Hover larger preview concept；
- direct drop；
- drag reorder；
- source ghost / neighbor shift；
- adaptive packing principle。

RETIRE / SUPERSEDE：
- Scene/Collection/Context/Workflow flat peers；
- old gradient active line；
- old heavy CSS shell；
- manual permanent column resize likely retire；
- local canonical Rail truth；
- generic New Scene item；
- Collection / Scope 自动等于 Railway worksite。

---

## 20. HTML 下一轮必须验证

1. 三 Surface 固定 + 当前 Surface Worksite previews + Receiver 的完整 Rail。
2. Generic icon vs true spatial preview。
3. Gen1 276px Peek vs LibTV 214px-class Peek。
4. Drag 时 Rail 从 REST morph 成 RECEIVE MAP。
5. 8 / 20 个 worksites 的 overflow / +N / Peek。
6. 右侧 Dock 开启时 Railway 与 safeRect 是否仍自然。

---

## 最终判断

Gen1 已经回答：Railway 能不能工作？答案：能。

Gen2 要做的是：把它从“能用的 42px 小格 Rail”升级成真正的空间导航骨架。

当前最看好的方向：

```text
Surface = Glyph
Worksite = 真实 Spatial Preview
Receiver = Glyth Identity
```

再叠加 Gen1 语义 + Gen2 新 hierarchy + Huabu mechanics + TapNow directness + Lovart low chrome + LibTV flyout density + Spatial continuity。

这不是重写 Railway。

这是把 Gen1 Railway 真正完成。
