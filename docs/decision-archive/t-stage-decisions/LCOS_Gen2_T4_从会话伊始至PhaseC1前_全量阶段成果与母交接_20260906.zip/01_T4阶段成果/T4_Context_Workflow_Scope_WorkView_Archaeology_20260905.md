# LCOS Gen2 · T4
# Context / Workflow / Scope / Work View 语义考古与当前归位

日期：2026-09-05  
线程：T4 · Work View / Context / Workflow / Assembly / Skill  
状态：`PHASE-A ARCHAEOLOGY / NO PRODUCTION PATCH`

> 本稿遵守 `LCOS_Gen2_六路统一语义考古_跨线程对账与重对齐指令_20260905`：
>
> **总规划/考古摘要只用于定位风险，不作为施工结论。**
>
> 本稿结论必须尽可能回到：
>
> 1. 原始用户原话；
> 2. 历史产品冻结 / closeout；
> 3. Gen1 / v0.15 源码快照；
> 4. current Gen2 source；
> 5. 2026-09-05 V2 最新冻结。
>
> 无法追回原始证据的条目明确标 `MISSING / CONTEXT_ONLY / OPEN`，不由 T4 自补。

---

# 0. Authority 顺序

```text
2026-09-05 用户最新明确纠正 / V2
→ 2026-09-02 Gen2 全功能冻结 / owner
→ 2026-08-29 UX freeze / closeout
→ 2026-08-21 原始三 Surface 产品稿
→ 更早产品定义
→ Gen1 / v0.15 源码
```

旧代码只能证明：

> 当时怎么实现、哪里混过。

不能证明：

> 今天产品就应该继续这么定义。

---

# 1. Evidence Recovery Census

| 证据 | 类型 | 状态 | 本稿可支持 | 不能支持 |
|---|---|---|---|---|
| 2026-09-05 V2 最终产品冻结 | 最新产品冻结 | FOUND_FULL | Scope/Collection/child worksite 分离；三 Surface；Context/Workflow/Glyth/Work View 最新定义 | exact Core schema |
| 六路统一语义考古指令 | 协调指令 | FOUND_FULL | 风险目录、状态标签、T4 必答项 | 不能作为产品结论本身 |
| 六路职责分工 | owner 指令 | FOUND_FULL | T4/T1/T2/T5/T6 边界 | 不决定 canonical schema |
| `LCOS_0.1_三大独立视图组件化详细施工总稿_v03..._20260821` | 历史产品主稿 | FOUND_FULL/PARTIAL-SEARCH | Main/Context/Workflow 作为三个一级独立视图的早期冻结 | 最新实现 |
| `LCOS_v0.15_UX冻结_同一套物理三个语义现场与Assembly_20260829` | 历史 UX freeze | FOUND_FULL | Same Physics/Different Semantics；Assembly 项目级；Workflow 非 DAG | 09-05 后覆盖项 |
| `LCOS_v0.15_UX冻结_Relation_Glyth_Colony_SpatialNavigation_20260829` | 历史 UX freeze | FOUND_FULL | Glyth context mapping / body drag / relation distinction | T4 canonical ownership |
| `LCOS_20260821至20260902_全功能最新冻结总账...` | 09-02 冻结总账 | FOUND_FULL/PARTIAL-SEARCH | Skill/Builder/Run/Cross-Surface Skill | 09-05 新覆盖项 |
| `LCOS_v015_前端最终收敛四阶段..._20260831` | 历史 convergence plan | FOUND_FULL/PARTIAL-SEARCH | Context 4 instruments、Workflow/Assembly/Skill restoration intent | 不能直接定义最新 Scope |
| `LCOS_Gen2_GLM施工正本_Phase_B_Node_Morphology_WorkView_20260902` | 旧施工计划 | FOUND_FULL/PARTIAL-SEARCH | Work View 连续容器、Focus 分离、occupied rect | “single dominant Work View” 已被 V2 覆盖 |
| `LCOS_前端源码合并版.md` | Gen1/v0.15 源码快照 | FOUND_FULL / SOURCE_SNAPSHOT | `ScopeKind`, `CanvasScope`, old Workbench/Workspace/camera 混合实现 | 不是直接 GitHub Gen1 repo 验证 |
| 原 Gen1 GitHub 仓库 | 原始 repo | MISSING / NOT_RESOLVED | 无 | 不能声称 direct GitHub verified |
| current `context-snapshot-service.ts` | Gen2 current source | GITHUB_VERIFIED | Checkpoint-backed snapshot；旧 branch→collection scope + cloned/new views + x/y | 不决定新 migration owner |
| current `workbench-service.ts` | Gen2 current source | GITHUB_VERIFIED | old Workbench=temporary scope + merge ViewRefs | 不能当 Unified Work View |
| current `routes/workflow.ts` | Gen2 current source | GITHUB_VERIFIED | workflow import/export 仍吃 `scopeId` | 不能证明 Workflow product identity=Scope |
| current `skill-package-service.ts` | Gen2 current source | GITHUB_VERIFIED | Skill package canonical CRUD/composition/version | 不含外部 usage binding |
| current `assembly.ts` contracts | Gen2 current source | GITHUB_VERIFIED | Assembly refs/read model/apply contract | `scope` compatibility taxonomy不是最新产品定义 |
| current `assembly-apply-service.ts` | Gen2 current source | GITHUB_VERIFIED | no second mutation; routes existing canonical services; skill unsupported | Skill usage binding仍缺 |
| 2026-08-29 用户逐字原话：“对，Scope就是长期的。”“对，Scope 是容器。” | 原始用户原话 | RECOVERED_ORIGINAL | 证明历史上 Scope 曾被用户明确定义成长期容器 | 已被 09-05 V2 覆盖 |
| 其它 Scope/Collection/Assembly/Skill/WorkView 用户逐字原话 | 原始聊天 | PARTIAL/MISSING | 只能由历史 freeze 间接确认 | 不得伪造逐字原话 |

---

# 2. 最重要的考古发现：Scope 的确发生过“产品语义覆盖”

## 2.1 历史用户原话

2026-08-29 历史对话追回：

```text
“对，Scope就是长期的。”
“对，Scope 是容器。”
```

这不是助手误总结。

说明在那个历史阶段：

```text
Scope
= long-lived container
```

曾经是真实用户产品判断。

### 状态

```text
HISTORICAL_TRUTH
SUPERSEDED
```

---

## 2.2 为什么旧代码也会强化这个印象

Gen1/v0.15 `ScopeKind`：

```ts
root
collection
context
workflow
delivery
temporary-workbench
```

旧 `CanvasScope` 还同时承载：

```text
parentScopeId
containerNodeId
camera
layoutMode
```

`createChildScopeFromSelection()` 会：

```text
创建 scope
创建 container node
克隆/创建 selected views
复制 internal edges
生成独立位置
```

旧 Workbench 也有：

```text
temporary-workbench scope
camera
layout
scope entry / leave
```

因此旧 source 实际把：

```text
Container
Collection
Context
Workflow
Workbench
Camera
Nested Canvas-ish navigation
```

压进同一个 Scope umbrella。

### 状态

```text
LEGACY_COMPAT
SUPERSEDED_AS_PRODUCT_MODEL
```

---

## 2.3 2026-09-05 V2 当前产品真相

V2 已经重新拆开：

```text
Collection
= 哪些东西长期算一组

Scope
= 这次工作只处理哪些对象

Child Canvas / Long-term Worksite
= 用户明确要单独开桌长期干

Work View
= 某对象/工作的深度工作窗口
```

因此：

```text
Scope ≠ Collection
Scope ≠ Worksite
Scope ≠ Child Canvas
Scope ≠ Work View
```

### 状态

```text
CURRENT_TRUTH
```

---

# 3. Scope 当前 T4 能确认到什么程度

## 3.1 CURRENT_TRUTH

Scope 的产品语言：

> **“这次只处理谁。”**

它是一次 Context / Workflow / Run 的工作范围。

它可以通过：

```text
Selection
target set
active range
work boundary
```

被表达。

但不能因为旧 `CanvasScope` 有 camera/layout/container 就推导：

```text
Scope 需要自己的 Canvas
Scope 是一个长期空容器
Scope 默认拥有独立 Camera
```

这些全部不成立。

---

## 3.2 PRESENTATION_ONLY

Scope 可以有：

```text
temporary highlight
field
boundary
active-range visualization
```

用于告诉用户“这次只处理这一批”。

这不等于：

```text
创建一个 Scope Entity 卡片
创建一个长期虚线框
创建一个 nested canvas
```

---

## 3.3 OPEN：Save / Commit exact persistence contract

后续考古摘要中存在：

```text
Selection-derived Scope
→ explicit Save / Commit
→ long-term recoverable truth
```

但本轮未追回足够一手原始用户/冻结正文来单独证明：

```text
具体 Save / Commit 什么
保存成 Scope identity？
保存成 Collection？
保存成 Workflow？
保存成 Long-term Worksite？
```

因此 T4 不闭环。

### 状态

```text
OPEN
WAIT_CROSS_THREAD
```

需要：

```text
T6
+ Coordinator
```

最终定义 canonical persistence。

T4 只负责：

```text
临时 Scope 的专业工作 UI / lifecycle
```

不能自行新增：

```text
ContextScopeDB
WorkflowScopeDB
ScopeContainerEngine
```

---

# 4. Main / Context / Workflow：历史与当前一致的主干

## 4.1 2026-08-21 原始主稿

已明确：

> Main / Context / Workflow 保持三个一级独立视图，并建立在同一套 Spatial Surface Engine 上。

因此早期就不是：

```text
Main
└─ Context child scope
   └─ Workflow child scope
```

---

## 4.2 2026-08-29 freeze

明确：

```text
Same Physics
Different Semantics
```

共享：

```text
SpatialCanvas
Selection
Move/Resize
Orbit
Semantic Drop
Composer
Glyth
Colony
Focus
History
```

语义差异：

```text
Main
= Object / Space / 项目地形

Context
= Meaning / Evolution / Source / 项目理解

Workflow
= Verb / Execution / 项目行动
```

---

## 4.3 2026-09-05 V2

继续冻结：

```text
Main
Context
Workflow
```

只有这三个一级工作空间。

### 状态

```text
CURRENT_TRUTH
KEEP
```

---

# 5. Context 不是 child canvas；Atlas 也不是 worksite

## 5.1 Context Surface

Context 本身是一级 Surface。

拥有独立：

```text
canvas identity
camera
selection
layout
history
```

这些由 Surface/Huabu owner承接。

### 状态

```text
CURRENT_TRUTH
```

---

## 5.2 Context Atlas

最新补充冻结：

> Context Atlas 是一张“有轻微高度和纵深的项目 Context 地图”，不是复杂 3D 世界。

其职责：

```text
面
= 看整个 Context 全局结构
```

它不是第二 Context truth。

它也不因为是“大界面”就自动成为 long-term worksite。

### 状态

```text
PRESENTATION_ONLY
INSTRUMENT
```

---

## 5.3 Evolution / Relationship / Provenance

历史 08-21 / 08-31 已经出现：

```text
Structure
Evolution
Relationship
Source/Provenance
```

最新 Atlas freeze 进一步把它们从 Atlas 第一层拆开：

```text
Evolution/Wave
= 2D professional view 优先

Relationship / Provenance
= Lens / inspection / Work View
```

因此：

```text
它们是对 canonical Context 的专业 Instrument
不是新的 Context entity
不是 child canvas
```

### 状态

```text
KEEP_AS_INSTRUMENT
PRESENTATION_ONLY
```

---

# 6. Context 点击一块以后：temporary detail ≠ worksite

最新 V2：

```text
点击时间块
→ 先临时详细查看
```

可以：

```text
看
Search
Focus
Reference
给 Agent
看来源
看演进
看底层对象
恢复 Archive
拖出真实对象
```

但：

```text
不自动创建长期 worksite
不自动创建 child canvas
```

### 状态

```text
CURRENT_TRUTH
```

---

# 7. 什么时候 Context 内部才值得 materialize nested long-term worksite

T4 能定义“产品门槛”，但不能定义 canonical owner。

只有当用户明确需要：

```text
独立视野
独立 layout
独立 history
长期持续
下次还能回来继续
```

才“值得”进入 long-term nested worksite 语义。

但：

```text
谁创建 worksite identity
parent-child navigation如何记录
canvasId如何产生
membership怎么持久化
```

不属于 T4 单独决定。

### 状态

```text
PRODUCT_GATE = CURRENT_TRUTH
CANONICAL_OWNER = OPEN / T2+T6
```

---

# 8. Workflow：一级 Surface，不是 Scope，也不是 DAG

## 8.1 历史 freeze

2026-08-29 已明确：

> Workflow 不是自动化流程搭建器。

而是：

```text
必要上下文
+ 当前目标
+ 动作/意图
+ Skill/能力
→ Agent/API
→ Return
```

---

## 8.2 最新 V2

Workflow：

> 从真实项目现场抽出来的一段值得单独继续做的工作。

最小可见粒度：

```text
一次输入/指令
→ Agent/API/Skill
→ 一次用户可感知结果
```

主画面：

```text
真实材料
关键动作
真实结果
Review
当前承接 Glyth
```

内部 tool calls / retry / provider 等进入深度查看。

### 状态

```text
CURRENT_TRUTH
```

---

## 8.3 Current source 的 `scopeId` 不能反推产品

current：

```text
GET /projects/:id/workflow/export
POST /projects/:id/workflow/import
```

仍接受：

```text
scopeId
```

并默认 root scope。

这只能证明：

```text
current transport / persistence 仍依赖 legacy scope taxonomy
```

不能证明：

```text
Workflow == Scope
```

### 状态

```text
LEGACY_COMPAT
MIGRATION_DEPENDENCY
```

exact Workflow membership / identity：

```text
WAIT T6
```

---

# 9. Workflow detail 是 Instrument，不是第二 Workflow worksite

以下：

```text
某一轮详情
Review
logs
tool calls
provider
retry
execution details
```

属于：

```text
professional Work View / Instrument
```

不是：

```text
再 materialize 一个 Workflow child canvas
```

Workflow Surface 已经是自由工作现场。

### 状态

```text
PRESENTATION_ONLY
INSTRUMENT
```

---

# 10. Work View：历史连续性与最新纠偏

## 10.1 KEEP

旧 09-02 Work View 计划有几个判断仍然正确：

```text
Work View不是固定右栏
Work View不是另一个页面 route
同一个对象从空间进入专业工作形态
Focus和Work View不是同一 enum
Work View project-scoped，不应被 Surface 切换无脑销毁
occupied rect影响 screen-space UI，不该搬 Camera
```

这些与 V2 不冲突。

### 状态

```text
KEEP
```

---

## 10.2 SUPERSEDED：single dominant Work View

旧施工计划写：

```text
同一时刻一个 dominant Work View
```

但 09-05 V2 明确允许：

```text
Conversation child canvas
+ Conversation deep preview
+ Assembly
```

同时存在；

并要求所有大工作区支持：

```text
Float
Dock
Undock
Resize
Move
横/竖组合
独立 Close
Restore
```

因此：

```text
single dominant Work View
= SUPERSEDED
```

---

# 11. Work View ≠ Child Canvas

这是 T4 必须彻底锁死的边界。

## Work View

```text
深度查看/编辑/审阅/操作窗口
screen-space professional region
可 Float/Dock/Immersive
不自动拥有独立长期 camera/layout/history
```

## Child Canvas / Nested Worksite

```text
真正独立空间现场
有自己的 canvas identity
camera
layout
history
长期进入/返回
```

所以：

```text
一个东西“变大了”
≠ 它变成 child canvas
```

也：

```text
有 window / panel
≠ 新的 long-term worksite
```

### 状态

```text
CURRENT_TRUTH
HARD_BOUNDARY
```

---

# 12. “Professional Workbench” 这个工程名必须防止与旧 WorkbenchService 串台

current Gen2：

```text
apps/local-core/src/workbench-service.ts
```

源码定义：

> A workbench is a temporary scope holding View References.

merge 时：

```text
temporary scope views
→ root View References
→ delete temporary workbench views
```

这明显是旧 `temporary-workbench Scope` 产品模型。

它不是：

```text
V2 multi-window Work View manager
```

### 状态

```text
WorkbenchService
= LEGACY_COMPAT
= SUPERSEDED_AS_PRODUCT_OWNER
```

因此 T4 未来工程中的：

```text
ProfessionalWorkbenchStage
```

只能是：

> UI presentation/window manager 的内部工程名。

不能复活 old Workbench domain semantics。

必要时为防误会，可改更窄名称：

```text
ProfessionalWindowStage
WorkRegionManager
```

最终命名留实施阶段。

---

# 13. Assembly：历史主语义很稳定

2026-08-29 raw freeze：

> Assembly 是整个 Project 共享的“仓库/装配工作壳”。

结构：

```text
Target
+
Source Bay
  Project
  Capture
  Sources
  Skills
```

入口：

```text
Main
Context
Workflow
Glyth / Conversation
```

区别只在 Target。

### 状态

```text
CURRENT_TRUTH
KEEP
```

---

# 14. Assembly current source：架构 KEEP，taxonomy PATCH

current contract：

```text
AssemblySourceRefV1
AssemblyTargetRefV1
WarehouseSnapshotV1
AssemblyApplyRequestV1
```

明确：

> ref 只引用 canonical identity，不复制正文/membership/relation truth。

current `AssemblyApplyService` 也明确：

> service 不拥有 mutation，只把 sourceRef+targetRef 路由到既有 canonical 服务。

这是正确架构。

### 状态

```text
KEEP
```

---

## 14.1 Legacy taxonomy

current source 仍把：

```text
context
workflow
collection
```

映成：

```text
scope relation endpoint
```

contract 注释还称：

```text
scope 类 target兼容引用
```

最新产品已经把这些概念拆开。

### 状态

```text
LEGACY_COMPAT
PATCH_MUTATION
WAIT_T6
```

T4 不能自行改 canonical relation endpoint taxonomy。

---

# 15. Skill：canonical body已成熟

current `SkillPackageService` 已有：

```text
list
create
update
versionBump
rename
install
disable
composition
subskills
dependency resolution
provenance
```

写操作限定 user skill root，system skill只作为只读 install source。

这与历史/09-02 freeze 一致：

```text
Skill
= first-class canonical package/artifact

Skill Builder
= 编辑 canonical Skill
```

### 状态

```text
CURRENT_TRUTH
KEEP
```

---

# 16. Skill Builder ≠ Harness Run

09-02 freeze：

```text
Skill
= 手册 / 可移植方法包

Harness Run
= 一次照手册执行、验证、调试的记录
```

Run 可以提出：

```text
Teach / Update Skill proposal
```

但：

```text
不自动回写 Skill
```

Skill Builder：

```text
是 Instrument / Work View
不是 Run editor
不是 long-term spatial worksite
```

### 状态

```text
CURRENT_TRUTH
HARD_BOUNDARY
```

---

# 17. Skill 外部 usage binding 仍然是 current gap

latest freeze 需要：

```text
Skill → Workflow
Skill → Composer
Skill → Glyth
Skill → capability target
```

并引用：

```text
skillId/version
```

不复制 package。

但 current `AssemblyApplyService` 明确：

```text
skill
→ unsupported
```

### 状态

```text
CURRENT_PRODUCT_REQUIRED
CURRENT_SOURCE_GAP
WAIT_CROSS_THREAD
```

需要 T6/Core 定义 canonical usage-binding。

T4 禁止：

```text
local SkillBindingStore
fake success toast
copy Skill package into target
```

---

# 18. Conversation / Glyth deep work：三个区域必须拆清

V2：

```text
Glyth double-click
→ same Conversation deep work
```

可同时存在：

```text
1. Conversation child canvas
2. Conversation deep preview
3. Assembly
```

它们不是同一种东西。

## Conversation child canvas

```text
nested long-term spatial worksite
```

T4不拥有其：

```text
canonical identity
navigation runtime
camera/geometry
```

## Conversation preview

```text
professional Work View / Instrument
```

T4 owns其专业区域生命周期。

## Assembly

```text
Project-shared Assembly
target = current Conversation
```

不是 Conversation private warehouse。

### 状态

```text
CURRENT_TRUTH
```

---

# 19. ContextSnapshot current source 暴露的 legacy debt

current `ContextSnapshotService`：

```text
Checkpoint-backed
never a second truth
```

这个很好：

```text
KEEP
```

但 `branch()` 当前会：

```text
create scope(kind='collection')
clone/create new ArtifactViews
generate x/y
```

这把：

```text
branch
Collection
View clone
spatial placement
```

历史地绑在一起。

最新 V2 已拆开：

```text
Collection containment
≠ child worksite
≠ spatial owner
```

### T4 状态

```text
Checkpoint snapshot/compare = KEEP
branch implementation = LEGACY_COMPAT / PATCH_MUTATION
exact migration = WAIT_T6
```

T4不能自己定义新的 Collection truth。

---

# 20. Current semantic status matrix

| 概念 | Current status | T4 判断 |
|---|---|---|
| Selection | CURRENT_TRUTH | 不属 T4 owner |
| Colony | CURRENT_TRUTH | 不属 T4 owner |
| Collection | CURRENT_TRUTH | canonical containment 交 T6 |
| Scope | CURRENT_TRUTH | 临时/当前工作范围，不是容器 |
| old long-lived Scope | SUPERSEDED | 仅 migration evidence |
| CanvasScope camera/layout | LEGACY_COMPAT | 不能迁成新 Scope body |
| Main Surface | CURRENT_TRUTH | 一级 Surface |
| Context Surface | CURRENT_TRUTH | 一级 Surface |
| Workflow Surface | CURRENT_TRUTH | 一级 Surface |
| Context Atlas | PRESENTATION_ONLY | Instrument / Context Home |
| Evolution | PRESENTATION_ONLY | 2D professional Instrument |
| Relationship | PRESENTATION_ONLY | professional lens |
| Provenance | PRESENTATION_ONLY | professional lens |
| Workflow deep detail | PRESENTATION_ONLY | Work View |
| Skill Builder | PRESENTATION_ONLY | edits canonical Skill |
| Harness Run | CURRENT_TRUTH | execution record, separate |
| Work View | CURRENT_TRUTH | professional depth window |
| single dominant Work View | SUPERSEDED | V2 allows N regions |
| Child Canvas | CURRENT_TRUTH | nested spatial worksite |
| old WorkbenchService | LEGACY_COMPAT | not Unified Work View |
| Assembly | CURRENT_TRUTH | Project-shared assembly |
| Skill package | CURRENT_TRUTH | canonical Skill truth |
| Skill usage binding | OPEN / GAP | T6/Core needed |
| Archive Work View | PRESENTATION_ONLY | UI possible; Archive truth T6 |
| ContextSnapshot checkpoint | KEEP | canonical history projection |
| ContextSnapshot branch→collection scope+x/y | LEGACY_COMPAT | migration needed |

---

# 21. T4 exact owner after archaeology

T4 owns:

```text
professional work lifecycle

Work View / professional region:
open
float
dock
undock
resize
compose
close
restore

Context:
Atlas entry
temporary detail lifecycle
Evolution/Relationship/Provenance professional bodies

Workflow:
deep detail / review professional bodies

Assembly:
Project-shared Source Bay presentation + canonical apply adapter

Skill:
Skill Builder professional body

Conversation:
adjacent professional regions around child canvas
```

T4 does NOT own:

```text
Colony truth
Collection containment
Scope canonical persistence schema
Child Worksite canonical identity
parent/child navigation
camera geometry
Surface spatial mechanics
Workflow canonical membership
Skill usage-binding truth
Archive canonical lifecycle
```

---

# 22. Cross-thread facts T4 must carry forward

## To T1

T4 only exposes:

```text
occupied rect
floating collision rect
professional region visibility
```

T1/Huabu owns:

```text
camera
geometry
safe spatial viewport
layout
```

Work View open/resize cannot move Camera.

---

## To T2

T4 can say：

```text
“这个 professional detail要打开”
```

T2 owns：

```text
真正 child worksite 的进入/返回/Arrival/back stack
```

T4 cannot make Work View into child navigation.

---

## To T6

T4 needs canonical answers for：

```text
Scope Save/Commit persistence
Workflow membership
Context membership where still scope-backed
Collection migration
Worksite identity
Skill usage binding
Archive lifecycle
```

---

# 23. Construction authorization state

```text
T4 PRODUCT SEMANTIC ARCHAEOLOGY
= PARTIALLY CLOSED

T4 SOURCE-LEVEL PLAN
= PATCHABLE

FINAL CONSTRUCTION PLAN
= NOT AUTHORIZED
```

Blocking reasons：

```text
1. exact Scope Save/Commit canonical persistence still OPEN
2. long-term Worksite canonical owner needs T2/T6
3. Workflow canonical membership still scope-tainted
4. Assembly context/workflow/collection relation endpoint still scope-tainted
5. Skill usage-binding missing
6. Archive lifecycle missing
7. several exact original user-chat quotes remain unrecovered
8. original Gen1 GitHub repo not directly resolved; only source snapshot recovered
```

---

# 24. 一句话

> **历史上 Scope 真的当过“长期容器”，所以旧代码不是凭空犯错；但 09-05 V2 已经把这个产品定义撤销。T4 现在必须把 Scope、Work View、Child Worksite、Context/Workflow Surface、Assembly、Skill 各自放回自己的层，而不是继续让旧 `scopeId` 当万能胶。**
