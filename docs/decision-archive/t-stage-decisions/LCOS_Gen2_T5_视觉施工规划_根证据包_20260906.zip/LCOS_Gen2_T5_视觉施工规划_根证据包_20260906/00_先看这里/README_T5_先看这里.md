# LCOS Gen2 · T5 视觉施工规划根证据包
日期：2026-09-06

## 这包是干什么的

这不是“视觉灵感合集”。

这是为了防止 T5 再次出现以下偏差：

- 只看最新总结，不看用户原话；
- 把极简理解成少东西 / 静态；
- 把 Apple/macOS 理解成到处玻璃；
- 把成熟 donor 只当灵感，再自己手搓一份更差的；
- 把 Context / Workflow / Glyth / Collection / Colony 全画成白卡；
- 把产品语义又因为视觉方便改掉；
- 把旧 prototype 的壳误当成最新产品冻结；
- 把 UI donor 的底层 store / canvas / taxonomy 一起搬进来。

## 强制阅读顺序

### 第一层 · 用户原话

先读：

1. `01_用户视觉原话/01_用户视觉原话_逐字摘录_20260830-20260906.md`
2. `01_用户视觉原话/02_冻结稿保留的用户视觉硬口径_非原始聊天逐字证据.md`
3. `01_用户视觉原话/03_历史视觉要求_恢复摘要_明确非逐字.md`

这三份的证据等级已经明确区分，不准把恢复摘要当逐字原话。

### 第二层 · 当前最高产品/视觉边界

依次读：

1. `02_当前最高冻结/LCOS_Gen2_PhaseB_四路合并_最终跨线程裁决稿_20260906.md`
2. `02_当前最高冻结/LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905.md`
3. `02_当前最高冻结/LCOS_Context_Workflow_Glyth_Assembly_Railway_重新收敛总稿_20260905(1).md`

发生冲突时：Phase B > V2 > 重新收敛总稿。

### 第三层 · 视觉纠偏 / donor

必读：

- `LCOS_Gen2_Donor双轨裁决_工程实现复用与UIUX高保真设计借鉴_20260904.md`
- `LCOS_Gen2_TapNow_Lovart_Spatial_外观参考与实现边界纠偏_20260904.md`
- `LCOS_Gen2_视觉微元素与动态组件采用方向纠偏_20260904.md`
- `LCOS_Gen2_历史GUI原话与CurrentHuabuChrome_深挖恢复_第二轮_20260904.md`
- `LCOS_visual_donor_inventory_expanded_20260904.tsv`

### 第四层 · 工程真实边界

T5 不是在真空里画 UI，要读：

- T1 Historical Semantic Reconciliation
- T2 Patched Navigation Cards
- T3 深挖后 UX 裁决
- T4 Patched Professional Work Plan
- 六路职责分工

这层只告诉 T5：

- 状态到底有哪些；
- 哪些是 visible host；
- 哪些是 remote target；
- 哪些是 Window；
- 哪些是真 Worksite；
- 哪些会占 safeRect；
- 哪些 mechanics 已有成熟 Huabu primitive。

不要求 T5照着工程文件做丑 UI。

### 第五层 · 历史视觉工程资料

用于回答：

> “以前为什么看起来不对？哪些成熟原语其实已经有？”

旧方案不能覆盖第二层最新冻结。

## T5 最重要的视觉法条

1. **极简、高级、接近 Apple/macOS 桌面系统质感，但不是 Apple 皮肤模仿。**
2. **图形优先，非必要不常驻文字。**
3. **内容对象首先像自己，不首先像 LCOS 卡片。**
4. **去卡片化不等于去动态。动态微元素可以多，但必须有功能归因。**
5. **成熟视觉组件能直接用就直接用，优先调参数，不重新发明。**
6. **TapNow / Lovart / Spatial 的最佳成熟呈现允许高保真借鉴，但不复制 proprietary source/assets。**
7. **Main / Context / Workflow / Glyth / Collection / Colony / Worksite / Work View 必须 silhouette 上可分。**
8. **Context Atlas 只做轻 2.5D 空间感，不做复杂 3D 城市。**
9. **Visible-host Drop 与 remote-transfer 的 motion 必须明显不同。**
10. **T5 只改“长什么样”，不重新定义“为什么存在”。**

## 旧稿警告

`99_SUPERSEDED_REFERENCE` 中的文件只用于历史追溯。

T5 不得从其中恢复已经被 V2 / Phase B 覆盖的：
- Scope container；
- Collection child canvas；
- old Workspace runtime；
- 旧 permanent chrome；
- single dominant Work View；
- 旧右拖语义。
