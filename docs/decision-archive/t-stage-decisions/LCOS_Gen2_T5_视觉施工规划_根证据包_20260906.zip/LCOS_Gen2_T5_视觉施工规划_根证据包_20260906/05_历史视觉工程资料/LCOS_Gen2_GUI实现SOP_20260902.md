# LCOS Gen2 · GUI 最终实现 SOP（源码级复刻 · 必须检查项）

> 日期：2026-09-02 ｜ 用途：GUI 施工前/中的**强制检查清单**，防止「假语义完成」「重复造轮子」「违反 Huabu ontology」。
> 核心原则：**凡是 Huabu 已有 / 成熟轮子已有，绝不重写；LCOS 只写独有的语义与形态。** 每个 GUI 决策过一遍下面的检查项，缺一项不得提交。

---

## 0. 一句话总纲

> **「沿用轮子预设 + Huabu 整套语法」是源码级复刻的必须检查项**：动手前先问「Huabu 有没有做？成熟轮子有没有做？」，都有 → 直接沿用/拷源码；没有 → 才允许 LCOS 自研（且必须填 `Custom Primitive Rejection Record`）。

---

## 1. 施工前必读（README 顺序）

1. `README.md`（本文件夹索引）
2. `LCOS_Gen2_GUI实现方案_大补充_20260902.md`（总纲 + 附录对账）
3. `LCOS_Gen2_GUI轮子复用_信息搜集档案_20260902.md`（逐环节/源码行号）
4. 当前模块的 L0 product truth（见迁移包 `01_CURRENT_CONTEXT`）

---

## 2. 源码级复刻的「必须检查项」（每项一个 GUI 决策都要过）

### 2.1 【M0】先问 Huabu（最高优先级）
- [ ] Huabu 是否已实现这个**空间物理/交互机制**？（显影机/选择/拖拽/缩放/连接/drop/undo/Work View）
- [ ] Huabu 是否已有对应**组件/primitive**？（`Common/*`：Button/Select/Popover/Modal/Tooltip/Toast/TabGroup/DropdownMenu/FloatingToolbar）
- [ ] Huabu 是否已有对应**动效**？（`useNodeTakeover`/LOD/overlay 过渡/浮动工具条动画）
- **命中 → 直接沿用/薄包，不重写。** 未命中 → 进入 §2.2。

### 2.2 【M1】再问成熟轮子
- [ ] 是否已有成熟轮子？列表：`motion`(动效，MIT)、lucide(图标，已在依赖)、cmdk(搜索)、react-arborist(树)、mind-elixir-core(导图)、cytoscape(关系场)、vis-timeline(时间线)、react-resizable-panels(分栏)、dnd-kit(仅 DOM 内拖拽)。
- [ ] 许可证是否 OK？**只收 MIT / Apache-2.0 / 兼容宽松**；**拒** Commons Clause、sustainable-use、pro-only。
- [ ] 是否「copiable」（能拿到源码拷进项目）？⚠️ **Amicro 教训**：宣传「CLI/零运行时」但 npm 只是展示站、无 bin、无组件分发 → **不采用**。
- **命中 → ADOPT/COPY（拷源码，注明 upstream 路径 + 版本 + license）。** 未命中 → 进入 §2.3。

### 2.3 【M2】Huabu 与轮子都没有 → 才允许 LCOS 自研（填 Rejection Record）
- [ ] 填《Custom Primitive Rejection Record》：Huabu candidate / 为何不用 / secondary candidates / license / maintenance / 为何全拒 / 为何必须自研 / owner / acceptance。
- **无此文件，不得提交 custom primitive。**
- 但注意：**LCOS 独有的语义/形态**（Glyth 形态、Selection≠Reference、Action Arc 契约、物种 morph、Work View 生命周期）**本来就要自己写**——这些不是「自研 primitive」，是「LCOS 语义层」，进 §2.4。

### 2.4 【M3】LCOS 语义层（必须自己写，但只写语义不写机械）
- [ ] object species morphology（Image 裸图/Paper 纸面/SlideDeck/Archive/GenericFile）
- [ ] Selection ≠ Reference 分离
- [ ] Action Arc 3/4 上限 + Esc/outside 关闭
- [ ] 物种角度/角标/选中 rim（去卡片化）
- [ ] Glyth 形态（深石墨+两眼，自绘 SVG + motion presence）
- [ ] Core-first relation（先写 Core relation 再投影 edge/Binding，禁止 edge-first）
- [ ] Work View 生命周期（Spatial/Docked/Immersive/Restore，开合不移动相机）

---

## 3. 层级与 ontology 硬约束（违反就是出错）

- [ ] **Project 真值 = Core（.lcosproj）**，不是一个 Huabu canvas 文件。
- [ ] **禁止 Huabu ontology 泄漏**：`Huabu Space ≠ LCOS Project`、`Huabu Frame ≠ LCOS Context/Collection`、`Huabu Edge ≠ LCOS all Relation`、`Huabu persistence ≠ LCOS persistence`、`spatial distance ≠ semantic truth`、`Agent Node ≠ mandatory receiver ontology`。
- [ ] **三 Surface 同构**：Main/Context/Workflow 共享**同一 Spatial Interaction Kernel**（不能 `MainSelectionManager/ContextSelectionAdapter/WorkflowSelectionController`）；区别只在于 semantic projection + surface-specific component capability。
- [ ] **Surface Difference = semantic objects + component capabilities**，不是「基础鼠标键盘重新实现一套」。
- [ ] **去卡片化**：对象 = 物种 morph + 完全隐形壳 + 仅选中显边框 + label 近距披露；**不带**通用卡片壳。节点**之外**的 UI 容器可精致成卡（但不能是 SaaS 注册表样）。
- [ ] **Active Path 不单独建 Node**：真实 relation/path 本身就是路径；Active Path Component 仅在提供额外真能力时才存在。
- [ ] **唯一 owner 硬 KPI**：每核心概念最多 1 个 production owner。

---

## 4. 每补丁必过（QA 阶梯，禁「static gate PASS = 完成」）

```text
source conformance
→ type/lint/unit
→ browser interaction smoke
→ screenshot/visual smoke
→ canonical persistence/reload
→ cross-surface parity（若 shared）
```

- [ ] **禁止**：「MVP 式完成」「语义完成」「基本完成」「接口已经有所以功能算完成」「测试绿所以体验算完成」。
- [ ] 每 Spatial patch 必测（三 Surface 逐项）：Click / Shift 多选 / marquee / Cmd Reference / Move / Resize / Action Arc / Right-click / Relation / Semantic Drop / Composer / Focus / Esc / zoom far-near / pointer cancel。
- [ ] 每 Work View patch 必测：main open → switch context → still open → switch workflow → still open → resize → camera unchanged → focus target not hidden → immersive → restore。
- [ ] 运行态证明必须真实 Browser E2E（不能 reducer 直接调用冒充 gesture）。

---

## 5. 提交/交接必写（Handoff 模板）

```text
Product proposition:
Huabu reused:
LCOS semantics added:
Legacy deleted:
Owner after patch:
Acceptance evidence:
Remaining debt:
```

- [ ] **引入新 owner 的同 patch 退休旧 owner**，禁止无限期兼容层。
- [ ] reuse 的 Huabu/轮子源码注明：upstream 路径 + 版本 + license（provenance）。
- [ ] 不在 Handoff 写「基本完成」。

---

## 6. 目录纪律

- [ ] 新增代码收进 `Huabu/apps/web/src/lcos/`（不散进 Huabu 原目录）。
- [ ] Huabu 原文件**只做薄接缝**（Canvas.tsx / NodeWrapper.tsx / previewWorkspace model+renderer / MainLayout.tsx / CanvasPage|CenterArea.tsx）。
- [ ] `packages/shared/canvas-engine` **不得出现 LCOS 领域语义**。

---

## 7. 微交互 / 动效（定案）

- **用 motion（framer-motion）**（MIT，React19 兼容，Huabu 生态通用）写微交互/过渡/Arrange。
- **优先复用 Huabu 已有动效**（useNodeTakeover / LOD / overlay 过渡 / FloatingToolbar 动画）。
- **React Bits 弃用**（Commons Clause + 营销氛围与 LCOS 相冲）；**Amicro 不采用**（npm 只发布展示站、无 CLI、无组件分发，未成库）。
- 动效边界：节点**本体**去卡片化；节点**之外**的 UI 容器/instrument 层（Arc 弧排/集合散布/Work View 纵深）可精致动效，只要不像 SaaS 注册表。

---

## 8. 全局动工指令（两条，覆盖所有阶段）

### 8.1 默认不新增安全门 / 不删既有安全措施

> **默认不新增 hash、冻结 contract、baseline 或 gate。** 只有能明确说出一个**具体失败场景**，
> 并说明 Git、版本号、主键、事务、唯一约束、类型和普通测试**为什么不足**时，才允许加入。
> **不要为了简化而删除已有安全措施。**
> 门禁只放在**不可逆、跨系统、安全、正式发布**这些边界。
> 前置检查不得挤掉真正的代码执行、模拟或测量。

要点：
- 新增 hash/contract/baseline/gate 是**例外**，默认**不加**。
- 要加就要先写清一个具体失败场景 + 逐一论证已有手段（Git/版本号/主键/事务/唯一约束/类型/普通测试）为何挡不住。
- **只准加**在四类边界：不可逆 / 跨系统 / 安全 / 正式发布。
- 门禁**不得挤掉**真正的执行、模拟或测量（检查是配角，执行是主角）。
- 已有安全措施**一律保留**，不得为简化而删。

### 8.2 每个细分阶段施工前，必须先联网调研成熟 GUI 形态与 UX 方案

> **所有细分阶段的对应施工开始前，一定要先联网搜索 GitHub 或全网搜索，理解了这个阶段应该有的成熟 GUI 实现形态和对应的 UX 交互方案之后，再进行施工执行。**

- 即：**先调研、后动手**。每个 H 阶段/模块动工前，先搜 GitHub/全网，搞清成熟项目这一步的 GUI 形态和 UX 交互。
- 反模式：不查就照自家脑补开工（Gen1 正是"没看别人怎么做"导致呈现灾难的教训）。
- 落地：动工前在 Handoff 里写明「本阶段调研到的成熟形态/UX」，再进入 M0/M1/M2。

---

*关联：README（索引）、GUI 实现方案大补充（总纲+对账）、GUI 轮子复用档案（§3.5 微交互定案）、FigmaMake 视觉基准、重建总纲/三Surface同构/Surface Component Grammar（迁移包 01_CURRENT_CONTEXT）。*
