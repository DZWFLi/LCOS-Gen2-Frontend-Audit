# LCOS Gen2 · Donor 双轨裁决
## 工程实现复用 ≠ UI/UX 视觉借鉴

> 日期：2026-09-04  
> 用途：同步给 LCOS Gen2 各施工规划 / 审计 / 前端重构会话  
> 适用范围：T1 Spatial/HUD、T2 Viewport/Chrome/Railway/Minimap/Navigation、T3 Action Arc/Composer、T4 Work View/Assembly/Context/Workflow/Skill、T5 Visual Component 等所有涉及外部 donor 的前端线程。  
> 性质：跨线程施工原则补充。若与更晚用户原话冲突，以更晚原话为准。

---

## 0. 核心裁决

今后 LCOS Gen2 对外部 donor 的评估，必须明确拆成两条独立轨道：

```text
Track A · 工程实现 Donor
Track B · UI / UX Design Donor
```

两条轨道不得混为一谈。

最关键的一句：

> **前端代码是前端代码，UI 设计是 UI 设计。**
>
> proprietary 产品的源码不能直接复制，不等于它的成熟 UI / UX 解法不能作为高保真设计 donor。

LCOS 当前的问题不是缺少产品语义，而是部分前端视觉完成度、交互精度和审美成熟度不足。

因此外部成熟产品的主要价值之一，就是帮助 LCOS 减少“自己重新设计但结果更差”的风险。

---

# 1. Track A · 工程实现 Donor

工程轨只判断“代码和实现轮子怎么拿”。

必须检查：

- 是否开源；
- License；
- 版本 / commit；
- 维护度；
- React / Huabu / Gen2 技术栈适配；
- 是否制造第二 canonical truth；
- 是否引入第二 viewport / store / canvas engine / pointer owner；
- 是否可 direct use；
- 是否只需 thin wrapper；
- 是否应只借 primitive；
- 是否应拒绝。

统一结论建议使用：

```text
DIRECT_USE
WRAP
LIFT
REFERENCE
REJECT
```

### 工程轨原则

优先级：

```text
Huabu 已有 mechanic
>
同栈 permissive OSS
>
成熟 OSS wheel
>
proprietary bundle provenance
>
self-build
```

也就是说：

> 能吃 Huabu 现成能力，不重新造。  
> 能从成熟 OSS upstream 直接拿，不照着竞品手搓。  
> proprietary bundle 只用于反溯 wheel / architecture，不直接复制代码。

---

# 2. Track B · UI / UX Design Donor

UI/UX 轨判断的是：

> “这个产品已经把界面和交互做得很好，我们应该借多少？”

这一轨可以比工程轨激进得多。

允许高保真参考的内容包括：

- layout geometry；
- 尺寸比例；
- spacing rhythm；
- 信息密度；
- chrome 密度；
- corner radius；
- shadow；
- blur；
- layer hierarchy；
- icon density；
- hover；
- active；
- selected；
- pressed；
- disabled；
- progressive disclosure；
- transient control；
- panel reveal / collapse；
- compact → expanded；
- tooltip；
- popover；
- context menu；
- visual grouping；
- navigation hierarchy；
- masonry / waterfall；
- dock / rail；
- marker / pin presentation；
- motion timing；
- easing；
- stagger；
- scale / fade；
- hover expansion；
- focus arrival feedback；
- visibility rules；
- persistent vs transient UI；
- 视觉节奏；
- “什么时候出现、什么时候隐藏”。

这些东西不应因为 donor 是 proprietary 产品就自动降级成“只看一眼”。

如果 Lovart / TapNow 某个 UI 解法明显成熟，LCOS 没必要为了所谓“原创”故意重新设计一版更差的。

---

# 3. 什么叫“高保真设计 donor”

后续文档禁止再只写：

```text
Lovart = reference only
TapNow = reference only
```

因为这类表述太模糊，容易被施工 Agent 理解成：

> “看一眼，然后自己重新设计。”

以后必须拆开写：

```text
ENGINEERING:
PROPRIETARY_REFERENCE_ONLY

VISUAL:
HIGH_FIDELITY_DESIGN_DONOR
```

例如：

## Lovart

```text
ENGINEERING:
WHEEL_PROVENANCE_ONLY

VISUAL:
HIGH_FIDELITY_UI_DONOR
```

## TapNow

```text
ENGINEERING:
PROPRIETARY_REFERENCE_ONLY

VISUAL:
HIGH_FIDELITY_UI_DONOR
```

## Spatial

```text
ENGINEERING:
BEHAVIOR_REFERENCE

VISUAL / MOTION:
HIGH_FIDELITY_INTERACTION_DONOR
```

## Morphicons

```text
ENGINEERING:
DIRECT_USE_CANDIDATE

VISUAL:
TUNE_TO_LCOS
```

## Amicro

```text
ENGINEERING:
ADOPT_PRIMITIVE_CANDIDATE

VISUAL:
TUNE_TO_LCOS
```

这样才能避免后续施工人员把“不能复制 proprietary source”错误扩展成“视觉也必须重新发明”。

---

# 4. 可以直接高保真借什么

对于 Lovart / TapNow / LibTV 等成熟产品，以下设计层内容可以大胆借鉴：

```text
位置
尺寸
比例
间距
排列关系
hover 展开
active 状态
selected treatment
compact / expanded
popover 位置
menu hierarchy
motion timing
motion direction
fade / scale / slide
chrome 显隐
信息层级
视觉密度
组件之间的距离
persistent / transient 策略
```

例如某个成熟产品的 Pin：

```text
默认很小
hover 后展开
active 后颜色增强
靠 viewport edge 自动避让
label 非常克制
```

这套 design solution 可以高保真复现。

甚至 implementation spec 层可以继续细化：

```text
28px compact
hover 34px
8px radius
120ms scale/fade
```

只要最终：

- 不直接复制 proprietary code；
- 不拿其品牌资产；
- 不照搬受保护的独有图形文件；
- 不制造产品身份混淆。

---

# 5. 什么不能直接抄

以下内容不进入“高保真 UI donor”许可范围：

- proprietary source code；
- bundle 中反编译出来的 React component；
- 直接提取的 CSS / JS；
- 原创 SVG path；
- Logo；
- 品牌 icon；
- mascot；
- 专有 illustration；
- 专有字体文件；
- 明显具有品牌识别性的独有视觉资产；
- 完整照搬造成产品身份混淆的整套 trade dress。

简化理解：

```text
抄设计解法
≠
抄品牌资产
≠
抄 proprietary code
```

---

# 6. 最理想的 donor 链路

最优情况不是“照着 Lovart 重写”。

而是：

```text
Lovart / TapNow
负责告诉我们：
应该长什么样
怎么显隐
怎么动
层级怎么排

↓

bundle / source archaeology
负责告诉我们：
背后可能用了什么 wheel

↓

OSS upstream
负责提供：
合法成熟 implementation

↓

LCOS
负责：
自己的 semantics
自己的 owner
自己的 token
自己的 identity
```

最终目标：

```text
UI quality:
Lovart / TapNow / Spatial 等成熟产品水平

Engineering:
Huabu + permissive OSS + thin LCOS seam

Product semantics:
LCOS 自己
```

---

# 7. 禁止为了“原创”把成熟设计改坏

后续施工不允许出现这种逻辑：

```text
“这个布局 Lovart 已经做得很好，
为了避免太像，
我们改成另一套。”
```

如果改变没有产品语义收益，只是为了显得不同，那么属于无价值重新设计。

只有以下情况才值得主动改：

1. LCOS 的信息层级不同；
2. LCOS 的对象语义不同；
3. Accessibility / keyboard / hit target 需要；
4. Huabu runtime 限制；
5. Work View / safe rect / viewport 约束；
6. 三 Surface 语义需要统一；
7. 外部 donor 方案和 LCOS 使用场景冲突；
8. 品牌资产必须替换；
9. License / code provenance 不允许直接实现。

否则默认：

> 成熟方案能直接借，就不要为了“原创感”重新发明。

---

# 8. 视觉层也不能盲抄

“高保真 donor”不等于整屏像素复制。

每次仍要做三项判断：

### A. Product fit

这个视觉解法是否适合 LCOS 的工作流？

### B. Semantic fit

它是否把 Search / Focus / Pin / Assembly / Surface / Layer 等不同语义混在一起？

### C. Architecture fit

它的视觉效果是否要求引入第二 state owner / canvas / geometry truth？

如果需要，就只借外观结果，不照搬其底层架构。

---

# 9. 对 Gen2 模块化架构的直接影响

为了长期吃 donor，Gen2 的前端模块化目标必须是：

> **canonical owner 稳定，supplier body 可替换。**

而不是：

> “把一个大文件拆成很多小文件。”

推荐结构：

```text
canonical semantic owner
        ↓
tiny adapter / derived presentation policy
        ↓
replaceable UI body
        ↓
existing Huabu composition seam
```

例如：

## Minimap

```text
Huabu viewport truth
→ @xyflow/react MiniMap mechanics
→ LCOS presentation policy
→ replaceable launcher/chrome donor
```

未来视觉换掉，不允许动 viewport / camera。

## Railway

```text
SurfacePort / Core truth
→ Railway presenter
→ replaceable Railway body
```

未来 Railway 视觉失败，只换 body，不动 Surface identity。

## Pin

```text
Core Pin identity
→ Pin presentation adapter
→ replaceable Pin HUD / marker body
```

未来 TapNow 风格过时，只换 renderer。

## Search

```text
Core Project Search
→ Search presenter
→ replaceable Search UI body
```

不允许 UI donor 把 Search 变成第二 search engine。

---

# 10. 对施工文档的强制写法

以后每一个外部 donor 条目至少要有以下字段：

```text
Donor:
Feature:

ENGINEERING_STATUS:
DIRECT_USE / WRAP / LIFT / REFERENCE / REJECT

VISUAL_STATUS:
HIGH_FIDELITY_DONOR / PARTIAL_DONOR / STYLE_REFERENCE / REJECT

Borrow:
- ...

Do not borrow:
- ...

Canonical owner:
- ...

Implementation source:
- ...

Replacement boundary:
- ...

Maximum failure blast radius:
- ...
```

示例：

```text
Donor:
TapNow

Feature:
Color Pin / Spatial HUD

ENGINEERING_STATUS:
PROPRIETARY_REFERENCE_ONLY

VISUAL_STATUS:
HIGH_FIDELITY_DONOR

Borrow:
- compact geometry
- hover expansion
- label density
- active color treatment
- viewport-edge placement behavior
- motion rhythm

Do not borrow:
- proprietary JS/CSS
- original SVG
- brand assets

Canonical owner:
LCOS Core Pin + Huabu spatial truth

Implementation source:
Huabu + LCOS thin renderer + permissive OSS primitive

Replacement boundary:
Pin visual body only

Maximum failure blast radius:
Pin HUD renderer
```

---

# 11. 各线程统一执行原则

## T1 · Spatial / HUD

优先高保真借：

- Spatial immersive canvas；
- TapNow HUD；
- mature LOD / overlay treatment。

但 spatial truth 保持 Huabu。

## T2 · Viewport / Chrome / Railway / Minimap / Navigation

优先高保真借：

- TapNow Pin / navigation；
- Lovart chrome；
- LibTV canvas shell；
- Spatial low-chrome behavior；
- Morphicons / Amicro motion primitive。

但 viewport / Surface truth 保持 Huabu + Core。

## T3 · Action Arc / Composer

优先高保真借：

- Codex Desktop anchor behavior；
- Lovart / TapNow transient action UI；
- Orbit / radial menu visual mechanics。

但 Selection / Reference / semantic actions 仍归 LCOS owner。

## T4 · Work View / Assembly / Context / Workflow / Skill

优先高保真借：

- Lovart masonry；
- dashboard hierarchy；
- persistent panel；
- transient controls；
- context/workflow visual language。

但 canonical data 不归 Work View 本地状态。

## T5 · Visual Component Adoption

这是最适合直接大量采用成熟视觉 body 的线程。

前提仍然是：

```text
visual body replaceable
semantic owner stable
```

---

# 12. 最终一句话

今后所有 LCOS Gen2 前端 donor 工作统一遵循：

> **成熟产品负责回答“应该长什么样、怎么动、怎么显隐”；成熟 OSS 负责回答“怎么实现”；LCOS 负责自己的语义、状态所有权和必要胶水。**

不要因为 proprietary code 不能复制，就强迫 LCOS 自己重新设计成熟 UI。

也不要因为某个成熟产品 UI 很漂亮，就把它背后的第二 canvas / 第二 store / 第二 geometry truth 一起搬进来。

目标不是原创竞赛。

目标是：

```text
成熟视觉
+
成熟实现
+
LCOS 独有语义
+
最薄增量
```

这才是 Gen2 当前正确的 donor 策略。


# 13. 源码级施工方案必须下压到“可直接照抄”粒度

前述“双轨 donor”裁决只解决“什么可以借、什么不能直接复制”的边界。

后续正式源码级施工规划，还必须再增加一条硬要求：

> **施工 Agent 不应再承担二次视觉设计判断。**
>
> 规划必须具体到：目标文件、目标组件、props、JSX 结构、CSS / Tailwind class、design token、状态表、动效参数、safe-rect / viewport 规则、donor provenance、copy / wrap / rewrite 决策，尽量达到“照着施工表即可落代码”的程度。

禁止只写：

```text
参考 TapNow 风格
做得更像 Lovart
增加 macOS 感
优化动效质感
Minimap 改得更轻
Railway 更高级
```

这类描述不是源码级施工计划，只是把审美判断重新甩给施工 Agent。

---

## 13.1 每个视觉组件至少落实到 15 层

后续正式施工表中的每一个视觉 / 交互组件，至少要覆盖：

```text
L1  Product behavior
L2  Visual donor
L3  Exact donor component / screen / state
L4  Exact LCOS target source file
L5  Existing canonical owner / state source
L6  Props / adapter interface
L7  JSX / DOM structure
L8  CSS / Tailwind classes / design tokens
L9  State matrix
L10 Motion values
L11 Safe-rect / viewport placement rule
L12 Responsive / Interaction LOD rule
L13 Donor source / OSS provenance / license
L14 Copy / Wrap / Lift / Rewrite decision
L15 Unit / browser / recovery acceptance
```

只要其中某一层仍然要求施工 Agent 自己重新想一遍“应该长什么样”，就说明规划粒度还不够。

---

## 13.2 proprietary UI donor 也要写成可直接施工的实现规格

对于 Lovart / TapNow / LibTV 产品 bundle：

```text
ENGINEERING:
不能直接复制 proprietary JS / CSS / component source

VISUAL:
可以作为 HIGH_FIDELITY_UI_DONOR
```

因此规划不能停在“视觉参考”。

必须把观察结果转换成 LCOS 可直接施工的 implementation spec，例如：

```text
Feature:
Compact Minimap

Visual donor:
TapNow compact minimap

Default:
width: 34px
height: 34px
border-radius: 10px
background: <LCOS token>
border: <LCOS token>
shadow: <LCOS token>
opacity: ...

Hover:
width: 148px
height: 104px
transition-duration: 160ms
timing-function: cubic-bezier(...)

Placement:
bottom: max(16px, safeRect.bottom + 12px)
right: max(16px, safeRect.right + 12px)

Interaction:
pointerenter → expanded
pointerleave → compact
canvas dragging → suppress expansion
Work View resize → recompute safeRect

Mechanics owner:
Huabu / @xyflow/react MiniMap

Replacement boundary:
launcher / chrome / presentation only
```

这样虽然没有复制 TapNow proprietary CSS 原文，但对施工者而言仍然达到：

> **“按这份规格直接写，不需要重新设计。”**

---

## 13.3 OSS donor 则进一步具体到“这个文件、这段组件直接拿”

如果 donor 是 MIT / Apache / BSD 等经审计允许直接收编的 OSS，施工计划应进一步明确：

```text
COPY FROM:
<upstream repo>/<exact file>

KEEP:
- exact primitive
- exact animation orchestration
- exact keyboard behavior
- exact accessibility behavior

CHANGE:
- LCOS semantic props
- LCOS token / class
- LCOS icon family
- owner binding

DO NOT REWRITE:
- already mature generic primitive
```

例如：

```text
COPY FROM:
packages/.../IconSwap.tsx

KEEP:
AnimatePresence
mode="wait"
initial={false}

CHANGE:
icon source
active semantic state
LCOS token classes

DO NOT REWRITE:
transition orchestration
```

只要 license、版本、维护度和架构边界通过审计，能直接抄成熟代码就不要重写。

---

## 13.4 CSS / token 也属于源码级规划，不是“后续美化”

后续施工规划必须显式给出：

```css
--lcos-nav-glass-bg: ...;
--lcos-nav-border: ...;
--lcos-nav-shadow: ...;
--lcos-nav-radius-sm: ...;
--lcos-nav-radius-lg: ...;
--lcos-nav-hover-scale: ...;
```

以及：

```text
default
hover
pressed
selected
active
disabled
dragging
focus-visible
LOD-compact
LOD-expanded
```

对应的 class / token / selector。

不允许把这些留成：

```text
后续 polish
后续 design pass
根据实际情况微调
```

如果 donor 已经给出了成熟答案，就应在施工规划阶段把它测量、拆解并写死到足以直接实现。

---

## 13.5 JSX / DOM 结构也要给出施工骨架

对于关键视觉组件，正式施工计划应至少给出接近以下粒度的骨架：

```tsx
<div
  className={cn(
    'absolute overflow-hidden',
    'rounded-[10px] border backdrop-blur-xl',
    expanded ? 'h-[104px] w-[148px]' : 'h-[34px] w-[34px]',
    'transition-[width,height,opacity,transform]'
  )}
>
  <MiniMap
    pannable
    zoomable
  />
</div>
```

这类代码骨架不是最终 patch，但它明确了：

- DOM ownership；
- presentation boundary；
- class strategy；
- state-driven styling；
- Huabu mechanic 的插入位置。

目的仍然是减少施工 Agent 自由发挥空间。

---

## 13.6 Donor 规划最终应形成“设计答案 → 实现答案”双映射

每个关键 UI 最终应该同时回答两件事：

```text
这个东西应该长什么样？
→ Lovart / TapNow / Spatial / LibTV 等设计 donor

这个东西具体怎么实现？
→ Huabu mechanic / OSS component / LCOS thin adapter
```

因此推荐最终施工条目使用：

```text
Donor:
Feature:

VISUAL_DONOR:
<product / exact component>

VISUAL_STATUS:
HIGH_FIDELITY_DONOR

ENGINEERING_DONOR:
<Huabu / OSS upstream / existing LCOS primitive>

ENGINEERING_STATUS:
DIRECT_USE / WRAP / LIFT / REFERENCE / REJECT

TARGET_FILES:
- ...

OWNER:
- ...

PROPS:
- ...

JSX_STRUCTURE:
- ...

CSS_TOKENS:
- ...

STATE_MATRIX:
- ...

MOTION:
- ...

SAFE_RECT_RULE:
- ...

LOD_RULE:
- ...

COPY_FROM:
- ...

KEEP:
- ...

CHANGE:
- ...

DO_NOT_COPY:
- ...

REPLACEMENT_BOUNDARY:
- ...

ACCEPTANCE:
- ...
```

---

# 14. 对后续 Gen2 五册施工交付的新增要求

所有涉及 UI / UX 的正式源码级施工册，都必须执行本补充。

尤其是 T2 的：

```text
01_Evidence_Census_Authority_Recovery.md
02_Current_Source_Consumer_Owner_Audit.md
03_Donor_Upstream_Adoption_Retirement_Matrix.md
04_Source_Level_Construction_Plan.md
05_Acceptance_Recovery_CrossReview_Plan.md
```

其中 `04_Source_Level_Construction_Plan.md` 不得只是“文件级任务列表”。

它必须尽可能具体到：

```text
这个现有文件
→ 接哪个 owner
→ 用哪个 donor
→ 抄哪个 OSS component
→ JSX 怎么嵌
→ CSS / token 是什么
→ hover / active 怎么变
→ motion 参数是什么
→ safe rect 怎么算
→ LOD 怎么切
→ 哪部分以后可替换
→ 浏览器里什么样才算完成
```

最终标准不是“施工 Agent 看懂了设计意图”。

而是：

> **施工 Agent 几乎不需要再做 UI 设计，只负责按已经审计好的 blueprint 落代码、跑测试、真浏览器验收。**

---

# 15. 更新后的总原则

此前总原则：

> **成熟产品负责回答“应该长什么样、怎么动、怎么显隐”；成熟 OSS 负责回答“怎么实现”；LCOS 负责自己的语义、状态所有权和必要胶水。**

现补充为：

> **而源码级施工规划必须负责把这三个答案进一步翻译成可直接施工的文件、组件、props、JSX、CSS、token、state、motion 与验收规格。**

因此最终目标不是：

```text
高层设计参考
+
施工 Agent 自己发挥
```

而是：

```text
高保真成熟设计答案
+
合法成熟实现 donor
+
LCOS canonical semantics
+
源码级 direct-construction blueprint
```

也就是：

> **能直接抄成熟 OSS 的地方，明确告诉施工者抄哪个文件、哪段 primitive。**
>
> **不能直接抄 proprietary code 的地方，也必须把其成熟 UI 拆成足够精确的 LCOS JSX / CSS / token / motion 实现规格。**

不要把“视觉实现细节”留到施工阶段临场发挥。
