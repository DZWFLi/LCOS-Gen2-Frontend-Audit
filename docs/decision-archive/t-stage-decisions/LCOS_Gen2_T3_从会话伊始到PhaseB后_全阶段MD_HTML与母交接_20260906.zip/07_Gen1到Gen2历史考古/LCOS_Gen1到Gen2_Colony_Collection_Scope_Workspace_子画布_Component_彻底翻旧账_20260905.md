# LCOS Gen1 → v0.15 → Gen2
# Colony / Collection / Scope / Workspace / 子画布 / Component 彻底翻旧账与当前语义归位

> 日期：2026-09-05  
> 性质：产品语义考古 + 旧代码事实 + 最新冻结对照  
> 目的：把此前容易混淆的“集合 / 空间群落 / 当前工作范围 / 长期工作现场 / 子画布 / 布局组件”彻底分开，并给 T1–T6 后续施工一个不能再串台的边界。
>
> 这不是“再发明一套新定义”。  
> 读取顺序严格采用：
>
> ```text
> 最新用户纠正 / 2026-09-05 V2
> → 2026-09-02 全功能冻结与 Gen2 owner
> → 2026-08-29 UX 冻结与真实 R3-A Colony closeout
> → 2026-08-14 A/B 产品世界观冻结
> → Gen1 / v0.15 真实代码
> ```
>
> 旧代码只证明“当时怎么实现 / 哪里混过”，不能反向覆盖后来的冻结。

---

# 0. 先给最终结论

这次翻完以后，必须把下面 8 个东西分开：

```text
Selection
= 我现在临时选中了谁

Colony
= 当前 Surface 里“哪一片东西被当作一个空间群体”

Collection
= 项目里“哪些对象长期算一组 / 被收纳在一起”

Scope
= 这一次 Context / Workflow / Run 到底处理哪些对象

Component / Layout Instrument
= 这一批对象怎么看、怎么排、怎么工作

Workspace / Current Scene / Long-term Worksite
= 一份可回来的长期工作现场

Child Canvas / Nested Worksite
= 真正拥有自己空间视野/布局/历史的嵌套工作现场

Work View
= 对一个对象或工作打开的深度操作窗口生命周期
```

它们**不能再靠一个 `scopeId`、一个虚线框、一个 Drop animation 统一解释**。

---

# 1. 这次先纠正 T3 前面犯的三个错误

## 错误 1：把 Scope 画成一个常驻“虚线容器”

T3 v3 HTML 里的：

```text
本轮镜头
[ 大虚线框 ]
```

会让用户自然理解成：

```text
Region
Colony
Collection
或一张小工作现场
```

这是错误表达。

当前 Scope 的核心是：

> **这一次工作只处理谁。**

它可以有暂时的范围高亮 / Field / boundary visualization，但它不应该默认变成一块长期空容器，等着用户往里摆东西。

---

## 错误 2：把所有 membership / semantic give 都做成“吸进去 → 原物回位”

这也是过度泛化。

“碰一下 → 建立语义 → source 回位”特别适合：

```text
Glyth
远端子画布 / worksite portal
Railway destination
另一个不在眼前展开的空间
```

因为用户是在：

> “让另一个地方也使用这个对象。”

但如果眼前就是一个**真实可见、直接摆内容的空间结构**：

```text
Colony field
展开 Collection
Gallery
Grid
Masonry
Stack
Frame / Region
```

左拖进去的直接视觉结果应该是：

> **当前 projection 留在那里 / 被那套布局接住。**

不能“进去一下又飞回来”。

---

## 错误 3：把 Collection 过早说成 T2 的“可进入小现场”

这个也必须撤回。

08-14 就已经明确：

```text
Collection 不再是子画布
Collection GUI 不进入新 Canvas
```

09-05 V2 又重新确认：

```text
Collection
Scope
子画布
不能混
```

所以：

> **Collection 默认不是一个要由 T2 负责“进入”的地方。**

T2 只在“导航到它 / Focus 它 / 定位它”层面参与。

只有某个对象被显式 materialize 成真正长期 nested worksite 时，才进入子画布那套导航。

---

# 2. 08-14：最早已经把 Collection / Workspace / Scope 分开

`LCOS_ROADMAP_OPEN_SOURCE_LAUNCH_PLAN_20260814_v3.md` 的 A Gate 已经写得非常直白。

---

## 2.1 Collection

冻结：

```text
Collection 不再是子画布

Collection
= Region/Fence 的持久、命名、可折叠形式

新数据
≠ old child-canvas Collection
```

GUI：

```text
点一次
→ 原地展开成员

再点一次
→ 折叠回 Collection Node

展开
→ 成员按保存布局出现
```

所以 Collection 从很早开始就是：

> **“桌面文件夹 / Stack 式长期收纳”**

而不是：

> “点进去一张新 Canvas”。

---

## 2.2 Workspace / Current Scene

同一份 08-14 冻结真正把“工作现场”给了 Workspace：

```text
Workspace = stable first-class entity
Current Scene = 当前激活的 Workspace
```

保存：

```text
节点呈现
Camera
布局
Context refs
Workflow refs
当前选区 / active object
```

目标：

> **点击 Workspace，恢复“我当时是在怎么工作的”。**

所以历史上：

```text
Collection
≠ Workspace
```

非常明确。

---

## 2.3 Scope

08-14 A Gate 已经要求：

```text
Scope
→ 退化为导航 / 局部呈现边界

不再作为：
业务成员资格
实体所有权
semantic gate
```

这非常关键。

因为旧代码仍然大量叫 `Scope`，但产品层已经明确：

> **不能继续拿旧 Scope 容器世界观解释新产品。**

---

# 3. 旧代码为什么这么容易把人带沟里
## 因为它真的把很多东西全塞进 Scope 了

Gen1 / v0.15 的 `model.ts`：

```ts
ScopeKind =
  | 'root'
  | 'collection'
  | 'context'
  | 'workflow'
  | 'delivery'
  | 'temporary-workbench'
```

而 `CanvasScope` 还带：

```text
parentScopeId
containerNodeId
camera
layoutMode
```

也就是说历史实现实际上把：

```text
Collection
Context
Workflow
Workbench
Camera
Container
```

很多不同层级概念，都经过 `Scope` 这个数据结构表达。

这是一种**历史实现复用**，不是最新产品定义。

---

# 4. 旧 Core 里其实已经开始主动拆这个混乱

后来 domain 源码里出现了一句非常关键的注释：

> **only Collection containment contributes structural depth. Context, Workflow and Scene membership are references/presentation, never ownership.**

翻成人话：

```text
真正有“收纳 / containment”意义的
= Collection

Context
Workflow
Scene
= 使用 / 引用 / 呈现成员
≠ 拥有这些对象
```

甚至还有：

```text
MAX_STRUCTURAL_CONTAINER_DEPTH = 2
```

说明当时已经明确：

> **Collection 是结构收纳；其它“某工作现场里有这些对象”不要冒充结构 ownership。**

这是今天区分 Drop 行为的一个重要底座。

---

# 5. 08-29：Colony 被正式从 Collection 里剥离

这一步特别重要。

正式冻结：

```text
Collection
= durable content containment / 收纳

Colony
= spatial organization scope / 圈起来
```

并明确：

```text
NO Collection → Colony truth shortcut
```

也就是说：

> **“这几个东西长期属于同一集合”**
>
> 和
>
> **“当前画布上这几个东西是一坨”**

是两件事。

---

# 6. Colony 到底是什么

产品语言：

> **这一片东西暂时 / 当前被视作一个空间群体。**

它不是：

```text
Folder
Collection
parent tree
Component
Fence card
child canvas
```

它可以服务：

```text
Selection scope
Move scope
Agent arrange scope
Navigation region
Component binding scope
```

---

# 7. Colony 的真实代码已经做到了什么

08-29 的 `PresentationColonyV0`：

```ts
{
  id,
  label?,
  surface: 'main' | 'context' | 'workflow',
  memberIds: string[],
  contour: { points: ... }
}
```

注意三个关键词：

```text
surface
memberIds
contour
```

它是：

> **一个 Surface 内的 Presentation spatial truth。**

不是一个跨 Surface 的项目内容容器。

---

# 8. Colony membership 不是纯几何，也不是随便经过就加入

这是此前很容易记错的一处历史变化。

R3-A 最终已经冻结：

```text
Colony membership = sticky Presentation truth
```

所以：

```text
仅仅从 Colony 边界穿过去
→ 什么也不发生
```

要加入：

```text
external object / Selection
→ 拖入 Colony
→ explicit Drop
→ add member ids
```

移动已有成员出去：

```text
刚刚越过边界
→ 不立刻踢出去

明显拖远
→ settle
→ 超过 peel threshold
→ 才脱离 Colony
```

这正是为了避免：

> 节点轻轻一抖，所属群落就不停变。

---

# 9. Colony 的空间轮廓是什么

旧 `spatialColony.ts` 已经不是矩形 Fence。

它：

```text
读取 member node geometry
→ 算出 support contour
→ 生成 organic closed path
```

所以 Colony 更接近：

> **围着一批真实对象长出来的一层空间场。**

而不是：

> 一张有标题栏的大 Card。

因此 T3 v3 里那个“本轮镜头大虚线矩形”更不能拿去代表 Colony。

---

# 10. Colony 与 Component 的最终关系

08-29 冻结有一句最重要的口诀：

```text
Colony
= 哪一片

Component
= 这一片怎么看 / 怎么排 / 怎么工作
```

例如：

```text
竞品视觉 Colony
+ Gallery

脚本演进 Colony
+ Versions / Evolution

用户反馈 Colony
+ Relationship

当前行动 Colony
+ Action Path
```

这说明：

> Component 不需要再拥有另一份 member truth。

Component 可以绑定：

```text
Selection
Colony
explicit object refs
```

然后只负责呈现 / 操作。

---

# 11. Universal Component 不是 Collection

冻结的通用 Component：

```text
Arrange
Gallery
Stack
```

V2 又补：

```text
Grid
Masonry
Frame / Region
Align
Distribute
```

这些是：

> **空间整理工具 / Instrument。**

不是：

```text
新项目内容
新 Collection
新 Workspace
```

---

# 12. 当一个 Component “看起来装着内容”时，到底发生什么

这是这次用户新纠正非常重要的地方。

例如一个 Gallery：

```text
[ 图片 A ][ 图片 B ]
[ 图片 C ][ 图片 D ]
```

用户左拖 E 进去。

正确直接体验：

```text
E 被 Gallery 接住
→ 当前 projection 留在 Gallery 的 layout 中
→ layout 重新排
```

不是：

```text
E 碰一下
→ Gallery +1
→ E 飞回原位置
```

---

# 13. 但“留在 Component 里”不自动等于“创建 Collection”

这一层也必须守住。

因为 Gallery 可以绑定：

```text
Collection
Colony
explicit refs
```

因此 Drop 的 canonical mutation 应由 binding owner 决定：

### Gallery bound to Collection

```text
Drop E
→ Collection membership + E
→ E 当前 projection 进入 Gallery layout
```

### Gallery bound to Colony

```text
Drop E
→ Colony memberIds + E
→ E 当前 projection 留入当前 spatial group
```

### Gallery bound to temporary Selection / explicit refs

```text
Drop E
→ 扩展这次 Component binding / 当前 presentation
```

除非用户显式保存成 Collection，否则：

```text
≠ 自动造 Collection
```

所以：

> **视觉上“放进去”**
>
> 不等于
>
> **领域上“一定变成 Collection containment”。**

---

# 14. Collection 到底是什么

当前最稳定的定义：

> **项目中明确保存、可复用的一组对象 / 长期内容 membership。**

它是：

```text
content grouping / containment
```

不是：

```text
spatial reading
work scope
child canvas
layout mode
```

---

# 15. Collection 的旧 GUI 已经证明“原地展开”才是正确传统

旧 App 里实际存在：

```text
expandedCollectionScopeIds
openingCollectionScopeIds
closingCollectionScopeIds
```

点击展开：

```text
找到 Collection container
找到 memberIds
→ layoutExpandedCollectionMembers()
→ 把成员在当前画布重新排出来
```

折叠：

```text
成员保留 committed expanded coordinates
→ 只做 transient fold animation
→ 隐藏当前 projection
```

代码注释还特别说明：

> fold animation 不重写 Project Truth / membership。

这和 08-14 的“桌面 Folder / Stack、原地展开折叠”完全一致。

---

# 16. Collection 展开布局不是“进入一个内层 Canvas”

旧 `collectionExpandLayout.ts` 的注释：

> **Readable local fan-out for physical members when a Collection is expanded. This is Presentation geometry only.**

小 Collection：

```text
2–9
→ 在 Collection node 附近 fan out
```

大 Collection：

```text
>9
→ balanced grid
```

还会避让周围障碍。

因此：

> **Collection 展开 = 当前 Canvas 的 Presentation geometry。**

不是新的 Camera。

不是新的 Canvas runtime。

---

# 17. 用户这次纠正后的 Collection 左拖规则

因此可以确认：

## Expanded / visibly-hosted Collection

```text
A 左拖进入
→ 加入 Collection membership
→ 当前 projection 真正进入 Collection 展开布局
→ 不弹回
```

---

## Collapsed Collection

更合理的直接动作是：

```text
A 左拖到折叠 Collection
→ membership 加入
→ A 的当前 free projection 被折叠/收纳进 Collection presentation
```

也不应该：

```text
A 飞回原位置
```

因为用户是在做：

> **收纳。**

---

# 18. Collection 的 Right-drag 不能简单照搬 Glyth

这里要特别小心。

Right-drag 的冻结心智是：

> **只拿它过去用，不动原位置。**

如果目标是 Collection：

```text
Right-drag A → Collection
```

可能合理表达：

> “让这个 Collection 也拥有 A 的 membership / projection，但 Main 当前 A 不动。”

这需要：

```text
same canonical object
+
multiple projections / membership
```

而不是复制 Artifact。

但这条对 **collapsed Collection 如何同时隐藏 Collection 内成员而又保留 Main projection** 有 presentation 冲突。

所以：

> **Right-drag → Collection 的 exact projection policy 不能由 T3 单独冻。**

需要 T1 / T6 / ProjectionBinding 一起定。

这和 Glyth 不一样。

Glyth Right-drag 没有这个矛盾：

```text
A stays
Conversation Context Mapping + A
```

---

# 19. Colony 左拖 vs 右拖

## 左拖

非常自然：

```text
A 拖进 Colony
→ explicit Drop
→ A 留在该空间位置
→ Colony contour / member truth 更新
```

符合“这一片”。

---

## 右拖

如果 A 明明在 Colony 外面：

```text
A 不移动
→ 只加 Colony membership
```

就会出现：

> “它明明不在这一片，为什么算这一片？”

虽然 Colony membership 是 sticky，不是纯几何，但这仍然违背主要空间心智。

因此建议：

```text
Right-drag 不应该被视为所有 target 的 universal membership action。
```

对 Colony：

> **默认不把“外部对象右拖到 Colony”作为标准加成员手势。**

如果未来有某种“给这个 Colony 使用但不加入空间群落”的语义，那应该是另一个 target capability，而不是 Colony membership。

这是 T3 本轮必须修正的地方。

---

# 20. Scope 到底是什么

09-02 总账：

> **Context / Workflow / Run 的工作范围。**

大白话：

> “这次只处理这些。”

它可以：

```text
由 Selection 提议
```

但只有：

```text
明确 Save / Commit
```

才成为长期可恢复 truth。

它不是：

```text
Folder
Collection
Colony
子画布
Workspace
```

---

# 21. Scope 为什么旧代码看起来像一个容器

因为旧：

```text
ScopeKind
CanvasScope
scopeId
opensScopeId
```

被拿来兼容：

```text
collection
context
workflow
delivery
temporary-workbench
```

甚至旧 CanvasScope 有 Camera。

后续冻结正是为了把这层历史过载拆掉。

所以 Gen2 绝对不能继续：

```text
旧 Scope type
→ 直接一对一映射成最终产品 Scope
```

---

# 22. Scope 正确的视觉方向

Scope 可以表现为：

```text
selection-derived field
work boundary
current target set highlight
Context / Workflow 内的 active range
```

但它不应该默认是：

```text
常驻空虚线 container node
```

特别是在 Main 上摆一个：

```text
“本轮镜头”
[空大框]
```

这是错误的 T3 Demo 表达。

---

# 23. Workspace / Current Scene 历史上才是真“工作现场”

旧产品冻结：

```text
Workspace = stable first-class entity
Current Scene = active Workspace
```

旧代码 Workspace 有：

```text
label
scopeId
camera
visibleLayers
focusedViewIds
contextPolicy
frameBounds
preferredSurface
```

因此 Workspace 具备：

> **恢复一份现场的意图。**

而 Collection 从来不是拿来做这个的。

---

# 24. Workspace Frame 也不等于 Collection

旧 `workspaceFrames.ts`：

```text
读取 workspace member nodes
→ 算 bounds
→ 画一个 frame
```

移动 Workspace Frame：

```text
moveWorkspaceMembers(...)
```

它表达：

> **一份工作现场成员的空间整体。**

但这是历史实现。

---

# 25. 现代 Gen2 对 Workspace / Child Canvas 的处理必须比旧代码更谨慎

09-02 明确：

```text
Main
Context
Workflow
= 三个独立一等 Spatial Worksite
```

每个都有：

```text
canvas identity
camera
selection
layout
history
```

同时明确：

```text
子画布 = nested spatial worksite
Work View ≠ 子画布
```

这是当前最重要的边界。

---

# 26. 现在什么时候才应该出现子画布 / 长期 Worksite

09-05 V2 的方向：

只有真的需要：

```text
独立视野
独立布局
独立历史
长期成员
以后回来继续
```

才值得 materialize 成 nested long-term worksite。

因此：

```text
Collection
→ 不自动子画布

Scope
→ 不自动子画布

Colony
→ 不自动子画布

Component
→ 不自动子画布
```

否则所有整理动作都会疯狂生小世界。

---

# 27. Glyth 是当前最明确的子画布案例之一

V2 已明确：

```text
双击 Glyth
→ 进入同一 Conversation 深度工作状态
```

它允许同时存在：

```text
Conversation 子画布
Conversation 深度预览
Assembly
```

其中：

```text
Conversation 子画布
= nested spatial worksite

Preview / Assembly
= Work View / deep work regions
```

这三者也不能混。

---

# 28. Work View 到底是什么

Work View 是：

```text
SPATIAL
→ FOCUS
→ FLOATING / DOCKED
→ IMMERSIVE
→ RESTORE
```

它处理：

```text
专业查看
编辑
深度工作
```

但：

> **它不是第四 Surface，也不是 child canvas。**

打开 Work View：

```text
不移动原 Canvas camera
不重排节点
```

---

# 29. Frame / Region 为什么还会出现在 V2，而老 Region 又说退役

这里很容易又被名字骗一次。

老的：

```text
Fence / Region
```

作为：

```text
durable component / business truth / scope owner
```

已经退役。

但 V2 仍允许：

```text
Frame / Region
```

作为：

> **空间整理工具 / visual instrument。**

所以：

```text
old Region domain semantics
= RETIRE

new Frame/Region spatial tool
= 可以存在
```

同名不等于同一 owner。

---

# 30. 跨 Surface 到底有哪些“集合”

现在可以按 truth 层分。

---

## 30.1 Selection

```text
surface-local / session-local
```

Main 的 Selection：

```text
≠ Context Selection
≠ Workflow Selection
```

不会跨 Surface 自动跟随。

---

## 30.2 Colony

`PresentationColonyV0` 自己带：

```text
surface: main | context | workflow
```

所以：

> **Colony 属于某一个 Surface 的 Presentation。**

同一批 canonical objects 可以：

```text
在 Main 是 Colony A
在 Context 是 Colony B
在 Workflow 根本不成 Colony
```

它们不是同一个跨 Surface Colony。

---

## 30.3 Collection

Collection 是：

> **项目级长期内容 membership / containment。**

同一个 Collection identity 可以被不同合法 Surface 使用 / 投影。

Surface 可以各自：

```text
有不同 projection
不同 layout
不同 camera
不同 visible component
```

但：

```text
Collection membership truth
```

不应该因为 Surface 不同复制三份。

---

## 30.4 Scope

Scope 是：

```text
某个 Context / Workflow / Run 当前工作边界
```

所以它天然有：

```text
work-context owner
```

它不是一个“跨三 Surface 的统一文件夹”。

同一组对象可以同时属于：

```text
Collection X
+
当前 Workflow Scope
+
某个 Conversation Context Mapping
```

这些都不冲突。

---

## 30.5 Context / Workflow membership

历史代码已经有独立：

```text
contextMembersById
workflowMembersById
collectionMembersById
```

这非常能说明问题：

```text
Context 使用哪些对象
Workflow 使用哪些对象
Collection 收纳哪些对象
```

本来就是不同 semantic channel。

Gen2 应把 owner 做干净，而不是把三份 state 再照搬。

---

## 30.6 Child Worksite membership

子画布里的对象：

```text
= 同一 Project object 的 projection / worksite membership
```

不是：

```text
复制一个 Artifact
```

它有自己的：

```text
canvas
camera
geometry
history
```

---

# 31. “一个东西被拖到另一个东西”现在应该先看 Target Class

不要再用：

```text
membership → source return
```

这么粗的规则。

真正应先分：

---

## A. Spatial Host / Visible Organizing Target

眼前就是可见空间组织。

例如：

```text
Colony field
expanded Collection
Gallery
Grid
Masonry
Stack
Frame / Region
```

### Left drag

```text
source 当前 projection
→ 真正进入 / 留在 target layout
```

target owner 再决定：

```text
Colony membership
Collection membership
Component binding
只是 geometry
```

---

## B. Remote Semantic Identity / Portal

例如：

```text
Glyth
Child Canvas portal
Railway destination
另一个 Worksite entry
```

### Left Give / Right Carry

```text
当前 source projection 留在原 worksite
target 获得：
mapping / membership / projection / use
```

这种才最适合：

```text
ghost transfer
+
source home
```

---

## C. Relation-only target

如果没有：

```text
contain
join
use
map
```

等 body-primary semantic：

```text
body collide
→ direct Relation candidate
```

---

# 32. 这对我们前面的“搬 / 给 / 右拖 / 连”要做一个修订

旧版：

```text
左拖空白 = 搬
左拖身体 = 给
右拖 = 借过去用
Relation handle = 连
```

仍然成立。

但必须增加一层：

> **“给”不是固定动画结果。**

---

## Give to visible host

```text
给
→ 当前 projection 留下 / 被排进去
```

---

## Give to remote identity

```text
给
→ 目标建立语义
→ source 当前 projection 回 home
```

---

所以：

```text
gesture grammar
≠ placement result
```

placement result 是 target contract。

---

# 33. T1–T6 到底谁管什么
## 不能再回答“都是 T5”

下面必须拆成：

```text
产品/UX owner
空间机械 owner
canonical truth owner
视觉 owner
```

---

# 34. Colony ownership

## T1

主责：

```text
空间交互
contour / hit
drag in
member move
peel
rescope
Selection / geometry
Huabu integration
```

## T6 / Core

负责：

```text
Presentation Colony persistence / validation
canonical presentation write
migration
```

## T5

负责：

```text
organic field 最终长相
edge wake-up
peel neck
selected motion
Component attachment visual
```

## T3

只负责：

```text
它与统一 local Drop / Right-click / Relation grammar 怎么接
```

但不能定义 Colony truth。

---

# 35. Collection ownership

## T6 / Core

主责：

```text
Collection identity
durable membership
containment validation
跨 Surface 同一 canonical truth
```

## T1 / Huabu side

负责：

```text
当前 Surface 中 Collection projection 的 geometry
展开 / 折叠
member layout
直接拖入的 spatial behavior
```

## T5

负责：

```text
Folder / Stack / visible host morphology
Gallery/Stack 等视觉 donor adoption
展开动效 / visual polish
```

## T3

负责：

```text
local drag admission
right-drag 语义入口
Action Arc / management
```

## T2

只负责：

```text
Focus / locate / Railway navigation 到 Collection
```

**不负责“进入 Collection 子画布”，因为默认没有这个产品行为。**

---

# 36. Scope ownership

## T4

负责：

```text
Context / Workflow / Run 中：
Scope 到底代表哪次工作边界
何时显现
何时保存
如何用于专业工作
```

## T6 / Core

如果 Scope 被明确持久化：

```text
persistence / work semantic truth
```

由 Core 承接。

## T1

负责：

```text
field / highlight / spatial range presentation
```

## T3

负责：

```text
用户怎样把对象纳入/移出当前 Scope
```

## T5

只负责视觉。

---

# 37. Component / Layout Instrument ownership

空间类：

```text
Arrange
Gallery
Grid
Masonry
Stack
Frame/Region
```

## T5

主导：

```text
donor 选择
visual body
morphology
motion polish
```

## T1 / Huabu

真正负责：

```text
geometry
batch layout
drag/drop physical mechanics
selection
resize
```

## Binding truth

取决于它绑定：

```text
Selection
Colony
Collection / explicit refs
```

Component 自己不能偷偷发明第二份 member truth。

---

# 38. Child Canvas / Nested Worksite ownership

## T1

```text
真实 SpatialCanvas mechanics
camera
geometry
selection
```

## T2

```text
进入
返回
Arrival
Location Orbit
Railway / path
parent ↔ child navigation
```

## T6

```text
worksite identity
membership / projection persistence
restart recovery
```

## T4

如果这个 nested worksite 是：

```text
Conversation / Workflow / Context 等专业工作对象
```

T4 定它周围需要哪些深度工作区域 / Work View。

但：

> **T4 Work View 不等于 child canvas owner。**

## T5

最终视觉 / transition。

---

# 39. Workspace / Current Scene 需要特别标一个迁移注意

历史产品定义非常清楚：

```text
Workspace / Current Scene
= 长期可恢复工作现场
```

左 Railway 到 09-05 仍然保留：

```text
长期 Workspace
```

所以这个用户概念没有消失。

但：

> **不能直接把 Gen1 `Workspace` interface 当成 Gen2 最终 canonical implementation owner。**

因为旧 Workspace 同时带：

```text
scopeId
camera
focusedViewIds
frameBounds
preferredSurface
```

是旧运行时组织方式的一部分。

Gen2 应保留：

```text
“长期可恢复 worksite”产品语义
```

但具体最后由：

```text
Workspace entity
Worksite identity
Project Session
或组合 contract
```

哪一个承接，需要 T2/T6 用当前 Gen2 source 最终落 owner。

T3 不应该自行宣布：

```text
child canvas == old Workspace
```

---

# 40. Work View ownership

明确：

```text
T4
= Work View product owner
```

T4 管：

```text
FLOATING
DOCKED
IMMERSIVE
RESTORE
occupiedRect
safeRect
```

T1/T2：

```text
确保 Canvas / HUD / camera interaction 合法
```

T3：

```text
Arc / Composer / Reference 等 local UI 如何避让
```

T5：

```text
panel / material / motion / proportions
```

---

# 41. T5 到底是什么

V2 已经说得非常死：

T5 可以改变：

```text
长什么样
怎么动
比例
材质
动效
组件美术
Glyth creature
```

T5 不能改变：

```text
Collection 是什么
Scope 是什么
子画布何时出现
Drop 是什么意思
是否复制数据
```

所以：

> **T5 绝对不是 Colony / Collection / Scope / 子画布 的统一 owner。**

---

# 42. 最值得总规划补的一张跨线程表

现在总规划真正应该建立：

```text
Semantic Container / Grouping Ownership Matrix
```

至少列：

| Concept | Canonical Truth | Surface Geometry | Local Gesture | Navigation | Professional UX | Visual |
|---|---|---|---|---|---|---|
| Selection | session/Huabu | T1 | T1/T3 | - | - | T5 |
| Colony | Presentation/Core | T1 | T1/T3 | T2 overview | component consumer | T5 |
| Collection | Core | T1 | T3 | T2 locate | - | T5 |
| Scope | Core/work owner | T1 | T3 | T2 if needed | T4 | T5 |
| Component | Presentation binding | T1 | T1/T3 | - | T4 for professional | T5 |
| Long-term Worksite | T6/current contract | T1 | T3 entry | T2 | T4 by domain | T5 |
| Child Canvas | worksite/presentation | T1 | T3 entry | T2 | T4 adjacent views | T5 |
| Work View | work session | screen-space | T3 coexist | - | T4 | T5 |

这比：

```text
“Collection 归第二路”
“Colony 归第五路”
```

这种单 owner 说法准确得多。

因为这些东西天然跨：

```text
truth
geometry
gesture
navigation
visual
```

五层。

---

# 43. 当前 Demo 必须改的地方

## REMOVE

```text
Main 上常驻“本轮镜头 Scope”大虚线容器
```

---

## REBUILD Colony

应该是：

```text
一批对象周围长出的 organic field
```

支持：

```text
显式拖入
sticky member
peel
rescope
```

---

## REBUILD Collection

至少展示两态：

```text
collapsed Folder / Stack identity
↕
in-place expanded members
```

左拖成员进去：

```text
留在 Collection presentation
```

不回弹。

---

## ADD Gallery / Stack as Instrument

展示：

```text
同一批对象
→ Gallery / Masonry / Stack
```

只是布局 / presentation。

不要自动创造 Collection。

---

## KEEP Glyth semantic-return

```text
Artifact → Glyth
→ Context Mapping
→ source home
```

这是正确使用回弹动作的地方。

---

## ADD Child Worksite Portal

明确演示：

```text
Artifact → nested worksite entry
→ child worksite 里出现 same canonical object projection
→ parent source stays
```

这和 Collection visually 不同。

---

# 44. 当前最关键的 Drag 结果表

| Target | 左拖结果 | 是否回原位 |
|---|---|---|
| Blank Canvas | Move | 否 |
| Colony visible field | 加成员 + 留在空间群体 | 否 |
| Expanded Collection | Collection membership + 留入展开布局 | 否 |
| Collapsed Collection | membership + fold/收纳 | 否 |
| Gallery/Grid/Masonry/Stack visible host | 进入/重排当前 projection；canonical mutation 由 binding 决定 | 否 |
| Frame/Region visual organizer | spatial placement | 否 |
| Glyth | Conversation Context Mapping | 是 |
| Child worksite portal | target worksite 增 projection/membership | 是 |
| Railway remote destination | 目标现场使用 same entity | 是 |
| Ordinary peer object，无 Give semantic | Direct Relation candidate | 是 |
| Relation handle | explicit Project Relation | source 从未移动 |

---

# 45. 一个很重要的新限制：Right-drag 不是万能 membership

Right-drag 的产品心智：

> “原位置不要动，只拿它过去用。”

最适合：

```text
Glyth
remote worksite
Railway
Assembly
Workflow input
```

但对：

```text
Colony
```

这种“哪一片”的空间组织，right-drag 加 member 而对象留在远处，很可能语义冲突。

对：

```text
Collection
```

则需要确认：

```text
membership
vs
当前 Surface projection hiding/folding
```

如何共存。

所以后续不能：

```text
所有 receiver
→ left/right drag 用同一 mutation
```

必须 target capability fail-close。

---

# 46. 当前仍需跨线程最终确认的少数点

翻完旧账以后，真正还没被产品历史完全写死的不是很多。

## A

```text
Right-drag → Collection
```

如何保留 source current projection，同时加入 Collection membership。

需要：

```text
T1 + T3 + T6 / ProjectionBinding
```

---

## B

```text
Gen2 Long-term Worksite
```

最终 canonical contract / data owner 到底叫什么。

产品语义明确：

> 可恢复长期现场。

但不要无脑复活旧 Workspace runtime。

需要：

```text
T2 + T6
```

---

## C

各 visible Component：

```text
Gallery
Stack
Grid
Masonry
```

在绑定：

```text
Collection / Colony / explicit refs
```

时 Drop exact mutation matrix。

需要：

```text
T1 + T5 + T6
```

T3 只提供统一 Gesture adapter。

---

# 47. 最后的人话版

以后谁再混，我建议直接拿这 7 句话审：

> **Selection：我现在选谁。**
>
> **Colony：这一片是谁。**
>
> **Collection：哪些东西长期是一组。**
>
> **Scope：这次只处理谁。**
>
> **Component：这一组现在怎么摆、怎么看、怎么工作。**
>
> **Worksite / 子画布：我要不要真的开另一张可长期回来的桌子。**
>
> **Work View：我要不要把某个东西暂时放大进入深度工作。**

如果一个设计解释不了它属于上面哪一层：

> **先别写代码。**

因为历史已经证明，最容易把 LCOS 做乱的不是功能不够，而是把“看起来都像一圈东西”的七个概念塞回同一个 Scope/Container 里。
