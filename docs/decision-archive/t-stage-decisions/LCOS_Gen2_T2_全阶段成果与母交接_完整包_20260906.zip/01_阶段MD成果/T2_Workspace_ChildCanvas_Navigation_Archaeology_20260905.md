# LCOS Gen2 · T2 Workspace / Child Canvas / Navigation 语义考古
## Gen1 → v0.15 → Gen2 · Workspace / Current Scene / Long-term Worksite / Child Canvas / Railway / Focus / Locate / Arrival / Back

日期：2026-09-05  
线程：T2 · Navigation / Railway / Arrival / Focus  
状态：阶段 A 专业自查与修正，**不施工**

---

# 0. 本文纪律

本文严格服从《六路统一语义考古 / 跨线程对账与重对齐指令》。摘要只用于定位风险，不作为施工证据。

证据优先级：

```text
2026-09-05 最新用户明确纠正 / 最终产品冻结 V2
→ 2026-09-02 Gen2 全功能冻结 / owner
→ 2026-08-29 UX / closeout
→ 更早产品冻结 / 原始用户原话
→ Gen1 / v0.15 历史源码
```

历史代码只回答“当时做过什么、哪里混过”，不得反向覆盖后续产品冻结。

状态仅使用：

```text
CURRENT_TRUTH
KEEP
SUPERSEDED
LEGACY_COMPAT
PRESENTATION_ONLY
OPEN
```

---

# 1. T2 当前责任边界

T2 回答：

> 用户怎么进入、离开、定位、返回一个工作现场。

当前主责：

- Railway；
- Navigation；
- Arrival；
- Back stack；
- Focus / Locate；
- parent ↔ child；
- Workspace / Worksite 导航；
- Context / Workflow long-lived destination；
- Child Canvas entry / return；
- Work View 出现以后 Search / Focus / Pin / Locator / Minimap / safeRect 是否仍正确。

T2 **不得自行决定**：

- Collection canonical membership；
- Scope truth；
- Workflow canonical truth；
- Colony geometry；
- Work View 专业内容；
- Long-term Worksite 最终 canonical contract。

---

# 2. 08-14 原始冻结：Collection 与 Workspace 当时已经分开

来源：`LCOS_ROADMAP_OPEN_SOURCE_LAUNCH_PLAN_20260814_v3.md`

## 2.1 Collection

原稿明确：

```text
Collection 不再是子画布
Collection GUI 不进入新画布
点击一次 → 原地展开成员
再点一次 → 折叠成 Collection Node
```

因此历史上已经明确：

> Collection = 长期收纳 / membership / 原地 presentation，不是“进入另一张 Canvas”。

状态：`CURRENT_TRUTH`（被 09-05 V2 再次确认）。

T2 结论：

```text
Collection Focus / Locate
≠ Enter Child Canvas
```

旧计划里任何“点击 Collection → 进入 Scene / Back”的设计均应标 `SUPERSEDED`。

---

## 2.2 Workspace / Current Scene

同一份 08-14 原稿明确：

```text
Workspace = stable first-class entity
Current Scene = 当前激活的 Workspace
点击 Workspace Node → 回到同一个工作现场
```

原稿还写了 Workspace 初期保存：

- 节点呈现；
- Camera；
- 布局；
- Context refs；
- Workflow refs；
- 当前选区 / active object。

产品目标：

> 点击 Workspace，恢复“我当时是在怎么工作的”。

这一条历史心智非常清楚：

> **长期可恢复工作现场确实是 LCOS 很早就存在的产品概念。**

状态：

- “长期可恢复现场”产品语义：`KEEP`
- “旧 Workspace interface 就是 Gen2 Long-term Worksite contract”：`OPEN`

---

## 2.3 Scope

08-14 原稿已经要求：

```text
Scope → 导航 / 局部呈现边界
不再作为业务 membership / entity ownership / semantic gate
```

所以旧源码中大量：

```text
scopeId
parentScopeId
CanvasScope
```

不能继续被解释成 Gen2 的产品 container hierarchy。

旧 `scopePath / parentScopeId` 可以证明历史导航 mechanics，但不能成为 Gen2 Child Worksite truth。

状态：旧 Scope-as-container runtime `SUPERSEDED`。

---

# 3. 08-21 三大视图：Workspace 与 Surface 再次分叉

来源：`LCOS_0.1_三大独立视图组件化详细施工总稿_v03_对话选择与承接全链补齐_20260821.md`

此阶段已明确一级工作视图：

```text
Main
Context
Workflow
```

三者：

- 共享同一物理交互内核；
- 但各自拥有独立 viewport / camera / selection / layout / history；
- 切换 active view 不扰动其它视图；
- SurfaceDock 是一级 Surface switcher；
- Railway 是项目级场景 / Workspace 导航。

因此：

> **Main / Context / Workflow 是顶层 Surface；Workspace / Worksite 是可恢复工作现场。两者不是同一个维度。**

状态：`CURRENT_TRUTH`，后续 Gen2 `surfacePort.ts` 继续确认。

---

# 4. Gen1 源码：Enter Workspace 与 Locate Workspace 本来就是两种动作

Gen1 源码链中恢复出两个不同路径。

## 4.1 Enter

`openWorkspaceScene(id)` 历史行为：

- 切 active workspace / scope；
- 清理 / 切换相应 selection；
- 恢复该 Workspace 的 camera；
- 恢复工作现场状态。

用户感知：

> **我进入另一个长期工作现场。**

## 4.2 Locate

`locateWorkspace(id)` 历史行为：

- 计算目标 frame / bounds；
- `fitBounds()`；
- 源码注释明确“仅改变 Camera”。

用户感知：

> **我还在当前现场，只是镜头去找它。**

因此必须冻结：

```text
ENTER_WORKSITE ≠ LOCATE_TARGET
```

这条差异不能再被一个万能 `navigateTo()` 抹掉。

状态：产品差异 `KEEP`；旧具体函数 / old scope runtime `LEGACY_COMPAT / SUPERSEDED`。

---

# 5. Back 的历史：产品动作有价值，旧 Scope hierarchy 不能复活

Gen1 breadcrumb 曾有：

```text
onEnter → enterScope
onBack → parentScopeId ? leaveScope : null
```

说明历史上确实存在：

> 用户进入一个更深工作现场后，要有明确返回路径。

但当时 Back 绑定 `Scope.parentScopeId`，而 Scope 已经被后续冻结降级。

所以：

- Back / Return 产品动作：`KEEP`
- `parentScopeId` 作为 Gen2 child-worksite canonical back stack：`SUPERSEDED`
- Gen2 back-stack persistence/session contract：`OPEN / WAIT_CROSS_THREAD`

---

# 6. 09-05 最新定义：Long-term Worksite、Child Canvas、Work View 必须三分

最新统一考古和 V2 已明确：

## Long-term Worksite

> 一份以后还能回来继续的长期工作现场。

## Child Canvas / Nested Worksite

> 真正拥有独立空间视野、布局、历史的嵌套工作现场。

## Work View

> 对某对象 / 工作打开的深度查看、编辑和操作窗口。

因此：

```text
Work View ≠ Child Canvas
Collection ≠ Child Canvas
Scope ≠ Child Canvas
Instrument ≠ Child Canvas
```

只有用户明确需要：

- 独立视野；
- 独立布局；
- 独立历史；
- 长期成员；
- 下次回来；

才成立长期 worksite / child canvas。

状态：`CURRENT_TRUTH`。

---

# 7. Work View 对 T2 的正确边界

旧阶段曾容易把 FOCUS / Docked / Immersive 当成 T2 全部 owner。

09-05 六路职责已重新分工：

```text
T4
= Work View / professional instrument lifecycle owner

T2
= navigation integration owner
```

所以 T2 负责：

- Work View 出现后 Railway 不失效；
- Search / Focus / Pin / Locator / Minimap 重新避让；
- occupiedRect / safeRect 消费；
- Work View open / resize 不自动移动 Camera；
- 用户显式 Focus/Locate 时才 safeRect-aware reframe；
- Restore 后导航上下文正确。

T2 不负责定义：

- Assembly / Context Atlas / Skill Builder 的专业内容；
- Float / Dock / Undock 产品生命周期本身；
- Work View canonical identity。

旧“T2 owns all Work View lifecycle”标 `PATCH_OWNER`。

---

# 8. Assembly 导航纠偏

最新用户明确纠正：

错误：

```text
Main 上存在一个“Assembly Node”
→ 点击它进入 FOCUS
```

正确：

```text
Selection
→ Action Arc
→ Assembly
→ same project-level Assembly Work View
→ 从当前 Selection / trigger anchor 进入 FOCUS
```

Assembly 是专业工作区，不是 Main 内容节点。

因此：

- `AssemblyNode` 产品概念：`SUPERSEDED / DO_NOT_BUILD`
- Assembly 作为普通 top spatial-index mode：`SUPERSEDED`
- Selection → Assembly trigger：`CURRENT_TRUTH`
- T2 只负责其打开后的 navigation/safeRect：`CURRENT_TRUTH`

---

# 9. Gen1 Shell Chrome：Railway / SurfaceDock / MiniMap 原本就是三个角色

历史前端 `CanvasSceneHost` 同时拥有独立 props：

```text
workspaceRail
surfaceDock
miniMap
```

而视觉审计也记录固定 Shell Chrome：

```text
左：WorkspaceRailVNext
底：SurfaceDock
画布：CanvasMiniMap
```

这说明它们不是后来靠记忆拆出来的三块，而是 Gen1 真正存在过的产品结构。

---

# 10. SurfaceDock：底部中心属于三视图，是原源码明确资产

Gen1 `SurfaceDock.tsx` 有非常关键的源码注释：

> 画布缩放控件已按“完成或删除”裁定移除；缩放走滚轮/触控板，dock 空间让给三视图与现场 pill。

因此：

```text
bottom-center
= Surface switching / current semantic scene
```

不是：

```text
= permanent canvas-editing toolbar
```

状态：

- SurfaceDock 的产品位置 / 心智：`KEEP`
- Gen1 具体视觉：`PRESENTATION_ONLY / MODERNIZE`
- Huabu NodeToolbar 永久占 bottom-center：`PATCH_UX`

注意：这不等于删除 Huabu Select / Pan / Lasso / Frame / Text / Sketch mechanics，只是它们不再自动获得一级 Chrome 优先级。

---

# 11. CanvasMiniMap：Viewport controls 集成 Minimap 是历史上已经做过的

Gen1 `CanvasMiniMap.tsx` 已经包含：

- Minimap；
- Zoom Out；
- live zoom %；
- click zoom % → reset 100%；
- Zoom In；
- Grid Snap；
- Fit Content；
- click map → move Camera；
- drag camera rect；
- activeSpatialViewport safe inset；
- arrival beacon；
- collapsed launcher。

因此用户最新提出：

> “Zoom / Fit / Lock 这些东西完全可以直接集成到 Minimap 里面”

不是新的拍脑袋合并，而是与 Gen1 历史产品资产高度一致。

状态：

- Spatial Navigator / Minimap cluster：`KEEP / MODERNIZE`
- Huabu world/viewport mechanics：`CURRENT_TRUTH`
- TapNow expanded direct-manipulation behavior：`PRESENTATION_ONLY / INTERACTION_DONOR`
- Lovart/tldraw low-chrome shell：`PRESENTATION_ONLY`

---

# 12. Railway：Gen1 是“可用资产”，不是应该重写的失败设计

Gen1 `WorkspaceRailVNext` 已有：

- 真实 member x/y normalized mini preview；
- 无 geometry 时 truthful fallback；
- `+N` overflow；
- Hover large preview；
- reorder；
- source ghost / neighbor shift；
- direct project-view semantic drop；
- adaptive packing。

这些证明 Railway 已经达到可用阶段。

真正要废的是旧 ontology：

```text
scene | collection | context | workflow
```

平级混在一起。

Gen2 当前 Railway 应承接：

- Main / Context / Workflow 一级现场导航；
- materialized long-term worksite destination；
- Receiver；
- cross-surface drop；
- current scene / worksite identity；
- preview。

Collection / Scope / Context 临时时间块都不能自动变 Rail item。

状态：

- Railway product concept：`KEEP`
- Gen1 preview/drop/reorder interaction：`KEEP / LIFT`
- old flat rail kind ontology：`SUPERSEDED`
- exact Gen2 long-term worksite item identity：`OPEN / WAIT_CROSS_THREAD`

---

# 13. Railway 的 Gen2 呈现方向：不是文件树，而是空间骨架

当前 T2 UX 方向，经 Gen1 与 Gen2 证据对齐后：

```text
Surface
→ Glyph first

Long-term Worksite
→ true spatial preview first

Receiver
→ Glyth identity first
```

Railway Rest：低 Chrome。

Railway Drag：临时成为 Receive Map。

Railway Hover：Peek，只回答“这是什么现场、大概有什么、要不要过去”，不复制 LayerPanel。

状态：`PATCH_UX`，但 exact visual 仍待 T5 final review。

---

# 14. Search / Focus / Locate / Enter / Arrival / Back 必须拆成六个动作

这是本轮 T2 最重要的语义整理之一。

## Search

用户不知道对象在哪 / 叫什么。

```text
Project Search
→ candidate
→ optional Focus handoff
```

状态：`CURRENT_TRUTH`。

## Focus / Where

对象身份已经知道，回答：

> 它在哪些 Surface / Worksite / projection 出现？

Focus 是 occurrence locator，不是全文 Search。

状态：`CURRENT_TRUTH`。

## Locate

目标 occurrence 已经决定。

```text
target bounds
→ Huabu camera fit
→ safeRect-aware framing
```

只改变 Camera / active projection visibility，不创建新 Worksite。

状态：`KEEP / CURRENT_TRUTH`。

## Enter Worksite

目的地是长期 worksite / child canvas。

它改变 active worksite identity，而不仅是 camera。

状态：产品行为 `KEEP / CURRENT_TRUTH`；canonical owner `OPEN`。

## Arrival

Arrival 是进入 / 定位之后的视觉确认：

```text
camera settles
→ target body / worksite identity short feedback
```

Arrival 不是第二 navigation store / state owner。

状态：`CURRENT_TRUTH / PRESENTATION_ONLY`。

## Back

返回上一个 navigation context / parent worksite。

产品动作：`KEEP`。

旧 `Scope.parentScopeId` owner：`SUPERSEDED`。

Gen2 back-stack persistence：`OPEN`。

---

# 15. Current Gen2 Spatial owner：Huabu 覆盖旧 Workspace geometry

当前 `apps/web-gen2/src/spatial/surfacePort.ts` 已明确：

```text
main
context
workflow
```

三者同属 Huabu canvas host family，但使用不同 canvasId；camera / selection / layout / history 隔离。

这证明：

> 三个一级 Surface 不再等同旧 Workspace runtime。

后续 Huabu SpatialTruth 裁决又明确：

- old Workspace `viewport / frameBounds / focusedViewIds` 是 legacy data；
- 不允许自动 `workspaceState → Huabu viewport`；
- Huabu viewport/world 才是 Gen2 Spatial Truth。

状态：`CURRENT_TRUTH`。

---

# 16. 当前 web-gen2 source：没有发现旧 Workspace-state 的 typed consumer，但不能宣判死亡

当前 `apps/web-gen2/src/backend/projects.ts` 自身声明只暴露 Gen2 实际使用的 project routes，目前为：

- `listProjects()`；
- `getProjectGraph()`。

并特别警告：

> graph 中 legacy workspace position / size / viewport / frameBounds 只允许数据读取，不能当 Huabu Spatial Truth。

同时当前 `apps/web-gen2/src/backend/` 没发现 workspace-state / workspace-membership 专用 client。

对当前仓库搜索：

- `workspace-states`；
- `workspace-memberships`；
- `focusedViewIds`；

未找到可靠 web-gen2 production consumer。

但这只允许得出：

```text
NO_CURRENT_WEB_GEN2_TYPED_CONSUMER_FOUND
```

不允许得出：

```text
Workspace API 已废弃
```

因为 Core 端仍然存在真实 routes/service。

状态：`OPEN / WAIT_T6`。

---

# 17. Core 仍存活的旧 Workspace state / membership

当前 Core 仍有：

`apps/local-core/src/workspace-state-service.ts`

保存：

```text
workspace.viewport
focusedViewIds
visibleLayers
intent
memberships
linkedRunIds
```

并提供 checkpoint / restore。

`apps/local-core/src/routes/workspace-states.ts` 仍提供：

```text
GET/POST /workspaces/:id/states
POST /workspaces/:id/states/:stateId/restore
GET /projects/:id/workspace-memberships
GET /workspaces/:id/entity-members
GET/POST /workspaces/:id/members
DELETE /workspaces/:id/members/:viewId
POST /workspaces/:id/members/move
```

因此现状是：

> 产品语义已经演化，但旧 Core Workspace persistence 资产还活着。

T2 无权判定它最终属于：

- `CURRENT_TRUTH`；
- `LEGACY_COMPAT`；
- migration substrate；
- 需要 replacement。

必须交 T6 + Coordinator。

---

# 18. `/view-rail-order` 也是同样的“机制可用、ontology 过时”

当前 Core `/projects/:projectId/view-rail-order` 已有：

- durable persistence；
- CAS；
- restart persistence；
- dedupe / append；
- conflict handling。

但当前 item kind 仍围绕旧：

```text
scene
collection
context
workflow
```

所以不能继续说：

> `/view-rail-order` 已经是最终 Gen2 Railway canonical contract。

正确状态：

- durable order mechanism：`KEEP`
- old item ontology：`SUPERSEDED`
- Gen2 Long-term Worksite rail identity / migration：`OPEN / WAIT_T6 + Coordinator`

---

# 19. 当前产品意义矩阵

| 历史词 / 当前词 | 当前定义 | 状态 | T2 可决定什么 |
|---|---|---|---|
| Workspace（历史） | 长期可恢复工作现场 | KEEP 产品心智 | navigation UX |
| Current Scene | 当前 active long-lived work context 的历史语言 | KEEP as historical meaning / naming OPEN | presentation / navigation |
| Main/Context/Workflow Surface | 三个一级语义现场 | CURRENT_TRUTH | switch / nav integration |
| Long-term Worksite | 以后还能回来继续的长期工作现场 | CURRENT_TRUTH | enter / return UX |
| Child Canvas | 独立 canvas identity + camera/layout/history 的 nested worksite | CURRENT_TRUTH | parent↔child nav UX |
| Work View | 深度专业工作窗口 | CURRENT_TRUTH | 仅 nav integration |
| Collection | 长期 membership，原地展开/折叠 | CURRENT_TRUTH | Focus/Locate only |
| Scope | 本轮只处理哪些 | CURRENT_TRUTH | 不建导航 container |
| old Workspace state runtime | viewport/focusedViews/membership checkpoint | OPEN | 不能认领 |
| old Scope back hierarchy | parentScopeId navigation | SUPERSEDED runtime | Back concept only |

---

# 20. Navigation action matrix

| 用户动作 | 是否换 active worksite | 是否移动 Camera | 是否创建新 identity | 当前 owner |
|---|---:|---:|---:|---|
| Search | 否 | 结果激活后可能 | 否 | Core Search + T2 presentation |
| Focus occurrence | 跨 Surface/Worksite 时可能 | 是 | 否 | T2 + Core occurrence truth |
| Locate | 否 | 是 | 否 | Huabu camera + T2 intent |
| Enter long-term worksite | 是 | 进入后的初始 framing 可能 | 否 | canonical OPEN；T2 UX |
| Create/materialize worksite | 是/新目的地 | 后续 | **可能创建新 worksite identity** | 非 T2，T4/T6/Coordinator |
| Back | 是（若此前 Enter） | 恢复/重新 frame 取决 contract | 否 | T2 UX；persistence OPEN |
| Work View Focus/Dock | 否 | open/resize 不自动 | 否 | T4 lifecycle + T2 safeRect |
| Collection Focus | 否 | 是 | 否 | T2 locate only |

---

# 21. T2 当前强制 DO NOT BUILD

在 Coordinator / T6 收口前禁止新增：

```text
WorkspaceRuntimeV2
LongTermWorksiteStore
ChildCanvasNavigationStore
ScopeBackStackV2
RailwayCanonicalStore
WorkViewCanvasOwner
CollectionSceneRuntime
```

同时禁止：

- 用旧 Workspace viewport 恢复覆盖 Huabu camera；
- 用 Scope.parentScopeId 复活 child-worksite hierarchy；
- 把 Collection / Scope 自动变 Railway destination；
- 把 Work View 当 child canvas；
- 把 Assembly 画成 Main node；
- 把 Locate 与 Enter 合并成一个不透明动作。

---

# 22. 当前结论

本轮考古后的 T2 主结论：

1. **长期可恢复工作现场不是新发明，是 Gen1 已稳定存在的产品资产，KEEP。**
2. **旧 Workspace runtime 不是 Gen2 现成答案；尤其 viewport/frameBounds/focusedViewIds 已被 Huabu-first 裁决覆盖。**
3. **当前 Core 仍保留 Workspace state/membership API，因此 exact canonical migration 必须由 T6 / Coordinator 回答，T2 标 OPEN。**
4. **Collection 从 08-14 就明确不是 child canvas；T2 只负责其 Focus/Locate。**
5. **Enter Worksite 与 Locate Target 从 Gen1 源码开始就应分开。**
6. **Back 产品动作 KEEP；Scope parent hierarchy SUPERSEDED。**
7. **SurfaceDock 底部三视图优先级有原源码依据，KEEP / MODERNIZE。**
8. **Minimap 集成 viewport controls 也是 Gen1 已存在资产，KEEP / MODERNIZE。**
9. **Railway 以 Gen1 可用资产升级，不重写；旧 flat ontology SUPERSEDED。**
10. **T2 不拥有 Work View 内容/lifecycle，只负责导航、safeRect 与 camera consequences。**

