# LCOS Gen2 · 交互级摸牌（四）：Phase B/C Donor Census 对照（Gen1 预冻结 → Gen2 Huabu-first）

> 日期：2026-09-02。源文档：`LCOS_v015_PHASE_BC_MATURE_DONOR_CENSUS_PRE_FREEZE_20260901.md`（用户提供，PRE-FREEZE / RESEARCH AUTHORITY）。
> 任务：把 Gen1 的 donor 裁决逐条对到 Gen2「Huabu 唯一空间宿主」现实上，标出**被 Huabu 白送而退休的**、**原样存活的**、**仍需 census 的**。

---

## 1. Gen1 总裁决（原文精神）

新默认序：① 判断是否通用成熟问题 → ② 是则先 donor census → ③ 核许可证/维护度/React-TS 适配/bundle 代价 → ④ 优先收编 MIT/Apache 成熟 primitive/算法/示例 → ⑤ LCOS 只写 canonical semantics/owner/adapter/空间整合层 → ⑥ donor 无法满足 LCOS 语义/空间约束才自研。

> 「让成熟框架负责别人已经做好一万遍的东西，让 LCOS 负责只有 LCOS 才需要拥有的东西。」

## 2. LCOS 必须自拥清单（17 项，Gen2 全部仍有效）

Project Object canonical truth；Main/Context/Workflow/Assembly Surface 语义；Selection truth；Selection ≠ Reference；Relation truth 与 Conversation Context Mapping 的区分；Action Arc command ownership；Unified Composer target adapter；Surface Component（Spatial Instrument）产品定义；SpatialCanvas 世界坐标/对象身份/跨 Surface 一致性；A20 SpatialOverlayPlacement/OverlayStack owner；Color Pin/Focus/Search/Map Locator canonical 分工；Assembly Admission Rules；Candidate→Validate→Preview→Commit；Glyth/Conversation canonical identity；Workflow Step↔Step 与 Domain Relation 的区别；Skill Artifact canonical package truth。

成熟框架只能当：functional core / render engine / interaction primitive / layout engine / UI shell / algorithm donor——**永不能成为 canonical owner**。

## 3. 逐 donor 对照表（Gen1 裁决 → Gen2 现实）

| Donor | Gen1 角色 | Gen2 裁决 | 备注 |
|---|---|---|---|
| **xyflow / React Flow** | Workflow 主 UI donor（NodeToolbar/NodeResizer/lasso/connect/minimap 等 pattern） | **退休——被 Huabu 白送** | Huabu 本体即 React Flow 宿主：NodeWrapper=NodeToolbar 等价、resize、lasso、connect、minimap 全部现成。census 想借的 14 项 pattern 一项都不用再借 |
| **tldraw** | 研究 only（license 限制） | 同上，且 Huabu 已吸收其 pattern | 不变 |
| **react-rnd** | resize math donor | **降级** | 世界坐标 resize 已由 Huabu NodeWrapper/NodeResizer 拥有；仅在 Work View 内部组件需要时才考虑 |
| **Rete.js** | Workflow 语义 donor（typed socket/dataflow/control-flow 分离/connection validation） | **存活**（H4 Workflow） | 只借 typed capability/socket 模型，不做 runtime——与宪法 §7.5 Workflow 哲学一致 |
| **n8n** | 产品 donor（catalog/diff/execution/log UI） | **存活（只看不抄）** | Sustainable Use License 红线不变 |
| **ELK.js** | 布局引擎（candidate→preview→commit） | **存活**（H3 Tidy） | RFS `SET_NODE_GEOMETRY` 已支持 commit 环节 |
| **Cytoscape.js** | Context Relationship functional core | **存活**（H4） | 接收 LCOS projection，编辑回 Core mutation path |
| **Sigma.js** | 大图只读 | 存活（可选） | 仅 Cytoscape 性能不足时 |
| **vis-timeline** | Context Evolution core | **存活**（H4） | 不当 canonical history store |
| **react-arborist** | Outline/Tree core | **存活**（H4/H5） | Context Structure / Skill outline / Assembly tree |
| **Mind Elixir** | 可编辑导图 | **存活**（H5 Skill Builder） | Gen1 已有 `presentation/mindMapLayout.ts` 纯逻辑可先迁 |
| **Markmap** | 只读导图投影 | 存活 | 不做 canonical editor |
| **dnd-kit** | DOM 拖放 primitive | **存活**（红线不变） | 只用于 instrument 内 DOM；**绝不接管 world-space**（Gen2 = Huabu 指针系统） |
| **cmdk** | catalog/palette primitive | **存活**（H2） | 只管 query/input/filtering shell；spatial projection 走 LCOS 顶部索引族 |
| **react-resizable-panels** | split primitive | **降级待定** | Huabu PreviewWorkspace 已有 split/dock/resize；仅在其无法满足某冻结交互时才引入 |
| **prompt-kit / Vercel AI Elements** | Composer UI donor | **存活**（H2 Composer） | Huabu ChatInput 作行为参考 |
| **Voice recorder/VAD/STT** | primitive + provider seam | **存活**（A24 底子：whisper.cpp provider seam 已 PASS） | 真机验收仍 OPEN |

## 4. 许可证红线（原文收录，Gen2 不变）

- 直接收编：MIT / Apache-2.0 / 兼容宽松许可。
- 只看不抄：n8n editor-ui（Sustainable Use）、tldraw production SDK、React Flow Pro-only examples。
- 冻结原则：**「能看不代表能复制；能复制不代表应该让它成为 owner。」**
- donor 进代码前登记六项：repository / version / license / copied files or dependency / modifications / LCOS adapter owner。

## 5. Phase B/C 原始定义 → Gen2 映射

- **Phase B = Mature Primitive Adoption + Morphology Restoration**（建 Donor Registry；把自研通用机械逐项换成熟 primitive；统一 Component Host；统一 local DOM interaction layer；B 不大规模扩产品功能；**B 禁止再写**：自制 tree/split pane/drag list/command palette/timeline engine/generic workflow connection editor/graph layout/resize engine）
- **Phase C = Surface-specific Product Instruments & Assembly**（B 铺 functional core，C 才落产品）
- **B1–B10 施工包**：Donor Registry 边界 / Component Host 恢复 / Catalog primitive / DnD primitive / Tree primitive / Split primitive / Graph adapter / Timeline adapter / Layout adapter / Donor 视觉收敛。
- **Gen2 映射**：B 的「统一 Component Host + primitive 收编」→ Huabu PreviewWorkspace + `lcos/work-view` renderer registry（H2）；B1 Donor Registry → GPT 计划 §8 + 本摸牌表；B7/B8/B9 → H4 instruments + H3 Tidy；B10 → H6。C 的 Context/Workflow/Skill/Assembly 家族 → H4–H5。**实质差异同 §14：B 的 Host 自建被 Huabu 白送。**

## 6. Component 心智公式（原文，Gen2 版）

```text
Gen1：LCOS Spatial Instrument Host + Mature Functional Core + LCOS Adapter
Gen2：Huabu 空间宿主（经 Host seam）+ Mature Functional Core + LCOS Adapter
```

例（Gen2 落地）：Context Evolution = Huabu Work View dock + vis-timeline + ContextEvolutionAdapter；Skill Builder = Work View + react-arborist/Mind Elixir + SkillPackageAdapter；Assembly = Work View Source Bay + cmdk/dnd-kit/arborist + AdmissionRules。

## 7. census 文档自列的下一轮待查（§18 十项，Gen2 视角再筛）

仍有效：Cytoscape/Sigma React 接法、vis-timeline 薄 adapter vs wrapper、Rete 借模型边界、Mind Elixir 受控状态适配、diff viewer 选型、Voice 最终选型。
已被 Huabu 消解：React Flow NodeToolbar/NodeResizer 源码边界（不用借了）、resize primitive 选型（宿主已定）。