# LCOS Gen2 · T3 第三路
# User-Intent-First UX Scene Freeze
## Local Object Interaction / Action Arc / Right-click / Compact Composer / Reference / Voice / Run-Receiver / Semantic Drop / Glyth

> 日期：2026-09-04  
> 性质：T3 源码施工前置 UX Scene Specification  
> 上游纪律：`LCOS_Gen2_UX场景先行_UserIntentFirst_源码施工前置协议_20260904.md`
>
> 本文优先回答：
>
> ```text
> 用户现在看到什么
> → 鼠标在哪里
> → 点/拖什么
> → 第一帧发生什么
> → 100~300ms 内发生什么
> → 什么绝对不出现
> → 下一步自然是什么
> ```
>
> **本文暂时高于此前 T3 `04_Source_Level_Construction_Plan` 中与 UX 场景冲突的假设。**
>
> 特别纠正此前错误：
>
> 1. 内容型对象不是“第一次只 Select，第二次再点才出 Arc”的强制两击流程。最新冻结允许 stable single click 结束后直接呈现 `Selection + Action Arc + Compact Composer`。
> 2. Action Arc 是 `3 normal / 4 max`，不是 5。
> 3. Multi-selection 有正式 Multi-selection Work，不得简单禁掉 Composer。
> 4. Right-click / More 是管理层，不得塞 Focus / Pin / Relation / Assembly 这类直接能力；对象直达 Assembly 属于 Action Arc。
> 5. Work View 打开不等于 local overlay 必须全部消失。确定的规则是：Work View 占据自己的 rect、Camera 不自动移动、所有 contextual overlay 必须尊重 activeSpatialViewport。是否某个 local Composer 与现有 Docked Work View 同时可见，若无更晚原话则标 `OPEN CROSS-SYSTEM UX`，不能拿当前代码 arbitration 反向定义产品。
> 6. Glyth 不是“普通节点 + 特殊菜单”，它是 Conversation / Agent 的空间身份；单击、双击、Reference、body drop、Relation、Receiver、Assembly 是不同因果链。

---

# PART 0 · T3 用户可感知系统地图

T3 不按文件分，而按用户体验分成 9 个大系统：

```text
S1  Object-local Interaction Grammar
    “我碰一个对象时，系统到底怎么回应？”

S2  Action Arc
    “这个对象现在最直接能做什么？”

S3  Right-click / More
    “我要管理、组织、配置这个对象。”

S4  Unified Compact Composer
    “我要让 AI / 当前工作流对这个 target 做什么。”

S5  Reference / Reference Pick
    “这一轮我额外明确给 AI 看什么材料。”

S6  Voice Input
    “我不打字，直接说，但仍然是同一个 Composer。”

S7  Run / Receiver
    “这次任务交给哪段持续存在的 Conversation 去执行，何时真正发出。”

S8  Semantic Drop
    “我把东西直接拖到哪里，就表示要在哪里用。”

S9  Glyth / Conversation Local Interaction
    “一段真实 Conversation 在空间中怎么被选、说话、装配、长期喂上下文、建立 Relation。”
```

跨系统但不由 T3 单独拥有：

```text
X1 Multi-selection
X2 Surface Component Functional Face
X3 Work View / activeSpatialViewport
X4 Takeover / low-LOD mark
X5 Main / Context / Workflow 三 Surface
```

---

# S1 · Object-local Interaction Grammar
## “我碰这个对象时，系统到底怎么回应？”

### System

Object-local Interaction Grammar

### User Goal

用户正在 Main / Context / Workflow 的空间里工作。

他不是想“打开一个工具栏”。

他只是想：

```text
选中一个对象
→ 看清它现在能做什么
→ 继续拖、改、AI Work、打开、装配、建立关系
```

整个系统必须保持：

> **对象是主体，控件是卫星。**

---

## Entry Condition

- 当前存在一个 content-like Project Object；
- 用户鼠标移动到它的真实 body；
- 该对象不是正在被另一种显式工具占用；
- 若是 Functional Surface Component，则先服从自身 Functional Face 规则。

---

## Current Selection

可能：

```text
none
或
另一个对象
或
当前对象
```

Selection 是当前空间操作集合。

Selection 不是 Reference。

---

## Current Surface

Main / Context / Workflow 共享同一套物理交互语法。

Surface 不改变 click / drag / Reference 的基本因果。

---

## Visual Focus

用户眼睛首先看：

```text
对象 body
```

不是顶部 HUD，不是右侧面板。

---

## Persistent UI

默认长期可见的只能是：

- 对象自身 morphology；
- 必要的 Selection feedback；
- 真正的 persistent identity / status，例如 Pin、Locator、species identity；
- 该 Component 自身不可缺的 Functional Face。

---

## Hidden UI

resting object 上默认不堆：

```text
AI
More
Assembly
Relation
Edit
Pin
小工具条
```

不能因为能力存在就永久贴图标。

---

# S1 Scene Sequence

## Frame A · Rest

画布里对象就是对象本身。

```text
没有 permanent Arc
没有 permanent Composer
没有 permanent More
```

用户视线不被一圈按钮抢走。

---

## Frame B · Pointer down

用户按下对象。

第一帧：

```text
系统只进入 Selection / potential drag intent
```

此时不能因为 pointerdown 就把 Composer 弹出来。

不能抢键盘 focus。

不能让节点尺寸突然变化。

---

## Frame C1 · 用户开始拖

如果 pointer movement 超过 drag threshold：

```text
drag wins
```

画面：

- 对象跟手移动；
- Action Arc 不冒出来；
- Composer 不冒出来；
- 不在 pointer 下面长出按钮；
- 不弹“移动到哪里”窗口。

完成 drag 后：

```text
对象 settle
用户仍在同一空间现场
```

---

## Frame C2 · stable click / pointerup

如果没有形成 drag：

```text
Selection feedback settle
```

对 content-like Project Object，最新冻结允许本次 stable single click 直接进入：

```text
Selection
+
Action Arc
+
Compact Composer
```

这里的重点不是“必须强制三样永远同时出现”，而是：

> **不能再人为规定用户必须第二次再点对象，才能开始局部 AI / direct action。**

species policy 可以决定某些对象只显示 Arc、某些 content object 同时显示 Composer。

---

## Frame D · 用户不继续操作

Action Arc / Composer 都是 transient。

对象 Selection 仍是持久的当前操作反馈。

如果 transient UI 按层级退出：

```text
对象仍然 selected
```

不能为了关掉 Composer 顺带把 Selection 清掉。

---

# S1 Camera Rule

单击 / Arc reveal / Composer reveal：

```text
Camera 不移动
```

对象也不移动。

只有用户明确执行 Focus / Open / Preview 等对应系统动作时，才进入那些系统自己的空间行为。

---

# S1 Popup Rule

stable click 后：

```text
可以有对象附近的 local transient UI
```

但不能：

```text
modal
大型侧栏
全局 prompt window
确认“是否打开局部操作”
```

---

# S1 Exit State

用户可以自然进入：

```text
Arc direct action
Composer AI Work
drag
right-click management
double-click object-specific open
```

---

# S1 Failure State

如果 target 在 pointerup 前消失 / projection invalid：

```text
不显示 stale Arc / Composer
不猜 target
```

---

# S1 Final Frozen Interpretation

```text
Object body first
Selection first
drag first
stable click can reveal local work
no mandatory second click
no permanent node Christmas tree
```

### UX FREEZE

`PASS`

---

# S2 · Action Arc
## “这个对象现在最直接能做什么？”

### System

Action Arc / Object Orbit

### User Goal

用户已经明确地看着一个对象。

他想知道：

```text
我现在最常做的几个动作是什么？
```

不是管理对象的全部功能。

不是打开“属性”。

不是一张大菜单。

---

## Entry Condition

- content-like object stable click；
- Glyth stable click；
- Component lifecycle/direct capability；
- 或其他明确 local action entry。

---

## Visual Focus

Action Arc 是对象旁边的“短动作卫星”。

用户眼睛仍然停在对象。

---

## Persistent UI

无。

Arc 本身不 persistent。

---

## Transient UI

```text
top-right corner-hugging short arc
```

没有可见的完整 orbit track。

---

## Hidden UI

- destructive management；
- Rename / Duplicate / Delete；
- 大量设置；
- Component 自己的 Functional Face；
- Composer Prompt 内容。

---

# S2 Scene Sequence

## Frame A · Object selected

对象 Selection 已稳定。

Arc 从 target 右上附近轻量出现。

不是从屏幕顶部飞下来。

不是固定在 viewport。

---

## Frame B · Arc settled

常态：

```text
3 个直接动作
```

上限：

```text
4 个
```

超过的东西：

```text
More
```

不是把 5、6、7 个按钮继续沿圆周堆。

---

## Frame C · Hover one action

hover：

- icon/label获得可读反馈；
- 不展开一张大说明卡；
- 除非动作本身需要解释，最多局部 tooltip / tiny label。

---

## Frame D · Click direct action

点击动作以后：

```text
直接进入那个动作
```

例如：

```text
Compose / Work
→ Compact Composer

Assembly（target capability存在）
→ 同一个 Project Assembly
→ target 已经是当前对象
→ 默认 Docked Source Bay

Relation
→ 进入临时 Relation intent

Pin
→ 显式持久空间标记
```

不能：

```text
点 Assembly
→ 先进入 Assembly
→ 再让用户重新选 target
```

---

## Frame E · More

More 进入 management 层。

它不是“Arc 第五个直接能力”。

---

# S2 GUI Spatial Layout

默认：

```text
Arc = target top-right
Composer = target below / near
```

两者不占同一位置。

Arc 不应盖：

- target body重要内容；
- Relation receptor；
- drag handle；
- Composer。

---

# S2 Camera Rule

Arc reveal：

```text
Camera 不移动
```

Arc自身不能为了“留出空间”改 camera。

---

# S2 Work View Collision

已知：

- Work View打开/resize不移动Camera；
- contextual overlay必须尊重 activeSpatialViewport。

未完全冻结：

```text
一个已存在的 Docked Work View
+
用户又点击 canvas object
```

此时 Arc是否允许与 Work View同时 visible，现有原文没有足够明确的“必须隐藏/必须共存”。

因此：

`OPEN CROSS-SYSTEM UX`

不能直接沿用当前代码 “workViewOpen → hide all local overlay” 当产品真相。

---

# S2 Final Frozen Interpretation

```text
3 normal / 4 max
immediate capability
top-right local
no visible orbit track
More = management
Assembly direct entry belongs here
```

### UX FREEZE

`PASS_WITH_ONE_CROSS_SYSTEM_OPEN`

---

# S3 · Right-click / More
## “我要管理、组织、配置这个对象。”

### System

Right-click / More

### User Goal

用户不是在做高频直接工作。

他现在想：

```text
管理这个对象
整理它
复制它
移动/归档
看属性
删除
```

---

## Entry Condition

- 右键对象；
- 或 Arc 里的 More。

---

## Visual Focus

菜单出现在：

```text
pointer附近
或
More trigger附近
```

不是 target body上再长一圈按钮。

---

## Owns

管理类能力：

```text
Rename
Duplicate
Copy / Copy Reference
Move / Add to...
Align / Distribute / Tidy
Collection / Colony
Export
Inspect / Properties
Hide / Lock（若保留）
Delete
```

---

## Does NOT Own

```text
Prompt
Voice
Run
Pin direct action
Relation direct action
Assembly direct entry
Component Functional Face
```

尤其：

```text
Right-click → Assembly 作为主要路径
已被最新 L0 覆盖
```

对象有 Assembly capability时，直接入口属于 Action Arc。

---

# S3 Scene Sequence

## Frame A · Right-click

对象本身不跳走。

Camera 不动。

一个 compact desktop-style menu 出现在局部。

---

## Frame B · Menu opened

当前 Selection 仍可见。

Action Arc 应让位，避免两层 local command 同时竞争。

Composer 是否必须关闭：

原文没有足够明确的统一规则，按 transient ownership做层级处理，但不允许顺带清 draft。

---

## Frame C · Management command

例如 Rename：

进入局部 rename。

Duplicate：

明确产生副本。

Delete：

执行 destructive flow。

---

## Frame D · Outside / Esc

菜单关闭。

对象保持当前空间位置。

---

# S3 Destructive Confirmation

是否所有 Delete 都需要确认、哪些是 Undo-first：

当前 T3 产品原文不足以冻结统一规则。

标记：

`OPEN MICRO POLICY`

不能施工 Agent自己选择“都弹 Modal”或者“全都无确认”。

---

# S3 Final Frozen Interpretation

```text
management-only
compact local menu
does not duplicate Arc
does not become AI work surface
```

### UX FREEZE

`PASS_WITH_DESTRUCTIVE_MICRO_POLICY_OPEN`

---

# S4 · Unified Compact Composer
## “我想让 AI / 当前工作流对这个 target 做什么。”

### System

Unified Compact Composer

### User Goal

用户看着一个明确 target。

他说的是：

```text
帮我对这个对象做点事
```

而不是：

```text
打开 Chat 页面
```

Composer 是 target-local AI Work surface。

---

## Entry Condition

Content-like object stable click 可以出现。

也可以由 Action Arc 的 Work / Compose 明确进入。

Glyth / Workflow / Assembly / Multi-selection 复用同一 shell，但 target adapter不同。

Surface Component 如果自身是结构/仪表：

```text
不因 selected 自动弹 generic Composer
```

只有显式 AI / Work affordance才开。

---

## Visual Focus

Composer 在 target 旁边。

用户仍然能同时看到：

```text
target
Selection
references
```

---

## Persistent UI

无。

Composer 是 transient/local work surface。

---

## Default Size

Idle：

```text
1–2 行
```

Typing：

```text
逐步增高
→ 3–4 行上限
```

之后：

```text
textarea内部滚动
```

外壳不继续无限长。

---

# S4 Scene Sequence

## Frame A · Composer appears

对 content-like object，stable click结束后可与 Arc一起出现。

位置：

```text
target below / near
```

不挡住 Action Arc。

---

## Frame B · No autofocus

Composer出现的第一帧：

```text
textarea不自动抢 focus
```

用户仍可继续：

- 拖对象；
- 点别的对象；
- 按 canvas shortcut。

只有：

```text
点击 input
专用 typing shortcut
Voice
Reference
AI Work
```

才真正进入输入 focus。

---

## Frame C · User clicks input

输入区 focus。

Canvas不因这个 click重新选别的东西。

Composer outer footprint保持稳定。

---

## Frame D · Prompt grows

1行 → 2行 → 3/4行。

达到上限后：

```text
内部 scroll
```

不是把画布一直往下顶。

---

## Frame E · References appear

Reference以：

```text
thumbnail / compact chip
```

确认 identity。

不是把完整节点复制进 Composer。

---

## Frame F · Parameters

常用参数保持 compact。

复杂参数：

```text
anchored popover
```

用户仍然留在 target旁边。

不能每改一个参数就打开 Inspector。

---

## Frame G · Run / Send

用户明确点击 Send / Run。

之前：

```text
prompt只是 draft
```

不产生 canonical mutation。

---

## Frame H · Structural AI mutation

如果 prompt要改：

- Assembly结构；
- Context结构；
- Workflow结构；
- Relation；
- destructive organization；

必须：

```text
Candidate
→ Validate
→ Preview / receipt
→ Commit
```

不能因为“AI理解了”就直接静默改项目。

---

# S4 Target Modes

同一 shell，不同 target adapter。

## Object Work

```text
target = object
```

## Multi-selection Work

```text
target = Selection
```

重要：

```text
Selection members != automatic References
```

UI只显示小的 target summary：

```text
3 selected
```

而不是三张完整卡。

**此前 T3 把 Multi-selection Composer 简单压掉是错的。**

---

## Glyth Speak

```text
target = Conversation / Receiver
```

同一 Composer，不造 `GlythPromptBox`。

---

## Workflow Work

参数/Skill/执行 target按 Workflow语义变化。

---

## Assembly Instruction

仍是 same Composer shell。

但 Assembly本体不是 Composer。

---

# S4 Camera Rule

Composer reveal：

```text
Camera 不移动
```

Composer因为边界空间不足时：

```text
placement 调整
```

不是让 camera给它腾位置。

---

# S4 Work View Relationship

Composer = local short-form AI Work。

Work View = sustained deep work projection。

已知：

```text
Work View占据viewport edge
Camera不自动移动
Composer placement必须尊重activeSpatialViewport
```

未完全冻结：

- Work View已打开时另一个 object-local Composer是否保持可见；
- 一个 Composer动作把 target提升进 Work View后，local Composer是否收起、保留还是转接。

标：

`OPEN CROSS-SYSTEM UX`

不能拿 current overlay code定产品。

---

# S4 Exit State

用户自然下一步：

```text
edit prompt
add Reference
Voice
select Skill / params
Run
close Composer
继续操作 target
```

---

# S4 Failure State

Run失败：

```text
prompt不应因为“发送过一次”就无条件消失
```

exact draft recovery由实施层接 Core状态，但 UX最少要求：

> 用户不能因为一次错误回到空白。

---

# S4 Final Frozen Interpretation

```text
target-local
small
bounded
no autofocus
Reference/Voice/params inline
explicit Run
same shell, target-specific semantics
```

### UX FREEZE

`PASS_WITH_WORKVIEW_TRANSITION_OPEN`

---

# S5 · Reference / Reference Pick
## “这一轮我明确给 AI 看什么。”

### System

Reference

### User Goal

用户已经有一个 Composer target。

现在想明确告诉 AI：

```text
这几个材料是这次任务的输入
```

它不是：

```text
当前我选中了什么
```

---

## Core Mental Model

```text
Selection
= 我现在操作谁

Reference
= 这一轮 AI 明确看什么

Relation
= 项目里长期是什么关系

Conversation Context Mapping
= 这段 Conversation 长期携带什么
```

四者绝不能视觉上“差不多就行”。

---

# S5 Scene A · Explicit Add Reference

Composer内有：

```text
+ Reference
```

用户点它。

不打开大 modal。

可以出现一个很小的 local chooser / source popover。

Lovart donor给出的成熟参考是：

```text
Upload
Paste
Select From Canvas
```

但这三个 exact source选项属于 donor设计答案，不全部等于 LCOS product freeze。

其中：

```text
Select From Canvas temporary mode
```

与 LCOS冻结完全一致。

---

# S5 Scene B · Select From Canvas

用户选择从画布挑 Reference。

Composer：

```text
保持原位
```

画布进入轻量 Reference Pick状态。

eligible objects出现轻微可选反馈。

不是把整个 Canvas换成新 Mode Screen。

---

## Frame B1

用户点击对象 B。

第一帧：

```text
B被加入Reference
```

但：

```text
Selection不变
```

原 target仍然是 target。

---

## Frame B2

Composer出现 B 的 compact chip / thumbnail。

用户继续点 C：

```text
Reference顺序 = B, C
```

---

## Frame B3 · Esc

Esc：

```text
退出 Reference Pick
Composer留下
已有 References留下
Selection留下
```

---

# S5 Scene C · Ctrl/Cmd quick Reference

Composer active时：

```text
Ctrl/Cmd + click Project Object
```

直接加入 Reference。

它是 accelerator。

不是唯一入口。

---

# S5 Scene D · Reference chip

chip主要回答：

```text
“我到底加的是谁？”
```

可有：

- title；
- species；
- remove；
- locate/inspect（若需要）。

不能变成第二 Inspector。

---

# S5 Camera Rule

Add / Remove Reference：

```text
Camera不动
```

若用户主动点 locate：

才交给 Focus/Navigation系统。

---

# S5 Failure

对象没有 canonical identity：

```text
不能猜
不能生成 nodeId reference
```

UI应 fail-close。

---

# S5 Final Frozen Interpretation

```text
explicit
ordered
local
Selection unchanged
Esc exits pick, Composer stays
```

### UX FREEZE

`PASS`

---

# S6 · Voice Input
## “我直接说，但仍然是在这个 Composer 里。”

### System

Voice Input Primitive

### User Goal

用户不想打字。

但他仍然在做：

```text
同一个 target
同一个 prompt
同一组 References
同一组 Skill / params
```

Voice只是输入方式变了。

---

## Entry Condition

Composer已经存在。

用户点 mic。

---

# S6 Scene Sequence

## Frame A · Idle

Composer原本 footer里有一个轻量 mic入口。

没有单独 Voice panel。

---

## Frame B · Recording starts

用户点 mic。

同一个 control region 原位 morph：

```text
mic
→ short waveform / activity
→ Cancel / Stop
```

Composer宽度尽量不变。

不打开覆盖画布的大录音 UI。

---

## Frame C · While Recording

非必要 controls让位。

但：

```text
target
References
Composer identity
```

仍然清楚。

---

## Frame D1 · Cancel

Cancel：

```text
停止录音
不发送
回到原prompt
```

---

## Frame D2 · Stop / Finish

停止录音以后：

```text
Transcribing
```

是轻量状态。

没有 Run。

---

## Frame E · Editable Text

转写结果变成普通 prompt text。

此刻用户可以：

```text
改词
继续打字
增删Reference
换Skill
换model/params
丢弃
```

---

## Frame F · Explicit Send

只有用户明确 Send / Run：

```text
才真正执行
```

---

# S6 Existing Prompt Merge

如果用户录音前 prompt里已经有文字：

```text
转写是插入cursor
append
还是replace某个selection
```

当前更晚冻结没有把这一粒度讲死。

所以：

`OPEN MICRO POLICY`

确定的只有：

```text
不能无提示清空原prompt
不能录完自动Run
```

---

# S6 Failure / Recovery

Mic denied / no device：

```text
Composer仍在
原prompt仍在
References仍在
```

Transcription fail：

```text
不影响已有 draft
```

---

# S6 Work View Collision

如果 Recording过程中打开/切换 Work View：

是否自动 cancel recording，当前缺足够用户原话。

标：

`OPEN CROSS-SYSTEM UX`

不能由 MediaRecorder implementation自己定义。

---

# S6 Final Frozen Interpretation

```text
same Composer
same width
short waveform
no separate panel
editable transcript
explicit Send
```

### UX FREEZE

`PASS_WITH_TWO_MICRO_POLICIES_OPEN`

---

# S7 · Run / Receiver
## “这件事现在交给谁做，什么时候真的发出去。”

### System

Run / Receiver presentation inside Composer

### User Goal

用户不是在选择：

```text
哪个provider API
```

主要心智应该是：

> **“这件事交给哪段持续存在的 Conversation / Glyth 做？”**

---

## Receiver vs Active Receiver

两个概念分开：

```text
本次 Run receiver
!=
Project Active Receiver
```

一次任务换 receiver：

不应偷偷改全项目 current receiver。

---

# S7 Scene A · 从 Glyth 发起

用户点一个 Glyth。

进入它的 Speak/Work Composer。

默认：

```text
receiver = 当前 Glyth
```

用户不需要再选一次自己刚刚点的 Conversation。

---

# S7 Scene B · 从普通对象发起

用户选一个 Artifact，打开 Composer。

Receiver：

优先可参考既有 detailed freeze：

```text
1. 如果这次 Work 是从某个 Glyth发起 → 当前Glyth
2. 否则 Project Active Receiver
3. 如果没有 Active Receiver → 明确选择
```

关键冻结：

```text
无 receiver 时不能猜
```

---

# S7 Scene C · Receiver selector

在 Composer里它应该像一个 compact target selector。

用户看到的是：

```text
[Glyth identity] 当前对话 ▾
```

而不是：

```text
Provider: Codex / WorkBuddy
```

Provider / executor属于 Advanced / runtime层。

---

# S7 Scene D · User changes receiver

用户换到另一个 connected Glyth。

第一帧：

```text
本次 draft 的 receiver改变
```

Project Active Receiver不自动改变。

若用户真想改全局 current：

通过 Glyth Orbit / selector里的显式 Set Current。

---

# S7 Scene E · Run

用户完成：

```text
Prompt
References
Skill / params
Receiver
```

点 Send / Run。

这是明确的 commit point。

---

# S7 Run Result

执行后的 streaming / review / result属于 Run / Work View / T6更大生命周期。

T3需要保证：

```text
Composer不会因为“点了发送”就先假装成功
```

---

# S7 Failure

Receiver不可用：

```text
明确提示
不按provider/title/time猜另一个
```

Run失败：

```text
draft不能莫名归零
```

---

# S7 Final Frozen Interpretation

```text
choose Conversation, not plumbing
Run receiver != Active Receiver
explicit Send
fail-close
```

### UX FREEZE

`PASS`

---

# S8 · Semantic Drop
## “我拖到哪里，就表示要在哪里用。”

### System

Semantic Drop

### User Goal

用户已经抓着一个对象/材料。

他不想先学系统的 taxonomy。

他想：

```text
我把它拖到那个明确的地方
→ 就在那里使用
```

---

## Core UX Rule

禁止：

```text
拖到感应区
→ 松手
→ 弹窗问你“想放哪里？”
```

也禁止：

```text
drop完再选Action类型
```

真正的 target本身就是语义。

---

# S8 Scene Sequence · Generic

## Frame A · Drag starts

用户拖起对象。

当前对象跟手。

无额外大面板。

---

## Frame B · Approaching eligible target

真实 eligible target出现 receive feedback。

feedback贴 target。

不是全屏进入“Drop Mode”。

---

## Frame C · Hover concrete target

target反馈变明确。

系统必须能表达：

```text
“松手以后会发生什么”
```

例如：

```text
加入这个 Conversation Context
放进这个 Assembly target
交给这个 Surface / worksite
```

不是只显示一个抽象蓝框。

---

## Frame D · Drop

用户松手。

如果 target已经明确：

```text
直接commit
```

不二次确认 destination。

---

## Frame E · Settle

目标现场出现可理解的结果反馈。

例如 Glyth：

```text
short tether settle
```

其它 destination使用它自己的 semantic feedback。

---

# S8 Invalid Target

用户拖到没有语义的地方：

```text
不commit
不猜
```

payload继续回到正常 drag/drop结束。

---

# S8 Edge Dwell

edge dwell 可以存在，但角色只能是：

```text
reveal hidden destination
navigation assist
carry hysteresis
```

不能再把：

```text
left edge
bottom edge
```

当最终 LCOS business destination taxonomy。

---

# S8 Native File Drop

普通 file → blank canvas：

```text
Huabu native artifact/drop语义
```

明确 file → semantic target：

```text
LCOS Semantic Drop
```

一个 pointer/drop不能同时产生两份结果。

---

# S8 Camera Rule

普通 local semantic drop：

```text
不因为preview出现就移动camera
```

跨 Surface / Railway导航属于 T2/T4。

T3不自行决定 camera travel。

---

# S8 General Destination Taxonomy

T3已经冻结：

```text
“visible concrete destination”
```

但 Assembly / Context / Workflow 所有具体 slot 的完整列表属于 T4。

所以：

`CROSS_THREAD PENDING`

不能 T3自己列一份 taxonomy硬塞进代码。

---

# S8 Final Frozen Interpretation

```text
destination is the UI
preview exact outcome
drop once
no chooser
no sensor-zone final semantics
```

### UX FREEZE

`PASS_FOR_GRAMMAR / PARTIAL_FOR_FULL_TARGET_TAXONOMY`

---

# S9 · Glyth / Conversation Local Interaction
## “一段真实 Conversation 在空间中怎样存在、工作、被长期喂上下文。”

### System

Glyth / Conversation local interaction

### User Goal

用户看到的不是一个聊天气泡。

他看到的是：

> **一段真实、持续存在的 Conversation / Agent session 在项目空间中的身份。**

它可以出现在：

- Main；
- Context；
- Workflow；
- Conversation长期工作现场。

---

## Persistent Visual Identity

Glyth body是主要 spatial identity。

关闭 Huabu agent tab：

```text
不删除 Glyth
不删除 Conversation
```

---

# S9 Scene A · Single click

用户单击 Glyth。

第一帧：

```text
Select
+
Orbit / Action Arc
```

Orbit保持稳定。

不是 pointerleave一离开就消失。

Composer freeze还允许：

```text
compact Speak Composer
```

与 Glyth local action共存。

是否每次 single click都强制自动开 Speak Composer，原文使用的是“may show”，因此不强制写成绝对 always。

---

# S9 Scene B · Glyth Orbit

可见直接能力按最新总账包括：

```text
Speak / Enter
Relation
Pin
Set Current / Receiver
Assembly / More
```

但 Action Arc整体仍受：

```text
3 normal / 4 max
```

约束。

所以不是把 5项永久全展开。

具体优先级需由最新 Glyth capability policy决定。

---

# S9 Scene C · Double click / Enter

用户双击 Glyth或按 Enter：

```text
进入 Speak / Conversation scene
```

必须复用：

```text
同一 Conversation
同一 Composer / agent session
```

不能新造一个聊天实体。

---

## Exact Presentation Open

“Speak / Conversation scene”最终是：

- Conversation subcanvas；
- Work View projection；
- 或某种组合；

更晚总账只明确：

```text
Conversation需要独立camera/layout/history时才materialize工作现场
```

并没有说每次双击都强制新建 canvas。

所以：

`OPEN PRESENTATION DETAIL`

确定的是：

```text
same Conversation/session
no duplicate chat
```

---

# S9 Scene D · Glyth Context Field reveal

选中 Glyth / 打开其 Composer以后：

只在当前 viewport / 当前 Surface范围内 reveal mapped objects：

```text
subtle world field
short light tether
mapped object indicator
```

不是全项目拉蜘蛛网。

Glyth仍是视觉中心。

---

# S9 Scene E · Durable Conversation Context Mapping

用户拖 Artifact / Fragment / Context / Workflow / Skill 等到 Glyth真实 body / receptive field。

连续画面：

```text
approach
→ Glyth attentive
→ receptive field reveal
→ drop
→ absorb
→ short tether settle
```

不用弹：

```text
请选择Relation类型
```

这一动作表达：

> **“让这段 Conversation 长期知道 / 携带这个项目对象。”**

---

# S9 Scene F · Prompt Reference

另一种完全不同的动作：

```text
Composer active
Ctrl/Cmd + click object
```

它只进入：

```text
本次 Run Reference
```

没有 tether durable mapping。

刷新/下一轮也不能冒充长期 Context Mapping。

---

# S9 Scene G · Relation

用户从 Glyth local direct action选择 Relation。

进入 Relation gesture。

这表达：

```text
Project Semantic Relation
```

不是 Conversation Context。

---

# S9 Scene H · Set Current / Receiver

用户点：

```text
Set Current
```

明确改变 Project Active Receiver。

这不是本次 Composer receiver切换的隐式副作用。

---

# S9 Scene I · Assembly

选择 Glyth：

```text
Action Arc
→ Assembly
```

默认：

```text
Docked Source Bay
```

Target Scene仍是当前 live canvas。

target已经是：

```text
这个 Glyth / Conversation
```

Source Bay来自：

```text
Project-level shared Assembly
```

不是“Glyth私有仓库”。

---

# S9 Real Body Bounds

Selection / hover / drop / relation halo：

都围绕 Glyth真实视觉 body。

不能围绕巨大透明 rectangle。

far zoom：

可以变 identity marker。

仍能被 Search / Focus定位。

---

# S9 Escape

按层级：

```text
Composer / Orbit / Focus
→ 再退出更深工作现场
```

不能一个 Esc就把 Conversation现场/用户上下文全丢。

---

# S9 Final Frozen Interpretation

```text
Glyth = Conversation spatial identity
single click = Select + Orbit
double click/Enter = Speak/Conversation scene
body drop = durable Context Mapping
Ctrl/Cmd = one-run Reference
Relation = Project semantic Relation
Set Current = Project Active Receiver
Assembly = shared Project Assembly
```

### UX FREEZE

`PASS_WITH_SPEAK_PRESENTATION_DETAIL_OPEN`

---

# PART 1 · Cross-system collision scenes

---

# X1 · Multi-selection

最新 Composer freeze明确：

```text
Multi-selection Work存在
```

正确心智：

```text
Selection
= 这次AI要操作的一组target

Reference
= 用户另外加的supporting material
```

因此：

```text
选中 A/B/C
不等于 Reference = A/B/C
```

GUI：

```text
aggregate selection feedback
+
small “3 selected” identity summary
```

不要复制3个完整target chip作为References。

---

## Multi-selection stable click

是否 selection形成后自动显示 Multi-selection Composer：

最新原文没有像 single content object那样把 automatic reveal讲得完全死。

所以：

`OPEN MICRO UX`

但：

```text
不能再写“multi-select禁止Composer”
```

---

# X2 · Surface Component Functional Face

Structural / Instrument Component：

```text
body = 工具本身
```

例如 Structure、Timeline、Workflow Review。

它被 selected：

```text
不自动弹 generic Prompt Composer
```

自身业务能力在 Functional Face直接操纵。

Action Arc：

```text
lifecycle / direct capability
```

Right-click：

```text
management
```

AI Work：

```text
显式 Work / AI affordance才开 Composer
```

这防止所有 Component都变成“一张卡 + AI输入框”。

---

# X3 · Work View

已确定：

```text
Docked/Immersive = same Work View projection
Work View可以跨Surface保持
Work View占viewport edge
Work View open/resize不移动Camera
```

T3相关：

```text
Action Arc / Composer / Context Menu placement
必须围绕activeSpatialViewport
```

不能盖到 Docked Work View下面。

---

## Work View unresolved collision

现在仍缺明确用户原话回答：

```text
右侧已有Docked Work View
+
用户在剩余canvas里又单击另一对象
→ Arc/Composer是否共存？
```

所以不能提前冻结：

```text
workViewOpen => all local overlay hidden
```

需要主协调跨线程裁决。

---

# X4 · Takeover / far zoom

对象在低 LOD变成 takeover mark / identity marker时：

```text
identity不变
```

local action如果允许出现：

anchor应是当前用户看得见的 mark。

不能跑到已经不存在的 full body bbox。

---

# X5 · Three Surfaces

Main / Context / Workflow：

共享：

```text
click
drag
Reference
local Action grammar
Composer shell
```

不共享：

```text
camera
selection state
layout
history
surface semantics
```

用户切 Surface：

不会因为物理交互同构而继承 Selection。

---

# PART 2 · T3 GUI Spatial Constitution

---

# 2.1 Resting Object

```text
[ Object Body ]

无常驻Arc
无常驻Composer
无常驻More
```

---

# 2.2 Stable Content Object

概念画面：

```text
          ○  ○  ○
       Action Arc
             ↘
      ┌───────────┐
      │   Target  │
      └───────────┘
          ↓
    ┌───────────────┐
    │ Ref chips     │
    │ Prompt...     │
    │ voice params ▶│
    └───────────────┘
```

Arc：

```text
右上
```

Composer：

```text
下/近target
```

二者不重叠。

---

# 2.3 Right click

```text
Target
   ↘ pointer
   ┌────────────┐
   │ Rename     │
   │ Duplicate  │
   │ Move/Add   │
   │ Inspect    │
   │ Delete     │
   └────────────┘
```

不是把 menu固定到target右侧一列。

---

# 2.4 Reference Pick

```text
Composer stays

Target A
+
Canvas B / C / D become lightly eligible

click B
→ B chip appears in Composer
→ A remains target
```

---

# 2.5 Voice Recording

同一个 Composer：

```text
before
[ Ref ] [ prompt ........ ] [🎙][Run]

recording
[ Ref ] [ prompt ........ ] [waveform][Cancel][Stop]

transcribing
[ Ref ] [ prompt ........ ] [Transcribing…]

editable
[ Ref ] [ transcribed text........ ] [🎙][Run]
```

宽度不应该突然从 compact变成大 Voice panel。

---

# 2.6 Glyth Context

```text
mapped object ─ light tether ─┐
                             │
                       [ Glyth ]
                             │
mapped object ─ light tether ┘
```

只显示当前可见范围的 mapping。

不全项目蜘蛛网。

---

# PART 3 · State / transition freeze

| System | Rest | Active | Exit |
|---|---|---|---|
| Object-local | body clean | Selection + local transient | transient closes, Selection can remain |
| Arc | hidden | 3 normal / 4 max | action / More / outside |
| Right-click | hidden | compact management menu | Esc/outside/action |
| Composer | hidden | target-local compact | layered Esc/outside/work transition |
| Reference | none/refs in draft | Pick mode / chips | Esc exits Pick only |
| Voice | idle | recording → transcribing | editable text / cancel |
| Run | draft | submitting/running | result/review/failure |
| Semantic Drop | no payload | tracking/receptive/preview | commit/cancel |
| Glyth | spatial identity | Select + Orbit / Speak | layered Esc |

---

# PART 4 · Popup / Confirmation Constitution

## No popup required

```text
stable select
Action Arc reveal
Composer reveal
Reference quick add
Glyth body context drop
Assembly target entry from Arc
```

## Local popover allowed

```text
parameter picker
Reference source
More
model selector
Receiver selector
```

## Full modal is NOT default

不能拿 modal解决：

```text
where to drop
which target
which local action
simple parameter
```

## Destructive confirmation

`OPEN MICRO POLICY`

---

# PART 5 · Camera / Object Motion Constitution

## Camera must NOT move because of

```text
stable click
Arc reveal
Composer reveal
Reference Pick
Voice recording
Right-click
Work View open/resize
Semantic Drop preview
```

## Object moves only because of

```text
explicit drag / resize / direct manipulation
```

## Camera may move because of

```text
explicit Focus / navigation / object-specific open
```

这些由各自空间系统拥有。

---

# PART 6 · User Pain → Final Scene

## Pain 01

旧方案：

```text
drag到感应区
→ 再选用途
```

Final：

```text
visible destination本身就是用途
```

---

## Pain 02

旧方案：

```text
固定侧栏 / 大prompt
```

Final：

```text
target-local Compact Composer
```

---

## Pain 03

旧方案：

```text
选中就等于引用
```

Final：

```text
Selection target
Reference supporting input
```

---

## Pain 04

旧方案：

```text
节点旁边功能按钮越来越多
```

Final：

```text
body clean
Arc direct
Right-click management
Functional Face intrinsic
Composer AI Work
```

---

## Pain 05

旧方案：

```text
Glyth附近节点就算context
```

Final：

```text
space proximity = only spatial organization
body drop = durable Context Mapping
Ctrl Reference = one Run
Relation port = Project Relation
```

---

# PART 7 · UX Freeze Gate

## S1 Object-local

`PASS`

## S2 Action Arc

`PASS_WITH_CROSS_SYSTEM_OPEN`

## S3 Right-click

`PASS_WITH_DESTRUCTIVE_POLICY_OPEN`

## S4 Compact Composer

`PASS_WITH_WORKVIEW_TRANSITION_OPEN`

## S5 Reference

`PASS`

## S6 Voice

`PASS_WITH_PROMPT_MERGE_AND_WORKVIEW_OPEN`

## S7 Run/Receiver

`PASS`

## S8 Semantic Drop

`PASS_GRAMMAR / PARTIAL_TARGET_TAXONOMY`

## S9 Glyth

`PASS_WITH_SPEAK_PRESENTATION_OPEN`

---

# PART 8 · Explicit OPEN list
## 这些地方施工线程不得自行产品设计

```text
OPEN-01
Docked Work View存在时，
canvas object-local Arc / Composer是否允许同时visible，
还是有明确yield规则？

OPEN-02
Voice transcript遇到已有prompt，
是cursor insert、append还是selection replace？

OPEN-03
Voice Recording过程中打开/切换Work View，
录音继续、暂停还是cancel？

OPEN-04
Multi-selection形成后，
Multi-selection Composer是否自动reveal，
还是由aggregate Work/Compose动作进入？

OPEN-05
Delete / destructive management的确认/Undo-first统一规则。

OPEN-06
Glyth double-click / Enter的 Speak/Conversation scene
最终默认是：
same local Composer expansion、
Conversation worksite、
Work View，
还是根据Conversation是否已有独立工作现场决定？

OPEN-07
Assembly / Context / Workflow所有concrete Semantic Drop target taxonomy，
由T4提供，T3不自建。
```

---

# PART 9 · Frozen UX → later implementation mapping
## 这里只建立追溯，不进入 exact file 施工

```text
UX-S1
stable click / drag causality
→ later audit Huabu pointer owner

UX-S2
Action Arc 3/4
→ later choose Huabu floating + Orbit geometry

UX-S3
management-only menu
→ later Huabu context menu primitives

UX-S4
target-local compact shell
→ later Huabu input/floating + LCOS target adapter

UX-S5
Selection != Reference
→ existing Reference semantic owner

UX-S6
Voice same Composer
→ recorder + STT adapter

UX-S7
Receiver is Conversation
→ existing Core Receiver / Run

UX-S8
destination is visible target
→ Huabu hit + LCOS semantic target adapter

UX-S9
Glyth four truths separate
→ ProjectionBinding + Context Mapping + Reference + Relation owners
```

只有当以上 UX Scene 被接受后，
旧 T3 `04_Source_Level_Construction_Plan` 才应该按照这些 Scene ID 重写 exact-file card。

---

# PART 10 · Final one-line T3 product picture

> 用户在空间里碰到一个真实对象时，不进入“软件操作模式”。稳定点击后，对象本身被选中，右上出现最多四个高频直接动作，附近出现一个很轻的 AI Composer；管理藏在右键，Reference明确另选，Voice只把说话变成可编辑文本，Run明确发送给某个持续存在的 Conversation。拖动则始终优先保持直接操纵，拖到一个真实可见目标就直接表达那个语义。Glyth作为 Conversation 的空间身份，把“本轮引用、长期上下文、项目 Relation、当前 Receiver”四件事彻底分开。整个过程中，Camera不会因为局部控件或 Work View 出现而被软件偷偷挪走。
