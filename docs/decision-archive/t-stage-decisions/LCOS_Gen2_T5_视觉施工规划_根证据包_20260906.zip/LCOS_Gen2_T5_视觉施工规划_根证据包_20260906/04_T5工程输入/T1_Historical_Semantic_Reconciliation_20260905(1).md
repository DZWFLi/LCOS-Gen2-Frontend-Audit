# T1 Historical Semantic Reconciliation

> Thread: T1 · Spatial Presentation / HUD / LOD / Layout  
> Current LCOS Gen2 HEAD: `c2ff890a867922a1256572199458438572eb0a8c`  
> Gen1 default `main` HEAD: `f0841587921781bd514edf6acffcbb592e672e52`  
> Gen1 historical integration branch: `origin/a24-to-phasea-20260901` at `3e99769`  
> Huabu documented pin: `58339e269b784728d67730c70bfe7792cae2457d`  
> Huabu upstream `main` checked 2026-09-05: `a3c411e1f655191344285141f08c4738fa6015f7`

## 0. Reconciliation verdict

T1 does not need a restart. The existing three short notes are retained as evidence notes, but they are not Stage-A deliverables.

The corrected semantic result is:

1. **Collection is durable content membership.** Expanding a Collection is a visible-host presentation on the current canvas, not a child canvas and not a new canonical owner.
2. **Colony is historical Presentation organization.** Its sticky membership, explicit add, peel, rescope and dissolve behavior are valid historical UX evidence. Its persisted contour and old Gen1 runtime implementation are not automatically valid under Gen2's Huabu-only geometry rule.
3. **The exact Colony history is branch divergence, not a clean rename/delete chain.** `spatialRegion.ts` was replaced by `spatialColony.ts` in commit `253e989`, but that commit lives on `a24-to-phasea-20260901`; Gen1 default `main` never received it. Gen2 imported the contract/Core validation but not the Web authoring/rendering chain.
4. **Visible-host and remote-target drops must be separated.** A left body-drag into a visible spatial host ends with the same source projection at the target position. A semantic transfer to a non-visible/remote target writes the target relation/membership and returns the source projection home. This distinction was missing from the earlier T1 notes.
5. **Right-drag is a borrow/use transport, not a universal “add” verb.** The target capability decides whether the drop is valid and which semantic mutation occurs. `Right-drag → Collection` remains open because Collection membership is durable containment, not temporary borrowing.
6. **Archive releases active spatial placement.** Restore returns the same canonical object with new mechanical placement; old x/y, camera-relative anchor, Colony contour position and temporary layout state are not restored.
7. **Old Workspace Frame/Region mechanics are selectively reusable.** Bounds derivation, group movement intent, visual contour and local fan-out can survive as mechanics. Their old Scope/Workspace/member/camera persistence model cannot.

No production patch is authorized by this document.

## 1. Evidence status vocabulary

| Status | Meaning |
|---|---|
| `USER_FROZEN` | Explicitly stated in current product freeze or latest user correction |
| `GITHUB_CURRENT` | Verified at current Gen2 or current upstream HEAD |
| `GITHUB_HISTORICAL` | Verified in a named historical commit/branch |
| `WIRED` | Has a production producer and consumer |
| `CONTRACT_ONLY` | Type/schema/validation exists without production Web flow |
| `PRESENTATION_ONLY` | Valid only as visual/spatial behavior, not canonical domain truth |
| `LEGACY_COMPAT` | May be read/migrated but must not receive new writes |
| `SUPERSEDED` | Replaced by a later ruling |
| `OPEN` | Requires another owner/coordinator verdict |

## 2. Authority order used

For conflicts, this reconciliation uses:

1. latest user correction in this conversation;
2. `LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905.md`;
3. original Gen1 closeout plus exact source at the relevant commit;
4. current Gen2 source at `c2ff890`;
5. vendored/current Huabu mechanics;
6. donor packages for implementation and visual precedent only.

Historical code proves that a behavior existed. It does not override the new Core/Huabu ownership split.

## 3. Colony exact history

### 3.1 What actually happened

| Point | Exact evidence | Finding |
|---|---|---|
| Before R3-A | historical `apps/web/src/state/spatialRegion.ts` | Region used rectangular bounds and geometry-derived membership |
| R3-A integration | commit `253e989` | adds `spatialColony.ts`, deletes `spatialRegion.ts`, adds R3-A closeout and validation scripts |
| Branch containment | `git branch -a --contains 253e989` | only `origin/a24-to-phasea-20260901` contains the commit |
| Gen1 default main | HEAD `f084158` | has no `spatialColony.ts`; therefore no later delete on main occurred |
| Gen2 contract | `packages/contracts/src/presentations.ts` | retains `PresentationColonyV0` and deprecated `PresentationSpatialRegionV0` |
| Gen2 Core | `apps/local-core/src/presentation-application-service.ts` | validates Colony id, surface, unique member ids and finite contour |
| Gen2 persistence test | `apps/local-core/tests/presentation-persistence.test.ts` | proves contract round-trip only |
| Gen2 Web | repo-wide use search | no Colony authoring, peel, rescope, render or Huabu mapping consumer |

Therefore the exact chain is:

```text
spatialRegion (historical live model)
  └─ R3-A branch replacement at 253e989
       ├─ spatialColony Web implementation
       ├─ PresentationColonyV0 contract
       └─ Core validation/persistence

Gen1 main: branch never merged
Gen2: contract + Core validation copied; Web implementation not copied
```

The former statement “the file may have been renamed or deleted” is now superseded. The evidence supports **branch-only implementation plus partial Gen2 carry-forward**.

### 3.2 Historical Colony behavior proven in source

At `253e989:apps/web/src/state/spatialColony.ts`:

- `colonyFromSelection`: requires at least two ids and creates a contour from member geometry.
- `colonyFromLasso`: selects nodes whose centers fall inside the polygon.
- `addMembersToColony`: explicitly unions ids; crossing the contour is not enough.
- `reconcileColonyAfterMove`: only moved members beyond `peelDistance = 44` are removed.
- `rescopeColony`: a new lasso replaces membership and contour in one operation.
- `migrateLegacySpatialRegion`: derives members from old bounds once.
- `colonyPathData`: renders an organic smoothed closed path rather than a rectangular fence.

At `_HANDOFF/LCOS_v0.15_R3A_CatalogColony_Closeout_20260829.md`:

- Collection = durable containment; Colony = spatial organization.
- membership is sticky Presentation truth;
- merely crossing the contour does not add/remove;
- add requires explicit Drop;
- peel requires decisive separation;
- rescope is explicit;
- dissolve deletes only the Colony;
- no conversion-to-Collection action;
- Context/Workflow must not invent local Colony truth.

### 3.3 What survives into Gen2

| Historical element | Status | Reason |
|---|---|---|
| Colony distinct from Collection | `KEEP` | prevents spatial grouping from mutating canonical containment |
| Sticky membership | `KEEP_AS_PRESENTATION_SEMANTIC` | stable working-set intent cannot flicker as geometry changes |
| Explicit add | `KEEP` | crossing a boundary must not silently mutate membership |
| Peel | `KEEP_BEHAVIOR`, `REIMPLEMENT` | user-understandable removal gesture; old distance/geometry code belongs to retired runtime |
| Rescope | `KEEP_BEHAVIOR`, `REIMPLEMENT` | explicit replacement of spatial working set |
| Dissolve without cascade | `KEEP` | deletes only presentation organization |
| Organic contour | `KEEP_VISUAL_INTENT` | T5 owns final morphology; Huabu owns geometry |
| Persisted absolute contour points in Core Presentation | `SUPERSEDED/OPEN_MIGRATION` | conflicts with Huabu as sole spatial geometry owner |
| `memberIds` as untyped strings | `OPEN_IDENTITY` | must resolve to stable entity/projection refs; node ids cannot cross canvases safely |
| old `spatialColony.ts` runtime | `RETIRE_AS_CODE_DONOR` | tied to old React state and CanvasNode geometry |

### 3.4 The contour contradiction

R3-A said contour points were durable Presentation geometry. Gen2's boundary says x/y, viewport and layout belong exclusively to Huabu and are never dual-persisted in Core. Both cannot remain current truth.

T1 ruling:

- durable Colony **membership and label** may remain Presentation semantics;
- the current absolute contour should be derived from Huabu member geometry or stored in Huabu-owned spatial data;
- Core must not become a second contour geometry store;
- legacy `PresentationStateV0.colonies[].contour` is compatibility input until T6/coordinator confirms migration ownership.

This is a real duplicate-truth failure scenario: after Huabu node movement/reconnect, Core contour coordinates can disagree with the visible nodes, causing peel/hit testing to use a field the user cannot see. Ordinary type checks and tests cannot prevent two valid stores from diverging. The remedy is owner removal, not another hash or gate.

## 4. Collection visible-host reconciliation

### 4.1 Canonical meaning

Current freeze:

- Collection means “these things count as a long-term group”;
- an object remains in the Project and additionally belongs to the Collection;
- Collection does not automatically own camera, layout, history or child canvas;
- multi-select batch Drop may form/join a Collection;
- no form-first confirmation, duplicate selection or automatic child workspace.

T1 does not own membership mutation. T1 owns how a visible Collection host accepts and presents the result.

### 4.2 Historical mechanics

`apps/web/src/features/canvas/collectionExpandLayout.ts` states “Presentation geometry only”. It:

- orders real member nodes;
- fans them out beside the Collection container;
- respects each member's measured width/height;
- avoids unrelated obstacles;
- uses up to three columns;
- returns positions only.

This proves the original presentation intent: **expand members in the current canvas**.

### 4.3 Correct visible-host behavior

A Collection is a visible host when its visual body/frame/expanded field is present under the pointer on the current Huabu canvas.

For left body drag into that host:

```text
drag existing projection
→ host advertises accepts(collection-membership)
→ preview names “加入 Collection”
→ Core/T6 commits membership
→ the current Huabu projection remains at the target/drop position
→ Collection host may reflow/expand using Huabu mechanics
```

The source does not snap back because the user physically moved the visible object into a visible spatial destination. Canonical identity is unchanged; membership is added.

The expanded host must not:

- clone the Artifact;
- create a child canvas;
- replace the object's ProjectionBinding;
- write geometry into Core;
- recompute Collection membership from enclosure;
- auto-open Composer.

### 4.4 Current Gen2 status

Current Gen2 README mentions `collection→frame (only when a spatial container is needed)`, but repo search finds no current Collection→Huabu Frame projection producer/consumer. This is a declared mapping, not a wired feature.

`semanticDropMachine.ts` currently knows only edge slots (`left` and `bottom`). `lcosDropState.ts` resolves them to `surface:left-dock` and `surface:bottom-dock`. It has no visible node-host destination model.

More importantly, `acquireDrop(payload)` has no production caller outside tests. A06 currently provides fabric/store/overlay/observer, not an end-to-end object drag.

Status: `CONTRACT/FABRIC_ONLY`, not `WIRED`.

## 5. Visible host vs remote target

The earlier generic rule “if not Move, source returns home” is insufficient. Destination visibility changes the spatial result.

| Gesture/destination | Semantic result | Current projection result |
|---|---|---|
| left drag to blank current canvas | Move | stays at drop position |
| left drag into visible Collection host | add durable membership | stays at target position |
| left drag into visible Scope/Workflow host | target-owned semantic mutation | stays at target if the host represents the current visible space |
| left drag to Rail/remote surface target | semantic transfer/add/use | returns to source home; target projection is created/updated remotely |
| right drag to a capability-valid target | borrow/use/reference | source never moves; ghost/proxy only |
| relation handle | create explicit Relation | source geometry unchanged |

The implementation must determine `destination.visibility = visible-host | remote-target`, not infer behavior from gesture button alone.

Failure prevented: treating visible-host add as remote transfer creates a “rubber-band snapback” after the user drops an object into a visible Collection. Treating a remote Rail target as visible move strands the source at an arbitrary edge coordinate. Types, ids and ordinary persistence tests do not catch this interaction mismatch; browser acceptance must.

## 6. Right-drag capability boundary

### 6.1 Historical evidence

Gen1's `semanticDrop.ts` explicitly says Semantic Drop is the interaction and right-drag is only its fastest trigger. It also supported Alt/Option + primary drag and a visible semantic-drop handle.

The historical generic helper said source objects never move and projected the same Project Entity into another Surface/Entity target. That is useful evidence for cross-surface borrowing, but it became too broad when reused as a universal destination rule.

### 6.2 Current ruling

Right-drag means:

> borrow/use/reference the same object through a ghost/proxy while leaving the source projection untouched.

It is valid only if the destination advertises a compatible capability, for example:

- Composer accepts Reference;
- Glyth/Conversation accepts long-lived context/reference according to T3/T6 semantics;
- Workflow accepts an input/use relation;
- Assembly target accepts use/attach without relocation.

It is not automatically valid for:

- creating arbitrary membership;
- moving between canvases;
- Archive/Delete;
- inventing a Relation type;
- converting a Collection/Colony/Scope.

`Right-drag → Collection` remains `OPEN`. Durable Collection membership means “belongs to”, while right-drag means “borrow/use without moving”. Unless T6 defines a non-membership Collection capability, T1 must fail closed and show no accepted target state.

## 7. Archive fresh-layout reconciliation

### 7.1 Frozen lifecycle

Archive preserves:

- canonical identity and content;
- versions/history/provenance;
- semantic Relations;
- Collection membership;
- Search/Assembly/Agent discoverability;
- Context/Workflow references in cold read-only form.

Archive releases:

- active Main x/y;
- old arrangement;
- viewport-relative position and camera anchor;
- old Colony position;
- projection-only temporary layout state.

Restore:

- restores the same canonical object;
- does not create a copy;
- does not restore old x/y;
- creates an eligible active projection with a fresh predictable layout.

### 7.2 T1 responsibility

T6 owns archive status, identity and active-projection eligibility. T1 owns only the fresh placement request once restore emits eligible objects.

The layout should be deterministic from the restore batch and current visible viewport, using Huabu commands/solver. It may choose Grid/Strip/Stack/Masonry according to the eventual product card, but it must not persist the archived position in a shadow store.

For single restore, place near the active spatial center or designated restore staging anchor. For multi/day restore, form a readable batch layout with stable order (archive order or explicit T6 result order) and no collision with existing nodes. The exact default pattern is a T1/T5/coordinator decision; the invariant is **fresh, mechanical, predictable**.

### 7.3 Current gap

Current Gen2 has no canonical Archive/Restore entity lifecycle found in production source. Removing a Huabu node plus unbinding is not Archive because reconciliation may project the entity again and the canonical lifecycle is unchanged.

Therefore T1 cannot implement Archive by itself. It can prepare a `restorePlacement` consumer only after T6 supplies an authoritative restored-entity event/query.

## 8. Workspace Frame / Region retirement and reuse

### 8.1 Workspace Frame

Historical `workspaceFrames.ts`:

- obtains members from explicit `workspaceIds`, otherwise `focusedViewIds`;
- calculates a padded bounding frame;
- accepts optional persisted `frameBounds`;
- marks active workspace.

Reusable:

- derived bounds from current members;
- visual frame header/label concept where a durable worksite actually exists;
- group movement and frame fit behavior, preferably through Huabu Frame.

Retire/supersede:

- `focusedViewIds` fallback as membership;
- Scope id as ownership boundary;
- persisted frame bounds in Core;
- Workspace camera as canonical navigation truth;
- using every Collection/Context/Workflow as a Workspace.

### 8.2 Region

Reusable:

- one-time migration intent;
- lasso candidate preview;
- organic spatial field/contour morphology;
- explicit rescope and dissolve grammar.

Retire:

- live rectangle-derived membership;
- Fence/Region as createable canonical species;
- Region→Collection conversion;
- independent Web geometry store;
- generic `focus-region` Agent backdoor.

### 8.3 Huabu Frame is a supplier, not semantic equivalence

Huabu Frame provides parentId, layout modes, reflow, resize, structured drop and grouping mechanics. It does not mean:

```text
Huabu Frame == Collection == Colony == Workspace
```

LCOS must decide whether a particular canonical/presentation object needs a visible frame and then map it to Huabu mechanics. The mapping is contextual and replaceable.

## 9. Focus, Pin and Work View corrections retained

- Gen1 `ProjectFocusNavigator.tsx`: Focus answers where a known object appears; Search is separate.
- Gen1 `useSpatialFocusRequest.ts`: camera-only; never changes Selection or membership.
- Huabu focus primitives may be reused, but Search result keyboard navigation must not silently become Focus behavior.
- `Canvas.tsx` currently uses `ResizeObserver` to compensate viewport x/y when the canvas wrapper changes size. This directly conflicts with the freeze that Work View open/resize must not move Camera.
- Existing Huabu `CanvasFloatingPopover`, takeover and LOD primitives match the mechanical need. Core mechanisms are identical between vendored and latest upstream for the checked takeover/popover/grid-layout files; Canvas differs mainly because of LCOS host seam patches.
- The active spatial viewport/occupied rect should reposition HUD, Popover, Pin, Locator and edge gestures. It should not rewrite the camera just because the Work View opened.

## 10. Final semantic matrix

| Concept | Canonical owner | Spatial owner | T1 role | Status |
|---|---|---|---|---|
| Collection membership | T6/Core | none | render/accept visible host | `USER_FROZEN` |
| Collection expanded layout | none | Huabu | request/policy/animation | `PRESENTATION_ONLY` |
| Colony membership | Presentation semantic owner, pending T6 identity form | Huabu renders | interaction grammar | `KEEP/OPEN_IDENTITY` |
| Colony contour geometry | Huabu | Huabu | derive/present | old Core write `SUPERSEDED` |
| Scope membership | T6/Core or T4 contract | none | visible working-boundary presentation | `CROSS_THREAD` |
| Worksite identity | T6/Core | Huabu canvas/frame mechanics | presentation only | `CROSS_THREAD` |
| ProjectionBinding | Gen2 Host/Core binding registry | references Huabu ids | consume, never store geometry | `GITHUB_CURRENT` |
| Focus/Where | T2 navigation semantic | Huabu camera | camera-only adapter | `KEEP` |
| Pin intent | T2/Core contract | Huabu screen/world projection | HUD/presentation | `KEEP/VERIFY_WIRING` |
| Archive lifecycle | T6/Core | active projection removed/recreated | fresh restore layout | `NOT_WIRED` |
| Semantic Drop gesture | T3 | Huabu pointer router | spatial preview/destination geometry | `FABRIC_ONLY` |
| Work View occupied rect | T4 | DOM/host layout | HUD safe rect, no camera move | `PATCH_REQUIRED` |

## 11. Supersession ledger

| Earlier statement | Corrected statement |
|---|---|
| `spatialColony.ts` may have been renamed/deleted | it was added on a non-main historical integration branch; Gen2 partially copied contract/Core only |
| Colony contour is durable Core Presentation geometry | sticky semantic may persist; absolute contour must not compete with Huabu geometry |
| Semantic Drop/right-drag always returns source | visible host left-drop stays; remote target returns; right-drag never moves source |
| Collection→Frame is implemented because README says so | mapping is declared but no production producer/consumer is present |
| A06 semantic drop is wired | machine/store/overlay/observer exist; no production `acquireDrop` caller and no commit target model |
| Archive can be node delete + unbind | false; authoritative lifecycle/eligibility is missing and reconcile may resurrect |
| Workspace Frame can be restored wholesale | only derived frame/group mechanics survive; old semantic fields retire |

## 12. Remaining unknowns

The following are intentionally not invented:

- stable identity type for Colony members in Gen2;
- whether Colony remains a first-class persistent Presentation object or becomes a Huabu frame/selection instrument with an LCOS label/membership sidecar;
- the exact mutation for right-drag into Collection;
- the canonical Archive/Restore endpoint/event;
- the default fresh layout style for single, batch and day restore;
- exact visible-host mapping for Collection across Main/Context/Workflow;
- whether the no-camera-on-Work-View policy is LCOS-only or should become Huabu default.

Those items are converted into explicit cross-thread questions in `T1_CrossThread_Questions_20260905.md`.

