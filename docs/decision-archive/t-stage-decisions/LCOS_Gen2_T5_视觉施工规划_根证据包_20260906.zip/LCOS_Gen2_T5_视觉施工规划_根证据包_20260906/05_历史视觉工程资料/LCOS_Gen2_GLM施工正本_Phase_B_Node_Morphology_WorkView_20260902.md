# LCOS Gen2 · GLM 施工正本 Phase B
## Responsive Node Morphology / Object Species / Unified Work View

> 本阶段回答用户最关心的前端问题：不是“给每种对象画一张卡”，而是让所有非外部文件对象共享 Huabu 文本节点的连续、可拉伸、随尺寸/缩放/交互态改变信息层级的表现宪法；同时把 LCOS 不可被 Huabu 右栏取代的 Work View 接成同一节点的中间态/工作态。

---

# 0. 权威来源与完成定义

| Source ID | 压缩包/原文定位 | 必须落地的事实 |
|---|---|---|
| U-RESP-01 | 用户：`一开始就做好不同态以及不同节点拉伸大小显示的不同gui信息表达层级` | 首次实现就有尺寸×zoom×interaction 的连续层级，不允许先做固定卡再“以后响应式”。 |
| U-RESP-02 | 用户：`除了外部文件以外的任何节点都要拥有和huabu文本节点一样的随机应变符合直觉的丝滑度` | 非外部文件节点采用同一 morphology contract；外部文件可由固有比例/viewer 例外。 |
| U-RESP-03 | 用户：`文本节点一样要支持大纲和思维导图两种模式` | Text/Outline/Mindmap 是同内容、同实体、同节点的三种 presentation，不造三类对象。 |
| U-VIEW-01 | 用户：右侧栏/页面是否可拖动，像 Gen1 中间态 | Work View 具 spatial/focus/docked/immersive/restore 生命周期；不是永久固定右栏。 |
| F-ROOT-07 | 根上下文 §7 | 去卡片化、Glyth 一级语言、ordinary UI 与 world object 分层。 |
| F-CAMERA | `LCOS_v015_Context_Workflow_Component_CameraFocus_审判与收敛_20260831.md` §1–§10 | SurfaceFrame 去卡片、resize grammar、read/edit/overview camera、screen-space hit token。 |
| F-WORKVIEW | `LCOS_v015_UNIFIED_WORK_VIEW...md` lifecycle/project-session/occupied rect/donor/Phase B–D | Work View 状态机与 project scoped continuity。 |
| F-L0 | Latest L0 §3–§6 | Work View 非 surface-local；dynamic safe region；扩展 geometry owner。 |
| F-PRESENT | `LCOS_Gen2_交互级摸牌_GPT审计盲区排查_20260902.md` §1.1–§1.3 | presentation 派生层、layout engines、viewer registry 不能遗漏。 |
| GH-HUABU-B | Huabu `useTextAutoSize.ts`、`useTextNodeSurface.ts`、`TextNodeBody.tsx`、`semanticZoom.ts`、`NodeWrapper.tsx` | 复用连续 resize、auto height、screen LOD、takeover/overlay。 |
| GH-G1-B | 旧 LCOS `presentationHierarchy.ts`、`mindMapLayout.ts`、`MindMapNoteVisual.tsx`、`documentSemanticZoom.ts`、viewer registry | 只迁纯逻辑和不可替代的对象呈现，不搬旧 Canvas。 |

Phase B 完成不是“有几个 renderer”。完成必须可在真 Huabu 上连续拖拽任意 LCOS 节点，观察内容层级自然变化；同一 Markdown 在 text/outline/mindmap 三态切换不改 entity/binding；Work View 能从节点 spatial 状态打开、拖动/停靠/沉浸、关闭并恢复相机与节点状态。

---

# 1. 节点呈现宪法

## 1.1 几何壳与内容表达分离

Huabu/ReactFlow 节点矩形仍存在，因为命中、布局、碰撞、resize、selection 需要 geometry。但“存在矩形”不等于视觉上画一张卡。

```text
Node geometry shell
  ├─ hit region / selection / handles / ports
  ├─ clip policy / measured bounds
  └─ PresentationBody
       ├─ identity mark
       ├─ summary
       ├─ working content
       └─ reading takeover / Work View
```

默认视觉：透明或近透明背景，无大面积白卡，无固定 header/footer。边界只在 hover/selected/editing/resizing 时以极轻 outline/material 出现。内容可以靠排版、图像、波形、glyph、关系结构形成自身轮廓。

## 1.2 三轴决定信息层级

禁止只按 `width` 断点。输入是：

1. 世界几何：world width/height。
2. 屏幕预算：world geometry × zoom 得到 screen pixels。
3. 交互态：rest/hover/selected/editing/dragging/resizing/focused。

可选第四轴：内容复杂度，例如标题长度、段落数、child count、media ratio。它只用于选择内部排版，不创建新 GUI 状态。

## 1.3 四种 density 不是固定四张组件

| Density | 典型屏幕预算 | 展示 | 禁止 |
|---|---:|---|---|
| mark | 短边 <44px 或宽 <84px | glyph/缩略/颜色身份；必要时 1 行短标题 | toolbar、metadata、滚动区 |
| summary | 宽 84–180px 或高 44–84px | 标题、状态、单一关键值/首图 | 固定 header/footer、完整表单 |
| working | 宽 180–480px、高 84–260px 左右 | 主要内容、局部编辑、1–2 个语义 affordance | 套娃卡片、右栏复制 |
| reading | 大尺寸或 explicit focus | 完整内容/仪器；必要时 Work View | 无限制把整应用塞进 node DOM |

这些是连续输入的输出标签，过渡应有 hysteresis，避免 resize 在阈值附近闪烁。

## 1.4 迟滞与内容稳定

```ts
export interface DensityThresholds {
  readonly markToSummaryPx: number
  readonly summaryToWorkingPx: number
  readonly workingToReadingPx: number
  readonly hysteresisPx: number
}

export function resolveDensityWithHysteresis(
  previous: PresentationDensity,
  budget: ScreenBudget,
  thresholds: DensityThresholds,
): PresentationDensity
```

初始 `hysteresisPx = 10`，与已有 Huabu semantic zoom 防抖对齐。切 density 时保留选区、编辑光标、滚动锚点；editing 中不因 zoom 降级卸载 editor。dragging/resizing 可暂时冻结重型 layout，pointerup 后再在 requestAnimationFrame/transition 中更新。

---

# 2. 目标目录与 owner

```text
apps/web-gen2/src/presentation/
  nodePresentation.ts                 # Phase A contract
  densityResolver.ts                  # shared continuous LOD
  morphologyRegistry.ts               # species -> adapter
  species/
    text/
      TextArtifactNode.tsx
      markdownDocumentModel.ts
      textPresentationMode.ts
      OutlineProjection.tsx
      MindMapProjection.tsx
    image/ImageArtifactNode.tsx
    audio/AudioArtifactNode.tsx
    video/VideoArtifactNode.tsx
    pdf/PdfArtifactNode.tsx
    conversation/ConversationGlythNode.tsx
    run/RunNode.tsx
    skill/SkillNodeShell.tsx
    generic/UnknownEntityNode.tsx
  shared/
    NodeIdentityMark.tsx
    FluidTitle.tsx
    ResponsiveMetadata.tsx
    ScreenSpaceAffordance.tsx
    useStableDensity.ts
    useNodeContentAnchor.ts
  work-view/
    workViewState.ts
    WorkViewHost.tsx
    WorkViewDock.tsx
    WorkViewSpatialHandle.tsx
    useOccupiedRect.ts
    workViewPersistence.ts
  viewers/
    viewerRegistry.ts
    viewerAdapters.ts
    ExternalFileFallback.tsx
```

Huabu changes remain thin:

- `NodeWrapper.tsx` provides presentation input/overlay/takeover.
- `useTextAutoSize.ts` and `useTextNodeSurface.ts` remain Huabu owners; LCOS adapters call/compose them rather than copy.
- Preview Workspace remains local agent/common preview owner; Work View hosts LCOS editing/inspection that cannot be represented by a generic preview tab.

---

# 3. B00 — 建立 morphology registry，而不是 renderer explosion

## 任务

在 Phase A `RendererFamily` 之下增加 `MorphologyAdapter`。同一 family 可按 canonical entity species 选择内容适配器，但所有适配器接收同一 presentation input。

```ts
export interface MorphologyProps<TModel> {
  readonly entityRef: CoreEntityRef
  readonly model: TModel
  readonly presentation: NodePresentationInput
  readonly density: PresentationDensity
  readonly capabilities: readonly NodeCapability[]
  readonly onIntent: (intent: NodeIntent) => void
}

export interface MorphologyAdapter<TModel = unknown> {
  readonly species: string
  readonly minWorldSize: Readonly<{ width: number; height: number }>
  readonly defaultWorldSize: Readonly<{ width: number; height: number }>
  render(props: MorphologyProps<TModel>): ReactNode
  openWorkView?(props: WorkViewOpenInput<TModel>): ReactNode
}
```

## 约束

- adapter 不调用 `setNodeGeometry`；resize intent 由 Huabu owner。
- adapter 不持久化 presentation density。
- explicit presentation mode 可以持久化为 view/projection preference，但不能改 artifact content type。
- `capabilities` 来自实体和 surface，决定 Action Arc/右键；不靠 renderer 猜。

## 初始尺寸预设

| Species | min world | default world | ratio policy |
|---|---:|---:|---|
| text | 120×48 | 280×160 | free; auto-height while authoring |
| conversation glyth | 72×72 | 112×112 | near-square at mark; free at working |
| image | 120×80 | 320×220 | preserve intrinsic by default, modifier frees |
| audio | 160×56 | 320×92 | free width, bounded height |
| video | 180×110 | 360×220 | intrinsic ratio until Work View |
| pdf/document | 140×180 | 260×340 | page ratio at preview, free in reading shell |
| run | 120×56 | 280×120 | free |
| skill | 120×56 | 300×180 | free |

这些不是固定框，而是 geometry safety/default。内容表达仍可无边界。

## 测试

registry 同 species 唯一；未知 species 回落 neutral renderer；resize 不更换 node type；100 nodes 不为每个节点加载所有 viewer bundle。

---

# 4. B01 — 统一 density resolver 与性能策略

## 目标文件

- `presentation/densityResolver.ts`
- `presentation/shared/useStableDensity.ts`
- 对接 Huabu `semanticZoom.ts`

## 代码预设

```ts
export const densityPreset = {
  width: { mark: 84, summary: 180, working: 480 },
  height: { mark: 44, summary: 84, working: 260 },
  hysteresis: 10,
  settleAfterResizeMs: 90,
} as const

export function screenBudget(input: NodePresentationInput): ScreenBudget {
  return {
    width: input.worldWidth * input.zoom,
    height: input.worldHeight * input.zoom,
    area: input.worldWidth * input.worldHeight * input.zoom * input.zoom,
  }
}
```

决策不能只看 area，因为极窄长节点面积可能大但无法展示段落；先短边/宽/高，再用 area 处理媒体缩略图质量。

## Resize 期间

1. geometry 每帧跟手。
2. density 用 10px hysteresis，文字排版可 requestAnimationFrame 更新。
3. 重型 graph/layout/viewer 在 resize 期间展示轻量 preview；pointerup 90ms 后计算。
4. 不用 300ms CSS transition 延迟尺寸；只对 opacity/transform 做 90–180ms 小过渡。
5. `prefers-reduced-motion` 下直接切换，但仍保持内容锚点。

## 性能预算

- 100 普通 nodes，连续 zoom/pan 目标 55–60fps（中等机器）；不能低于 45fps 持续 2 秒。
- density resolve 是 O(1)；不得读取 DOM layout 多次造成 forced reflow。
- mark/summary 不加载 Markdown editor、PDF engine、graph engine。
- Work View bundle lazy import，预热仅在 hover intent 明确且 idle 时。

## 验收矩阵

每种 species 至少 4 尺寸 × 6 zoom × 6 interaction phases；生成 Storybook/测试页不是完成，还必须在真 canvas resize。

---

# 5. B02 — 文本节点：同一 Markdown 的 Text / Outline / Mindmap

## 需求核心

三个模式共享：artifactId、revisionId、Markdown source、Huabu nodeId、ProjectionBinding。切换只改变 `presentationMode`，不复制节点、不派生新 Artifact。

## 内容模型

```ts
export interface MarkdownDocumentModel {
  readonly source: string
  readonly headings: readonly MarkdownHeading[]
  readonly blocks: readonly MarkdownBlockRef[]
  readonly revisionId?: string
}

export type TextPresentationMode = 'text' | 'outline' | 'mindmap'
```

Parser 必须是一个 owner。Outline 和 Mindmap 从同一 heading AST 派生，不能各自 regex parse；编辑 source 后增量/重新解析，保持可识别 heading 的 stable semantic key（例如 source position + normalized path，不写入 Core 新 ID，除非 Core 已有 block identity）。

## 迁移旧 LCOS

### 直接迁的纯逻辑

- `features/presentation/presentationHierarchy.ts`：visible hierarchy、collapse state 的纯函数。
- `features/presentation/mindMapLayout.ts`：root/children、subtree weight、左右分支、edge path 算法。
- `features/presentation/documentSemanticZoom.ts`：只提取层级思想，阈值统一到 Gen2 density resolver。

### 需要重写 adapter 的部分

- `MindMapNoteVisual.tsx`：视觉/DOM 与旧 canvas 耦合，保留交互知识，按 Huabu node surface 重写。
- 旧 selection/drag：改用 Huabu pointer/geometry。
- 旧 presentation stores：collapse/presentation mode 进入 view preference owner；不复制 Core content。

### 删除

- 任何为 mindmap 单独创建 CanvasNode 的逻辑。
- 任何 text→outline 时生成新 artifact 的逻辑。
- 固定 `NODE_WIDTH=188` 作为最终 UI 的用法；旧布局常量仅作算法起点，按 screen density 和 content measure 计算。

## 模式入口

不在节点常驻三按钮。入口顺序：

1. selected/hover 的单一 mode affordance，最近使用模式可直接切换。
2. 右键菜单完整列出 Text / Outline / Mindmap。
3. Action Arc 仅当“切换呈现”是当前最相关主动作时出现。
4. 快捷键可后续补，必须与文本编辑冲突检查。

## Text 模式

复用 Huabu `useTextNodeSurface` / `useTextAutoSize`：

- 新建/空文本：内容驱动高度。
- 用户显式 vertical resize 后，进入 manual height；清除高度行为沿用 `resizeEndClearHeight` 规则。
- 双击/Enter 进入编辑；Esc 退出且保留内容。
- mark 只显示 identity/首行；summary 1–3 行；working 完整可编辑；reading 进入 Work View 或 takeover，不在 node 内造滚动地狱。

## Outline 模式

Density 行为：

- mark：文档 glyph + heading count。
- summary：标题 + 一级 headings 前 3 条。
- working：可展开/折叠层级、键盘上下移动、拖动重排 heading。
- reading：完整 outline + 正文定位，可在 Work View 中 split preview。

重排必须生成对 Markdown source 的 deterministic edit proposal，走 artifact revision mutation；不能只改本地 tree state。

## Mindmap 模式

- mark：根 glyph + branch count。
- summary：root + 一级分支，无文字溢出。
- working：可折叠、拖分支、从 heading 拖出创建普通文本投影。
- reading：Work View/聚焦相机中完整可编辑 mindmap。

“拖出生成普通文本节点”默认是同 artifact 的 block/view projection，还是复制内容新 artifact，必须按旧原文和现有 Core view contract裁决。没有 canonical block/view identity 时先做只读拖影，不得静默复制内容；这是明确 fail-close 点。

## 代码骨架

```tsx
export function TextArtifactNode(props: MorphologyProps<TextArtifactModel>) {
  const mode = useTextPresentationMode(props.entityRef)
  const density = props.density
  if (density === 'mark') return <TextIdentityMark model={props.model} mode={mode} />
  switch (mode) {
    case 'text': return <TextSurface model={props.model} density={density} />
    case 'outline': return <OutlineProjection model={props.model} density={density} />
    case 'mindmap': return <MindMapProjection model={props.model} density={density} />
  }
}
```

## 测试

- 三模式 artifactId/nodeId/binding 不变。
- source edit 后 outline/mindmap 同步。
- collapse 只改变 view state，不删除 Markdown。
- resize/zoom 中 mode 不自动切换；只切 density。
- editing 光标与 IME 中文输入不因 density render 丢失。
- 10k 字 Markdown 在 mark/summary 不 mount 全 AST UI。

---

# 6. B03 — 图像、音频、视频、PDF/外部文件物种

## 总原则

对象确实有不可替代的媒介差异时保留 species；区别只是排布/尺寸时共用 primitives。不能把所有对象压成同一白卡，也不能每种 MIME 发明一套导航/toolbar。

## Image

| Density | 呈现 |
|---|---|
| mark | crop thumbnail 或 color average + image glyph |
| summary | 图像主体，标题浮现仅 hover/selected |
| working | intrinsic ratio preview、轻量 crop/fit 控件 |
| reading | Work View 中高分辨率、版本/标注/来源 |

Huabu 已有 image node/preview 时优先复用 renderer/body；LCOS adapter 只加 entity identity、revision/provenance 和 intents。不要复制图片解码、缩略缓存。

## Audio

mark 用 audio glyph + duration ring；summary 用静态简化 waveform；working 才有 playhead/play/pause；reading Work View 才显示 transcript、markers、versions。波形 donor 可以用现成 canvas/SVG renderer，但 waveform 数据缓存由 media preview owner，不能写进 Core entity schema。

## Video

mark 静态 poster；summary poster + duration；working hover/selected 才显示播放控制；reading Work View 加 timeline/captions/version。不得在 20 个 summary nodes 自动播放/解码视频。

## PDF/外部文件

这是用户允许的例外：文件可能需要页面比例/框定范围，因为外部格式本身有 viewport。仍应在小态自适应，但完整文件阅读走 Huabu Preview Workspace 或 LCOS Work View adapter，不能在小节点内嵌完整 PDF viewer。

## Viewer Registry 迁移

旧 `features/viewer/artifactViewerRegistry.tsx` 体量大，不能遗漏也不能整包搬。先建立清单：MIME match、lazy loader、capability、preview/workview、fallback。逐 adapter 对照 Huabu `NodePreviewContent.tsx`、`PreviewRenderer.tsx`：

```ts
export interface ViewerRegistration {
  readonly id: string
  readonly supports: (artifact: ArtifactModel) => boolean
  readonly nodePreview?: LazyExoticComponent<ViewerComponent>
  readonly workView?: LazyExoticComponent<ViewerComponent>
  readonly externalOpen?: (artifact: ArtifactModel) => Promise<void>
}
```

相同能力 Huabu 已有则 adapter；只有 LCOS revision/provenance/instrument 无替代时保留自有 Work View。

---

# 7. B04 — Conversation Glyth 节点

## 不可替代部分

Conversation 是进入项目的 agent/session 身份，不只是一个聊天卡；右上角/角标、Glance 状态、receiver、run status 与本地 agent 通用 tab 是不同层。

## 呈现层级

- mark：Glyth 本体 + 最小状态角标。
- summary：名称/agent、当前状态、最近活动的极短 cue。
- working：可直接投递/reference/connect；不把完整聊天塞进节点。
- reading：打开 Huabu Preview Workspace 的通用会话 tab，或 LCOS Conversation Work View（只有项目语义/引用/运行编排无法由通用 tab 承担时）。

## 右上角角标

角标不是新的 object。它是 conversation/run state 的 projection：idle/running/needs-review/error/complete。只允许一个主 badge，错误/审阅优先；不能同时堆 provider、model、online、run、pin 五个角标。

```ts
export type GlythBadge =
  | { kind: 'none' }
  | { kind: 'running'; progress?: number }
  | { kind: 'review'; count: number }
  | { kind: 'error'; recoverable: boolean }
  | { kind: 'done'; recent: boolean }
```

provider/model 信息进 tooltip/Work View，不常驻节点。

## Glance 动效边界

Phase B 只接状态与 layout；Phase D 实现 motion preset。先保证 reduced-motion 和无动画时信息仍完整。动画不能是 run truth；刷新后从 Core state 重建。

---

# 8. B05 — Run、Skill 等非媒体节点的响应式共性

## Run

mark：状态 glyph；summary：动作+状态；working：关键输入/输出/审阅动作；reading：Run Work View（日志、diff、references、receiver）。不能用右侧 agent tab 替代 LCOS 的 run review，因为通用 tab 不拥有 Core changeSet/review/provenance。

## Skill

mark：skill glyph；summary：名称/版本；working：输入输出/子 skill 轮廓；reading：Skill Work View/Builder。Skill 与 Harness Run 不合并为同一实体；UI grammar 可共用，但一个是可复用 project artifact，一个是一次执行记录。

## Context/Workflow instrument shell

Phase B 只提供 `lcos/instrument` morphology shell、resize/focus/workview 能力。具体结构/关系/时间线/步骤编辑在 Phase C，避免 B 阶段造假数据。

---

# 9. B06 — Unified Work View 状态机

## 产品裁决

Work View 不是永久右侧栏，也不是另一个页面路由；它是同一个对象从空间形态进入工作形态的连续容器。Huabu Preview Workspace 保留用于各本地 agent 通用 tab、文件预览等；LCOS Work View承载无法被通用 tab 替代的编辑、结构、执行、审阅与 direct manipulation。

## 状态

```ts
export type WorkViewPlacement =
  | { kind: 'spatial'; nodeId: string }
  | { kind: 'floating'; rect: ScreenRect }
  | { kind: 'docked'; edge: 'right' | 'left' | 'bottom'; sizePx: number }
  | { kind: 'immersive' }

export interface WorkViewState {
  readonly projectId: string
  readonly entityRef: CoreEntityRef
  readonly placement: WorkViewPlacement
  readonly restore: {
    readonly surface: SurfaceKey
    readonly canvasId: string
    readonly viewport: Viewport
    readonly nodeId?: string
  }
}
```

## 生命周期

```mermaid
stateDiagram-v2
  [*] --> Spatial
  Spatial --> Floating: Open work
  Floating --> Docked: Snap edge
  Docked --> Floating: Drag handle
  Floating --> Immersive: Expand
  Docked --> Immersive: Expand
  Immersive --> Docked: Restore
  Floating --> Spatial: Close
  Docked --> Spatial: Close
```

Focus 是 camera/presentation 语义，Work View 是工作容器；二者可关联但不能混成一个 enum。双击默认优先 reading camera/focus，只有对象需要重型工具或明确 open intent 时才开 Work View。

## Persistence

project scoped，记录 active entity、placement、dock size、必要内部 tab；不记录临时 hover、density。Work View 状态不属于某个 surface，切 surface 时若仍有同 project 工作可保持；但 restore 必须回到原 surface/canvas/node。

## 单主视图

同一时刻一个 dominant Work View。其他打开请求：替换当前，或进入 Huabu Preview Workspace tabs；禁止在画布上堆 5 个浮动 IDE。未保存编辑时替换必须确认/保存草稿，不能静默丢失。

---

# 10. B07 — Dynamic Spatial Safe Region / occupied rect

## 需求来源

F-L0 §5–§6。Work View/HUD/导航改变可用画布区域时，扩展现有 geometry/camera owner，不造第二 viewport。

## 目标文件

- `work-view/useOccupiedRect.ts`
- Huabu camera fit/viewport owner 的公开 inset/occupied rect 参数
- `WorkViewHost.tsx`

## 类型

```ts
export interface ScreenInsets {
  readonly top: number
  readonly right: number
  readonly bottom: number
  readonly left: number
}

export interface OccupiedRegion {
  readonly id: string
  readonly rect: ScreenRect
  readonly priority: number
}
```

Camera `fit/read/edit/overview/locate` 应接收 insets/occupied regions，将目标放进剩余 safe rect。不能通过给 canvas DOM 加 margin 模拟，因为那会破坏 screen↔world 转换、drop、overlay anchoring。

## 行为

- dock right 420px：camera 保持当前 world center 映射到剩余区域中心，使用 160–220ms gentle transform。
- resize dock：camera 不每像素震动；以 rAF 合并，内容跟手，必要时 pointerup 再轻微 settle。
- floating Work View：通常不挤画布；显式 focus/locate 时避让其 rect。
- immersive：canvas 可冻结 pointer，但不销毁；退出恢复 viewport。
- HUD/navigation：同一 occupied-region registry，不各自改 camera。

## 测试

open/resize/close 后 target node 不被遮住；连续 20 次不积累 viewport drift；zoom 0.5/2 和 DPI 150% 均正确；切 surface/restore 回原 camera。

---

# 11. B08 — Work View 与 Huabu Preview Workspace 的分工接线

## Preview Workspace 保留

Huabu 已有 `PreviewWorkspace.tsx/Panel/Group/Tab`、model/persistence，存储 key 为 `huabu.previewWorkspace.${canvasId}`。它适合：

- 本地 agent 通用标签页。
- 文件/网页/媒体预览。
- 多个轻量只读资源的 tabs。
- Huabu 自身生成/预览工作流。

## LCOS Work View 必须保留的能力

- Core Run review/changeSet/provenance。
- Skill builder 与 root/subskill。
- Context structure/evolution/relationship/source instruments。
- Workflow direct manipulation 与 checkpoint/review。
- Artifact revision editing、ordered references、receiver/Composer 配合。

## Adapter 而非竞争

```ts
export type OpenDestination =
  | { kind: 'preview-workspace'; preview: HuabuPreviewInput }
  | { kind: 'lcos-work-view'; work: LcosWorkViewInput }
  | { kind: 'external'; url: string }

export function resolveOpenDestination(capabilities: NodeCapability[]): OpenDestination
```

同一对象可“快速预览”进 Preview Workspace、“开始工作”进 Work View；文案与 icon 必须区分。右栏不应永远固定 LCOS renderer，也不应吞掉节点 spatial→working 的连续性。

---

# 12. B09 — Camera read/edit/overview/locate 与组件 Focus

## 四种相机意图

| Intent | 目标 | 触发 |
|---|---|---|
| locate | 找到对象，保留周边空间关系 | Pin/Search/locator |
| read | 让主要内容达到可读屏幕尺寸 | 双击/Enter/阅读 |
| edit | 留出 editor/handles/Composer 空间 | 明确编辑 |
| overview | 看结构整体 | Escape/overview action |

不能都调用同一个 `fitBounds` 常量。每个 intent 计算 target screen occupancy 和 safe region：

```ts
export const cameraIntentPreset = {
  locate: { targetOccupancy: 0.28, maxZoom: 1.15 },
  read: { targetOccupancy: 0.62, maxZoom: 1.6 },
  edit: { targetOccupancy: 0.52, maxZoom: 1.4 },
  overview: { paddingPx: 72, maxZoom: 1.0 },
} as const
```

数值必须真机校准。外部文件/视频可限制 maxZoom；文本 read 可更高。

Component Focus 是局部阅读态：弱化周围节点、保持可见空间上下文、Esc 恢复。它不打开全屏 modal，也不改变 canonical selection/reference。

---

# 13. B10 — CSS、材料与动效边界

Phase B 只提供结构 token，最终材料/Glance/Pin motion 在 Phase D。

```css
.lcos-node-surface {
  position: relative;
  inline-size: 100%;
  block-size: 100%;
  min-inline-size: 0;
  color: var(--lcos-fg-primary);
  background: transparent;
  border: 1px solid transparent;
  border-radius: var(--lcos-node-radius, 14px);
}

.lcos-node-surface[data-phase='hover'],
.lcos-node-surface[data-phase='selected'] {
  background: color-mix(in srgb, var(--lcos-surface-tint) 5%, transparent);
  border-color: color-mix(in srgb, var(--lcos-fg-primary) 14%, transparent);
}

.lcos-node-surface[data-phase='editing'] {
  background: color-mix(in srgb, var(--lcos-surface-tint) 8%, transparent);
}
```

禁止：每种 species 自己定义一套 shadow/radius/header；`overflow:hidden` 无脑裁正文；固定 `height: 320px`；小节点中出现内滚动条；blur 100px 普遍铺满导致 GPU 压力。真正 iOS26 invisible-shell material由 Phase D统一裁决。

过渡预设：density 内容 fade/translate 90–140ms；Work View open/close 180–260ms spring；camera 160–220ms；resize geometry 0ms。`prefers-reduced-motion` 关闭位移动画。

---

# 14. B11 — 物种逐项迁移表

| Gen1 模块 | 精髓 | Gen2 去向 | 被替换部分 |
|---|---|---|---|
| `presentationHierarchy.ts` | hierarchy/collapse 纯逻辑 | text outline/mindmap model | 旧 node/store |
| `mindMapLayout.ts` | subtree weight/左右布局/edge path | lazy mindmap layout adapter | 固定尺寸/旧 canvas coordinate |
| `MindMapNoteVisual.tsx` | branch affordance/drag intent | 新 Huabu renderer | 原 DOM/CSS/selection |
| `documentSemanticZoom.ts` | 文档 LOD 思想 | shared density resolver | 自己的 zoom owner |
| `artifactViewerRegistry.tsx` | viewer admission/MIME fallback | viewerRegistry adapters | 已被 Huabu preview 覆盖的 viewer |
| `SurfaceFrame` | 组件承载意图 | NodeWrapper + WorkViewHost | 白卡 shell |
| conversation/Glyth | project identity/receiver/status | ConversationGlythNode | 旧 floating chrome |
| old Workbench/Workbench dialog | working lifecycle | Unified Work View | modal/page duplication |

每迁一项必须写 donor trace：原文件/函数、复制/改写/删除、license、为什么 Huabu 无替代、用什么测试证明行为保留。

---

# 15. B12 — 自动测试、视觉矩阵与人工验收

## 自动测试

1. density resolver 阈值/迟滞/interaction override。
2. morphology registry lazy loading。
3. Text/Outline/Mindmap 同源 identity。
4. Markdown parse + hierarchy + collapse + layout deterministic。
5. viewer destination resolve。
6. Work View state transitions、restore、project persistence。
7. occupied rect 与 camera intent geometry。
8. Conversation badge priority。
9. no duplicate renderer family/node type。

## 真 canvas 视觉矩阵

| 维度 | 值 |
|---|---|
| species | text/image/audio/video/pdf/conversation/run/skill/instrument |
| width | 72/120/180/280/480/720 world px |
| height | 44/72/120/240/480 world px |
| zoom | .25/.5/.75/1/1.5/2 |
| phase | rest/hover/selected/editing/dragging/resizing/focus |
| DPI | 100/125/150% |

不用保存 9×6×6×7 的全部截图，但测试页必须可遍历；人工至少覆盖每 species 的四 density 与 editing/resize。

## Text 三态剧本

1. 创建 Markdown，输入中英文、列表、三级 headings、代码块。
2. 从 120×48 拉到 720×480，观察 mark→summary→working→reading，无内容硬裁。
3. zoom .25→2，层级有迟滞，无闪烁。
4. 切 Outline，折叠/展开；artifact/node/binding 不变。
5. 切 Mindmap，折叠分支、拖动；返回 Text 内容不丢。
6. 编辑 heading，另外两态同步。
7. reload/Core restart 后 content/mode/persistence 符合 owner 规则。

## Work View 剧本

1. 节点 spatial 打开 floating。
2. 拖到右侧 dock；resize 420→620px，camera safe region跟随。
3. immersive，再 restore 到 dock。
4. 切 Context surface；Work View仍属于 project，不丢；关闭后 restore 到原 Main camera/node。
5. 打开另一个对象：按单主视图规则替换或提示未保存。
6. 通用文件“预览”进入 Huabu Preview Workspace；LCOS“编辑/审阅”进入 Work View，入口语义清楚。

---

# 16. 施工拆分与预计工时

| 包 | 内容 | 预计 |
|---|---|---:|
| B00–B01 | registry + density + performance harness | 2–3 天 |
| B02a | Markdown model/Text mode 接 Huabu text surface | 2–3 天 |
| B02b | Outline migration/edit proposal | 2–3 天 |
| B02c | Mindmap migration/layout/interaction | 3–5 天 |
| B03 | media/PDF viewer adapters | 3–4 天 |
| B04–B05 | Glyth/Run/Skill shells | 2–3 天 |
| B06–B08 | Work View + Preview Workspace division | 4–6 天 |
| B07+B09 | safe region/camera intents/focus | 3–4 天 |
| B10–B12 | polish/perf/visual/desktop/restart | 3–5 天 |

单一工程 agent 预计 24–36 个有效工作日。若旧 Markdown block identity 或 Huabu viewer API 缺口要求 Core/Host 追加，再加 4–7 天；不得用复制 artifact 来掩盖 block identity 缺口。

---

# 17. Phase B 退出条件

- 每种非外部文件节点均使用共享 presentation contract。
- 连续 resize/zoom 有四级表达和迟滞，非固定卡断点拼贴。
- Text/Outline/Mindmap 同源、同 entity、同 node、同 binding。
- Outline/Mindmap 迁移了旧 LCOS 的纯逻辑精髓，未搬旧 canvas/store。
- 不同媒体物种保留不可替代表现，通用 preview 交给 Huabu。
- Conversation Glyth/角标的 truth 来自 Core/session/run，不来自动画本身。
- Unified Work View 可 floating/docked/immersive/restore，非永久右栏。
- Preview Workspace 与 Work View 分工经真实入口验证。
- safe region 扩展 Huabu camera owner，无第二 viewport。
- 100 node 性能、zoom/DPI、IME、reload/restart 均有证据。

任何一项只做了 interface/mock/故事页，均标“未完成”。

