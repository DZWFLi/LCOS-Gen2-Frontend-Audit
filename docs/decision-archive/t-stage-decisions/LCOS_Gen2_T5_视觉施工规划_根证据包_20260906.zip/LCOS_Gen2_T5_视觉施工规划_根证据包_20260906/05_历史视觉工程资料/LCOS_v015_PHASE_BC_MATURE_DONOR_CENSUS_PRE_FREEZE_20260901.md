# LCOS v0.15 · Phase B/C 成熟框架 Donor Census 与初步冻结

日期：2026-09-01  
状态：PRE-FREEZE / RESEARCH AUTHORITY  
目的：在 Phase B/C 进入真实 GUI/Surface Component/Workflow/Context 施工前，优先确定“哪些东西直接收编成熟方案，哪些东西必须由 LCOS 自己拥有”。

---

## 0. 总裁决

LCOS 后续前端不再默认“自己从零实现一个功能”。

新的默认顺序：

1. 先判断该能力是不是通用成熟问题；
2. 若是，先做 GitHub donor census；
3. 核许可证、维护度、React/TS 适配、bundle/runtime 代价；
4. 优先收编 MIT/Apache 等成熟 primitive、算法或 copy-paste 示例；
5. LCOS 只写自己的 canonical semantics、owner、adapter 和空间整合层；
6. 只有在 donor 无法满足 LCOS 语义/空间约束时才自研。

一句话：

> 让成熟框架负责“别人已经做好一万遍的东西”，让 LCOS 负责“只有 LCOS 才需要拥有的东西”。

---

# 1. 什么必须继续由 LCOS 自己拥有

以下不能外包给第三方框架：

- Project Object canonical truth；
- Main / Context / Workflow / Assembly 的 Surface semantics；
- Selection truth；
- Selection ≠ Reference；
- Relation truth 与 Conversation Context Mapping 的区分；
- Action Arc command ownership；
- Unified Composer target adapter；
- Surface Component 作为 Spatial Instrument 的产品定义；
- SpatialCanvas 的世界坐标、对象身份与跨 Surface 一致性；
- A20 SpatialOverlayPlacement / OverlayStack owner；
- Color Pin / Focus / Search / Map Locator 的 canonical state 分工；
- Assembly Admission Rules；
- Candidate → Validate → Preview → Commit；
- Glyth / Conversation canonical identity；
- Workflow Step→Step 与 Project Domain Relation 的区别；
- Skill Artifact canonical package truth。

成熟框架只能成为：
- functional core；
- render engine；
- interaction primitive；
- layout engine；
- reusable UI shell；
- algorithm donor。

不能成为 LCOS canonical owner。

---

# 2. Workflow Surface 第一轮 donor 结论

## 2.1 Primary UI donor：xyflow / React Flow

Repository: `xyflow/xyflow`  
License: MIT  
成熟度：高

可直接借的东西非常多：

- NodeToolbar
- NodeResizer
- custom node
- custom edge
- sub flows
- lasso selection
- node intersection
- proximity connect
- edge drop
- connection limit
- minimap/controls 的交互经验
- node position animation
- selection feedback
- copy-paste examples

尤其重要：

React Flow 官方 examples 中存在大量 MIT Licensed copy-paste 示例，适合直接做 donor。

### LCOS 用法

不把 Workflow Surface 整体替换成 React Flow。

原因：

LCOS 已经冻结：
- Main / Context / Workflow 共用 SpatialCanvas；
- Selection / Orbit / Drag/Drop physical grammar 共用；
- canonical object truth 不应被 React Flow node/edge state 接管。

正确用法：

```text
LCOS SpatialCanvas
    +
React Flow donor patterns
```

重点拆：
- NodeToolbar 交互；
- NodeResizer/resize handle；
- connection hit-testing；
- node/edge intersection；
- lasso；
- subflow visual conventions；
- edge insertion；
- animated route transition。

---

## 2.2 Workflow semantic donor：Rete.js

Repository: `retejs/rete`  
License: MIT  
成熟度：高

Rete.js 本身就是 visual programming / workflow framework，并明确覆盖：

- dataflow
- control flow
- typed node/socket
- processing graph
- plugins
- multiple frontend renderers

### LCOS 用法

Rete 不做 Workflow canonical runtime。

更适合借：

- typed socket / port capability 模型；
- dataflow 与 control-flow 分离；
- connection validation；
- node plugin architecture；
- node capability schema；
- graph processing contract。

这对 LCOS Workflow 的真正价值比“把画布换成 Rete”更大。

建议：

```text
Workflow Step capability
→ borrow Rete-style typed socket semantics

Workflow visual projection
→ remain LCOS SpatialCanvas
```

---

## 2.3 Workflow 产品 donor：n8n

n8n 当前 Workflow Canvas、workflow diff、execution/log UI 非常值得继续研究。

特别值得借鉴：

- node catalog / search；
- workflow diff；
- execution status；
- logs panel；
- node insertion；
- edge insertion；
- active execution feedback；
- workflow initialization / mapping；
- node parameter progressive disclosure。

但有重要许可证边界：

`n8n-editor-ui` 属于 Sustainable Use License，不是普通 MIT library。

因此：

> n8n = 产品/架构/交互 donor，不作为可直接复制源码 donor。

可以研究行为、状态机、信息层级；
不要直接把 editor-ui 源码搬进 LCOS。

---

## 2.4 Workflow layout donor：ELK.js

Repository: `kieler/elkjs`

ELK 专门负责 graph layout，而不是 renderer。

特别适合：

- layered directional layout；
- port-aware layout；
- edge routing；
- incremental layout；
- workflow auto tidy；
- deterministic layout candidate。

### LCOS 用法

这和我们以前冻结的：

```text
free placement
+ soft guides
+ optional Tidy
```

非常匹配。

正确接法：

```text
LCOS canonical positions
↓ user asks Tidy / AI proposes layout
ELK candidate positions
↓
preview
↓
commit
```

绝不能自动偷偷把用户节点推走。

---

# 3. Context Surface 第一轮 donor 结论

Context 不应该继续靠“我们自己画几个卡片和线”来表现结构/演进/关系。

Context 的差异本来就是：
- evolution；
- relationship；
- occurrence；
- version；
- structure。

这些已经有成熟 visualization core。

---

## 3.1 Relationship Lens primary donor：Cytoscape.js

Repository: `cytoscape/cytoscape.js`  
License: MIT  
成熟度：非常高

它同时提供：

- graph model；
- interactive renderer；
- graph analysis；
- rich event/hit-testing；
- graph layout integration。

适合 Context 中：

- Relationship Lens；
- selected scope relationship view；
- dependency / semantic neighborhood；
- route/highlight；
- graph analysis。

### 关键边界

Cytoscape graph 不是 LCOS Project graph truth。

它只接收 projection：

```text
LCOS Context Projection
→ Cytoscape view model
→ Lens
```

所有编辑必须回到 LCOS mutation path。

---

## 3.2 大图关系可视化 donor：Sigma.js + Graphology

Repository: `jacomyal/sigma.js`  
License: MIT

Sigma 专门用 WebGL 渲染成千上万 nodes/edges，建立在 Graphology 之上。

适合未来：

- 项目级大量关系 overview；
- large-scale Focus/relationship overview；
- read-heavy Relationship Lens。

不适合拿来直接做每个 Context 主编辑器。

建议：

- Cytoscape = rich interaction / edit-near lens；
- Sigma = large graph read/overview lens。

---

## 3.3 Context Evolution primary donor：vis-timeline

Repository: `visjs/vis-timeline`  
License: MIT OR Apache-2.0

成熟能力：

- interactive timeline；
- item / range；
- zoom / pan；
- create / edit / delete；
- time scale 从 milliseconds 到 years；
- DataSet 双向更新。

非常适合：

- Context evolution；
- version occurrence timeline；
- artifact evolution；
- workflow/history occurrence；
- scope milestones。

### LCOS 用法

不把时间轴当 canonical history store。

```text
LCOS Version / Evolution truth
→ Timeline Projection
```

Timeline UI 只产生 typed intent，再交回 LCOS mutation/history owner。

---

## 3.4 Context deterministic spatial layout：ELK.js

Relationship Lens、Context structure、workflow-like dependency 都可以复用同一个 layout engine。

不用 Context 再写一套“节点自动排版算法”。

---

## 3.5 Context Version / Diff donor

可调研/试接：

- `otakustay/react-diff-view`
- `MrWangJustToDo/git-diff-view`
- `diff2html`

用途：

- version comparison；
- artifact delta；
- Before / Delta / After；
- Context evolution diff。

不要把 diff viewer 做成 Context 默认脸；
它应该是专门的 Diff / Evolution Component Functional Face。

---

# 4. Surface Component 第一轮 donor 结论

Surface Component 不需要我们自己把所有“功能脸”都画出来。

Frozen definition 仍是：

> Surface Component = Spatial Instrument

因此应该：

```text
LCOS Component Host
+
成熟 Functional Core
```

---

## 4.1 Structure / Outline Instrument：react-arborist

Repository: `jameskerr/react-arborist`  
License: MIT

成熟功能：

- drag/drop sorting；
- open/close；
- inline rename；
- virtualization；
- keyboard navigation；
- ARIA；
- filtering。

适合：

- Context Structure；
- Workflow outline；
- Skill package outline；
- Assembly source tree；
- large nested artifact navigation。

不需要自己再写一棵缩水版文件树。

---

## 4.2 Mind-map / Skill Builder donor

### Mind Elixir

Repository: `SSShooter/mind-elixir-core`  
License: MIT

适合：
- editable mind map；
- framework-agnostic；
- shortcuts；
- plugin architecture；
- large mindmap。

### Markmap

Repository: `markmap/markmap`  
License: MIT

适合：
- Markdown / outline → read-oriented mindmap；
-快速投影；
- Skill package / document structure preview。

建议：

- Skill Builder 真编辑：优先 Mind Elixir / own LCOS adapter；
- Markdown/outline preview：Markmap。

---

## 4.3 Component resize donor：react-rnd / resize primitives

Repository: `bokuweb/react-rnd`  
License: MIT

它有成熟：
- controlled size；
- controlled position；
- resize handles；
- min/max；
- grid increments。

但 LCOS 不能让 react-rnd 接管世界坐标 drag。

可借：
- resize math；
- handles；
- min/max constraints；
- aspect lock。

世界位置继续由 SpatialCanvas owner。

---

## 4.4 Split-view donor：react-resizable-panels

Repository: `bvaughn/react-resizable-panels`  
License: MIT

适合：

- Assembly Target ↔ Warehouse；
- Context Component 内部 dual-pane；
- Diff before/after；
- Workflow logs / output split view。

这是典型“不准再自己写拖动分栏”的成熟 primitive。

---

# 5. Assembly donor

Assembly 的产品 truth 仍由 LCOS 定义，但绝大多数机械 GUI 不需要自己做。

推荐组合：

```text
Assembly Workspace
├─ react-resizable-panels
│   └─ Target ↔ Warehouse split
│
├─ cmdk
│   └─ searchable category / object catalog
│
├─ dnd-kit
│   └─ warehouse list / nested material drag interactions
│
├─ react-arborist
│   └─ hierarchical source browsing where needed
│
└─ LCOS SpatialCanvas / Admission Rules
    └─ actual canonical drop and mutation
```

---

# 6. Search / Catalog donor：cmdk

Repository: `dip/cmdk`  
License: MIT

成熟：
- command menu；
- combobox；
- filtering；
- sorting；
- composable；
- keyboard/a11y。

适合：

- Surface Component Catalog；
- Skill Catalog；
- Assembly search；
- Command palette；
- object chooser；
- model/skill/reference selectors。

Search Result 的最终 spatial projection仍走 LCOS CenteredSpatialIndex；
cmdk 只负责 query/input/result filtering shell。

---

# 7. Drag/Drop donor：dnd-kit

Repository: `clauderic/dnd-kit`  
License: MIT

成熟能力：

- framework-agnostic core；
- DOM layer；
- React adapter；
- pointer/mouse/touch/keyboard sensors；
- collision detection；
- lists/grids/multiple containers/nested contexts；
- accessibility。

适合：

- catalogs；
- lists；
- Component 内部 reorder；
- Skill Builder outline；
- Assembly warehouse；
- multi-container management。

### 不适合

不要直接让 dnd-kit 替代 SpatialCanvas world-space drag。

建议：

```text
Canvas world drag
= LCOS

DOM/local instrument drag
= dnd-kit
```

---

# 8. Infinite canvas donor：tldraw

tldraw 技术非常成熟，约 50k star 量级，是很好的 UX / implementation donor。

但当前 SDK production use 需要 tldraw license key / commercial or hobby license。

同时 LCOS 已经拥有 SpatialCanvas 与自己的 truth。

因此冻结：

> tldraw 不作为 LCOS v0.15 Runtime Replacement。

只用来研究：
- shape interaction；
- selection；
- handles；
- zoom/pan；
- gesture；
- performance；
- camera；
- snapping；
- component ergonomics。

不做直接 runtime 依赖。

---

# 9. Phase B 初步重新定义

Phase B 不再简单理解成“把 GUI 画漂亮”。

建议冻结为：

# Phase B = Mature Primitive Adoption + Morphology Restoration

核心任务：

1. 建 Donor Registry；
2. 把自研的通用机械 UI 逐项替换/对齐成熟 primitive；
3. 建统一 Component Host；
4. 建统一 local DOM interaction layer；
5. 建统一 resize / split / popover / catalog / tree / timeline / graph adapter；
6. 保证所有 donor 都被 LCOS semantics 包住；
7. 把 Main / Context / Workflow 的“形态差异”做出来，但不在 B 大规模扩产品功能。

Phase B 不应该再写：
- 自制 tree；
- 自制 split pane；
- 自制 drag list；
- 自制 command palette；
- 自制 timeline engine；
- 自制 generic workflow connection editor；
- 自制 graph layout；
- 自制 resize engine。

---

# 10. Phase B 候选施工包

建议 B 阶段控制在约 8–10 个 package。

## B1 · Donor Registry & Integration Boundary
- dependency/adoption policy；
- licenses；
- adapter ownership；
- no canonical truth leakage。

## B2 · Component Host Restoration
- Spatial Instrument host；
- resize primitive；
- internal hit-testing；
- expanded/collapsed/locator；
- component selection。

## B3 · Local Catalog / Command Primitive
- cmdk；
- searchable Surface Component Catalog；
- Skill / Assembly chooser shared primitive。

## B4 · Local DnD Primitive
- dnd-kit；
- lists / trees / warehouse reorder；
- no canvas world drag takeover。

## B5 · Tree / Outline Primitive
- react-arborist；
- Context/Workflow/Skill outline adapter。

## B6 · Split / Instrument Layout Primitive
- react-resizable-panels；
- Assembly / Diff / logs foundation。

## B7 · Graph / Relationship Projection Adapter
- Cytoscape primary；
- Sigma optional large-reader path。

## B8 · Timeline / Evolution Projection Adapter
- vis-timeline；
- Context evolution projection contract。

## B9 · Deterministic Layout Adapter
- ELK.js；
- Candidate → Preview → Commit；
- Context/Workflow Tidy。

## B10 · Donor Visual Re-skin / Motion Convergence
- remove donor-looking UI；
- bind LCOS tokens/material/Action Arc/Locator/Selection。

如果 package 能安全合并可缩到 8 个左右，但不要混成一个超级包。

---

# 11. Phase C 初步重新定义

# Phase C = Surface-specific Product Instruments & Assembly

B 只铺成熟 functional cores；
C 才真正落产品。

---

# 12. Context Surface C-stage candidate families

建议第一批只做真正有价值的：

## Context Structure
Functional core:
- react-arborist

## Context Evolution
Functional core:
- vis-timeline

## Context Relationship Lens
Functional core:
- Cytoscape.js
- Sigma large-reader optional

## Context Diff / Delta
Functional core:
- diff viewer donor

## Context Occurrence / Route
LCOS CenteredSpatialIndex + Map Locator
不需要第三方 graph UI替代。

---

# 13. Workflow Surface C-stage candidate families

## Workflow Path / Step editor
- LCOS SpatialCanvas remains host
- React Flow / Rete donor semantics

## Workflow Step Functional Face
- typed capability / sockets from Rete concepts
- LCOS species renderer

## Workflow Scope / Subflow
- React Flow subflow interaction donor
- LCOS scope truth

## Workflow Review / Execution
- n8n interaction donor
- own LCOS implementation
- status / logs / result

## Workflow Tidy
- ELK candidate layout

## Workflow Diff
- n8n product pattern donor
- diff component functional core

---

# 14. Skill Builder C-stage donor family

Skill Builder仍是 Workflow Surface 的专门投影。

建议组合：

```text
Root Skill identity / routing
        ↓
react-arborist outline
        ↔
Mind Elixir editable mind map
        ↓
LCOS Skill Package adapter
```

Markmap 可用于 read projection，不做 canonical editor。

---

# 15. Assembly C-stage donor family

Assembly Workspace：

- split = react-resizable-panels；
- searchable catalog = cmdk；
- local warehouse DnD = dnd-kit；
- hierarchy = react-arborist；
- prompt = Unified Compact Composer；
- actual target/drop/mutation = LCOS Admission Rules；
- spatial category = CenteredSpatialIndex。

---

# 16. 许可证红线

优先直接收编：

- MIT
- Apache-2.0
- compatible permissive license

谨慎/只参考：

- n8n editor-ui Sustainable Use License
- tldraw production SDK license
- Pro-only React Flow examples

冻结原则：

> 能看不代表能复制；能复制不代表应该让它成为 owner。

所有 donor 进入代码前要登记：
- repository；
- version；
- license；
- copied files / dependency；
- modifications；
- LCOS adapter owner。

---

# 17. 当前第一轮 Primary Donor Registry

| LCOS 能力 | Primary donor | 角色 |
|---|---|---|
| Workflow node UI patterns | xyflow / React Flow | copy-paste/example donor |
| Workflow typed flow semantics | Rete.js | semantic donor |
| Workflow product behavior | n8n | reference only |
| Directed graph layout | ELK.js | runtime layout engine |
| Context relationship | Cytoscape.js | functional core |
| Large relationship reader | Sigma.js | optional functional core |
| Context evolution | vis-timeline | functional core |
| Tree / outline | react-arborist | functional core |
| Mind-map editor | Mind Elixir | functional core |
| Markdown mindmap | Markmap | projection core |
| Local DnD | dnd-kit | interaction primitive |
| Catalog / picker | cmdk | UI primitive |
| Split view | react-resizable-panels | UI primitive |
| resize mechanics | react-rnd concepts/primitive | local component primitive |
| Prompt Composer | prompt-kit / Vercel AI Elements donor | UI donor |
| Voice | mature recorder + STT adapter | primitive + provider seam |

---

# 18. 接下来在真正进入 B/C 前还要补的 donor census

下一轮需要继续查：

1. Relationship / graph editing React wrappers 的性能与 theme 接法；
2. Cytoscape vs Sigma 的 React integration；
3. vis-timeline React wrapper 是否值得依赖，还是直接写极薄 adapter；
4. React Flow NodeToolbar / NodeResizer MIT example 的具体源码边界；
5. Rete socket/dataflow 哪些可以直接依赖，哪些只借模型；
6. Skill Builder 的 Mind Elixir 事件模型与 controlled state 适配；
7. Component Catalog 是否 cmdk 足够；
8. resize primitive 到底用 react-rnd / re-resizable / own tiny adapter；
9. diff viewer 选型；
10. Voice recorder / VAD / STT donor 最终选型。

---

# 19. 初步结论

现在可以明确反转以前“Surface Component 必须我们自己画”的施工习惯。

新的 Component 心智应该是：

```text
LCOS Spatial Instrument Host
        +
Mature Functional Core
        +
LCOS Adapter
```

例如：

```text
Context Evolution Component
= LCOS host + vis-timeline + ContextEvolutionAdapter

Context Relationship Component
= LCOS host + Cytoscape + ContextRelationshipAdapter

Skill Builder Component
= LCOS host + react-arborist / Mind Elixir + SkillPackageAdapter

Workflow Path Component
= LCOS host + React Flow/Rete donor logic + WorkflowProjectionAdapter

Assembly
= LCOS Workspace + resizable-panels + cmdk + dnd-kit + AdmissionRules
```

这样做不是“偷懒”。

这是把工程资源从重复造轮子转向：
- canonical semantics；
- cross-surface grammar；
- projection；
- AI mutation；
- real product differentiation。

也是 Phase B/C 应该真正完成的事情。
