# LCOS Gen2 · T4
# Patched Professional Work Plan
## 基于 2026-09-05 V2 + 原始语义考古后的第四路修正版

日期：2026-09-05  
状态：`PHASE-A PATCHED PLAN / WAIT COORDINATOR`

> 本稿不是最终施工正本。
>
> 它只做一件事：
>
> **把 T4 之前已经形成的 source/donor/ExactFile 方案，按本轮语义考古逐项标记哪些继续、哪些修改、哪些废止、哪些等待跨线程裁决。**

---

# 0. Patch 标签

```text
UNCHANGED
= 原计划仍成立

PATCH_UX
= 产品/交互表达需调整，owner基本不变

PATCH_OWNER
= 责任边界需改，不能由原模块继续拥有

PATCH_MUTATION
= current canonical mutation/taxonomy 与最新产品冲突

SUPERSEDED
= 明确被后续冻结覆盖

WAIT_CROSS_THREAD
= T4 已达到证据边界，不得继续拍板
```

---

# 1. 总体架构修正版

T4 不再用：

```text
“Work View 系统”
```

模糊包住所有专业工作。

改成：

```text
Project Session
├─ Surface Layer
│  ├─ Main
│  ├─ Context
│  └─ Workflow
│
├─ Professional Window Layer
│  ├─ Assembly
│  ├─ Context instruments
│  ├─ Workflow detail
│  ├─ Skill Builder
│  ├─ Run Review
│  ├─ Conversation Preview
│  ├─ Archive viewer
│  └─ Web/PDF/HTML deep viewer
│
└─ Nested Worksite Layer
   └─ true child canvases / long-term worksites
```

三层必须分离。

---

# 2. M0 Project Session

## 原计划

```text
Core Project
→ Project Launcher
→ LcosProjectSessionProvider
→ SurfaceRegistry
→ current Huabu canvas
→ runtime.retarget()
```

## 本轮状态

```text
UNCHANGED
```

理由：

- 与 Scope/Worksite考古不冲突；
- 反而更需要 Project Session 上移，避免专业窗口与 Surface 切换销毁 runtime；
- Core Project identity已经存在；
- SurfaceRegistry已有 contract/tests。

## Patch owner

T4只拥有：

```text
Project-scoped professional lifecycle coordinator
```

不拥有：

```text
导航 route语义
parent/child back stack
canonical worksite identity
```

因此：

```text
App/Router exact route shape
= WAIT_CROSS_THREAD T2
```

---

# 3. M1 Professional Window Manager / Unified Work View

## 原计划

Dockview Core/React 作为多专业窗口 engineering donor：

```text
Float
Dock
Undock
Resize
Move
Split
Close
Restore
```

Canvas 作为 protected root panel / protected spatial body。

## 本轮状态

```text
UNCHANGED AS DONOR CANDIDATE
PATCH_OWNER on terminology
```

### 必须补丁

统一专业窗口 manager：

```text
不是 child canvas manager
不是 worksite manager
不是 old WorkbenchService
```

建议工程命名优先：

```text
ProfessionalWindowStage
ProfessionalRegionManager
```

而不是容易和 old Core `WorkbenchService` 混淆的：

```text
WorkbenchServiceV2
```

---

# 4. “single dominant Work View”

旧施工计划：

```text
同时只能有一个 dominant Work View
```

## 本轮状态

```text
SUPERSEDED
```

V2 允许 N 个专业区域同时存在。

例如：

```text
Conversation child canvas
+ Conversation Preview
+ Assembly
+ Run Review
```

可组合。

---

# 5. Stable body / state continuity

旧计划：

```text
同一个专业 body
Floating → Docked → Immersive
不应因 placement 改变无意义重建
```

## 本轮状态

```text
UNCHANGED
```

但语义从：

```text
整个系统只有一个 WorkViewSession
```

改为：

```text
每个 ProfessionalRegion 有自己的 presentation identity
```

---

# 6. Protected Canvas

旧计划：

```text
Canvas稳定
work region open/resize
不改 camera
不自动 node layout
```

## 本轮状态

```text
UNCHANGED
```

必须继续验证：

```text
open
dock
resize
float
redock
close
surface switch
```

过程中：

```text
camera transform unchanged
```

除非用户显式 Focus。

---

# 7. old WorkbenchService

current：

```text
temporary Scope
ViewRefs
merge to root
delete temp views
```

## 本轮状态

```text
SUPERSEDED_AS_PRODUCT_OWNER
LEGACY_COMPAT
```

### Plan patch

禁止：

```text
Professional Window Manager
→ 调 old WorkbenchService 创建 temporary scope
```

这两个概念没有继承关系。

---

# 8. M2 Assembly

## 原计划

```text
Project-shared Source Bay
Project / Capture / Sources / Skills
current target自动带入
canonical AssemblyApply
Lovart material browser / masonry donor
```

## 本轮状态

```text
UNCHANGED UX
PATCH_MUTATION on legacy scope mappings
```

### KEEP

```text
one Project Assembly
no second warehouse
Source Bay composes multiple canonical read sources
AssemblyApply only routes existing canonical services
```

### PATCH_MUTATION

current：

```text
context/workflow/collection
→ relation endpoint kind='scope'
```

必须交 T6迁移。

T4 UI不得再根据 `scope` taxonomy做业务判断。

---

# 9. Assembly Target

历史 freeze：

```text
Main
Context
Workflow
Glyth/Conversation
```

## 状态

```text
CURRENT_TRUTH / UNCHANGED
```

但：

```text
Context/Workflow target canonical identity
```

不再从旧 `ScopeKind` 直接推导。

---

# 10. M3 Context Atlas Entry + Temporary Detail

## 原计划

Atlas作为 Context大工作态 / professional body。

## 本轮状态

```text
PATCH_UX
```

### 新边界

Atlas：

```text
Context Home / Instrument
= 面
```

不负责：

```text
Evolution编辑
Relationship全铺
Provenance全铺
nested worksite
```

点击 region：

```text
temporary detail first
```

不是 materialize child canvas。

### Donor保持

```text
Astra
→ 轻2.5D视觉语言

Spatial
→ focus / morph / yielding

TapNow
→ marker / label / HUD
```

这些只提供 mechanics/visual，不提供产品 taxonomy。

---

# 11. M4 Context Professional Instruments

## 原计划

```text
Structure
Evolution
Relationship
Provenance
```

## 本轮状态

```text
PATCH_UX / KEEP_AS_INSTRUMENT
```

### 最新形式

不再机械要求：

```text
“四个并列永久 tab”
```

而是按用户任务进入：

```text
Evolution/Wave
Relationship lens
Provenance/Source lens
temporary detail
```

### Evolution

```text
2D first
```

不为了 Atlas 的2.5D把时间编辑强塞进地图。

---

# 12. ContextSnapshot

## KEEP

```text
Checkpoint-backed snapshot
compare
history refs
```

## PATCH_MUTATION

current `branch()`：

```text
scope(kind=collection)
+ new ArtifactViews
+ generated x/y
```

不能作为 Gen2 final branch semantics。

### T4动作

```text
UI/Work View 不依赖这个 legacy side effect
```

### exact canonical fix

```text
WAIT_CROSS_THREAD T6
```

---

# 13. Scope module

此前 T4有过：

```text
Context/Workflow Scope body
active scope panel
```

## 本轮状态

```text
PATCH_UX
PATCH_OWNER
```

### 现在 Scope 只允许作为：

```text
current target set
selection-derived work range
temporary work boundary
```

### 不允许作为：

```text
persistent empty container
child canvas
long-term Worksite
old CanvasScope owner
```

### Save/Commit

```text
WAIT_CROSS_THREAD
```

T4只准备 UI hook，不定义 canonical persistence。

---

# 14. M5 Workflow Deep Work

## 原计划

Workflow专业工作、真实材料/动作/结果、Run Review。

## 本轮状态

```text
UNCHANGED PRODUCT DIRECTION
PATCH_MUTATION on scope-backed identity
```

### KEEP

```text
Workflow = first-class Surface
not DAG builder
not Run log
minimal visible action = one user-perceived work round
```

### Deep body

```text
Review
Run detail
logs
provider
retry
```

都是：

```text
professional instruments
```

不是第二 Workflow child canvas。

### scopeId route

current import/export `scopeId`：

```text
LEGACY_COMPAT
```

T4 typed client可支持兼容 transport，但产品 UI 不显示“Scope=Workflow”。

---

# 15. Workflow extraction / “整理为 Workflow”

最新 V2：

```text
Selection/current region
→ 整理为 Workflow
```

用户显式采用后才成为正式 Workflow。

## 本轮状态

```text
CURRENT_TRUTH
WAIT_CROSS_THREAD for canonical mutation
```

T4 owns：

```text
professional UX / preview / proposal
```

T6 owns：

```text
正式 Workflow identity + membership mutation
```

---

# 16. M6 Skill Builder

## 原计划

```text
Skill Builder professional body
outline/mindmap
Root/Subskills
versions
canonical Skill package
```

## 本轮状态

```text
UNCHANGED
```

current SkillPackageService已经支撑：

```text
CRUD
version
composition
dependencies
provenance
```

Builder只编辑这份 truth。

---

# 17. Skill Builder ≠ Worksite

此前若任何方案暗示：

```text
打开 Skill Builder
→ materialize独立 child canvas
```

## 状态

```text
SUPERSEDED / WRONG_OWNER
```

Skill Builder：

```text
professional Instrument / Work View
```

默认不是 long-term spatial worksite。

---

# 18. Skill ≠ Harness Run

## 状态

```text
UNCHANGED / HARD FREEZE
```

Skill：

```text
manual / capability package
```

Harness Run：

```text
execution/debug record
```

Run结果可提出 Teach/Update proposal，但不自动写 Skill。

---

# 19. Skill usage binding

## 原计划

T4等待 canonical Core seam。

## 本轮状态

```text
WAIT_CROSS_THREAD
```

不变。

最新产品需要：

```text
Skill → Workflow
Skill → Composer
Skill → Glyth
Skill → target
```

current AssemblyApply：

```text
unsupported
```

所以 T4仍禁止 fake UI truth。

---

# 20. M6 Run Review

## 原计划

T4负责：

```text
Run/Result/Review professional body
Artifact Return
Accept/Reject/Retry presentation
```

Run engine/Core truth不属 T4。

## 状态

```text
UNCHANGED
```

注意：

```text
Harness Run
≠ Skill Builder
```

继续两个 body。

---

# 21. Conversation deep work

## 原计划

multi-region：

```text
Conversation child canvas
Conversation preview
Assembly
```

## 状态

```text
UNCHANGED PRODUCT
PATCH_OWNER
```

### T4 owns

```text
Preview professional region
Assembly region
their Float/Dock/Close/Restore
multi-region composition
```

### T4 does NOT own

```text
Conversation child canvas canonical identity
parent/child navigation
camera/layout/history
```

这些：

```text
T2 + T6 + T1
```

---

# 22. Child Worksite Materialization Gate

T4可以携带产品门槛：

```text
需要独立视野
独立 layout
独立 history
长期持续
以后回来继续
```

但不能把它实现成：

```text
if detailOpenCount > N:
  createChildCanvas()
```

## 状态

```text
WAIT_CROSS_THREAD
```

用户意图是决定性前提。

---

# 23. M7 Spatial / Workbench boundary

## 原计划

T4输出 occupied rect / floating collision rect。

T1消费 safe region。

## 状态

```text
UNCHANGED
```

T4不再拥有任何 Camera restore。

---

# 24. M8 Archive Work View

## 原计划

```text
date-grouped
Masonry
single/multi/Restore All
```

## 状态

```text
UNCHANGED UX
WAIT_CROSS_THREAD canonical lifecycle
```

Archive UI是 professional body。

Archive identity/lifecycle不是 T4。

---

# 25. M9 Shared Donor Adapter Layer

## 原计划

```text
WorkbenchLayoutAdapter
AssemblySourceAdapter
ContextEvolutionProjection
SkillBuilderProjection
ActiveSpatialOccupancyAdapter
```

## 本轮状态

```text
UNCHANGED PRINCIPLE
PATCH NAMING
```

避免：

```text
ScopeAdapter
```

成为新万能抽象。

每个 adapter必须以 current canonical target类型工作。

---

# 26. Donor map after archaeology

| Donor | T4可借 | 禁止 |
|---|---|---|
| Dockview | window topology / float/dock/split/restore | 不能定义 Work View vs Child Worksite |
| Spatial | focus yielding / morph / settle / stack motion | 不能定义 Collection/Scope truth |
| Lovart | Assembly/Archive browsing / masonry / material hierarchy | 不能复制 IA/domain taxonomy |
| TapNow | marker/fixed-screen label/HUD mechanics | 不能决定 Pin/Scope canonical semantics |
| Astra | Context Atlas轻2.5D语言 | 不能把 Context变3D世界 |
| LibTV | Skill结构/可复用包的成熟 mechanics | 不能改 Skill/Run canonical ownership |
| Huabu |唯一 spatial body / geometry / camera / selection | 不承接 Core domain truth |

---

# 27. Prior T4 artifacts patch ledger

## `LCOS_Gen2_T4_V2冻结_统一多工作区窗口_Dockview_Donor裁决与架构纠偏_20260905.md`

```text
Dockview donor census                    UNCHANGED
N professional regions                   UNCHANGED
Protected Canvas                         UNCHANGED
single WorkView assumptions              already SUPERSEDED
Workbench naming                         PATCH_OWNER
child-worksite boundary                   PATCH_OWNER
```

---

## `LCOS_Gen2_T4_ProjectIdentity_SurfaceRetarget_WorkbenchStage_ExactHandoff_20260905.md`

```text
ProjectSession lift                      UNCHANGED
Core Project identity                    UNCHANGED
SurfaceRegistry wiring                   UNCHANGED
T4 owning route/navigation               PATCH_OWNER / T2
ProfessionalWorkbench naming             PATCH_OWNER
```

---

## `LCOS_Gen2_T4_Assembly_SourceBay_CanonicalApply_SkillBinding_GapMatrix_20260905.md`

```text
Source Bay composition                   UNCHANGED
Warehouse != whole Assembly              UNCHANGED
AssemblyApply thin canonical router       UNCHANGED
context/workflow/collection→scope mapping PATCH_MUTATION
Skill read/catalog                        UNCHANGED
Skill usage binding                       WAIT_CROSS_THREAD
```

---

## `LCOS_Gen2_T4_模块化职责与Donor映射_吸收Spatial_ContextAtlas补丁_20260905.md`

```text
modular structure                         UNCHANGED
M0 ProjectSession                         UNCHANGED
M1 Workbench                              PATCH_OWNER terminology
M2 Assembly                               PATCH_MUTATION taxonomy
M3 Atlas                                  PATCH_UX sharper Instrument boundary
M4 Context Instruments                    PATCH_UX
M5 Workflow                               PATCH_MUTATION scope legacy
M6 Skill/Run                              UNCHANGED
M7 Spatial boundary                       UNCHANGED
M8 Archive                                WAIT_CROSS_THREAD truth
M9 adapters                               UNCHANGED principle
```

---

# 28. 04 / 05 / 99 patch classification

由于正式 T4 `04_Source_Level_Construction_Plan / 05_Acceptance / 99 Coordinator Handoff` 具体最新文件尚未全部回收到当前会话，本稿先锁“命题级 patch”，不伪造逐文件行号。

## 04 Source-Level Construction Plan

必须：

```text
PATCH_OWNER
- Work View vs child worksite
- Professional Workbench naming
- Conversation child canvas ownership

PATCH_UX
- Context Atlas
- Scope presentation
- Context instruments

PATCH_MUTATION
- ContextSnapshot branch legacy scope/x/y
- Workflow scopeId assumptions
- Assembly scope endpoint mapping

SUPERSEDED
- single dominant Work View
- Scope as container/worksite

WAIT_CROSS_THREAD
- Scope Save/Commit canonical persistence
- Workflow membership
- Skill usage binding
- Archive lifecycle
- long-term Worksite canonical owner
```

---

## 05 Acceptance

新增必须证明：

```text
Scope highlight不创建child canvas
Atlas click先temporary detail
Evolution是独立2D instrument
Work View open不创建Workspace/Scope
multiple professional regions共存
Conversation child canvas与Preview/Assembly identity分层
Surface switch不销毁Project professional session
Skill Builder不创建Run
Run Review不修改Skill
Assembly drop不写前端fake membership
```

---

## 99 Coordinator Handoff

必须明确列：

```text
T4 CLOSED facts
T4 OPEN facts
T4 does-not-own facts
current source legacy dependencies
cross-thread asks
```

不能写：

```text
“Scope已全部解决”
“Worksite按Workspace实现”
“Skill装配已完成”
```

这种超出证据边界的话。

---

# 29. T4 final implementation order after archaeology

在 Coordinator phase B 之前只允许继续：

```text
A. donor/source proof
B. prototype isolated mechanics
C. exact current-source census
D. adapter boundary design
```

禁止 production patch。

Coordinator 回填 owner后，建议顺序：

```text
1. ProjectSession lifecycle
2. ProfessionalWindowStage prototype
3. Surface-safe occupied rect integration
4. Assembly Source Bay read/write adapters
5. Context temporary detail + professional instruments
6. Workflow deep detail
7. Skill Builder
8. Run Review
9. Archive UI after Core lifecycle
10. Conversation deep-region composition after child-worksite owner closes
```

---

# 30. Final architecture principle

```text
Surface
= where spatial work lives

Scope
= who this work is about right now

Professional Window
= how I inspect/edit something deeply

Child Worksite
= another durable spatial desk

Assembly
= where project sources are found/assembled

Skill
= reusable canonical capability

Run
= one execution record
```

T4只管把专业工作展开得连续、稳定、可组合。

不再让一个 `scopeId` 替五个概念顶班。
