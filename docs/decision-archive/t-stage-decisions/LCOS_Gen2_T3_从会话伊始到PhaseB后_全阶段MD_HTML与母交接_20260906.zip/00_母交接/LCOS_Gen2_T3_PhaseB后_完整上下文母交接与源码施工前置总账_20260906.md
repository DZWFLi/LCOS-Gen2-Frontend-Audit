# LCOS Gen2 · T3 当前完整上下文母交接稿
## Local Interaction / Action Arc / Compact Composer / Reference / Voice / Receiver / Semantic Drop / Glyth
### Phase B 裁决后 · 源码施工前最终 Context Handoff

> 日期：2026-09-06  
> 当前线程：T3  
> 当前阶段：**Phase B 产品/跨线程裁决已关闭 → 即将进入 Phase C1 源码级施工方案**
>
> **极重要：如果当前 ChatGPT 会话因为上下文/额度限制无法继续，本文件应作为新会话第一份必读文件。**
>
> 新会话在写任何 source-level plan 之前，应依次读取：
>
> 1. 本文件；
> 2. `LCOS_Gen2_PhaseB_四路合并_最终跨线程裁决稿_20260906(3).md`；
> 3. `LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905(3).md`；
> 4. `LCOS_Gen2_UX场景先行_UserIntentFirst_源码施工前置协议_20260904(1).md`；
> 5. 本文件后文列出的 T3 审计 / donor / UX / 历史考古 MD。
>
> 本文件不是 private chain-of-thought。
> 它是可以转交给下一会话、Coordinator、T5 和 Codex 的：
>
> - 用户原话与裁决摘要；
> - 已验证事实；
> - T3 当前职责；
> - 历史方案有效性；
> - 当前 source facts；
> - donor 采用结论；
> - Phase B 回填；
> - 后续源码施工 SOP。

---

# 0. 当前最高 Authority

从 2026-09-06 起，T3 不再重新讨论已被 Phase B 关闭的产品语义。

当前 Authority 顺序：

```text
A0
最新用户明确纠正 / 当前消息

A1
LCOS_Gen2_PhaseB_四路合并_最终跨线程裁决稿_20260906

A2
LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905

A3
UX 场景先行 / User-Intent-First 协议

A4
T3 已完成历史考古 / source audit / donor deep dive

A5
当前 LCOS_Gen2 + Huabu upstream source

A6
旧 v0.15 / Gen1 implementation
仅用于 provenance / migration / compatibility
不得反向覆盖 A0-A3
```

必须牢记：

> **旧代码证明“以前怎么实现”，不自动证明“现在产品应该是什么”。**

---

# 1. 最新 Phase B 对 T3 的直接裁决
## 以下全部 CLOSED，不再重新 OPEN

最新 Coordinator Phase B 对 T3 最直接的回填：

```text
Right-drag
= source spatial placement 不动
= target 按唯一 natural semantic commit
= Relation handle 永远另算 Project Relation

Visible Host 左拖
= 当前 projection 留在 target

Remote Target 左拖
= source 当前 projection 留在 source scene
= target canonical semantic / mapping / projection 更新

Multi-select
= 不自动打开 Composer
```

因此 T3 不再重新讨论：

```text
Scope 是否 durable container
Collection 是否 child canvas
Context top-level 是否人工 membership
Workflow 是否 DAG
Work View 是否 child canvas
旧 Workspace 是否原样复活
Colony 是否 Collection
Colony contour 是否继续 Core points
Right-drag 是否 temporary relation
Archive 是否第二仓库
Work View resize 是否自动改 Camera
same canvas 是否默认多 authoritative projection
SurfaceDock / Railway 谁是一级主入口
```

只有：

```text
current source 存在真实技术冲突
AND
无法通过薄适配解决
```

才回报 Coordinator。

否则：

> **不得重新进行产品语义讨论。**

---

# 2. T3 当前正式职责

T3 = **用户怎样直接操作一个对象并把意图交给系统。**

T3 主责：

```text
Object-local Interaction Grammar
Action Arc
Right-click / More
Unified Compact Composer
Reference / Reference Pick
Voice input
Run Receiver presentation
Semantic Drop / Semantic Carry gesture language
Relation explicit gesture
Glyth local interaction
Local overlay collision / coexistence with Work View
```

T3 不主责：

```text
Colony canonical/presentation truth
Collection canonical membership
Scope work truth
Worksite identity
Child Canvas navigation
Workflow canonical composition
Context Atlas truth
Assembly canonical target mutation
Archive canonical lifecycle
最终 visual morphology
```

这些由 Phase B 指定的其它 owner 承接。

T3 只消费它们暴露的 target contract / canonical command。

---

# 3. T3 产品语言：最终大白话

当前 T3 可以压成：

```text
点
= 选

再点 / 明确 Work
= 做

多选
= 先整理，不自动 AI

Reference
= 只给这一轮 AI 看

Voice
= 另一种输入文字的方法

Receiver
= 这一轮交给哪段 Conversation

左拖到空白
= 搬

左拖进 Visible Host
= 放进去，当前 projection 留下

左拖给 Remote Target
= 给另一个地方用，当前 source scene 保留原 projection

右拖
= 当前 source spatial placement 从头到尾不动
= target 按自己的唯一 natural semantic commit

Relation handle
= 明确建立 Project Relation
```

统一的是：

> **手势语言。**

不统一的是：

> **target mutation / placement result。**

后者必须由目标 owner / Core contract 决定。

---

# 4. 用户在本线程逐步确认的关键原话 / 意图摘要

以下不是逐字完整聊天转录，而是保留用户原意的交接摘要。

## 4.1 关于 donor 原则

用户反复确认：

> 最新冻结不是具体方向指引，而是方向约束与分工调整。  
> 具体最优呈现仍然要专项线程自己深挖。  
> TapNow / Lovart / Spatial 上成熟、好用、好看的呈现方式能直接拿就直接拿。

因此：

```text
Freeze
→ 约束产品语义/职责

Donor research
→ 决定最好怎么呈现

Huabu/OSS/current source
→ 决定最薄怎么实现
```

不能把产品冻结当 UI 设计稿。

---

## 4.2 关于 Semantic Give

用户对：

> “碰一下目标 → 建立语义 → 原物回到原位”

这一想法明确表示非常喜欢。

但后续进一步纠正：

> **不能把回弹动作到处套。**

只有 Remote Target / Portal 等场景适合 source 留在原 scene。

Visible Host：

```text
Expanded Collection
Gallery
Grid
Masonry
Stack
Frame / Region
当前 Surface 中真实空间 host
```

左拖成功以后：

> 当前 projection 应该真的留下 / 进入布局。

这条已被 Phase B D03 / D04 正式关闭。

---

## 4.3 关于右键 Drop

用户最初担心：

> 以前 LCOS 一直确认 Right-click Drop，现在还有没有意义？

随后形成：

```text
右键点击
= 管理

对象右键拖
= source 本体不动
= 只拿 proxy / semantic transport 去目标
```

Phase B 最终修正 T3 的旧措辞：

不能继续把 Right-drag 写成：

```text
temporary borrow
```

正式应写：

> **source spatial placement 不动；目标按自己的唯一 natural semantic 建立目标关系。生命周期由目标语义决定。**

例如：

```text
Right-drag → Collection
= durable Collection membership
但 source 当前 projection 不动
```

Relation handle 仍严格独立。

---

## 4.4 关于 Collection / Colony / Scope

用户明确提醒：

> 这些概念太重要，不能搞混。  
> 必须翻 Gen1 / v0.15 历史代码和原话，确认谁是谁。

这导致 T3 做了一次正式历史考古，并发现此前确有偏差。

当前最终：

```text
Collection
= 哪些东西长期算一组
= canonical durable many-to-many membership

Colony
= 当前 Surface / Worksite 里哪些东西形成一片
= surface-local Presentation semantic

Scope
= 这一次只处理谁
= transient work boundary
= 不再有 durable canonical Scope identity

Component
= 这一批东西怎么看 / 怎么排 / 怎么工作

Worksite
= 另一张以后还能回来继续的桌子

Work View
= 把一件事拿近、展开、深度操作的窗口
```

T3 不再重新定义这些产品语义。

---

## 4.5 关于 Voice

用户最终确认：

```text
有选中文字
→ 转写替换当前 selection

有 caret
→ 插入 caret

没有 active caret / selection
→ append 到末尾
```

Voice：

```text
不自动 Run
不打开独立 Voice Workbench
转写后仍是普通可编辑文字
```

这项已关闭。

---

## 4.6 关于 Remove / Archive / Delete

用户确认：

```text
Projection / view-local remove
→ 直接做
→ Undo

真实文件 / canonical entity / 整套 Workflow 等
→ 不能直接删
→ 明确确认
```

后续 Phase B 将 Archive 正式闭合为 canonical lifecycle：

```text
Archive
→ archived/archivedAt
→ membership/relation/history 保留
→ active Main projection eligibility=false

Restore
→ clear archived
→ fresh projection
→ fresh Huabu layout
→ 不恢复旧 x/y
```

因此 T3 只负责入口 / 用户反馈。

---

# 5. User-Intent-First 施工纪律

此前 T3 已接受并执行：

```text
用户原话
→ UX 场景
→ GUI 排布
→ 状态/转场/动效
→ 交互动线冻结
→ source owner audit
→ Huabu
→ donor
→ Adopt / Wrap / Lift / Retire
→ Exact File
→ JSX/CSS/token/motion
→ tests
→ real browser
```

但是：

> Phase B 已关闭的产品问题，不再回到 UX 产品讨论。

现在进入 source plan 后，只允许：

```text
真实技术冲突
→ Coordinator conflict
```

不允许：

```text
“我觉得另一种产品方案更好”
→ 重新 OPEN
```

---

# 6. T3 已完成的历史考古结论

T3 曾经错误/过度泛化过：

```text
Scope 画成常驻虚线容器
Collection Drop 一律回弹
Collection 过早说成 T2 的 child-canvas-like place
Right-drag 说成 temporary borrow
```

这些全部已被后续历史考古 + Phase B 修正。

历史考古找回：

## Collection

08-14 已明确：

```text
Collection 不再是子画布
原地 collapsed ↔ expanded
```

旧 source 也存在：

```text
expandedCollectionScopeIds
openingCollectionScopeIds
closingCollectionScopeIds
layoutExpandedCollectionMembers()
```

说明 Collection presentation 本来就是：

> 当前 Canvas 上展开 / 收起成员。

Phase B 最终：

```text
Collection identity
= canonical project object

Entity → Collection
= durable many-to-many membership

presentation
= Huabu / spatial
```

---

## Colony

08-29 R3-A exact closeout：

```text
Collection
= durable content containment

Colony
= spatial organization scope
```

Colony：

```text
create
explicit add
sticky membership
peel
rescope
dissolve
organic field
```

Phase B 最终：

```text
membership 可持久
但属于 Surface-local Presentation semantic

contour
= derive-only from Huabu member geometry

Core 不再持久 contour points
```

---

## Scope

旧 `ScopeKind / CanvasScope / scopeId` 曾承载：

```text
collection
context
workflow
delivery
temporary-workbench
camera/layout
```

这是历史 implementation overloading。

Phase B D01：

```text
Scope 当前没有长期 canonical identity
```

若用户想长期保存：

```text
长期一组
→ Collection

正式一段工作
→ Workflow

长期另一张桌子
→ Worksite

只是本轮
→ Scope 消失
```

不做 DurableScope。

---

## Workspace / Worksite

旧 Workspace 曾保存：

```text
camera
visibleLayers
focusedViewIds
scopeId
frameBounds
...
```

当前不是原样复活。

Phase B：

> 沿用 / 迁移旧 Workspace identity，逐步瘦身成 Worksite contract。

禁止：

```text
old Workspace system
+
new Worksite system
```

同时存在。

---

# 7. T3 当前 donor 深挖结果

## Lovart

最适合高保真借：

```text
Compact Composer
Selection Toolbar
Multi-selection
Reference chips
Select From Canvas
local popover
hover/focus affordance
context menu density
thumbnail / chip anatomy
```

不能借：

```text
Selection auto→Reference
Lovart 自己的业务 action taxonomy
```

---

## TapNow

最适合借：

```text
Conversation identity
Run / streaming / stop
receiver presentation
voice states
attachment
reconnect / continuity
queue UX（仅未来 donor，当前不进默认 Gen2）
```

不能借：

```text
provider-first mental model
right-drag blank canvas pan
Selection 自动作为 context
Agent 产品语义整体照搬
```

---

## Spatial

最适合借：

```text
low chrome
direct manipulation
approach / receptive
hit / settle
ghost / proxy
home spring
creature attention
gaze
squash
blink
subtle tether / field
~200ms motion grammar
```

不能借：

```text
Spatial 自己的业务 object semantics
```

---

## Orbit

只 LIFT：

```text
satellite geometry / trig
```

明确 REJECT：

```text
large wedge radial menu
visible full orbit track
```

---

## Huabu

继续做唯一 Spatial Body：

```text
pointer lifecycle
drag activation threshold
selection
node geometry
viewport/camera
floating placement
popover
toolbar anchor
controlled input mechanics
IME
send/stop
```

禁止 T3 另造：

```text
pointer router
selection owner
floating positioning engine
```

---

# 8. Action Arc 当前结论

冻结：

```text
3 normal
4 max
```

原则：

```text
direct high-frequency actions
icon/glyph first
hover 才补 label
no permanent orbit track
```

组合 donor：

```text
Geometry
= Orbit satellite

Button anatomy
= Lovart compact icon actions

Motion
= Spatial snappy settle

Anchor / boundary
= Huabu

Action semantics
= LCOS T3
```

---

# 9. Multi-selection 当前结论

Phase B / V2 已关闭：

```text
multi-select
→ Selection only
→ lightweight local toolbar

NO auto Composer
```

只有用户明确：

```text
AI Work
```

才开 Composer。

重要：

```text
Selection A+B+C
= target A+B+C

Reference D+E
= supporting input

Selection
≠ Reference
```

---

# 10. Compact Composer 当前结论

Composer：

```text
target-local
compact
1–2 rows idle
3–4 rows max
then internal scroll

no huge side panel
no automatic focus
```

组成：

```text
target identity
prompt
References
Voice
Receiver
Skill / params when needed
Run
```

Structural AI change：

```text
Candidate
→ Validate
→ Preview / Receipt
→ Commit
```

失败：

```text
draft preserved
refs preserved
receiver preserved
```

---

# 11. Reference 当前结论

Entry：

```text
reference glyph
→ Canvas / Upload / Paste
```

Canvas Pick：

```text
Composer stays
eligible object hover gets tiny affordance
click candidate
→ ordered ref enters Composer
→ Selection target unchanged

Esc
→ exit Reference Pick only
```

Fail-close：

```text
no canonical identity
→ do not silently invent Reference
```

---

# 12. Receiver / Run 当前结论

用户心智：

```text
这次交给哪段 Conversation
```

不是：

```text
哪个 provider
```

Receiver UI：

```text
small Glyth / Conversation identity
```

per-run Receiver change：

```text
≠ Project Active Receiver
```

Set Current 必须是显式动作。

Queue：

```text
TapNow donor candidate
CURRENT GEN2 DEFAULT = DEFER
```

除非 T6/Run source plan 出现真实 queue contract，不加新产品能力。

---

# 13. Glyth 当前结论

Glyth：

> 一段持续 Conversation 的空间身份。

不是普通 card/node。

点击层级：

```text
第一次点
→ Select

already selected 再点
→ Action Arc + Compact Composer

双击
→ same Conversation deep work
```

Phase B D10：

```text
Conversation Child Canvas
= nested Worksite

Conversation Preview
= Professional Window

Assembly
= Project-shared Professional Window
target=current Conversation
```

三者共享 Conversation identity，但不得共享 state owner。

Artifact body → Glyth：

```text
Conversation Context Mapping
```

Relation：

```text
Relation handle
```

Receiver：

```text
explicit Conversation identity
```

---

# 14. Semantic Drop / Drag Grammar 当前最终版

## A. Blank Canvas

```text
left body drag
→ Move
→ source stay
```

---

## B. Visible Host

例如：

```text
expanded Collection
Gallery
Grid
Stack
Masonry
current Surface real spatial host
```

Phase B D04：

```text
left drop success
→ current projection stays at target
```

canonical mutation：

> target owner / Core contract 决定。

例如 Collection：

```text
Add Collection membership
+
projection stays
+
Huabu may host reflow
```

---

## C. Remote Target / Portal

例如：

```text
Glyth
Railway remote destination
Child Worksite portal
closed/unopened Worksite
```

左拖：

```text
canonical semantic / mapping / target projection 更新
source 当前 projection 保留在 source scene
```

右拖：

```text
source 从头到尾不移动
```

---

## D. Right-drag

当前最终产品语言：

> **source spatial placement 不动；target 按自己的唯一 natural semantic commit。**

不能再写：

```text
temporary borrow
```

示例：

```text
Right-drag → Collection
= durable Collection membership
= source current projection remains
```

---

## E. Relation

Relation handle：

```text
only Project Relation
no membership
no mapping
no spatial move
```

永远和 body-natural semantic 分开。

---

# 15. Work View / Local UI coexistence

Phase B D14 / D15 已关闭：

T4 对外提供一套：

```text
occupiedRects
safeRect / safeInsets
activeRegions
```

T3 消费：

```text
Arc
Composer
local popover
Reference pick indicators
```

禁止：

```text
DOM query N 个 panel
hardcoded right panel width
persisted safeRect
```

Camera：

```text
Professional Window open/resize
→ 不允许自动改 Camera
```

由 host policy override 解决，不改 Huabu global default。

Local UI priority：

```text
active editing / voice / ref pick
>
draft Composer
>
Arc
>
tooltip
```

同一 target 在 Work View 与 local shell：

```text
same Composer state
one dominant projection
```

不能两份 draft。

---

# 16. Remove / Archive / Delete 当前结论

## Remove

```text
projection / local presentation / mapping removal
→ immediate
→ Undo
```

具体 canonical side effect 由 target contract 决定。

---

## Archive

Phase B：

```text
canonical lifecycle
membership/relation/history preserved
read-only in archived state
Searchable / Referenceable / Agent-readable
Restore explicit
fresh layout
no old x/y recovery
```

T3：

```text
只负责入口和 local receipt
```

---

## Delete

真实 canonical entity / file / important durable structure：

```text
explicit confirmation
```

不能和 Remove 混文案。

---

# 17. T3 已产出的全部主要文件与当前状态

## 17.1 Evidence / Audit

### `LCOS_Gen2_T3_01_Evidence_Census_Authority_Recovery_20260904.md`

状态：

```text
KEEP + PATCH
```

用途：

- authority census
- evidence recovery
- historical source inventory

Phase B 后：

> 不再用其中旧 OPEN 覆盖新裁决。

---

### `LCOS_Gen2_T3_02_Current_Source_Consumer_Owner_Audit_20260904.md`

状态：

```text
KEEP
+ Phase B owner correction
```

用途：

- current source
- consumer
- owner
- seam audit

---

### `LCOS_Gen2_T3_03_Donor_Upstream_Adoption_Retirement_Matrix_20260904.md`

状态：

```text
KEEP
```

用途：

- Huabu
- Lovart
- TapNow
- Spatial
- Orbit
- CopilotKit
- adopt/wrap/lift/retire

需要：

```text
最终 source plan 重新绑定 exact UX / Phase B contract
```

---

## 17.2 旧 Source Plan

### `LCOS_Gen2_T3_04_Source_Level_Construction_Plan_20260904.md`

状态：

```text
SUPERSEDED AS FINAL
```

价值：

```text
old exact-file research / patch inventory 仍可利用
```

但：

> 必须在 Phase B 后重写正式 source-level plan。

---

### `LCOS_Gen2_T3_05_Acceptance_Recovery_CrossReview_Plan_20260904.md`

状态：

```text
PARTIAL KEEP
```

测试框架可复用。

旧产品行为断言需按 Phase B 更新。

---

### `LCOS_Gen2_T3_99_COORDINATOR_HANDOFF_20260904.md`

状态：

```text
SUPERSEDED
```

本文件将成为新的 handoff 母稿。

---

## 17.3 UX / Product Recovery

### `LCOS_Gen2_T3_UserIntentFirst_UX_Scene_Freeze_20260904.md`

状态：

```text
KEEP AS HISTORICAL UX RECOVERY
```

但跨线程 OPEN 以 Phase B 为准。

---

### `LCOS_Gen2_T3_深挖后UX裁决与跨线程重新排班建议_20260905.md`

状态：

```text
HISTORICAL / PARTIALLY SUPERSEDED
```

其中：

- donor principle 保留；
- 跨线程 owner 猜测部分以 Phase B 覆盖。

---

### `LCOS_Gen2_T3_V2冻结后_Donor深挖与最优呈现裁决_20260905.md`

状态：

```text
KEEP
```

尤其：

- Action Arc donor composition
- Multi-selection
- Composer / Reference
- Receiver
- Voice
- motion
- Glyth local response

Phase B 只覆盖其中未关闭的 target semantics。

---

### `LCOS_Gen2_T3_P0语义交互矩阵与剩余开放项收口_20260905.md`

状态：

```text
HISTORICAL + SUPERSEDED OPEN LIST
```

其通用 gesture reasoning 可留。

但：

```text
Right-drag
Visible Host
Remote Target
Collection
Scope
Worksite
```

全部以 Phase B D01–D04 / D07 / D10 覆盖。

---

### `LCOS_Gen1到Gen2_Colony_Collection_Scope_Workspace_子画布_Component_彻底翻旧账_20260905.md`

状态：

```text
KEEP AS HISTORICAL PROVENANCE
```

价值：

- Gen1 → v0.15 → Gen2 语义演化
- old Scope overloading
- R3-A Colony exact history
- Collection in-place expansion
- Workspace/Worksite migration warnings

其未决问题已由 Phase B 大量关闭。

---

## 17.4 Donor / anti-laziness

### `LCOS_Gen2_T3_V6_反惰性_Donor模块化复用深挖_V1_20260904.md`

状态：

```text
KEEP AS DONOR EVIDENCE
```

---

## 17.5 Demo

### `LCOS_Gen2_T3_UX_交互小样_20260904.html`

状态：

```text
OBSOLETE VISUAL PROTOTYPE
```

不要作为最终 UX evidence。

---

### `LCOS_Gen2_T3_UX_交互小样_v2_Lovart_TapNow_20260904.html`

状态：

```text
HISTORICAL PROTOTYPE
```

价值：

- Reference pick
- Receiver
- Voice
- multi-select
- semantic transfer 初步验证

Glyth body / target semantics 不是最终。

---

### `LCOS_Gen2_T3_当前完整UX交互演示_v3_20260905.html`

状态：

```text
UX EXPERIMENT
NOT PRODUCT AUTHORITY
```

明确需要修：

```text
Scope 大虚线框
Collection left-drop 回弹
部分 target taxonomy
```

后续 Demo 必须按 Phase B 重构。

---

# 18. 当前已知 T3 Current Source Facts
## 后续 source plan 必须重新 exact verify，不可只靠这份摘要

以下是 T3 此前已经核过的关键 source。

---

## `LcosComposerShell.tsx`

当前：

```text
fixed bottom-center ~360
local prompt
refs
no real submit
transitional
```

裁决：

```text
semantic refs KEEP
current shell RETIRE / REPLACE
```

需要 source plan 重新确认 current HEAD 是否已变化。

---

## `CanvasFloatingPopover.tsx`

已有：

```text
flow rect → screen/page rect
portal
floating-ui
offset / flip / shift
ResizeObserver
attention arbitration
```

裁决：

```text
REUSE
```

T3 不造第二 positioning engine。

---

## `NodeFloatingToolbar.tsx`

已有：

```text
live node geometry
authoritative rect
multi-selection/takeover geometry
```

裁决：

```text
REUSE as anchor mechanics donor
```

---

## `ChatInput.tsx`

已有：

```text
controlled value
onChange
IME-safe Enter
autoresize
attachments
paste/drop
send/stop
history
model/agent/permission slots
```

裁决：

```text
REUSE mechanics
NOT whole-domain ownership
```

---

## `LcosHostOverlay.tsx`

此前：

```text
actionArcOpen:false
Arc not landed
binding-derived refs
drop + composer shell
```

后续：

```text
host composition only
```

不能变 mega-owner。

---

## `useLcosCanvasProps.tsx`

已有：

```text
host recognizers
Reference suppressor
binding map
semantic connect
project node maps
```

Relation fail-close。

后续 source plan 需判断：

```text
body semantic receive
right-drag carry
relation handle
```

如何最薄接入，不新建 router。

---

## `lcosReferenceState.ts`

此前同时承担：

```text
Composer draft
node/entity cache
```

source plan 应评估：

```text
identity cache lifecycle
vs
ComposerDraft
```

是否需要薄拆。

不能新造 canonical truth store。

---

## `lcosRecognizers.ts`

此前：

```text
Reference mouse / Ctrl/Cmd
Shift selection
fail-close unbound
~4px drag slop
Drop observer canClaim:false
```

原则：

```text
one Huabu pointer router
```

Right-drag / body receiver 应进入现有 recognizer lifecycle。

---

## `referenceController.ts`

重要保护：

```text
ordered References
Composer opens empty
Selection 不自动 copy into Reference
```

必须 KEEP。

---

## `voice-transcription.ts`

已有 Core：

```text
POST /runtime/voice/transcriptions
multipart audio
```

不造独立 Voice backend。

---

## `backend/client.ts`

此前发现：

```text
JSON.stringify body
```

可能缺：

```text
FormData / raw body thin transport seam
```

必须 source recheck 后再决定 exact patch。

---

## `Canvas.tsx`

此前：

```text
one pointer router
Shift multi-select
Ctrl/Cmd Reference
stock dblclick preview
root contextmenu suppression
```

需要：

```text
neutral host contextmenu seam?
node click/dblclick seam?
semantic carry recognizer seam?
```

source plan 不能先下结论，先 exact inspect current HEAD。

---

## `semanticDropMachine.ts`

已有：

```text
idle
tracking
dwell
preview
committing
failed
```

mechanics good candidate。

但旧 target taxonomy / preview owner 必须按 Phase B 修。

---

## `lcosDropState.ts`
## `LcosDropPreview.tsx`

此前 hardcode：

```text
surface:left-dock
surface:bottom-dock
```

以及旧：

```text
左侧导航坞
底部停靠区
```

状态：

```text
RETIRE / REPLACE / MIGRATE
```

exact final migration 待 source plan。

---

## `NodeWrapper.tsx`
## `nodePresentation.tsx`

现有状态优先级：

```text
editing
> resizing
> dragging
> selected
> hovered
> rest
```

后续 local action / receive / carry state 必须尊重现有 presentation arbitration。

---

# 19. Core / Existing Backend Facts T3 需要消费

## Runs

已有：

```text
POST /projects/:id/runs
```

支持已知字段：

```text
instruction
outputIntent
target
contextArtifactIds
requestedProvider
sessionId
resultPolicy
receiverRef
orderedReferences
resultSlotId
```

T3 不建 duplicate execution API。

---

## Receiver

已有：

```text
connected conversations
receiver binding
handoff
```

T3 只做 UI presentation + thin typed client seam。

---

## Voice

已有 transcription runtime。

---

# 20. Phase B 后的 T3 工程 seam 到底是什么

“工程 seam”不是新模块。

它的意思：

> **T3 先告诉 T5 和其它线程：T3 的交互在真实源码里从哪里长出来、复用什么、哪些状态会被暴露、哪些旧 body 会退休、视觉能改到哪。**

T3 第一阶段不是最终施工正本。

而是：

# `T3 Source Engineering Seam Skeleton`

它应包含：

```text
UX capability
→ exact current source file
→ current owner
→ exact consumer
→ existing Huabu / donor primitive
→ proposed thin seam
→ state surface exposed to T5
→ migration
→ retirement
→ risk / blast radius
```

例如：

```text
Action Arc
→ anchor 从哪里来
→ current selected geometry consumer 谁
→ Arc actions 怎样 resolve
→ T5 可改 body / icon / motion 哪些
→ T3 不让 T5 改 semantic owner

Semantic Carry
→ right pointer event 当前走哪里
→ drag threshold owner 谁
→ proxy state 从哪里露给 T5
→ target natural semantic 如何调用 canonical command
```

---

# 21. 为什么先做 seam skeleton，再给 T5

用户当前要求的小步快跑顺序：

```text
Phase B 裁决
↓
T1 / T2 / T3 / T4 / T6
各自产出 Source Engineering Seam Skeleton
↓
把和视觉有关的工程 seam / state / constraints 给 T5
↓
T5 做 Final Visual Plan
↓
视觉结果回填各路
↓
每一路形成 FINAL SOURCE CONSTRUCTION PLAN
↓
production coding
```

这不是：

```text
五路写完全部 final plan
→ T5 最后才开始
```

T5 现在可以并行：

```text
visual research
donor compare
motion
icons
glyph
LOD
density
candidate body
```

但在 seam skeleton 回来前：

```text
不要锁 final body
```

---

# 22. T3 应该交给 T5 的 Engineering Seam 信息

T3 后续必须给 T5 的不是一堆工程黑话，而是：

```text
Action Arc
- anchor state
- visible action count
- rest / hover / pressed / dismiss states
- safeRect collision

Composer
- target-local bounds
- max height
- reference chip states
- voice states
- receiver states
- running / failed / recovered states

Reference
- eligible / hover / picked / invalid
- canvas-pick mode

Semantic Give
- approach
- receptive
- hit
- commit
- source stay / source home
- receipt

Right-drag
- source fixed
- proxy appear
- proxy carry
- target accept / reject
- proxy settle / dissolve

Relation
- relation intent
- handle
- live line
- receptor
- commit

Glyth
- selected
- attention
- receive
- context receipt
- relation receive
- active receiver

Work View collision
- occupiedRects
- safeRect
- local UI priority
```

T5 再决定：

```text
shape
material
motion curve
icon/glyph
spacing
density
LOD
micro-animation
```

---

# 23. 后续源码施工必须采用“小步快跑”

为了防止当前会话在长时间 source reasoning 中再次吃光上下文：

> **不要一口气写完整 04/05/99。**

建议顺序如下。

---

## C1-S0 · Authority / Contract Lock

只做：

```text
Phase B → T3 interaction contract 回填
所有 CLOSED 问题写死
旧 T3 冲突措辞列退休清单
```

产物：

```text
T3_C1_S0_Authority_Contract_Lock.md
```

---

## C1-S1 · Current Source Exact Map

只做：

```text
Action Arc
Composer
Reference
Voice
Receiver
context menu
pointer recognizers
semantic drop
relation
Glyth local hooks
```

每一个：

```text
exact file
symbol
owner
consumer
current behavior
```

不写 patch。

---

## C1-S2 · Engineering Seam Skeleton

只做：

```text
existing primitive
thin seam
new/changed types
state exposed
consumer
migration
retirement
```

这是第一份交 T5 的工程骨架。

---

## C1-S3 · Exact Construction Cards

按功能分小卡：

```text
C03-ARC
C03-COMPOSER
C03-REFERENCE
C03-VOICE
C03-RECEIVER-RUN
C03-CONTEXTMENU
C03-SEMANTIC-GIVE
C03-RIGHT-CARRY
C03-RELATION
C03-GLYTH
C03-WORKVIEW-COLLISION
```

每张都写：

```text
exact files
edit order
new seam
reuse
retire
migration
tests
browser acceptance
rollback
blast radius
```

---

## C1-S4 · Test / Recovery Plan

分：

```text
pure logic
component
integration
browser interaction
migration
restart / recovery
rollback
```

---

## C1-S5 · T5 Visual Input Pack

从 source plan 摘：

```text
真实状态
允许视觉变化
不可变化的 semantic
existing primitive constraints
screen-space constraints
LOD / animation hook
```

给 T5。

---

## C2 · T5 Final Visual

T5 返回：

```text
body
motion
LOD
icon
density
spacing
material
```

---

## C3 · Final Source Plan

把 T5 visual patch 回填：

```text
JSX
CSS
token
motion
exact component
```

生成新的正式：

```text
04 FINAL SOURCE CONSTRUCTION PLAN
05 FINAL ACCEPTANCE / RECOVERY
99 FINAL COORDINATOR HANDOFF
```

---

# 24. 每一张源码施工卡必须包含的字段

从 Phase B 起，正式施工卡至少：

```text
Card ID

UX / Phase-B decision refs

Goal

Current exact file(s)

Current symbol(s)

Current owner

Current consumer(s)

Existing primitive / donor

Adopt / Wrap / Lift / Retire

New thin seam

Data / state flow

Canonical mutation owner

Presentation owner

Migration path

Legacy retirement

Failure behavior

Undo / recovery

Tests

Real browser acceptance

Rollback

Blast radius

Cross-thread dependency

T5 visual seam
```

缺一个关键 owner：

> 不允许靠猜补。

---

# 25. T3 source plan 的核心反惰性纪律

## 不造第二套 Pointer

必须进入 Huabu existing pointer / recognizer lifecycle。

---

## 不造第二 Selection owner

Selection 继续 Huabu / existing canvas owner。

---

## 不造第二 floating engine

Arc / Composer / menu：

```text
复用 CanvasFloatingPopover / NodeFloatingToolbar family
```

---

## 不造第二 Run API

调用现有 Core run / receiver。

---

## 不造第二 Voice backend

复用现有 transcription。

---

## 不造第二 canonical reference store

Reference UI state：

```text
ordered refs
```

canonical identity 由现有 binding / Core resolver 提供。

---

## 不造 Mega Interaction Registry

Target natural semantic：

```text
由目标 owner 暴露 typed capability / command
```

T3 只做薄 resolver / adapter。

不能：

```text
T3 中维护一张产品宇宙 if/else
```

---

# 26. Visible Host / Remote Target 施工时特别注意

这是当前最容易再次做错的部分。

## Visible Host

例如 Collection：

```text
左拖
→ canonical membership command
→ projection stays
→ Huabu host reflow
```

T3 不自己移动 geometry owner。

---

## Remote Target

例如 Glyth：

```text
左拖
→ context mapping command
→ source current projection stays
```

T3 visual：

```text
transfer / receipt
```

但不 duplicate canonical object。

---

## Right-drag

```text
source geometry untouched
→ proxy presentation only
→ same target command as target natural semantic
```

但 command lifecycle 由 target semantic 决定。

---

# 27. Relation 必须保持独立

无论：

```text
Collection
Glyth
Workflow
Worksite
```

只要用户走 Relation handle：

```text
= Project Relation
```

不得顺手：

```text
add membership
add Context Mapping
add Workflow composition
move projection
```

---

# 28. Selection / Reference / Relation / Mapping 四分纪律

永远不能混：

```text
Selection
= 当前操作谁

Reference
= 本轮 Run 参考谁

Relation
= Project durable semantic relation

Conversation Context Mapping
= Conversation 长期知道谁
```

用户不需要背术语。

代码必须背。

---

# 29. T3 对其它线程只消费，不重新裁决

## T1 提供

```text
Huabu geometry
selection
drag
visible host placement
Collection reflow
Colony mechanics
```

---

## T2 提供

```text
Railway destination
Worksite navigation
Enter / Back / Arrival
```

---

## T4 提供

```text
ProfessionalWindowEnvironment
target-natural semantics for Context / Workflow / Assembly / Skill views
```

---

## T6 提供

```text
canonical identity
Collection membership transaction
Context Mapping
Relation validation
Archive lifecycle
ProjectionBinding / worksite identity
Run / receiver
```

---

## T5 提供（C2 回填）

```text
final body
motion
LOD
icon
density
spacing
material
```

T3 不重新决定上述线程产品 truth。

---

# 30. 如果新会话接管，第一件事绝不能做什么

禁止新会话：

```text
重新解释 Collection
重新讨论 Scope 要不要保存
重新问 Work View 是不是子画布
重新讨论 Right-drag temporary 还是 durable
重新决定 Railway / SurfaceDock
重新决定 Colony contour 存不存 Core
```

这些已经 CLOSED。

新会话真正第一步：

```text
read Phase B
read this handoff
re-open current source
verify HEAD
start C1-S0 / C1-S1
```

---

# 31. 如果 source 发现真实冲突，如何上报 Coordinator

只有满足：

```text
A. current source 的真实 owner / API / data model 与 Phase B 冲突
B. 不能通过 adapter / migration / thin seam 无损解决
C. 强行实现会造成 duplicate truth / broken recovery / destructive migration
```

才允许：

```text
ARCHITECTURE CONFLICT
```

报告必须包含：

```text
exact file
exact symbol
current behavior
Phase B decision
why thin adapter fails
minimum alternatives
blast radius
recommended coordinator decision
```

不能说：

```text
“我觉得产品换个方案更好”
```

---

# 32. 当前本地可直接交接的 T3 文件清单

```text
LCOS_Gen2_T3_01_Evidence_Census_Authority_Recovery_20260904.md
LCOS_Gen2_T3_02_Current_Source_Consumer_Owner_Audit_20260904.md
LCOS_Gen2_T3_03_Donor_Upstream_Adoption_Retirement_Matrix_20260904.md
LCOS_Gen2_T3_04_Source_Level_Construction_Plan_20260904.md
LCOS_Gen2_T3_05_Acceptance_Recovery_CrossReview_Plan_20260904.md
LCOS_Gen2_T3_99_COORDINATOR_HANDOFF_20260904.md

LCOS_Gen2_T3_UserIntentFirst_UX_Scene_Freeze_20260904.md
LCOS_Gen2_T3_V6_反惰性_Donor模块化复用深挖_V1_20260904.md

LCOS_Gen2_T3_深挖后UX裁决与跨线程重新排班建议_20260905.md
LCOS_Gen2_T3_V2冻结后_Donor深挖与最优呈现裁决_20260905.md
LCOS_Gen2_T3_P0语义交互矩阵与剩余开放项收口_20260905.md
LCOS_Gen1到Gen2_Colony_Collection_Scope_Workspace_子画布_Component_彻底翻旧账_20260905.md

LCOS_Gen2_T3_UX_交互小样_20260904.html
LCOS_Gen2_T3_UX_交互小样_v2_Lovart_TapNow_20260904.html
LCOS_Gen2_T3_当前完整UX交互演示_v3_20260905.html
```

上位输入：

```text
LCOS_Gen2_PhaseB_四路合并_最终跨线程裁决稿_20260906(3).md
LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905(3).md
LCOS_Gen2_UX场景先行_UserIntentFirst_源码施工前置协议_20260904(1).md
LCOS_Gen2_Donor双轨裁决_工程实现复用与UIUX高保真设计借鉴_20260904(3).md
```

---

# 33. 现阶段推荐的正式下一步

不再继续产品讨论。

下一步直接：

# `C1-S0 · T3 Phase-B Interaction Contract Lock`

随后：

# `C1-S1 · T3 Current Source Exact Map`

随后：

# `C1-S2 · T3 Source Engineering Seam Skeleton`

做到 C1-S2 后：

> 把 T3 的真实工程状态/约束/视觉 hook 发给 T5。

再继续 exact construction cards。

---

# 34. 一句话给新会话

> **你不是来重新设计 T3 产品语义的。产品已经被 Phase B 关完。你现在的任务是把 T3 已冻结的交互语言精确映射到 current LCOS_Gen2 / Huabu source：找 exact file、exact owner、exact consumer，最大化复用成熟 primitive，新增最薄 seam，退休旧 body，写 migration/test/browser/recovery/blast-radius，然后把可视工程状态交给 T5，最后再吸收 T5 的高保真视觉回填。**

---

# 35. 一句话给 T5

> **T3 会先给你真实的 anchor、state、gesture、safeRect、source-stay/source-home、proxy、receiver、relation、voice、run、reference 工程 seam；你不用重新定义这些是什么意思。你只需要从 Lovart / TapNow / Spatial 等成熟 donor 中挑最好的 body / motion / density / glyph / LOD，然后把视觉结果回填给 T3。**

---

# 36. 当前线程状态

```text
Historical archaeology
DONE

Current source audit
DONE FOR PRE-PHASE-B
→ C1-S1 must reverify current HEAD

Donor deep dive
DONE ENOUGH FOR C1

UX semantic recovery
DONE

Cross-thread product OPEN
CLOSED BY PHASE B

Next
SOURCE-LEVEL CONSTRUCTION PLANNING
```

从这里开始：

> **小步快跑，不一口气把所有施工稿写完。**

