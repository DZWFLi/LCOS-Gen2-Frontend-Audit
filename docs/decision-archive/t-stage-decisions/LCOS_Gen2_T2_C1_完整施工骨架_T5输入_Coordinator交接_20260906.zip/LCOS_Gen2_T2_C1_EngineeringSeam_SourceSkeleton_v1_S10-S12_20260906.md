# LCOS Gen2 · T2 Phase C1 Engineering Seam / Source Skeleton v1
## Checkpoint 04 · S10–S12
### Railway Receive Map / Receiver in Railway / Navigation More & Low-Frequency Management

日期：2026-09-06  
状态：`PHASE C1 · SOURCE-LEVEL SKELETON · CHECKPOINT 04`  
LCOS 基线：`DZWFLi/LCOS_Gen2 @ c2ff890a867922a1256572199458438572eb0a8c`  
Huabu vendored pin：`microsoft/Huabu @ 58339e269b784728d67730c70bfe7792cae2457d`  
Huabu upstream audit head：`a3c411e1f655191344285141f08c4738fa6015f7`  
upstream vs pin：`ahead 24 / behind 0`

> 承接 Checkpoint 01–03。
>
> 本稿完成 T2 C1 的最后三张 engineering seam：
>
> - `T2-S10 Railway Receive Map / Remote Destination`
> - `T2-S11 Receiver in Railway`
> - `T2-S12 Navigation More / low-frequency management`
>
> 产品语义仍以 Phase B 为最高 authority。
> 本稿不重新裁决 T3/T6/T4 owner，只钉 T2 的 destination presentation、Receiver presentation 和低频导航管理 UI。

---

# 0. 这一组的核心边界

这三个 seam 最容易出现“左边 Railway 最后长成第二套万能侧栏”的灾难。

所以先写死：

```text
Railway REST
= structural navigation skeleton

Railway RECEIVE
= 当前拖拽动作下的 destination map

Receiver
= current canonical conversation receiver identity/presence

More
= 低频管理
```

Railway 永远不是：

- node tree；
- LayerPanel；
- Search engine；
- provider dashboard；
- run monitor；
- settings sidebar；
- canonical store；
- generic move chooser。

---

# 1. T2-S10 · Railway Receive Map / Remote Destination

# 1.1 USER BEHAVIOR

普通状态：

```text
Railway 很轻
```

当用户拖起 LCOS Selection，且当前 payload 可以跨 Surface/Worksite 处理：

```text
Railway REST
→ RECEIVE
```

表现：

- 不可接受目标降权；
- 可接受 Surface / Worksite destination变清楚；
- 唯一明确 destination可直接 drop；
- Surface下有多个长期 Worksite时，可在 hover/dwell 后展开 Peek，继续拖到具体 destination；
- 不弹“请选择目标位置”的 modal；
- drop结束/cancel后Railway回 REST。

---

# 1.2 OWNER boundary

## T3 owns

- pointer/drag gesture；
- left/right drag grammar；
- Semantic Drop machine；
- payload acquisition；
- drop commit lifecycle。

## T2 owns

- Railway destination list/presentation；
- eligible/hot/ineligible UI state；
- Rail Peek中的 concrete destinations；
- destination hit area；
- Receive mode visual transition。

## T6 owns

- target-natural semantic transaction；
- membership/relation/mapping/Worksite canonical write；
- Undo/Redo canonical consequences。

## T1/Huabu owns

- world projection move/create/remove geometry；
- actual spatial transfer mechanics when transaction requires a physical cross-canvas move。

T2不能因为 Railway是drop target就成为 drop semantic owner。

---

# 1.3 CURRENT T3 semantic-drop seam

## Pure state machine

`apps/web-gen2/src/interaction/semanticDropMachine.ts`

已有 pure fabric。

## Huabu presentation state

`huabu/apps/web/src/lcos/lcosDropState.ts`

current：

```text
state: SemanticDropState
bounds: DropBounds
begin(payload)
advance(...)
commitAt(...)
fail(...)
cancel()
```

源码明确：

> Nothing here mutates Core/canvas truth; presentation state for in-flight spatial placement only.

这是正确 owner。

---

# 1.4 Current generic destination limitation

`lcosDropState.ts` 当前硬编码：

```ts
DOCK_LEFT = 'surface:left-dock'
DOCK_BOTTOM = 'surface:bottom-dock'
```

并：

```text
left edge band
→ generic left dock slot

bottom edge band
→ generic bottom dock slot
```

也就是说 Phase A 只有：

```text
“用户靠近左边了”
```

还不知道：

```text
“用户现在正在 Workflow root / Worksite X / Receiver Y 上”
```

这就是 S10 要补的真实 source gap。

---

# 1.5 Current recognizer

`huabu/apps/web/src/lcos/lcosRecognizers.ts`

`createDropRecognizer()`：

- pure observer；
- never claims pointer；
- only advances if payload already acquired；
- mouse only；
- reads wrapper screen rect；
- on release cancels uncommitted tracking/dwell/preview；
- recognizer itself does not invent payload。

KEEP。

T2不新增第二 pointer recognizer。

---

# 1.6 Destination contract should extend existing DropDestination

不要创建：

```text
RailwayDropMachine
```

推荐在：

`apps/web-gen2/src/interaction/semanticDropMachine.ts`

扩 existing destination descriptor，使其可以表达：

```ts
DropDestination =
  | existing...
  | {
      kind: 'navigation-target'
      targetId: string
      targetKind: 'surface' | 'worksite' | 'receiver'
      surface?: SurfaceKey
    }
```

最终 target semantic payload的 exact字段由 T3/T6 cross-review。

关键：

> Railway item只声明“我是哪个 destination”，不声明“drop一定会做什么业务写入”。

---

# 1.7 T2 destination presenter

### PLANNED NEW

`apps/web-gen2/src/presentation/railwayReceive.ts`

纯函数输入：

```text
RailwayItemVM[]
DropPayload capabilities
current Surface/Worksite
T3 eligibility result
```

输出：

```ts
RailwayReceiveItemVM {
  key
  destination
  eligibility: 'eligible'|'ineligible'|'hot'
  reason?
  direct
  requiresPeek
}
```

不能自己从 payload type猜最终 semantic mutation。

---

# 1.8 Railway actual hit targets

`huabu/apps/web/src/lcos/ui/Railway.tsx`

在 RECEIVE 状态：

每个可接受 item render一个真实 hit target。

建议用 neutral DOM contract：

```html
data-lcos-drop-target
data-lcos-drop-target-id="..."
```

但 DOM attribute 只是 hit-testing identity，
不是 canonical data storage。

更稳健实现可由 T3建立 WeakMap/registry：

```text
HTMLElement → DropDestination
```

T2 Railway mount/unmount时 register/unregister。

---

# 1.9 Why DOM hit-testing is allowed here

Phase B 禁的是：

```text
DOM query → 推测 Work View safeRect
```

因为那会把 layout implementation冒充 contract。

这里：

```text
pointer point → actual rendered drop target element
```

本来就是 UI hit testing。

只要 target identity来自 typed Railway VM，
不是从 className/title猜，
就是合法。

---

# 1.10 RECEIVE state handoff

T2需要从 T3 drop presentation store消费：

```text
state.status
payload
active destination/hot target
```

不要复制为：

```text
RailwayDragStore
```

Railway body derive：

```text
drop idle
→ REST

drop tracking/dwell/preview + Rail-relevant payload
→ RECEIVE
```

---

# 1.11 Peek during drag

如果 Surface root 有：

```text
multiple eligible long-term Worksites
```

pointer hover/dwell：

```text
~250–400ms candidate
```

可以从 compact root morph/open Railway Peek，
显示 concrete Worksite targets。

这只是 presentation dwell，
最终 exact duration T5回填。

禁止：

```text
drop
→ open modal
→ choose worksite
```

---

# 1.12 Source stays / moves rule

T2不决定。

Railway只是 destination surface。

Commit结果由 T3/T6 semantic transaction返回，例如：

```text
sourceProjection: 'stay' | 'move' | 'remove'
targetProjection: 'none' | 'create' | 'reuse'
canonicalMutation: ...
```

T2据结果播放：

- source stays；
- target acceptance；
- remote Arrival/receiver feedback。

禁止 Railway body直接：

```text
deleteNode()
moveNode()
addMembership()
```

---

# 1.13 Huabu upstream cross-Space move donor

当前 vendored pin `58339e2` 没有 move-selection。

最新审计 upstream `a3c411e...`：

```text
ahead 24
behind 0
```

新增真实 source：

```text
packages/shared/src/types/api/space-move.ts
apps/server/src/modules/canvas/space-move-plan.ts
apps/server/src/modules/canvas/space-move.service.ts
apps/server/src/modules/canvas/canvas.route.ts
apps/server/src/modules/canvas/write-coordinator.ts
apps/web/src/api/canvas.ts
apps/web/src/components/Panels/Canvas/MoveSelectionModal.tsx
```

---

# 1.14 What Huabu move mechanic actually provides

`MoveSelectionBody`：

```ts
selectedNodeIds
destination:
  existing(canvasId)
  | new(title)
createSourcePreview
expectedSourceVersion
```

response：

```text
transferId
destination canvas/version
source preview id
source version
moved roots
moved node/frame counts
preserved edges
omitted boundary edges
renamed nodes
moved conversations
```

Error taxonomy包括：

```text
MOVE_SOURCE_STALE
MOVE_SOURCE_NODE_MISSING
MOVE_NODE_NOT_MOVABLE
MOVE_DESTINATION_MISSING
MOVE_DESTINATION_SAME_AS_SOURCE
MOVE_DESTINATION_CREATE_FAILED
MOVE_WORLD_NOT_ALLOWED
MOVE_AGENT_RUNNING
MOVE_AGENT_TASK_OWNED
MOVE_AGENT_PENDING_CHANGES
MOVE_ARTIFACT_MISSING
MOVE_DESTINATION_CONFLICT
MOVE_COMPENSATION_FAILED
MOVE_OUTCOME_UNKNOWN
...
```

这是一套成熟工程 primitive。

---

# 1.15 Upstream server engineering strengths

`space-move.service.ts` 当前：

- source/destination validation；
- source version CAS；
- `withCanvasMutexes([source,destination])`；
- `buildSpaceMovePlan()`；
- artifact clone/rewrite；
- active Agent/thread safety；
- task ownership safety；
- pending changes safety；
- Agent workload rehome；
- destination write；
- source write；
- delayed publish；
- compensation/error handling；
- optional source preview。

### ENGINEERING_STATUS

`HIGH_VALUE_UPSTREAM_ADOPTION_CANDIDATE`

---

# 1.16 What NOT to adopt from Huabu

## REJECT primary UI

`MoveSelectionModal.tsx`

因为它要求：

```text
open modal
→ choose existing/new Space
```

LCOS Railway destination已经由空间位置表达，
不需要再问一次。

## REJECT universal semantic

Huabu move = physical cross-Space move。

LCOS Railway drop可能是：

- Collection membership；
- Context/Workflow semantic use；
- remote target projection；
- receiver target；
- actual move；
- reference/proxy；
- Worksite transfer。

所以不能：

```text
every Railway drop
→ moveSelection API
```

---

# 1.17 Upstream adoption plan

由 Huabu sync/construction owner先 selective sync：

```text
space-move contract
space-move-plan
space-move service
canvas route/API
write coordinator changes
tests
```

但：

```text
MoveSelectionModal
```

不接入 LCOS primary path。

由于 upstream ahead 24，
不能直接整仓 fast-forward后假设无冲突。

需 source-level selective sync + upstream regression。

---

# 1.18 Current LCOS T3 commit gap

`lcosDropState.ts` 注释：

> concrete surface placement commit lands with Phase C.

所以 S10 最终 commit需要：

```text
T3 semantic drop commit
→ T6 semantic transaction
→ if physical canvas transfer required:
   Huabu move-selection mechanic
→ projection/reconcile
```

T2只消费 transaction status：

```text
pending
success
recoverable failure
permanent failure
```

---

# 1.19 Railway Receive body planned files

## MODIFY

```text
huabu/apps/web/src/lcos/ui/Railway.tsx       # from S02 planned
huabu/apps/web/src/lcos/lcosDropState.ts     # T3-owned cross-review
huabu/apps/web/src/lcos/lcosRecognizers.ts   # T3-owned, only target resolution integration
apps/web-gen2/src/interaction/semanticDropMachine.ts  # T3 owner
```

## PLANNED NEW T2

```text
apps/web-gen2/src/presentation/railwayReceive.ts
```

If target registry needed：

```text
huabu/apps/web/src/lcos/dropTargetRegistry.ts
```

owner应归 T3 host gesture infrastructure，
Railway只 register。

---

# 1.20 S10 tests

## Presenter

- no drop → REST；
- eligible root；
- ineligible root；
- direct target；
- root with multiple Worksites → requiresPeek；
- Receiver eligible/ineligible；
- current destination same source；
- legacy rail item never default semantic target。

## T3 integration

- drag acquisition；
- pointer Rail hit；
- hot target changes；
- leave target；
- cancel；
- drop once；
- no duplicate commit；
- pointer capture outside canvas；
- Rail Peek target selection while drag continues。

## Huabu selective sync

必须跑 upstream：

```text
space-move-plan.test.ts
space-move.service.test.ts
canvas route move tests
```

再加 LCOS：

```text
no MoveSelectionModal primary path
```

---

# 1.21 S10 browser acceptance

- drag Selection → Railway；
- Rail enters Receive；
- eligible targets visibly differentiated；
- hover Surface root with one destination；
- hover Surface root with several Worksites；
- direct drop；
- no chooser modal；
- cancel；
- error；
- source-stay semantic；
- actual physical transfer semantic；
- remote destination；
- right-click drag/T3 semantic alternate path；
- Work View open；
- narrow viewport。

---

# 1.22 S10 recovery

Semantic Core transaction fail：

```text
Rail returns REST
source untouched
error anchored to gesture/drop result
```

Huabu physical transfer fail：

根据 upstream response：

```text
MOVE_SOURCE_STALE → refresh/retry
MOVE_AGENT_RUNNING → refuse honestly
MOVE_DESTINATION_CONFLICT → target refresh
MOVE_COMPENSATION_FAILED / OUTCOME_UNKNOWN → force reconciliation before any retry
```

Railway不得自己“补偿”。

---

# 1.23 S10 blast radius

T2 presenter：

`BR-1`

T3 drop integration：

`BR-2`

Huabu upstream move adoption：

`BR-4`

但 selective sync、只在 actual move transaction使用。

---

# 1.24 S10 Coordinator status

当前无不可薄适配技术冲突。

Upstream Huabu sync是工程依赖，
不是产品 OPEN。

---

# 2. T2-S11 · Receiver in Railway

# 2.1 USER BEHAVIOR

Railway底部保留：

> 当前 Receiver / 当前承接会话的轻量身份。

它回答：

```text
现在是谁在承接这个 Project
```

不是：

- Provider control center；
- model selector；
- token meter；
- Run dashboard；
- lease/watchdog panel。

普通 Rail只显示：

```text
Glyth / conversation identity
presence/status
active state
```

详细管理进 More / Conversation/Receiver 专业 UI。

---

# 2.2 CURRENT canonical contract

`packages/contracts/src/receiver.ts`

## ConnectedConversationV1

真实字段：

```text
id
projectId
provider
executorId
conversationRef
conversationSessionId?
label
isRunning
waitingReason
lastActiveAt
workspaceRef
branchRef
...
```

注意：

源码明确：

> 存原料，不存 status 结论。

## ProjectReceiverBindingV1

```text
projectId
connectedConversationIds
activeReceiverId
revision
```

---

# 2.3 Status projection

existing pure:

```ts
projectConnectedConversationStatusV1()
```

当前：

```text
waitingReason != null → waiting
isRunning → working
else ready
```

`offline` 需要 runtime heartbeat layer，
不能凭 lastActiveAt 自己猜。

T2 Rail没有 heartbeat evidence时：

```text
不显示“offline”伪结论。
```

---

# 2.4 Canonical identity bridge

`packages/contracts/src/conversation-identity.ts`

明确：

```text
ConnectedConversation
↔ explicit conversationSessionId
↔ ConversationSession
↔ conversationArtifactId
↔ conversationViewId
↔ Glyth
```

源码冻结：

> 不靠 provider/title/最近时间/前端映射表猜。

因此 Railway Receiver body：

```text
有 explicit conversationSessionId / identity chain
→ 可显示真正 Glyth identity

没有
→ 诚实显示 connected conversation identity
→ 不猜对应哪个 Glyth
```

---

# 2.5 CURRENT Core runtime owner

`apps/local-core/src/receiver-runtime-service.ts`

负责：

```text
listProjectConversations
connectConversation
createConversation
setActiveReceiver
disconnectConversation
getProjectReceiverBinding
prepareHandoff
getPendingHandoff
consumePendingHandoff
```

Events：

```text
channel='continuity'
type='continuity.changed'
```

payload kind：

```text
receiver.connected
receiver.created
receiver.activated
receiver.disconnected
receiver.handoff_prepared
receiver.handoff_consumed
```

这已经是完备 canonical owner。

---

# 2.6 CURRENT route

`apps/local-core/src/routes/receiver.ts`

Endpoints：

```text
GET  /projects/:id/connected-conversations
POST /projects/:id/connected-conversations
DELETE /projects/:id/connected-conversations/:id

GET  /projects/:id/receiver-binding
POST /projects/:id/receiver-binding

POST /projects/:id/receiver-handoff
GET  /projects/:id/receiver-handoff/:conversationId
POST /projects/:id/receiver-handoff/:conversationId/consume
```

T2不造 ReceiverStore。

---

# 2.7 CURRENT frontend consumer state

current `apps/web-gen2/src/backend/` 审计未发现 typed Receiver client。

Railway Receiver body也尚未存在。

Current：

```text
CORE_OWNER_EXISTS
CORE_EVENTS_EXIST
FRONTEND_TYPED_CLIENT_GAP
T2_BODY_GAP
```

---

# 2.8 PLANNED typed client

`apps/web-gen2/src/backend/receiver.ts`

class：

```ts
CoreReceiverClient
```

T2真正需要的方法：

```text
listConnectedConversations(projectId)
getBinding(projectId)
setActiveReceiver(projectId,connectedConversationId)
disconnect(projectId,connectedConversationId)
```

Handoff methods属于 continuity/Receiver workflow，
若 T4/T6已有 client则不在 T2 duplicate。

Railway只要读 current identity与必要管理 action。

---

# 2.9 PLANNED presenter

`apps/web-gen2/src/presentation/receiver.ts`

input：

```text
ConnectedConversationV1[]
ProjectReceiverBindingV1
optional identity chain / session link
```

output：

```ts
RailwayReceiverVM {
  connectedConversationId
  label
  active
  status: 'ready'|'working'|'waiting'|'unknown'
  conversationSessionId?
  conversationViewId?
  glythResolvable
}
```

禁止输出：

```text
model name
token usage
lease state
failureCount
provider dashboard
```

provider最多作为管理/tooltip辅助，
不做 resting body主身份。

---

# 2.10 PLANNED hook

`huabu/apps/web/src/lcos/useLcosReceiver.ts`

职责：

```text
GET conversations
GET binding
derive presenter
subscribe Project Events continuity invalidation
```

复用 Checkpoint02：

`CoreProjectEventsClient`

当：

```text
channel=continuity
type=continuity.changed
```

→ debounce/refetch receiver reads。

Own active switch response可即时更新 UI，
event用于 multi-client/out-of-band sync。

---

# 2.11 Railway mount

Checkpoint01 `Railway.tsx`：

```text
Receiver item fixed near bottom
```

Worksite list滚动/overflow不能把 Receiver推没。

典型结构：

```text
Surface roots
Worksites
flex spacer
Receiver
```

T5最终尺寸/body。

---

# 2.12 Receiver click / activation boundary

Railway Receiver item直接行为只允许调用已冻结的 navigation/receiver action。

如果有 linked Conversation Glyth：

```text
click → known conversation target / T4 conversation preview or S03 child Worksite path
```

exact product route由 T4/T6 seam注入。

T2不擅自决定：

```text
click = switch receiver
```

因为 switching active receiver是 canonical continuity mutation，
应是显式管理动作。

---

# 2.13 Active Receiver switch

低频/显式：

```text
Peek / More
→ select another connected conversation
→ POST receiver-binding
```

若产品要求 Handoff prepare：

现有 `receiver-handoff` 机制必须由 continuity owner接线。

T2不能为了一个 Rail menu绕过 Handoff纪律直接裸 setActiveReceiver，
如果 T6/T4 final seam要求 prepare-before-activate。

所以 `useLcosReceiver` 暴露：

```text
requestActivateReceiver(id)
```

实际 orchestration通过 T6/T4 continuity seam注入，
而不是 Railway自己串两三个 POST。

---

# 2.14 Receiver disconnect

More：

```text
Disconnect
```

走 Core route。

如果 active receiver：

Core service已有：

```text
disconnect
→ clear activeReceiverId
→ revision++
```

T2不重复。

Destructive action可用 ConfirmDialog / existing confirm primitive。

---

# 2.15 Receiver RECEIVE target

如果 T3/T6判定某 payload允许投给 Receiver：

Railway RECEIVE：

```text
Receiver item becomes eligible target
```

drop target不是“切 active Receiver”。

它表达：

```text
当前 payload 的目标是这只 Receiver/Conversation
```

actual transaction T3/T6 owner。

---

# 2.16 S11 files

## CURRENT KEEP

```text
packages/contracts/src/receiver.ts
packages/contracts/src/conversation-identity.ts
apps/local-core/src/receiver-runtime-service.ts
apps/local-core/src/routes/receiver.ts
apps/local-core/src/project-events/project-event-hub.ts
apps/local-core/src/routes/project-events.ts
```

## PLANNED NEW

```text
apps/web-gen2/src/backend/receiver.ts
apps/web-gen2/src/presentation/receiver.ts
huabu/apps/web/src/lcos/useLcosReceiver.ts
```

## MODIFY

```text
huabu/apps/web/src/lcos/ui/Railway.tsx
huabu/apps/web/src/lcos/useLcosRailway.ts
```

---

# 2.17 S11 tests

## backend

- list；
- binding；
- set active；
- disconnect；
- 409；
- unavailable。

## presenter

- no active；
- ready；
- working；
- waiting；
- unlinked session；
- linked Glyth；
- no heuristic matching；
- active id missing from list。

## event

- receiver.activated refetch；
- disconnected；
- multi-client；
- SSE reconnect。

---

# 2.18 S11 browser acceptance

- no Receiver；
- one active；
- multiple connected conversations；
- working；
- waiting；
- linked Glyth；
- unlinked identity；
- switch through explicit management；
- disconnect；
- second client changes active Receiver；
- Railway worksite overflow；
- Rail RECEIVE with Receiver eligible/ineligible。

Rest state不得出现：

```text
Codex
GPT
model
tokens
running task details
```

堆成运维仪表盘。

---

# 2.19 S11 recovery

Receiver GET fail：

```text
Rail keeps neutral unavailable receiver glyph
no guessed identity
```

Activation fail：

```text
old active remains
pending state rollback
```

Identity chain missing：

```text
show ConnectedConversation label
glythResolvable=false
```

Disconnect fail：

```text
keep item
```

---

# 2.20 S11 blast radius

client/presenter：

`BR-1`

receiver activation continuity：

`BR-2/BR-3 cross-owner`

T2只消费 orchestration seam。

---

# 3. T2-S12 · Navigation More / low-frequency management

# 3.1 PRODUCT_BEHAVIOR

Railway/Navigation primary gestures：

```text
click = navigate/activate
hover = Peek
drag = reorder or Receive
```

低频管理放：

```text
right-click / More
```

避免常驻小按钮堆满 Rail。

---

# 3.2 What belongs direct

直接动作：

```text
Enter Worksite
Activate Surface
Locate/Focus known target
Peek
drag reorder
drop
```

不塞 More。

---

# 3.3 What belongs More

候选按 item capability：

## Worksite

```text
Rename
Archive
Remove from Rail / management distinction as final T6 contract
```

## Receiver

```text
Manage/Switch Receiver
Disconnect
```

## legacy item

```text
migration action
remove stale legacy ref where canonical contract allows
```

## Surface root

极少管理项，
不应该因为 menu framework存在就塞一堆设置。

---

# 3.4 Current mature menu primitive

exact：

`huabu/apps/web/src/components/Common/DropdownMenu.tsx`

MIT Huabu component。

Current：

```text
DropdownMenu
DropdownMenuItem
DropdownMenuSubmenu
```

能力：

- controlled/uncontrolled；
- Popover positioning；
- bottom/top/side align；
- outside click dismiss；
- Escape dismiss；
- just-dismissed reopen guard；
- nested menu；
- hover/click/ArrowRight submenu；
- shortcut label；
- icon/trailing affordance。

### ENGINEERING_STATUS

`DIRECT_USE`

不要再造 menu primitive。

---

# 3.5 Current exact visual/mechanic defaults

`DropdownMenuItem`：

```text
ghost neutral Button
w-full
px-3
py-1.5
text-xs
```

Submenu close grace：

```text
120ms
```

Popover default vertical offset：

```text
4px
```

这些是 implementation default，
T5可以在 LCOS wrapper上覆盖 body tokens，
但不要重写 dismissal/keyboard/submenu mechanics。

---

# 3.6 PLANNED Railway More wrapper

优先不新建通用 framework。

在：

`huabu/apps/web/src/lcos/ui/Railway.tsx`

或小型：

`RailwayItemMore.tsx`

直接：

```tsx
<DropdownMenu>
  ...
</DropdownMenu>
```

是否拆文件看 final body复杂度。

---

# 3.7 Capability-driven menu

不要：

```text
if item.kind==='worksite' hardcode every action
```

在 T2 presenter生成：

```ts
RailwayManageCapabilities {
  rename: boolean
  archive: boolean
  disconnect: boolean
  removeLegacyRef: boolean
}
```

这些 capability来自 canonical owner/action availability。

T2不自己判断：

```text
“看起来能删”
```

---

# 3.8 No ActionRegistry

禁止因为菜单多了就新建：

```text
GlobalActionRegistry
NavigationActionBus
RailwayCommandManager
```

action callback从现有 feature hook注入：

```text
onRename
onArchive
onDisconnect
...
```

---

# 3.9 Rename

Worksite rename：

canonical owner T6。

Railway可提供：

- More → Rename；
- Peek inline rename，如果 T5最终需要。

但只调用 typed rename contract。

不在 Railway local state永久改 title。

Optimistic UI失败必须 rollback。

---

# 3.10 Reorder

Reorder是直接 drag，
不是 More主动作。

S02已经：

```text
PUT /view-rail-order
CAS
```

More最多提供 accessibility fallback：

```text
Move up / Move down
```

是否需要由 accessibility验收决定。

---

# 3.11 Archive

Phase B D13：

Archive canonical lifecycle。

T2 menu只触发：

```text
onArchive(target)
```

不实现 archive storage。

Archive成功后：

- Rail item根据 canonical result消失/转 archived state；
- Search仍可找到；
- Focus archived no ghost locate。

不要将：

```text
Remove from Rail
```

偷偷当 Archive。

---

# 3.12 Delete / remove distinction

Rail order presentation删除：

```text
remove Rail ref
```

与 canonical Archive/Delete不同。

如果最终 new ontology允许用户隐藏一个 Worksite Rail presentation而不Archive，
必须由 T6 presentation contract明确提供。

T2不能用 PUT rail-order擅自发明“删除 Worksite”。

---

# 3.13 Right-click

Railway item：

```text
onContextMenu
→ same More menu
```

不要维护两套菜单内容。

Contextmenu只改变 trigger origin/position。

如果 `DropdownMenu`现有 trigger model不足以支持 pointer-position context menu，
优先 WRAP Popover positioning，
不造第二 menu system。

---

# 3.14 Tooltip / label

Rest Railway图形优先。

常驻不显示长 label。

Hover：

```text
Tooltip / Peek
```

复用 Huabu现有 Tooltip/Popover体系。

More menu可有文字，
因为这是显式展开的低频管理界面，
符合最终冻结“必要文字在 hover/focus/explicit expansion出现”。

---

# 3.15 Menu / Peek arbitration

同一 Rail item：

```text
Peek open
→ More opened
→ Peek yields/freeze
```

不能：

```text
Peek + submenu + tooltip
```

同时叠三层。

实现上：

Railway item local presentation state：

```text
peek
menuOpen
```

不需要全局 store。

---

# 3.16 S12 file ledger

## CURRENT DIRECT_USE

```text
huabu/apps/web/src/components/Common/DropdownMenu.tsx
huabu/apps/web/src/components/Common/Popover.tsx
huabu/apps/web/src/components/Common/Button.tsx
```

## MODIFY

```text
huabu/apps/web/src/lcos/ui/Railway.tsx
apps/web-gen2/src/presentation/railway.ts
```

## OPTIONAL NEW

```text
huabu/apps/web/src/lcos/ui/RailwayItemMore.tsx
```

只有 final complexity证明值得拆才创建。

---

# 3.17 S12 tests

- right-click opens same menu；
- More opens；
- Escape；
- outside click；
- menu cannot reopen same frame；
- submenu keyboard；
- capability absence hides action；
- Rename success/fail；
- Archive callback；
- Disconnect callback；
- no duplicate management actions；
- Peek yields to menu；
- no canonical mutation in menu component。

---

# 3.18 S12 browser acceptance

- mouse hover Peek；
- right-click；
- More click；
- keyboard Tab/Enter/Escape；
- nested submenu；
- narrow Rail；
- Receive mode disables management；
- reorder mode disables More；
- current active Worksite；
- Receiver；
- legacy item；
- Surface root；
- reduced motion；
- dark/light final T5 tokens。

---

# 3.19 S12 recovery

Action fail：

```text
menu can close
Rail returns canonical state
inline/transient error near originating item
```

No stale optimistic title/status。

---

# 3.20 S12 blast radius

`BR-0/BR-1`

使用成熟 Huabu UI primitives，
不触 Core schema。

---

# 4. Checkpoint 04 shared architecture

```text
                  T3 pointer/drop
                        │
                        ▼
              SemanticDropMachine
                        │
              payload + eligibility
                        │
                        ▼
          T2 Railway Receive presenter
                        │
                  actual target
                        │
                        ▼
               T3 commit orchestration
                        │
           ┌────────────┴─────────────┐
           │                          │
           ▼                          ▼
       T6 semantic              Huabu physical
       transaction              move when required
                                      │
                                      ▼
                           upstream move primitive

Receiver:
Core receiver truth
→ typed client
→ T2 receiver presenter
→ Railway bottom identity

Management:
typed capabilities
→ Railway More
→ Huabu DropdownMenu
→ injected owner callbacks
```

---

# 5. Current vs planned file matrix after S10–S12

## Core CURRENT KEEP

```text
packages/contracts/src/receiver.ts
packages/contracts/src/conversation-identity.ts
apps/local-core/src/receiver-runtime-service.ts
apps/local-core/src/routes/receiver.ts
apps/local-core/src/project-events/*
```

## web-gen2 PLANNED

```text
src/backend/receiver.ts
src/presentation/receiver.ts
src/presentation/railwayReceive.ts
```

## Huabu/LCOS CURRENT

```text
huabu/apps/web/src/lcos/lcosDropState.ts
huabu/apps/web/src/lcos/lcosRecognizers.ts
huabu/apps/web/src/components/Common/DropdownMenu.tsx
```

## Huabu/LCOS PLANNED/MODIFY

```text
huabu/apps/web/src/lcos/useLcosReceiver.ts
huabu/apps/web/src/lcos/ui/Railway.tsx
huabu/apps/web/src/lcos/useLcosRailway.ts
```

## Upstream Huabu selective adoption

```text
microsoft/Huabu:
packages/shared/src/types/api/space-move.ts
apps/server/src/modules/canvas/space-move-plan.ts
apps/server/src/modules/canvas/space-move.service.ts
apps/server/src/modules/canvas/canvas.route.ts
apps/server/src/modules/canvas/write-coordinator.ts
apps/web/src/api/canvas.ts
tests for all above
```

REJECT primary UI:

```text
MoveSelectionModal.tsx
```

---

# 6. C1 seam coverage status

```text
S01 SurfaceDock                         DONE
S02 Railway order/presenter             DONE
S03 Worksite Enter/Back                 DONE

S04 Project Search                      DONE
S05 Focus/Where                         DONE
S06 Color Pin                           DONE

S07 Locator/Camera/Arrival              DONE
S08 Minimap/Spatial Navigator           DONE
S09 Work View Occupancy Consumer        DONE

S10 Railway Receive Map                 DONE
S11 Receiver in Railway                 DONE
S12 Navigation More                     DONE
```

T2 C1 **engineering seam coverage已经完整**。

但：

> 这仍然不是 production-ready final source construction plan。

下一阶段必须先做 consolidation。

---

# 7. Remaining implementation dependencies, not product OPEN

## DEP-01 T6 Worksite migration exact contract

needed by：

- S02；
- S03；
- S04 locations；
- S05 occurrences。

Status：

```text
Phase B product CLOSED
exact T6 source export dependency
```

## DEP-02 T4 occupancy exact export

needed by：

- S07 safeRect；
- S08 Spatial Navigator；
- S09 all.

Status：

```text
Phase B product CLOSED
current HEAD export not found
WAIT_FOR_T4_ENGINEERING_SEAM
```

## DEP-03 T3 Semantic Drop commit contract

needed by S10。

Status：

```text
Phase B behavior CLOSED
exact C1 transaction seam cross-review
```

## DEP-04 Huabu upstream selective move sync

engineering adoption dependency。

No product decision required。

---

# 8. No Coordinator escalation

目前四个 checkpoint发现的 source conflicts都可通过薄 seam解决：

```text
Cmd+F conflict
→ hotkey arbitration

locationRefs capped 5
→ navigation occurrences read seam

Huabu resize moves Camera
→ host viewportPolicy

Railway drop Phase A only generic left dock
→ typed destination target integration

vendored Huabu lacks move-selection
→ selective upstream adoption
```

没有一个要求重新裁决产品语义。

所以：

```text
COORDINATOR_ESCALATION = NONE
```

---

# 9. Next deliverables

C1 seam结束后，不直接 coding。

下一步：

## C1-CONSOLIDATE

一份：

`LCOS_Gen2_T2_C1_Consolidated_ExactFile_SourceConstructionPlan_20260906.md`

内容：

- 12 seam合并；
- 文件级施工顺序；
- owner/consumer总图；
- exact modify/new/retire matrix；
- migration ordering；
- dependency gates；
- test pyramid；
- browser execution order；
- rollback sequence；
- blast-radius sequencing。

## T5 ENGINEERING INPUT

一份：

`LCOS_Gen2_T2_to_T5_EngineeringSeams_VisualInputPack_20260906.md`

只摘视觉真正需要的信息：

- Railway real states；
- real preview capability；
- Search/Focus/Pin states；
- Locator progress；
- Arrival target-body capability；
- Spatial Navigator mechanics；
- SurfaceDock primary；
- safeRect behavior；
- Receiver states；
- canvas tools secondary；
- donor exact measurements；
- final body仍开放的项目。

## COORDINATOR HANDOFF

一份 dependency/owner handoff，
不重新提 Phase B已关闭 OPEN。

---

# 10. Checkpoint 04 conclusion

T2 C1 source skeleton目前已经不再是“应该怎么做”的产品方案。

它现在已经能指出：

```text
哪个 existing file 保留
哪个 existing file 修改
哪个 exact route/contract 是 owner
哪个 component 是 consumer
哪里新增 thin typed client
哪里新增 pure presenter
哪里只加 UI state
哪里必须 selective sync upstream
哪里必须退休旧 ontology/placement
哪里必须等待 T3/T4/T6 exact engineering export
```

而且没有通过：

```text
第二 store
第二 camera
第二 minimap
第二 search
第二 menu framework
第二 drop machine
```

来掩盖接线困难。

这才是进入 consolidated source plan 前应有的状态。
