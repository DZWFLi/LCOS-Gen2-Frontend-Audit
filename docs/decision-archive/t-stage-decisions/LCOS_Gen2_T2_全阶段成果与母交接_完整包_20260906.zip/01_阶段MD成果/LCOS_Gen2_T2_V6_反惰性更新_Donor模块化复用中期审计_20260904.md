# LCOS Gen2 · T2 V6 反惰性更新与 Donor 模块化复用中期审计

> 日期：2026-09-04  
> 线程：T2 · Viewport / Chrome / Railway / Minimap / Navigation  
> 性质：**V6 intake + Round 1/2/4 中期证据审计，不是最终施工正本，不授权 patch。**  
> 当前目标：确认新 donor / 拆包 / Spatial v4 是否能通过 Gen2 可替换架构直接复用成熟实现，同时避免第二 viewport、第二 store、第二 UI framework 和第二 canonical truth。

---

## 0. 先给结论

V6 的变化非常关键：

> T2 的“模块化”不能理解成增加更多 manager / registry / store，而要理解成：**canonical owner 不动，supplier body 可替换，失败只炸到局部 UI body / adapter。**

对第二路目前最合理的总结构是：

```text
Local Core canonical semantics
        ↓
SurfacePort / ProjectionBinding / Huabu spatial truth
        ↓
thin feature adapter / derived presentation policy
        ↓
replaceable supplier body
        ↓
existing Huabu composition seam
```

因此：

- Minimap 换外观，不动 Huabu viewport；
- Railway 换 body，不动 Surface truth；
- Search 换 presentation，不动 Core Search；
- Pin/Locator 换视觉 donor，不动 Pin canonical identity；
- Right-click 换菜单形态，不动 pointer router / semantic actions；
- Morphicons / Amicro / Orbit 失败，最多撤掉它们自己的 visual body，不允许回滚 Core / Binding / Surface。

这是 V6 `P14 Failure Blast Radius` + `P15 Replacement Boundary` 真正在源码里的落法。

---

## 1. 上一轮 blocker 已解除

上一轮 T2 缺的 6 份 raw original，本次 `Library补充(1).zip` 已补齐：

1. `LCOS_v015_原文到后续施工计划_差分审计_20260831.md`
2. `LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md`
3. `LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md`
4. `LCOS_v0.15_UX冻结_Search_CommandPalette_人话语义_20260829.md`
5. `LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md`
6. `LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md`

同时补入：

- `LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md`
- `LCOS_v015_Navigation_Pin_Orbit_Receiver_ProjectIdentity_补充收敛表_20260831.md`
- `LCOS_v015_VIDEO_DONOR_原稿总索引与施工映射_20260831.md`
- `LCOS_v015_三Surface交互同构硬规则_20260831.md`
- `LCOS_v015_LATEST_L0_WORKVIEW_HUD_DIRECT_MANIPULATION_ADDENDUM_20260901.md`
- 等 T2/T4 交叉原文。

因此：

```text
上一轮状态：ROUND_1_BLOCKED_BY_RAW_ORIGINALS
当前状态：RAW_ORIGINAL_BLOCKER_CLEARED
```

但 V6 Mandatory Read 是更大的 completion table，所以当前仍不把“补齐 6 份”写成“Round 1 全部完成”。

---

## 2. V6 相比 V2 真正新增了什么

### 2.1 从“donor census”升级为“wheel provenance”

现在不是看到竞品好看就写：

```text
TapNow donor
Lovart donor
LibTV donor
```

而是必须拆成：

```text
product behavior / visual evidence
→ bundle 内 wheel signature
→ exact OSS upstream
→ license / maintenance / framework fit
→ Huabu 是否已经在用同一个 wheel
→ DIRECT_USE / WRAP / REFERENCE / REJECT
```

这会直接消灭一类常见返工：

> “竞品用了一个成熟轮子，我们没找到轮子，反而照着它重新手搓一遍。”

### 2.2 LibTV 新规则

LibTV 要拆成两个责任域：

#### `libtv-skills`

- 明确 MIT；
- 可以作为 implementation donor；
- 但 T2 直接代码价值有限，更多是 project/session identity 与 API boundary 参考。

#### LibTV product build

- 不允许复制 bundle；
- T2 exact chunks 中已经反溯出 React Flow / Zustand / Radix / AntD / Leva 等痕迹；
- 必须回 exact upstream 后判断。

对 T2 最关键的发现不是“LibTV 又给了一个 Minimap”，而是：

> **LibTV 的成熟 canvas chrome 仍然站在 React Flow 这一类成熟 canvas wheel 上。Huabu 本身已经依赖 `@xyflow/react`，所以 LCOS 没有任何理由再新建 Minimap engine。**

### 2.3 Spatial v4 新规则

Spatial v3 已 supersede，v4 增加 AX/runtime/window evidence。

最重要的 source correction：

```text
Minimap               0 exact hit
MiniMap               0 exact hit
minimap               0 exact hit
EdgePin               0
Beacon                0
centeredSpatialIndex  0
Locator               0 exact hit
```

因此 Spatial 不再能被当成：

- Minimap implementation donor；
- Edge Pin implementation donor；
- Locator implementation donor。

它对 T2 的价值收敛到：

- immersive canvas shell；
- 极低 persistent chrome；
- same-object zoom / presentation continuity；
- transient local control；
- content-first / controls-as-satellites；
- CanvasTransition / CanvasSidebar / CanvasToolbar / NavigationHelper 等后续行为深挖。

这是好事。参考项目终于从“神话生物”回到了证据对象。

---

## 3. 当前动态 GitHub 基线

本轮重新核验：

```text
DZWFLi/LCOS_Gen2 main
c2ff890a867922a1256572199458438572eb0a8c

microsoft/Huabu main
dc128fff2d37b5481ec305070a7e86d3de85f7d2

LCOS vendored Huabu upstream pin
58339e269b784728d67730c70bfe7792cae2457d
```

LCOS vendor import commit 明确记录：

```text
upstream pin 58339e2
+ three LCOS thin-seam commits
```

动态 compare：

```text
58339e2 ... dc128fff
upstream ahead by 19 commits
```

对 T2 relevant upstream delta 已看到：

- `apps/web/src/components/Common/DropdownMenu.tsx`
- `apps/web/src/components/Panels/Canvas/Canvas.tsx`
- `NodeFloatingToolbar.tsx`
- `MultiSelectToolbar.tsx`
- `AppMenu.tsx`
- Space move / cross-Space support 的相关 product work。

这意味着最终 T2 施工表不能只对 vendored Huabu 写方案，必须把这 19 commits 中和 T2 相关的 delta 分类：

```text
ADOPT_UPSTREAM
MERGE_UPSTREAM
WRAP_UPSTREAM
REFERENCE
NOT_RELEVANT
```

当前没有理由先 fork 新 menu primitive。Huabu upstream 的 Common DropdownMenu 已经继续长出 link / nested menu / keyboard 等能力。

---

## 4. Current source 已确认的关键 owner

### 4.1 `surfacePort.ts`

当前职责已经很健康：

```text
main / context / workflow
→ distinct canvasId
→ same spatial kernel family
→ independent camera / selection / layout / history
```

它是 Railway 应该消费的 Surface semantic seam。

**Railway 不应拥有 Surface state。**

Replacement Boundary：

```text
换 Railway body
≠ 改 surfacePort
≠ 改 Huabu canvasId
≠ 改 Core
```

### 4.2 `LcosCanvasAdapter.tsx`

当前是 React glue：

```text
framework-agnostic HostSeam
→ CanvasHostExtension
→ Huabu Canvas
```

这条 seam 应保护，不应因为 T2 再建立一个 `NavigationHostRuntime`。

### 4.3 `hostSeam.ts`

当前已有：

```text
node renderers
overlays
recognizers
connectIntent
```

其中 overlays 已经提供 canvas-level LCOS overlay injection。

当前判断：

> Railway / Pin HUD / Search spatial overlay 等 screen-space body 应优先证明现有 overlay/composition seam 能不能挂，不先新增 shell registry/host slot。

只有后续 source trace 证明现有 overlay 无法满足某个具体生产 consumer，才允许补薄 seam。

### 4.4 Huabu `Canvas.tsx`

当前已经直接使用：

```text
@xyflow/react
  ReactFlow
  Controls
  MiniMap
  Panel
```

当前 MiniMap：

```text
<MiniMap
  pannable
  zoomable
/>
```

这已经把核心机械事实定死：

> Minimap 必须继续使用同一 ReactFlow world / viewport，不允许引入第二坐标映射。

### 4.5 Huabu `canvasStore.ts`

当前：

```text
viewport → per-canvas local UI state
huabu.viewport.<canvasId>

minimapEnabled → global UI preference
huabu.minimapEnabled
```

因此未来 compact/expanded Minimap 不能再新建一份：

```text
lcosMinimapOpen
lcosViewport
lcosMiniMapCamera
```

这会直接变成第二 truth。

Transient hover/expanded presentation 若需要，优先局部 component state；持久 preference 继续尊重当前 owner，最终再决定是否迁移旧 `minimapEnabled` 的产品含义。

### 4.6 Huabu `panelStore.ts`

当前已经掌握 screen chrome：

- left collapsed；
- canvas search opened；
- right collapsed；
- preview fullscreen；
- right anchor；
- composer focus request。

因此 V6 的禁令“第二 global sidebar store”有非常具体的现实对象：

> Railway 不能再建一个 parallel global panel store。

---

## 5. T2 donor 第一轮 source-level 裁决

| Supplier | Exact evidence | License / boundary | T2 当前裁决 | 原因 |
|---|---|---|---|---|
| Huabu `@xyflow/react MiniMap` | current `Canvas.tsx` | Huabu current dependency | **ADOPT / KEEP OWNER** | 已经共享真实 viewport，pannable/zoomable，无第二 geometry |
| LibTV embedded React Flow | `inflated/3pi7g2wjxur9o.js` | product bundle 不复制，回 upstream | **PROVENANCE → ADOPT EXISTING HUABU WHEEL** | 证明成熟产品也在用同类 wheel，不新增依赖 |
| Toolcase `gc-minimap` 3.0.2 | `@toolcase/game-components` | MIT | **REJECT AS MAP MECHANICS / REFERENCE FOR CHROME** | 自己要求 worldX/Y/Width/Height + markers，并自行算百分比；接 LCOS 会造第二 world mapping |
| Toolcase Compass/Waypoint/Objective | package d.ts / built source | MIT | **REFERENCE / selective primitive candidate** | 可借视觉 morphology，但任何方向/位置必须来自 Huabu world→screen 计算，不让 donor 自己成为 truth |
| Morphicons 1.7.1 | package + source + LICENSE | MIT，React >=18，zero runtime deps core | **DIRECT_USE_WITH_TUNING candidate** | 非常适合 Surface switch / Minimap launcher / mode transition 的 icon body，换掉只影响视觉 body |
| Amicro `IconSwap` | `src/components/IconSwap.tsx` | MIT；`motion/react` | **ADOPT_PRIMITIVE candidate** | Huabu 已有 motion，源码很薄，适合状态 icon 切换，不值得重写 |
| Amicro `Dock` | `src/components/css-animations/Dock.tsx` | MIT；Motion/Reorder | **REFERENCE / partial LIFT candidate** | 内含自己的 reorder/items state，直接拿来做 Railway 会偷走 Surface order owner；只可借 magnification/body behavior |
| orbit-css radial layout | `_radial-layout.scss` | MIT | **ADOPT_PRIMITIVE candidate** | 纯 presentation geometry，适合 satellite/radial body，前提是不接管 semantic action state |
| React Bits Dock | source | MIT + Commons Clause | **REJECT_DIRECT_USE for open-source distribution until legal-cleared** | 许可禁止把组件本身再分发；LCOS 若公开源码直接内置有风险 |
| React Bits LineSidebar | source | MIT + Commons Clause | **REFERENCE_ONLY** | 同上，而且文字型 line sidebar 未必符合最终 Railway |
| React Bits TargetCursor | source | MIT + Commons Clause + GSAP | **REJECT for T2 runtime** | 新增全局 cursor/pointer owner，与 Huabu pointer lifecycle 冲突，且多 GSAP 依赖 |
| Lovart/tldraw stack | product bundle + tldraw upstream | tldraw current production license 非默认 permissive | **REFERENCE_ONLY** | 不允许因为 Lovart 好看把第二 canvas engine 塞进 Huabu |
| TapNow product build | minified/proprietary bundle | reference only | **VISUAL/RESPONSIBILITY_REFERENCE** | Pin/Minimap/context-menu UX 可借，语义和源码不复制 |
| Spatial v4 | proprietary/source archaeology | behavior evidence | **BEHAVIOR_REFERENCE** | 低 chrome、zoom continuity、local transient control；没有 Minimap source proof |
| libtv-skills | explicit LICENSE | MIT | **IMPLEMENTATION DONOR, LOW T2 DIRECT VALUE** | 更适合 project/session API boundary，T2 仅做身份/入口职责参考 |

---

## 6. 一个重要 donor 纠偏：Toolcase Minimap 不能“因为成熟”就直接接

Toolcase `gc-minimap` 的真实 API：

```text
worldX
worldY
worldWidth
worldHeight
backgroundImage
rotation
markers[] = { id, x, y, color, size }
```

真实 render 逻辑还会自己做：

```text
px = (marker.x - worldX) / worldWidth * 100
py = (marker.y - worldY) / worldHeight * 100
```

这对游戏 HUD 很合理。

但 LCOS 已经冻结：

```text
Huabu = only spatial / viewport truth
```

如果我们为了“直接复用”再喂 Toolcase 一套 world bounds + markers mapping：

```text
Huabu world
→ LCOS adapter copy
→ Toolcase world model
```

那就是第二 geometry projection。

所以正确复用是：

```text
Huabu ReactFlow MiniMap = mechanics
Toolcase = corner/frame/marker visual grammar reference
Morphicons/Amicro = launcher transition body
LCOS = Pin / Locator semantic mapping
```

而不是：

```text
Toolcase MiniMap = LCOS Minimap engine
```

这正是 V6 反惰性规则真正有用的地方：反惰性不等于“看到成熟组件就全塞进来”，而是避免**既重复造轮子，也重复造 truth**。

---

## 7. 建议冻结的 T2 可替换架构模式

注意：下面是当前高置信 architecture direction，不是最终 exact-file construction plan。

### 7.1 模式：Supplier Body Slot，不建 Mega Registry

每个功能局部保持：

```text
canonical semantic owner
→ tiny props adapter
→ supplier body
→ existing host composition
```

不要建：

```text
NavigationRegistry
ChromeManager
HudEngine
RailwayStore
MinimapManager
```

### 7.2 Minimap

```text
Huabu ReactFlow viewport
        ↓
existing MiniMap mechanic
        ↓
LCOS compact/expanded presentation policy
        ↓
replaceable launcher/chrome body
```

允许替换：

- launcher icon；
- hover/expanded shell；
- corner/marker visual style；
- motion；
- safe-rect placement。

明确不允许触碰：

- Huabu viewport truth；
- ReactFlow world geometry；
- ProjectionBinding；
- Core；
- Surface camera。

Maximum Failure Blast Radius：

> Minimap launcher/chrome + placement only。

### 7.3 Railway

```text
SurfacePort descriptor
+ Core project/member/receiver truth
+ existing drag/pointer mechanics
        ↓
Railway presenter
        ↓
replaceable Railway body
```

Railway 负责：

- Surface/worksite navigation；
- member preview；
- cross-Surface drop target；
- Receiver cue；
- Surface order presentation。

Railway 不负责：

- 当前 Surface Layer tree；
- current canvas search；
- viewport；
- selection；
- Surface canonical store；
- Assembly warehouse。

`CanvasLayerPanel` 继续做当前 Surface 内容 hierarchy/filter/local search。

### 7.4 Search / Focus / Pin

三个 semantic owner 永久分开：

```text
Search
Core project retrieval
→ transient Search body
→ result → Focus handoff

Focus / Where
known entity occurrence
→ Huabu focus/fly-to
→ arrival beacon / occurrence index

Pin
Core durable marker/bookmark
→ color/pin presentation
→ focus on target
```

LibTV/TapNow/Lovart 的 Agent Web Search / thread history / node search 不能抢 Project Search primary entry。

### 7.5 Right-click

当前优先路线：

```text
Huabu pointer arbitration
→ Huabu Common DropdownMenu / Popover
→ LCOS semantic menu items
```

不要：

```text
new ContextMenu framework
new document global listener
new action registry mega-store
```

Huabu upstream 还在增强 DropdownMenu，说明这块更应该吃 upstream，而不是自己分叉。

---

## 8. T2 推荐的 supplier 分层

### Tier 0 · Current Huabu native mechanics

最高优先：

- ReactFlow viewport；
- MiniMap；
- Controls；
- Panel；
- CanvasFloatingPopover；
- Pointer router；
- DropdownMenu/Popover/Common controls；
- panelStore existing chrome owner。

### Tier 1 · Same-stack permissive primitive

只有 Huabu body 真缺时：

- Morphicons；
- Amicro `IconSwap`；
- orbit-css radial presentation；
- Toolcase isolated marker/chrome motif，前提是不接管 world/semantic truth。

### Tier 2 · Product UX / behavior reference

- TapNow；
- Lovart；
- LibTV product build；
- Spatial v4 recordings/source evidence。

这些告诉我们：

- 怎么藏 chrome；
- 什么时机展开；
- entry hierarchy；
- progressive disclosure；
- product responsibility split。

但不直接复制 proprietary bundle。

### Tier 3 · Reject / legal or architecture conflict

- tldraw 作为第二 canvas engine；
- React Bits 直接复制进公开 LCOS repo，在 Commons Clause 未解决前；
- React Bits TargetCursor 作为全局 cursor owner；
- Toolcase Minimap 作为第二 world mapping。

---

## 9. 对“让 Gen2 模块化后直接复用”的具体回答

**可以，而且 T2 是最适合这样做的一路。**

但模块化目标应该从：

```text
把文件拆小
```

改成：

```text
让 donor swap 不越过 owner boundary
```

我们最终应该能做到：

### 场景 A · Morphicons 不喜欢了

只换：

```text
navigation/launcher visual body
```

不动：

```text
SurfacePort
Core Search
Pin truth
Huabu viewport
```

### 场景 B · Minimap UX 不满意

只换：

```text
launcher
expanded shell
visual style
placement
```

不动：

```text
ReactFlow viewport
world geometry
camera
```

### 场景 C · Railway 视觉失败

只换：

```text
Railway body
```

不动：

```text
surface identity
cross-Surface semantic target
receiver truth
LayerPanel
```

### 场景 D · TapNow Pin 风格以后过时

只换：

```text
Pin HUD renderer / marker body
```

不动：

```text
Core Pin identity
Focus target
ProjectionBinding
```

这才是能长期吃 donor 的架构。

---

## 10. 当前不建议新增的东西

本轮没有发现需要新增以下 owner 的证据：

```text
NavigationManager
RailwayStore
MiniMapEngine
ChromeRegistry
GlobalHudStore
ContextMenuEngine
SecondViewportAdapter
```

原因不是“追求少文件”，而是现有 Huabu / Core / SurfacePort 已经覆盖 owner。

若后续 exact consumer trace 发现缺口，只允许补：

```text
feature-local pure resolver
feature-local props adapter
replaceable presentation body
```

不默认加新 contract / gate / baseline。

---

## 11. 下一轮合法深挖

V6 现在要求至少 5 轮 source investigation。

本次完成/推进：

```text
Round 1  Asset/Scope Recovery       → blocker cleared，completion table继续补齐
Round 2  Current Owner Trace         → 已确认关键 spatial/chrome seams，仍需 exact rail/pin/receiver Core route
Round 3  Historical Pain             → 已重新恢复关键原文，仍需整理 5+条 EARLY→CORRECTED→FINAL 链
Round 4  Supplier Comparison         → 已出现第一批 ADOPT/REJECT，仍需 Morphicons/Amicro/Orbit exact API adoption matrix
Round 5  Cross-boundary Audit        → 尚未正式完成
```

下一步 T2 必须继续：

1. 补完 22 份 File Library Mandatory Read completion table；
2. 全文读 V6 T2 指定 Gen2 ZIP audit entries；
3. 把 `58339e2...dc128fff` 19 commits 里的 T2 relevant delta 逐文件分类；
4. 追 current production Core routes：Pin / Marker / Receiver / Surface order / Search；
5. 追 `CanvasPage → MainLayout → Header/LayerPanel/Canvas/Preview` 当前 chrome ownership；
6. 追 keyboard/global search/contextmenu consumer；
7. 对 Morphicons / Amicro / Orbit / Toolcase 做 exact import/API/license/maintenance matrix；
8. 形成 T2 唯一入口表；
9. 做 10+ 个 second-truth / duplicate-entry 反证问题；
10. 最后才生成 V6 要求的五份 ≥30KB 施工规划文件。

---

## 12. 当前 STOP / 允许状态

```text
RAW ORIGINAL BLOCKER: CLEARED
V6 INTAKE: COMPLETE
DONOR PROVENANCE: IN PROGRESS
CURRENT OWNER TRACE: IN PROGRESS
FINAL PLANNING AUTHORITY: LOCKED
PATCH AUTHORITY: LOCKED
```

本稿不授权 patch。

它只冻结当前一个非常重要的架构判断：

> **T2 的复用策略是“Huabu mechanics + LCOS semantics + replaceable donor body”。**
>
> 不以“直接复用”为借口引入第二 spatial truth；也不以“保持 Huabu”作为借口拒绝成熟 visual body。
