# LCOS Gen2 · T4 第四路
## Typed Core Clients × Exact Route × Transport Gap 审计
### Assembly / Run Review / Context Snapshot / Skill / Workflow

日期：2026-09-04  
源码基线：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`  
状态：`EXACT_ROUTE_AUDIT / PRE-CONSTRUCTION`

---

# 0. 结论

T4 当前后端缺口不是“Core 还没有能力”，而是：

```text
Core 已有 canonical routes
→ web-gen2 还没有对应的小型 typed clients
```

因此正确施工是：

```text
existing Core route
→ small typed client
→ WorkView body
```

不是：

```text
new WorkView API
new Phase-C facade
new Gen2Host mega methods
new frontend business truth
```

当前真正需要改底层 transport 的唯一已确认场景：

```text
Workflow import requires multipart/form-data
but HttpClient currently JSON-stringifies every request body
```

这是具体失败，不是“为未来扩展”。

---

# 1. 当前 web-gen2 backend reality

当前：

```text
apps/web-gen2/src/backend/
├── artifacts.ts
├── client.ts
├── coreTypes.ts
├── projects.ts
├── relations.ts
├── search.ts
└── sqliteBindingStore.ts
```

没有：

```text
assembly.ts
runs.ts
context.ts
skills.ts
workflow.ts
```

现有 `CoreArtifactClient` 已经提供正确 precedent：

> real routes only；如果 route shape 不等于 canonical entity，可以定义 route-specific projection，但不能虚构不存在的 generic API。

---

# 2. Gen2Host 不扩成 mega facade

当前 `Gen2Host` 只组合：

```text
projects
artifacts
relations
search
projection / reconciliation
```

Phase A 的 `DOCK_GAP_REGISTRY` 已明确：

```text
run
workflow
skill
voice
workbench
```

是后续 dock capability gaps。

正确方向：

```text
CoreAssemblyClient
CoreRunClient
CoreContextClient
CoreSkillClient
CoreWorkflowClient
```

平行于 Gen2Host。

不做：

```text
Gen2Host.runs.*
Gen2Host.skills.*
Gen2Host.workflow.*
CoreWorkViewFacade
PhaseCFacade
```

---

# 3. HttpClient 当前 transport contract

当前 `RequestOptions`：

```ts
body?: unknown
signal?
headers?
auth?
mode?: 'json' | 'text' | 'blob'
```

只要 `body !== undefined`：

```text
Content-Type = application/json
body = JSON.stringify(body)
```

这是现有 JSON client 正确行为。

不能为了 multipart 把整个 body model 重做。

---

# 4. Workflow multipart 是具体失败场景

Core：

```text
POST /projects/:id/workflow/import
```

明确：

```text
readRawBody()
parseMultipartImport(content-type, raw)
```

没有 multipart boundary：

```text
Multipart boundary is required
```

且必须存在 file part。

所以当前：

```text
HttpClient.postJson(FormData)
```

必然错误：

```text
Content-Type: application/json
JSON.stringify(FormData) -> {}
```

普通 typecheck/unit API shape 无法替代真实 transport 测试。

---

# 5. HttpClient 最小改法候选

不改现有 JSON callers。

建议只新增一个 raw request body seam：

```ts
interface RequestOptions {
  body?: unknown
  rawBody?: BodyInit
  ...
}
```

规则：

```text
body 与 rawBody 不能同时存在
body     → application/json + JSON.stringify
rawBody  → browser/native body unchanged
```

再加：

```ts
postFormData<T>(
  path: string,
  body: FormData,
  signal?: AbortSignal,
  headers?: Record<string, string>,
): Promise<T>
```

关键：

```text
DO NOT manually set Content-Type for FormData
```

boundary 必须让浏览器生成。

---

# 6. HttpClient exact files

## MODIFY

```text
apps/web-gen2/src/backend/client.ts
apps/web-gen2/test/core-clients.test.ts
```

## DO NOT MODIFY

```text
apps/web-gen2/src/backend/coreTypes.ts
```

`coreRequest()` 本身已经能把 RequestOptions 传给 HttpClient。

如果 `RequestOptions.rawBody` 加入后：

```text
coreRequest()
```

无需业务逻辑变化。

---

# 7. CoreAssemblyClient

候选文件：

```text
apps/web-gen2/src/backend/assembly.ts
```

---

## 7.1 Warehouse

Core route：

```text
GET /projects/:projectId/warehouse
```

当前 query mapping：

```text
search            → ?search=
kinds[]           → ?kinds=a,b
provenanceOrigin  → ?provenance=
usedHereTarget    → ?usedHereTarget=
limit             → ?limit=
cursor            → ?cursor=
```

返回：

```ts
WarehouseSnapshotV1
```

---

## 7.2 current route mismatch

Shared contract：

```ts
WarehouseQueryV1.usedHereTarget:
  | workspace
  | scope
  | conversation
```

但当前 route 只解析：

```text
workspace:<id>
```

所以第一版 client 不能直接声称完整支持 `WarehouseQueryV1`。

建议 route-real type：

```ts
type CoreWarehouseQuery = Omit<WarehouseQueryV1, 'usedHereTarget'> & {
  readonly usedHereTarget?: {
    readonly kind: 'workspace'
    readonly id: string
  }
}
```

并把：

```text
scope / conversation usedHere
```

登记为 Core gap。

禁止静默暴露一个实际无效的 UI filter。

---

## 7.3 Assembly Apply

Core：

```text
POST /projects/:projectId/assembly/apply
```

request：

```ts
AssemblyApplyRequestV1
```

response：

```ts
AssemblyApplyResultV1
```

注意 request 自带 projectId，同时 URL 也带 projectId。

Client 不应自行改 contract。

---

## 7.4 Assembly Source Bay composition

Warehouse 不含 Skill kind。

Skill Source 来自：

```text
CoreSkillClient.listSkills()
```

因此 Assembly Source Bay 应组合：

```text
Project/Warehouse source
+
Skill Catalog source
+
Capture source where applicable
```

而不是要求 Warehouse API 再塞 Skill。

---

# 8. CoreContextClient

候选：

```text
apps/web-gen2/src/backend/context.ts
```

只做 Snapshot/Evolution 需要的 route。

---

## 8.1 list

```text
GET /projects/:id/context-snapshots
GET /projects/:id/context-snapshots?workspaceId=
```

返回：

```ts
readonly Checkpoint[]
```

注意：

当前 `ContextSnapshotService` 是基于 existing immutable Checkpoint table。

不建第二 history store。

---

## 8.2 create

```text
POST /projects/:id/context-snapshots
```

body：

```ts
{
  label: string
  workspaceId?: string
}
```

返回：

```ts
Checkpoint
```

---

## 8.3 compare

```text
POST /projects/:id/context-snapshots/:snapshotId/compare
```

body：

```ts
{
  otherSnapshotId: string
}
```

返回：

```ts
SnapshotCompareResultV1
```

结构：

```text
base
other
added
removed
kept
```

前端不自己 diff。

---

## 8.4 branch

```text
POST /projects/:id/context-snapshots/:snapshotId/branch
```

body：

```ts
{
  label: string
  targetScopeId?: string
}
```

返回：

```ts
BranchSnapshotResultV1
```

Core branch：

```text
new/existing collection scope
+ new ArtifactViews
```

不复制 Artifact。

---

# 9. Context Evolution donor projection

`vis-timeline` body 需要的最小 data：

```text
id        ← Checkpoint.id
label     ← Checkpoint.label
time      ← Checkpoint.createdAt
workspace ← Checkpoint.workspaceId
scope     ← Checkpoint.scopeId
```

选择两个点：

```text
CoreContextClient.compare()
```

Branch：

```text
CoreContextClient.branch()
```

因此不新增：

```text
ContextVersion
TimelineVersion
EvolutionStore
```

---

# 10. CoreRunClient

候选：

```text
apps/web-gen2/src/backend/runs.ts
```

---

## 10.1 Shared contracts already exist

可直接复用：

```text
RunReview
RunInputRequestV1
AnswerRunInputRequestV1
AcceptArtifactReturnInput
AcceptArtifactReturnResult
RejectArtifactReturnResult
RetryRunInput
RetryRunResult
RunEvent
RunRecipeV0
```

特别：

```text
RunReview.capabilities
```

已经由 Core 返回：

```text
accept
reject
retry
enabled + reason
```

UI 不自行按 status 猜。

---

## 10.2 list project reviews

```text
GET /projects/:id/runs?limit=N
```

返回：

```ts
RunReview[]
```

---

## 10.3 get review

```text
GET /runs/:runId/review
```

返回：

```ts
RunReview
```

---

## 10.4 events

```text
GET /runs/:runId/events
GET /runs/:runId/events?after=sequence
```

返回：

```ts
RunEvent[]
```

恢复 cursor：

```text
RunEvent.sequence
```

第一版不造 SSE。

TapNow 的 Last-Event-ID 只作为“增量恢复”行为证据。

---

## 10.5 input request

```text
GET /runs/:runId/input-request
POST /runs/:runId/input-request
```

answer body：

```ts
AnswerRunInputRequestV1
```

---

## 10.6 runtime actions

```text
POST /runs/:id/dispatch
POST /runs/:id/recover
POST /runs/:id/sync
POST /runs/:id/cancel
```

返回 route projection：

```ts
{
  review: RunReview
  providerError?: {
    code: string
    message: string
    retryable: boolean
    provider: 'workbuddy' | 'codex'
  }
}
```

`RuntimeRunActionResult` 当前是 local-core internal type，不在 shared contracts。

Client 可定义 route-specific projection。

不因此移动 Core internal type。

---

## 10.7 create

```text
POST /projects/:id/runs
```

当前 HTTP input shape 没有 shared `CreateRuntimeRunInput` export。

建议：

```ts
interface CoreCreateRunInput { ...exact route body... }
```

只作为 HTTP request projection。

不新增 shared contract，除非后续多个 independent consumer 确实需要同一 public input type。

---

## 10.8 RunRecipe

```text
GET /runs/:id/recipe
```

返回：

```ts
RunRecipeV0
```

放入 `CoreRunClient`，不要因为 route 当前在 `f6-assembly.ts` 就归 Assembly client。

---

# 11. ArtifactReturn Review

Core：

```text
POST /artifact-returns/:returnId/accept
POST /artifact-returns/:returnId/reject
POST /artifact-returns/:returnId/retry
```

---

## accept

input：

```ts
AcceptArtifactReturnInput
```

要求：

```text
expectedBaseRevisionId
```

返回：

```ts
AcceptArtifactReturnResult
```

accept 成功后：

- Run completed event；
- semantic reindex；
- ResultSlot materialize；
- continuity intake（次级，失败不回滚 accept）。

---

## reject

返回：

```ts
RejectArtifactReturnResult
```

Run 也进入 completed。

---

## retry

input：

```ts
RetryRunInput
```

Core 语义：

```text
旧 ArtifactReturn
→ 新 Run
→ 新 Dispatch
→ retryOfRunId = previous Run
```

不是旧 Run 原地回 running。

UI 验收必须检查：

```text
retry 后出现新 Run identity
```

---

# 12. CoreRuntimeClient 是否需要

不是 T4 第一阶段必需。

只有以下 UI 真需要时再加：

```text
GET /runtime/providers
GET /projects/:id/session-lifecycle
POST /projects/:id/session-lifecycle/:provider/recover
```

不要把：

```text
OCR
codex-dispatch-plan
```

顺手收进 T4 client。

---

# 13. CoreSkillClient

候选：

```text
apps/web-gen2/src/backend/skills.ts
```

---

## 13.1 Catalog

```text
GET /projects/:id/skills
GET /projects/:id/skills?search=
GET /projects/:id/skills/:skillId
```

返回：

```text
SkillCatalogEntryV1[]
SkillCatalogReadV1
```

---

## 13.2 Validate

```text
POST /projects/:id/skills/validate
```

body：

```ts
{ content: string }
```

返回：

```ts
SkillPackageValidationV1
```

---

## 13.3 Create

```text
POST /projects/:id/skills
```

body：

```ts
{
  id: string
  content: string
}
```

返回：

```ts
SkillPackageV1
```

---

## 13.4 Update

```text
POST /projects/:id/skills/:skillId/update
```

body：

```ts
{ content: string }
```

---

## 13.5 Version bump

```text
POST /projects/:id/skills/:skillId/version-bump
```

body：

```ts
{ version: string }
```

---

## 13.6 Rename

```text
POST /projects/:id/skills/:skillId/rename
```

body：

```ts
{ newId: string }
```

---

## 13.7 Install / Disable / Enable

```text
POST /projects/:id/skills/:skillId/install
POST /projects/:id/skills/:skillId/disable
POST /projects/:id/skills/:skillId/enable
```

---

# 14. Skill Proposal

Completed Run → proposal：

```text
POST /runs/:runId/skill-proposal
```

Core 对未 completed Run：

```text
409
RUN_NOT_COMPLETED
```

List：

```text
GET /projects/:id/skill-proposals
```

Actions：

```text
POST /projects/:id/skill-proposals/:proposalId/accept
POST /projects/:id/skill-proposals/:proposalId/reject
```

因此前端只有两条 Skill authoring 路：

```text
Manual Builder
→ validate
→ create/update Skill Package

Run-derived
→ skill-proposal
→ accept/reject
→ Skill Package
```

不造第三种 install state。

---

# 15. Skill Builder 后端新增量

当前判断：

```text
Core services to add = 0
```

第一阶段只需：

```text
CoreSkillClient
SkillBuilderProjection
Outline/MindMap bodies
```

跨 T6：

```text
skill SourceRef apply semantics
LibTV provider/runtime integration
```

---

# 16. CoreWorkflowClient

候选：

```text
apps/web-gen2/src/backend/workflow.ts
```

只做：

```text
exportZip
importZip
```

---

## 16.1 export

```text
GET /projects/:id/workflow/export?scopeId=
```

response：

```text
application/zip
```

现有：

```text
HttpClient.getBlob()
```

足够。

---

## 16.2 import

```text
POST /projects/:id/workflow/import?scopeId=
```

request：

```text
multipart/form-data
file part
```

response：

```ts
interface WorkflowImportResultProjection {
  readonly imported: boolean
  readonly members: number
  readonly workspaces: number
}
```

---

# 17. Workflow 不承担 execution

Core workflow archive：

```text
manifest.json
workflow.json
references.json
```

明确：

```text
Core 不执行 semantic condition
predicateText 只是创作内容
```

真正 execution：

```text
Run / Runtime
```

所以禁止：

```text
CoreWorkflowClient.dispatch()
CoreWorkflowClient.run()
Workflow execution engine
BPMN runtime
```

---

# 18. Exact test files

## typed route/client

继续使用：

```text
apps/web-gen2/test/core-clients.test.ts
```

验证：

- exact URL
- method
- body
- query encoding
- shared type projection
- Core envelope errors

---

## multipart transport

同一测试文件或一个极小 transport test：

断言：

```text
FormData instance reaches fetch unchanged
Content-Type NOT manually set
Authorization still present
response envelope unwrap works
```

---

# 19. Browser E2E 只测浏览器真实风险

复用：

```text
huabu/apps/web/e2e/
```

只给这些放 Playwright：

```text
fullscreen runtime lifetime
WorkView restore
Camera continuity
ProjectionBinding continuity
Arborist internal DnD disabled / no leak
MindElixir wheel/pointer/keyboard isolation
```

不拿 Playwright 测：

```text
query string
JSON body
Core error envelope
```

---

# 20. 更新后的 ExactFile 候选

## MODIFY

```text
apps/web-gen2/src/backend/client.ts
apps/web-gen2/src/index.ts
apps/web-gen2/test/core-clients.test.ts

huabu/apps/web/src/pages/CanvasPage/CanvasPage.tsx
huabu/apps/web/src/pages/CanvasPage/CenterArea.tsx
```

---

## ADD

```text
apps/web-gen2/src/backend/assembly.ts
apps/web-gen2/src/backend/runs.ts
apps/web-gen2/src/backend/context.ts
apps/web-gen2/src/backend/skills.ts
apps/web-gen2/src/backend/workflow.ts

huabu/apps/web/src/lcos/LcosRightSurfaceHost.tsx
```

body/adapters 后续按专业模块分阶段加入。

---

## NOT MODIFY FIRST

```text
apps/web-gen2/src/host/projectionFacade.ts
apps/web-gen2/src/host/createLcosHostRuntime.ts
apps/web-gen2/src/backend/coreTypes.ts

huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
huabu/apps/web/src/store/panelStore.ts
huabu/apps/web/src/store/canvasStore.ts
huabu/apps/web/src/store/previewWorkspace/*
huabu/apps/web/src/components/Common/CanvasFloatingPopover.tsx

apps/local-core/src/*
packages/contracts/src/*
packages/domain/src/*
```

---

# 21. Cross-thread gaps

## T4 → T1

```text
WorkView occupied rect
→ current activeSpatialViewport / HUD / navigation geometry owner
```

T4 只发布 rect。

---

## T4 → T6

```text
Skill SourceRef apply semantics
LibTV native provider/runtime session integration
Warehouse scope/conversation usedHere route mismatch
```

---

# 22. 当前最值得记住的减法

旧思路：

```text
先建 WorkView architecture
再连 Core
```

现在：

```text
先把真实 Core route 一一接薄
再让 body 只消费 canonical read/write
```

也就是：

> **模块化不靠多一层 framework，而靠每个模块都只知道它该知道的东西。**

当前 T4 已经没有理由新增：

```text
WorkView mega store
WorkView API
second Run model
second Context model
second Skill model
Workflow execution model
```

---

# 23. 下一步

继续进入：

```text
1. CanvasPage runtime hoist exact symbol / prop chain
2. LcosRightSurfaceHost exact mux contract
3. WorkView target/body resolver最小模型
4. Context donor wrapper API/CSS/lifecycle
5. Skill donor wrapper API/CSS/lifecycle
6. Assembly Source Bay visual/read/write chain
7. T1/T6 cross-thread dependency table
```

之后才写第四路最终施工正本。
