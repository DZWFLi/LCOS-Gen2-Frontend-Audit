# LCOS Gen2 · T3 第三路接管 / Round 1 Context Blocker
## Local Object Interaction / Action Arc / Compact Composer / Reference / Voice

日期：2026-09-04  
状态：`ROUND_1_CONTEXT_RECOVERY_BLOCKED`

---

## 0. 结论

第三路已按《LCOS_Gen2_六线程_ExactFile_反惰性规划引导包_V2_20260904》锁定为：

> **T3 · Local Object Interaction / Action Arc / Compact Composer / Reference / Voice**

当前不进入源码级施工规划正文。

原因不是当前 LCOS Gen2 / Huabu 源码不可访问，而是 T3 `MANDATORY_EXACT_READ_LIST` 中仍有若干指定原文，在本会话无法取得“exact standalone raw original / 可重新全文读取的原文对象”。

按照当前 SOP：

- 索引不能替代原文；
- SHA256 清单不能替代原文；
- 旧 Agent 的 `FOUND_FULL` 记录不能替代本会话重新全文读取；
- patch / cumulative diff 中嵌入的复制段不能自动冒充 ExactFile；
- 搜索 snippet 不能记为 `FULL_READ`；
- Mandatory 原文缺失时停在 Round 1，不进入施工规划；
- 不根据摘要自行补全产品语义。

---

## 1. T3 Scope Freeze

本线程负责：

- local object pointer interaction；
- stable click / selected-then-click / double-click；
- node / blank-area right-click；
- Action Arc；
- Unified Compact Composer；
- Reference / Reference Pick；
- Voice input；
- local Semantic Drop interaction chain；
- Glyth 本地交互与 Composer 接线边界；
- Huabu 现有 popover / floating toolbar / chat input primitives 的采用判断。

本线程不负责重新定义：

- Huabu Spatial Truth；
- Core Domain Truth；
- Selection / Reference / Relation 三种 truth；
- Work View lifecycle；
- Assembly semantics；
- Skill / Run separation；
- Search / Focus / Pin mental model；
- Visual species / node-body styling（T5）；
- project-global Work View / Assembly / Context / Workflow / Skill host（T4）。

遇到跨线程产品语义冲突，状态为 `REPORT_CONFLICT`，回主协调会话裁决。

---

## 2. 当前确认可访问的 Mandatory 原文

已确认本会话存在 exact File Library 对象或本次上传包中的 exact source，可继续在解除 blocker 后执行全文读取：

- `LCOS_20260821至20260902_全功能最新冻结总账_白话UX与Gen2施工映射.md`
- `LCOS_v015_MANDATORY_PRECONSTRUCTION_CONTEXT_20260831.md`
- `LCOS_v015_CONSTRUCTION_CONTEXT_INDEX_20260831.md`
- `LCOS_v015_Frontend_Gen2_Huabu_First_重建总纲_20260901.md`
- `LCOS_Gen2_Context_Recovery_可见对话原文_20260903.md`
- `LCOS_Gen2_重构进度审计澄清_Context_Recovery_Census_20260903.md`
- `LCOS_Gen2_详细施工方案_SOP_审计优先版_20260903.md`
- `LCOS_v015_UNIFIED_COMPACT_COMPOSER_PROMPT_REFERENCE_VOICE_GUI_FREEZE_20260831.md`
- `LCOS_v015_VIDEO_DONOR_原稿总索引与施工映射_20260831.md`
- `LCOS_v015_LATEST_L0_WORKVIEW_HUD_DIRECT_MANIPULATION_ADDENDUM_20260901.md`

其中 Composer freeze 已确认冻结的关键产品边界包括：

- Action Arc = 高频直接动作；
- Right-click / More = 管理、组织、复制、删除等次级操作；
- Composer = Prompt / Reference / Skill-or-Tool / Voice / Run；
- Selection ≠ Reference；
- content-like object 稳定 click 可出现 Selection feedback + Arc + Composer；
- pointerdown / drag initiation 期间 Composer 不抢 focus、不破坏 drag；
- Structural Surface Component 不因 selection 自动弹 generic Composer；
- Voice 是 Unified Composer input modality，不是独立 Panel；
- Voice：Idle → Recording → Transcribing → Editable Text → Explicit Send。

---

## 3. 当前缺失的 T3 Mandatory ExactFile 原文

下面 9 份在当前会话没有取得可重新全文读取的 exact standalone original，因此统一记为：

`MISSING_RAW_IN_CURRENT_SESSION`

1. `LCOS_v015_原文到后续施工计划_差分审计_20260831.md`
2. `LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md`
3. `LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md`
4. `LCOS_v0.15_UX冻结_Relation_Glyth_Colony_SpatialNavigation_20260829.md`
5. `LCOS_v015_三Surface交互同构硬规则_20260831.md`
6. `LCOS_v015_Lovart_Composer_ReferencePick_补充拆解_20260831.md`
7. `LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md`
8. `LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md`
9. `LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md`

注意：

这些文件中若干在 Recovery Archive 的 SHA / curated index / 历史 census 中有记录，部分内容也可能被历史 patch 或其他文档引用。

这只能证明 provenance / historical existence，不能满足 V2 的 ExactFile Full Read 要求。

---

## 4. 当前上传 ZIP 的状态

### `LCOS_Gen2_六线程_ExactFile_反惰性规划引导包_V2_20260904(3).zip`

已读取：

- shared anti-reinvention constitution；
- T3 planning guide；
- T3 exact mandatory read list；
- T3 current GitHub target paths；
- 5+ audit rounds；
- final deliverable requirements；
- STOP / anti-invention rules。

### `Gen2开发(4).zip`

T3 指定的审计 / 旧施工参考条目已确认可定位，包括：

- Semantic Drop 审计；
- GPT 审计盲区排查；
- A 系列谱系考古；
- MD2 交互与导航；
- MD3 工作台与现场编排；
- Phase A / Phase C 施工参考；
- D03g Glyth Neighbor Grammar 等。

当前先记：

`SOURCE_AVAILABLE_NOT_YET_FULL_READ`

原因：Mandatory File Library original 尚未闭合，本线程按 SOP 不越过 Round 1 偷跑后续规划。

### `LCOS_Gen2_FileLibrary_Recovery_Archive_20260904(4).zip`

已确认：

- exact local sources 与 File Library references 被明确分层；
- archive 自己声明不会伪造“无损原文”；
- `FOUND_FULL` 不等于 `EXACT_BYTES`；
- `04_RAW_BYTES_EXPORT_REQUIRED` 对若干 T3 原文仍要求从 File Library / 原始迁移包导出 raw source。

因此 Recovery Archive 是 provenance / recovery aid，不是缺失原文的替代品。

---

## 5. Current GitHub Dynamic Reality

本轮已动态核验：

### LCOS Gen2

Repo：

`DZWFLi/LCOS_Gen2`

当前 main latest observed：

`c2ff890a867922a1256572199458438572eb0a8c`

最近核心变化已经涉及 T3 所依赖的 interaction/reference owner：

- reference click suppressor 绑定 runtime lifecycle；
- ProjectionBinding 成为 Reference identity 来源；
- unbound native node fail-close；
- overlay 读取真实 selection / dragging；
- project session runtime / reconciliation 已进入 production composition。

### Vendored Huabu Pin

`HUABU_UPSTREAM.md` 当前声明：

`58339e269b784728d67730c70bfe7792cae2457d`

并明确：

- construction host = Gen2 repo 内 `huabu/`；
- standalone Huabu clone 不再是 construction host；
- LCOS 施工应基于 vendored Huabu + 明确 upstream diff。

### Huabu upstream

`microsoft/Huabu` 当前 main latest observed：

`dc128fff2d37b5481ec305070a7e86d3de85f7d2`

相对 vendored pin：

`ahead_by = 19 commits`

与 T3 直接相关、发生 upstream delta 的路径至少包括：

- `apps/web/src/components/Common/DropdownMenu.tsx`
- `apps/web/src/components/Panels/Canvas/FloatingToolbars/NodeFloatingToolbar.tsx`
- `apps/web/src/components/Panels/ChatPanel/ChatInput.tsx`
- `apps/web/src/components/Panels/ChatPanel/ThreadChatInput.tsx`
- `apps/web/src/components/Panels/Canvas/Canvas.tsx`
- ChatInput / ThreadChatInput 新测试
- `apps/web/e2e/chat-composer-performance.spec.ts`

因此解除 Round 1 blocker 后，Round 4 不能只审 vendored pin，必须把这些 upstream changed paths 纳入 dynamic supplier comparison。

---

## 6. T3 Current Source Targets

V2 guide 指定的当前源码目标包括：

- `apps/web-gen2/src/integration/huabu/LcosCanvasAdapter.tsx`
- `apps/web-gen2/src/host/createLcosHostRuntime.ts`
- `huabu/apps/web/src/lcos/LcosHostOverlay.tsx`
- `huabu/apps/web/src/lcos/LcosComposerShell.tsx`
- `huabu/apps/web/src/lcos/useLcosCanvasProps.tsx`
- `huabu/apps/web/src/components/Common/CanvasFloatingPopover.tsx`
- `huabu/apps/web/src/components/Panels/Canvas/FloatingToolbars/NodeFloatingToolbar.tsx`
- `huabu/apps/web/src/components/Panels/ChatPanel/ChatInput.tsx`
- `huabu/apps/web/src/components/Panels/ChatPanel/ThreadChatInput.tsx`
- `huabu/apps/web/src/components/Common/DropdownMenu.tsx`

这些当前都不是“缺源码 blocker”。

解除原文 blocker 后要逐个执行：

`consumer → owner → event path → state owner → mutation owner → persistence / recovery → test`

而不是看到文件存在就宣布功能完成。

---

## 7. Donor 当前状态

已取得 `LCOS_v015_VIDEO_DONOR_原稿总索引与施工映射_20260831.md`。

它明确要求 T3 / Phase A 回读：

- V02 Trae；
- V03 TapNow；
- V04 Lovart Composer；
- V05 Codex Desktop。

尤其：

- V04 是 Composer / Reference 一级 donor；
- V03 是 Spatial Interaction 一级 donor；
- donor 只提供 craft / interaction hierarchy / causality；
- 不允许 donor taxonomy 覆盖 LCOS product truth。

但 V04 / V05 以及 V01–V03 共用的解析原稿目前仍有 exact raw 缺口，所以 donor 状态只能记：

`INDEX_AVAILABLE / PARSED_RAW_INCOMPLETE`

不能进入 `ADOPTED` 或 `VERIFIED`。

---

## 8. 解除 blocker 后的固定执行顺序

收到缺失原文后，本线程从当前停止点继续，不重开架构讨论：

1. 完成 T3 Mandatory File Library `FULL_READ Completion Census`；
2. 全文读取 T3 指定 Gen2 ZIP 审计正文；
3. Round 2：current consumer / owner / runtime trace；
4. Round 3：historical user pain / supersession recovery；
5. Round 4：vendored Huabu vs current upstream + donor / license / API comparison；
6. Round 5：cross-boundary / recovery / contradiction audit；
7. 证据不足时进入 Round 6+；
8. 完成 `ADOPT / WRAP / LIFT / RETIRE / REJECT` 总账；
9. 证明没有 second pointer router / second selection / second drop owner / second Composer truth；
10. 最后才写 Source-Level Construction Plan。

规划阶段不写 production patch。

---

## 9. 最终施工规划交付格式

解除 blocker 并完成至少 5 轮审计后，T3 输出：

- `01_Evidence_Census_Authority_Recovery.md`
- `02_Current_Source_Consumer_Owner_Audit.md`
- `03_Donor_Upstream_Adoption_Retirement_Matrix.md`
- `04_Source_Level_Construction_Plan.md`
- `05_Acceptance_Recovery_CrossReview_Plan.md`
- `99_COORDINATOR_HANDOFF.md`

前 5 份按 V2 guide 要求为源码级长文档，不用功能 wishlist 冒充施工规划。

---

## 10. STOP

当前停止点：

`ROUND_1_CONTEXT_RECOVERY_BLOCKED_BY_9_T3_MANDATORY_EXACT_ORIGINALS`

当前不做：

- 不提前写 T3 construction cards；
- 不自行设计新的 pointer router；
- 不建第二 selection / reference / relation store；
- 不把 Action Arc 扩成 CRUD 菜单；
- 不把 Composer 做成固定侧栏；
- 不根据历史摘要猜 Relation / Glyth / three-surface 交互规则；
- 不拿 SHA / index / cumulative patch 冒充 exact original；
- 不因 current source 可访问就绕过产品原文证据。

下一输入应直接提供上述 9 份 standalone 原文，或提供包含它们的原始 `LCOS_GEN2_ACCOUNT_MIGRATION_20260902` / 对应 context package。
