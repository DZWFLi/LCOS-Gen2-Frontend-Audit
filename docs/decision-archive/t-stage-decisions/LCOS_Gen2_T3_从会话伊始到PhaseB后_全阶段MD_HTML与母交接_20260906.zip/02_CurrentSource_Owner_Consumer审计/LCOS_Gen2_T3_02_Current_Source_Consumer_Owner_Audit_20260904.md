# LCOS Gen2 · T3 第三路正式施工规划
## 02_Current_Source_Consumer_Owner_Audit
### Local Object Interaction / Action Arc / Compact Composer / Reference / Voice

> 日期：2026-09-04  
> 基线：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`  
> Vendored Huabu pin：`58339e269b784728d67730c70bfe7792cae2457d`  
> Huabu upstream observed：`dc128fff2d37b5481ec305070a7e86d3de85f7d2`  
> 文档性质：T3 五册正式交付中的第 02 册。  
> 本册回答：**当前每条交互链到底谁生产、谁消费、谁拥有，哪些能保留，哪些是假接线，哪些必须退役。**
>
> 注意：本册不是 production patch，不写“先造一个 manager 再说”。所有新 seam / store / contract 必须先有明确失败场景。

---

# 0. 结论

T3 当前不是“缺一套交互系统”。

恰好相反，基础机械已经相当完整：

```text
Huabu
├─ ReactFlow / pointer router
├─ Selection
├─ Drag / resize threshold
├─ NodeWrapper interaction phase
├─ node/takeover geometry
├─ CanvasFloatingPopover
├─ Popover / DropdownMenu
├─ ChatInput mechanics
└─ external HTML5 drop

LCOS Gen2
├─ ProjectionBinding
├─ Reference controller
├─ Reference recognizer
├─ Semantic Drop pure machine
├─ overlay arbitration
├─ Local Core Relation
├─ Local Core Receiver
├─ Local Core Runs
└─ Local Core Voice transcription
```

真正缺的主要是：

```text
1. selected-then-click → local affordance producer
2. Action Arc body + action policy
3. target-local Compact Composer body
4. Composer draft owner 与 UI body 解耦
5. explicit Reference Pick mode
6. right-click management menu 的 host wiring
7. LCOS-specific double-click 的极窄 activation seam（仅必要 species）
8. Semantic Drop 真实 destination hit/commit wiring
9. Voice recorder → Core transcription 的前端 adapter
10. Run/Receiver/Voice typed frontend clients
```

换句话说：

> **T3 不是重建，是接线、退役过渡壳、吃成熟 donor、把状态归回正确 owner。**

---

# 1. 状态标记

本册统一使用以下状态，避免所有东西都被写成模糊的“已有/未有”。

```text
WIRED_CURRENT
生产链、消费链、owner 和真实用户路径已经接上。

MECHANIC_EXISTS_NOT_LCOS_WIRED
通用机械已有，但 LCOS 业务路径还没有连接。

SEMANTIC_OWNER_EXISTS_UI_MISSING
语义/状态 owner 已有，缺 UI producer/body。

TRANSITIONAL_WRONG_SHAPE
有实现，但它明确只是 Phase A/过渡态，或与最新冻结 UX 不匹配。

MISSING_THIN_SEAM
缺一个很薄的中性 seam；若不补，只能把 LCOS 逻辑硬编码进 Huabu 或新建第二事件 owner。

MISSING_TYPED_CLIENT
Core route 已存在，但 web-gen2 端缺 typed client/adapter。

PROTECT
当前 owner 正确，施工不得换 owner。

RETIRE
后续正式路径完成后删除/停止生产。

CROSS_THREAD
T3 只消费接口，不在本线程定义 canonical truth。
```

---

# 2. 当前完整 Owner Map

## 2.1 Pointer / Gesture

Canonical mechanic owner：

```text
Huabu Canvas
→ useCanvasPointerRouter
→ stock recognizers
→ hostExtension.recognizers
```

LCOS 当前已经只通过 host extension 注入：

```text
reference-pick recognizer
semantic-drop observer
```

这一层必须 `PROTECT`。

禁止：

```text
document.addEventListener('pointerdown')
window.addEventListener('click')
独立 PointerRouter
第二 ReactFlow pointer graph
```

除非是明确局部 DOM 控件自己的 click。

---

## 2.2 Selection

Canonical owner：

```text
Huabu canvasStore / ReactFlow controlled selection
```

冻结规则：

```text
Shift = additive Selection
Ctrl/Cmd = LCOS Reference
```

Selection 不复制到 Reference。

Selection 不写 Relation。

`PROTECT`。

---

## 2.3 Reference

Pure semantic owner：

```text
apps/web-gen2/src/interaction/referenceController.ts
```

Presentation bridge：

```text
huabu/apps/web/src/lcos/lcosReferenceState.ts
```

Identity source：

```text
ProjectionBinding
→ listNodeBindings()
→ nodeId → CoreEntityRef
```

Recognizer：

```text
huabu/apps/web/src/lcos/lcosRecognizers.ts
```

当前状态：

```text
WIRED_CURRENT / PROTECT
```

需要扩展的是 explicit Reference Pick UX，不是替换 Reference truth。

---

## 2.4 Relation

Canonical owner：

```text
Local Core Relation
```

T3 只触发 intent。

不把关系写进：

```text
Selection
Reference
node local state
Arc state
Composer state
```

`CROSS_THREAD / PROTECT`。

---

## 2.5 Overlay arbitration

Pure owner：

```text
apps/web-gen2/src/interaction/overlayArbitration.ts
```

它已经知道：

```text
action-arc
composer
drop-preview
reference-badge
work-view
resize-handles
...
```

但是 production `LcosHostOverlay` 目前只真正喂：

```text
selection
drag
drop
composer pseudo-open
```

而：

```text
actionArcOpen = false
workViewOpen = false
```

所以：

```text
ARBITRATION_LOGIC = PROTECT
PRODUCTION_INPUT_WIRING = INCOMPLETE
```

---

## 2.6 Target geometry

当前最成熟的 owner：

```text
NodeWrapper
NodeFloatingToolbar
CanvasFloatingPopover
NodeTakeoverLayer / nodeCollapse mark
ReactFlow internal node geometry
```

T3 不自己计算 camera / world→screen。

`PROTECT`。

---

## 2.7 Composer

当前 visible shell：

```text
huabu/apps/web/src/lcos/LcosComposerShell.tsx
```

问题：

```text
fixed bottom-center
width 360
inline styles
prompt local component state
no submit
no voice
no target anchor
reference draft 与 prompt draft 分家
```

文件自身也声明后续被正式 Composer 接管。

状态：

```text
TRANSITIONAL_WRONG_SHAPE
RETIRE
```

---

## 2.8 Voice

Backend canonical owner：

```text
POST /runtime/voice/transcriptions
```

Core 已处理：

```text
multipart
audio validation
provider
AbortSignal
typed error
text response
```

Frontend：

```text
MISSING_TYPED_CLIENT
```

Recorder：

```text
当前 LCOS 无
成熟 MIT donor 可 LIFT
```

---

## 2.9 Run

Backend canonical owner：

```text
POST /projects/:projectId/runs
```

已有：

```text
instruction
outputIntent
target
contextArtifactIds
workspace
savedContext
provider
resultPolicy
session
receiverRef
orderedReferences
resultSlotId
dispatch
recover
sync
cancel
input-request
events
```

web-gen2 backend 目录目前没有 runs client。

状态：

```text
CORE = WIRED_CURRENT
WEB_GEN2 = MISSING_TYPED_CLIENT
```

---

## 2.10 Receiver

Core owner：

```text
connected-conversations
receiver-binding
receiver-handoff
```

包括：

```text
active receiver
prepare handoff
pending handoff
consume
main/context/workflow surface identity
selection snapshot
```

T3 Composer 不能自己猜 receiver。

状态：

```text
CORE = WIRED_CURRENT
T3 FRONTEND ADAPTER = MISSING
```

---

# 3. V6 26 项 Deep-Dive Checklist

---

# 3.1 Pointerdown

## Current owner

```text
Huabu useCanvasPointerRouter
ReactFlow / stock pointer path
hostExtension.recognizers
```

## Current producer

Canvas root pointer events。

## Current consumers

```text
placement recognizer
frame drag
sketch stroke move
lasso
LCOS reference pick
LCOS semantic-drop observer
```

## Current status

```text
WIRED_CURRENT
```

## T3施工裁决

不新增 pointerdown owner。

Action Arc / Composer 的 selected-then-click 识别，只允许：

```text
新增 observer recognizer
canClaim = false
```

除非某一独占手势真的需要 claim。

## Duplicate risk

若用 document/window listener：

```text
pointer router
+
global listener
```

将出现：

- 同一 pointer 生命周期两个 owner；
- drag cancellation 顺序不一致；
- panel/editor target filter 不一致；
- touch/pen grammar 被破坏。

## Replacement boundary

无。

## Acceptance

任何 T3 新交互必须能在 pointer router 单测中证明：

```text
drag owner 不变
Selection owner 不变
touch/pen 不被新逻辑抢走
```

---

# 3.2 Pointerup

## Current owner

同 pointer router / ReactFlow gesture lifecycle。

## Current T3 producer/consumer

Reference recognizer：

```text
pointerdown claim
move > slop cancel
pointerup toggle Reference
```

Drop observer：

```text
pointerup
→ tracking/dwell/preview 未提交则 cancel
```

## Status

```text
WIRED_CURRENT
```

## New requirement

selected-then-click 的 reveal 必须在 pointerup 才确认，不能 pointerdown 直接弹 Arc/Composer。

原因：

```text
pointerdown 时还不能知道用户是在 click 还是 drag
```

## Acceptance

```text
pointerdown + move > threshold + pointerup
= 0 local affordance reveal
```

---

# 3.3 Drag threshold

## Current owner

Huabu：

```text
getDragActivationDistance(input mode)
ReactFlow nodeDragThreshold
ReactFlow nodeClickDistance
```

Reference recognizer：

```text
SLOP_PX = 4
```

## Status

```text
CURRENT_CONTRADICTION
```

## Failure scenario

鼠标/pen/touch 的 Huabu threshold 可按输入模式变化，而 Reference 固定 4px。

结果可能出现：

```text
Huabu 判断为 click
Reference 判断成 drag-cancel
```

或反过来。

用户会看到同一轻微抖动：

```text
普通 click 可选中
Ctrl/Cmd click 却不加 Reference
```

## Resolution

Reference recognizer 不再拥有独立 magic `4`。

优先：

```text
从 Huabu drag activation policy 读取同源阈值
```

如果 Reference 因 semantic safety 必须更严格，也要通过同一 token/policy 明确派生，而不是 literal。

## Gate justification

不需要新增 gate。

普通单测 + pointer simulation 足够证明。

---

# 3.4 Double-click

## Current owner

Huabu ReactFlow：

```text
onNodeDoubleClick
```

当前 stock 行为：

```text
EXPANDABLE_TYPES
→ openPreviewNode(node.id, transient)
```

## Status

普通 content node：

```text
WIRED_CURRENT
```

LCOS special species：

```text
POTENTIAL MISSING_THIN_SEAM
```

## Concrete failure scenario

Glyth 双击若冻结语义要求：

```text
Open Glyth-specific work / conversation-local work
```

而 stock Huabu 只会按 native node type Preview。

没有 seam 时只能：

A. 在 Huabu Canvas 硬编码：

```text
if LCOS Glyth...
```

B. LCOS 再建 window dblclick listener。

两者都坏。

## Conditional seam

只有确认 species-specific double-click 真的与 stock Preview 不同，才新增中性：

```text
activationIntent
```

概念返回：

```text
handled
native
```

Huabu 不知道 Glyth。

## Retirement

若所有 LCOS species 最终都可用 stock Preview：

```text
不新增 seam
```

---

# 3.5 Selected-then-click

## Latest UX

第一 click：

```text
Selection
```

稳定已选对象再 click：

```text
局部 affordance reveal
```

不是第一下就弹满屏控件。

## Current owner

无正式 LCOS producer。

## Status

```text
MISSING_THIN_SEAM
```

## Recommended mechanic

新增到现有 Huabu pointer router 的：

```text
local-affordance observer recognizer
```

特征：

```text
canClaim=false
mouse primary
记录 pointerdown 时 target
记录 target 当时是否已经 selected
move 超 Huabu threshold → candidate cancel
pointerup stable
→ request local affordance
```

## Why observer

Selection / drag 仍由 Huabu。

T3 只观察：

```text
“这个手势最终是不是已选对象的稳定再次点击”
```

## Do not do

```text
onClick local state inside every node renderer
```

这会让不同 species 各有一套 timing。

---

# 3.6 Contextmenu

## Current Huabu state

Canvas root 已：

```text
onContextMenu
```

对：

```text
input
textarea
select
contenteditable
a[href]
```

保留 native。

其余：

```text
preventDefault()
```

但没有 LCOS menu producer。

## Status

```text
MECHANIC_EXISTS_NOT_LCOS_WIRED
```

## Problem

当前事件被吃掉，却没交给 host。

若 LCOS 自己用 document `contextmenu`：

```text
第二 event owner
```

## Thin seam justification

这是一个具体失败场景，普通类型/测试不能消掉：

```text
Huabu root 已经拥有并阻止 contextmenu，
host 若无回调就拿不到正式事件。
```

因此可以扩展现有 `CanvasHostExtension`，提供极窄 neutral callback：

```text
context menu intent
```

输入应只包含中性信息：

```text
nodeId | null
screen point
surface/canvas id if already neutral
```

Huabu 不认识 LCOS action。

## Alternative

若 ReactFlow 已能在同一 Canvas.tsx 直接 wiring：

```text
onNodeContextMenu
onPaneContextMenu
```

优先使用这些 native props，再转 host callback。

仍不新增 global listener。

---

# 3.7 Escape

Escape 不是一个“全局超级 Manager”。

当前已有 owner：

```text
Popover
DropdownMenu
node placement
editor
...
```

## T3 rule

每个 transient owner 只在 active 时监听 Escape。

优先级由 UI nesting 自然决定：

```text
menu/popover
→ reference pick
→ local affordance
→ Composer close policy
```

## Reference Pick

Esc：

```text
exit pick
keep Composer
keep draft
keep already picked References
```

## Drop

当前 pointer cancel/up 有 reset。

需要补：

```text
active drop + Escape → idle
0 Core side effect
```

## Composer

不得：

```text
Escape = 清空 draft
```

关闭 visible body 与丢弃 draft是两回事。

---

# 3.8 Modifier Reference

## Current

```text
Ctrl/Cmd + click
```

已实现。

Shift：

```text
Huabu additive Selection
```

## Status

```text
WIRED_CURRENT / PROTECT
```

## Current strengths

- only mouse primary；
- LCOS projected/bound only；
- unbound node fail-close；
- no fabricated identity；
- pointerup commit；
- order preserved；
- click suppressor prevents Selection mutation。

## Required change

仅统一 drag threshold。

不重写 Reference grammar。

---

# 3.9 Action Arc reveal

## Current

overlay arbitration 已有：

```text
'action-arc'
```

production host：

```text
actionArcOpen=false
```

body：

```text
不存在
```

## Status

```text
SEMANTIC_OWNER_MISSING_SMALL
UI_MISSING
```

## Correct architecture

```text
stable selected re-click
→ local affordance presentation state
→ target identity
→ resolveLocalObjectActions(target, context)
→ top 3–5
→ ActionArcBody
```

## Pure resolver

推荐：

```text
resolveLocalObjectActions()
```

不是 registry。

输出 discriminated union action descriptor。

理由：

- Arc 与 Right-click 复用语义；
- 但不需要运行时动态 registration；
- 普通 pure function/union 已够；
- 新 registry 只增加生命周期和变异入口。

## Body

可替换。

Radial geometry 可吃 MIT Orbit。

Pointer / positioning 不交给 Orbit。

---

# 3.10 Composer reveal

## Current

`LcosComposerShell` 自己根据：

```text
refs
focus
prompt
```

决定 render。

`LcosHostOverlay` 却把：

```text
composerOpen = !dropActive
```

## Status

```text
TRANSITIONAL_WRONG_SHAPE
```

## Contradiction

“没有 drop”显然不等于“Composer open”。

当前只是因为壳自己又 return null 才没常驻。

正式 Composer 一旦加入 target anchor、voice、draft persistence，就会产生：

```text
overlay arbitration 说开
body 说关
```

两个 visibility owner。

## Resolution

必须只有一个 local-affordance presentation state：

```text
closed
arc(target)
composer(target)
```

互斥。

drop/workview 等高优先级输入只做 arbitration suppression。

不能反过来成为“open producer”。

---

# 3.11 Composer focus

## Frozen behavior

Composer reveal 不能自动抢 focus。

## Why

selected-then-click 之后用户可能：

```text
继续 drag
继续点击另一对象
按 shortcut
```

自动 focus 会：

- 抢键盘；
- 改 editing phase；
- 破坏 drag；
- 让 Space/shortcut 落进 textarea。

## Current

`LcosComposerShell` 不主动 focus，只有真实 input click。

这个原则保留。

## New body

```text
reveal → visible, focus false
user click textarea → focus
```

若通过明确 keyboard command “Compose” 打开，则 keyboard invocation 可允许 explicit focus，但必须是另一条可证明的入口，不是 pointer reveal 默认。

---

# 3.12 Textarea selection

## Current mechanics

Huabu：

- Canvas contextmenu 排除 textarea/input；
- NodeWrapper 有 editing phase；
- ChatInput IME-safe；
- panel target / editable target已有若干输入政策。

## T3 rule

local-affordance observer 对：

```text
input
textarea
select
contenteditable
interactive child
```

必须 pass。

## Failure prevented

在 textarea 拖选文字时：

```text
pointermove
```

不能被识别为 canvas selected-then-click / drag。

右键：

```text
保留 native editing menu
```

---

# 3.13 Attachment drop

## Current mechanic

Huabu `ChatInput` 已有：

```text
dragover
dragleave
drop
paste
image/pdf/text upload
pending attachment
```

## Status

```text
MECHANIC_EXISTS_NOT_LCOS_WIRED
```

## Important semantic boundary

不能因为 mechanic 成熟，就自动决定：

```text
“LCOS Compact Composer 的文件 = Reference”
```

这个映射必须有产品/Core semantics 支持。

因此当前可直接复用的是：

```text
input-surface drop handling mechanics
file reading/upload affordance mechanics
```

而“生成何种 LCOS input object”仍由 Composer adapter 决定。

## Construction direction

优先把 Huabu ChatInput 中 generic attachment/input mechanics 抽/复用为 common body。

不要复制整份到 LCOS。

---

# 3.14 External drop

## Current Huabu

Canvas 已能：

```text
internal Huabu payload
native files
URL
plain text
```

落为 native canvas node。

## Status

```text
WIRED_CURRENT for native Huabu canvas
```

## LCOS caveat

LCOS Semantic Drop 是另一层：

```text
“把一个 payload 拖到具有业务语义的具体 destination”
```

它不应劫持所有 external file drop。

普通空画布 file drop：

```text
Huabu native owner
```

明确 LCOS semantic target：

```text
Semantic Drop path
```

## Do not duplicate

不要同时让同一个 file drop：

```text
Huabu addNode
+
LCOS semantic commit
```

必须在 target resolution 后只有一个 commit owner。

---

# 3.15 Semantic Drop

## Current pure machine

```text
idle
tracking
dwell
preview
committing
failed
```

closed payload：

```text
object
file
text/url
assembly
```

这是正确的 fabric。

## Current host adapter

`lcosDropState` 硬编码：

```text
surface:left-dock
surface:bottom-dock
```

## Status

```text
MACHINE = PROTECT
DESTINATION RESOLVER = TRANSITIONAL_WRONG_SHAPE
COMMIT = MISSING
```

## Latest UX conflict

最新冻结不接受：

```text
“拖到感应区 → 弹分类选项”
```

正确：

```text
拖到哪个具体 visible object/container/slot
→ 那里就是 intent
```

所以 edge dwell 可保留为内部显隐/空间导航机制，但不能是用户最终 semantic destination taxonomy。

---

# 3.16 Drop dwell

## Current tokens

```text
dwellBand = 56px
dwellMs = 420ms
dwellRadius = 10px
cancelDistance = 16px
```

## Status

```text
MECHANIC_EXISTS
CURRENT_DESTINATION_USE_IS_TRANSITIONAL
```

## Final role

Dwell 适合：

- edge navigation reveal；
- hidden dock reveal；
- transient destination discovery；
- carry/hysteresis。

不适合：

```text
dwell 完成后再问用户“你到底要放哪”
```

## Acceptance

最终浏览器测试必须测：

```text
意外掠过 edge 不触发
稳定停留触发
移动离开恢复 tracking
visible destination hover 后 preview 保持
```

---

# 3.17 Drop cancel

## Current

pointerup/pointercancel：

```text
tracking/dwell/preview
→ idle
```

## Missing

- Escape；
- source unmount；
- project/canvas swap；
- WorkView/surface disposal；
- recoverable failed 的明确 retry/return policy。

## Status

```text
PARTIAL
```

## Requirement

任何 preview 前/preview 中 cancel：

```text
0 Core mutation
0 Projection mutation
0 Relation mutation
```

committing 后：

```text
按 transaction result 收口
不能 UI 假装 reset 就等于 rollback
```

---

# 3.18 Glyth body drop

## Frozen semantic

四个相邻概念必须分开：

```text
spatial proximity
= Huabu geometry

drop onto Glyth body
= durable Conversation Context Mapping

Ctrl/Cmd click
= current Run Reference

relation port
= Project Relation
```

## Current production

Glyth durable body drop 尚未正式 wired。

## Status

```text
SEMANTIC_OWNER_KNOWN
UI/INTENT_WIRING_MISSING
```

## Construction rule

不要新建：

```text
GlythPointerRouter
GlythDropManager
```

generic semantic target resolver 根据：

```text
ProjectionBinding
species / target adapter
actual body hit
```

输出：

```text
GlythContextDestination
```

commit 交给正式 Core owner。

## Body bounds

必须是真实 Glyth body。

不是：

```text
周围 halo 大矩形
整个 renderer bbox
邻近距离
```

Halo 只能 feedback，不是 hit truth。

---

# 3.19 Receiver

## Current Core

已有完整 receiver runtime routes：

```text
connected-conversations
receiver-binding
receiver-handoff
```

## Status

```text
CORE WIRED_CURRENT
T3 FRONTEND MISSING_TYPED_CLIENT
```

## Composer rule

Run submit 时 receiver 必须来自：

```text
active receiver / explicit receiver selection
```

不能从：

```text
当前 node title
当前 Selection
最后打开的 chat
```

猜。

## Cross-thread

Receiver client/typed contract 与 T6 对齐。

T3 只消费。

---

# 3.20 Right click

Right click 是 contextmenu 的 product layer。

## Action scope

Right-click / More：

```text
Open / Focus
Pin
Add Reference
Assembly
Duplicate（若允许）
Reveal / Source
Delete / Remove Projection
More...
```

## Arc scope

只 3–5 高频动作。

## Shared semantic source

二者共享：

```text
resolveLocalObjectActions(target, context)
```

但不同 filter：

```text
Arc = direct/high-frequency
Menu = management/full allowed set
```

## UI mechanics

```text
Huabu Popover
Huabu DropdownMenuItem
```

不造新的 menu framework。

---

# 3.21 Multi select

## Current owner

Huabu Selection。

已有：

```text
MultiSelectToolbar
MultiSelectResizer
selection rectangle
```

## Status

```text
WIRED_CURRENT
```

## T3 rule

generic single-target Composer 不应自动绑定多选。

默认：

```text
multi selection
→ Huabu multi-select mechanics
```

若未来有 explicit multi-target Compose：

必须单独有冻结产品语义。

不能把：

```text
selectedNodeIds
```

直接复制成 Reference list。

## Arc

单对象 Arc 默认 suppressed。

---

# 3.22 Editing node

## Current owner

NodeWrapper：

```text
hovered
editing
isResizing
isDragging
selected
```

并解析 interaction phase：

```text
editing > resizing > dragging > selected > hovered > rest
```

## Status

```text
WIRED_CURRENT / PROTECT
```

## T3 rule

editing phase 时：

```text
不自动 reveal generic Arc
不自动 reveal generic Composer
```

除非编辑器自身明确提供局部 AI action。

contextmenu：

```text
native editor menu
```

Selection 与 text selection 不混。

---

# 3.23 Takeover mark

## Current mechanics

NodeWrapper / NodeFloatingToolbar 已能：

```text
collapsed/takeover
→ blended mark rect
→ floating toolbar anchor
```

## Status

```text
MECHANIC_EXISTS
T3 NOT YET WIRED
```

## T3 rule

Action Arc / Composer 不能自己算：

```text
node original bbox
```

当 body 已 takeover 时，应 anchor：

```text
same takeover mark geometry
```

## Cross-thread

T1 给 mark/presentation。

T3 消费 anchor。

---

# 3.24 WorkView target

## Current arbitration

`overlayArbitration` 已：

```text
workViewOpen → work-view exclusive
```

production：

```text
workViewOpen=false
```

## Status

```text
ARBITRATION EXISTS
REAL T4 STATE NOT WIRED
```

## T3 rule

Work View 打开：

- 不移动 camera；
- local Arc/Composer 被 arbitration suppress；
- draft 不因 body unmount 丢失；
- 回来可恢复 target/draft；
- placement 使用 T4/T2 safe/occupied rect 约束。

## Critical draft implication

如果 prompt 仍是 `LcosComposerShell` local `useState`：

```text
WorkView suppress/unmount
→ prompt lost
```

而 Reference store 还在。

产生：

```text
refs survive
prompt disappears
```

这是不能接受的 current architecture split。

---

# 3.25 Voice

## Backend

已有。

## Recorder

当前 LCOS 无。

## Donor

CopilotKit MIT `CopilotChatAudioRecorder` 可以 LIFT：

```text
MediaRecorder
AudioContext
MIME fallback
permission errors
cleanup
waveform
idle/recording/processing
```

## Frontend transport gap

当前 `HttpClient`：

```text
JSON.stringify(body)
Content-Type: application/json
```

不能正确发 FormData audio。

## Status

```text
CORE = WIRED_CURRENT
RECORDER = DONOR_READY
TRANSPORT = MISSING_THIN_METHOD
COMPOSER UI = MISSING
```

## Correct flow

```text
Idle
→ Recording
→ Transcribing
→ Editable Text
→ Explicit Send
```

## Never

```text
voice stop
→ auto submit Run
```

---

# 3.26 Run submit

## Core

已存在。

## Current T3

Composer shell：

```text
no submit
```

web-gen2 backend：

```text
no runs client
```

## Status

```text
MISSING_TYPED_CLIENT + UI WIRING
```

## Correct payload source

```text
instruction
= Composer prompt

orderedReferences
= Composer explicit ordered Reference

target
= explicit target adapter / Core identity

receiverRef
= receiver owner

outputIntent
= target/action policy

provider/skill
= explicit resolved selection
```

## Never infer

```text
Selection → orderedReferences
title → target
last open conversation → receiver
Arc state → persisted Run truth
```

## Recovery

Run failure：

```text
draft remains editable
References remain
target remains
error surfaced locally
retry creates/dispatches according to Core semantics
```

不清空 draft 作为“错误处理”。

---

# 4. Gesture State Matrix

下面是 V6 强制要求的不同 target 类型下事件所有权。

---

## 4.1 Blank canvas

| Event | Owner | T3 behavior |
|---|---|---|
| pointerdown | Huabu | pass |
| pointermove | Huabu pan/lasso/tool | T3 pass |
| pointerup | Huabu | no Arc/Composer |
| dblclick | Huabu/native product behavior | T3 none |
| contextmenu | Huabu host seam | blank-area management menu only if frozen |
| Escape | active tool owner | T3 none |
| Ctrl/Cmd click | no bound node | Reference recognizer pass |

禁止：

```text
blank click → generic Composer
```

除非未来有明确 global-compose command。

---

## 4.2 Content node · unselected

| Event | Owner | Behavior |
|---|---|---|
| first stable click | Huabu Selection | select |
| drag | Huabu | move |
| dblclick | Huabu stock Preview | open if expandable |
| right click | host contextmenu seam | management menu |
| Ctrl/Cmd click | Reference recognizer | add/remove Reference without Selection |
| Shift click | Huabu | additive Selection |

第一 click 不直接弹工具串。

---

## 4.3 Content node · already selected

| Event | Owner | Behavior |
|---|---|---|
| stable re-click | T3 observer after Huabu | reveal local affordance |
| drag | Huabu | cancel reveal candidate |
| dblclick | stock Huabu / optional LCOS activation | open |
| right click | context menu path | management |
| Escape | local affordance | close transient |

local affordance policy可选择：

```text
Arc
Composer
或 Arc 内 Compose action
```

具体 species policy进入第 04 册，不在 pointer层硬编码。

---

## 4.4 Functional node / Surface Component

冻结原则：

```text
自身 Functional Face 优先
```

因此：

| Event | Behavior |
|---|---|
| click functional control | component owner |
| click body | Selection |
| stable re-click | 仅若 component policy允许 local affordance |
| generic Composer | 默认不自动 |
| contextmenu | management only |
| drag | Huabu |

不能把 Structural/Functional component 全部当“内容卡”。

---

## 4.5 Glyth

| Event | Semantic |
|---|---|
| stable click | Selection |
| selected re-click | Glyth local affordance |
| Ctrl/Cmd click | current Run Reference |
| body drop | durable Conversation Context Mapping |
| relation port | Project Relation |
| dblclick | Glyth-specific open/work if frozen |
| right click | management |
| spatial proximity | 只是 geometry |

这是 T3 最重要的“不要语义串台”。

---

## 4.6 Multi selection

| Event | Behavior |
|---|---|
| Shift click | Huabu additive |
| body drag | Huabu multi move |
| resize | Huabu MultiSelectResizer |
| selected re-click | 不弹 single-target Arc |
| Composer | 不自动 |
| Reference | 不由 multi selection派生 |
| right click | 若支持 multi management，则明确 multi action policy |

---

## 4.7 Frame / container

Frame 是空间结构。

| Event | Behavior |
|---|---|
| click | Huabu Selection |
| drag | Huabu |
| resize | Huabu |
| drop child | Huabu container/structured drop owner |
| selected re-click | 结构操作优先，不自动 content Composer |
| contextmenu | frame management |
| Relation | 不因 containment 自动写 Core relation |

---

## 4.8 Edge / relation path

| Event | Behavior |
|---|---|
| click | Huabu edge selection |
| dblclick | current Huabu label editor |
| contextmenu | edge management if exposed |
| Composer | 不自动 |
| Relation edit | Relation owner |
| drag | edge/handle mechanics |

不要把 edge 当 node target 喂给 generic Composer。

---

## 4.9 Editing text

| Event | Behavior |
|---|---|
| pointerdown/move | text/editor |
| selection drag | text selection |
| contextmenu | native |
| Escape | editor semantics first |
| Ctrl/Cmd click | 不触发 Reference unless click is outside editable surface and grammar明确 |
| Arc | suppressed |
| generic Composer | suppressed |

---

## 4.10 External file drag

空画布：

```text
Huabu native file drop
```

进入明确 LCOS semantic target：

```text
Semantic Drop
```

目标 resolving 前不得双 commit。

---

## 4.11 Modifier Reference

```text
Ctrl/Cmd
→ Reference path

Shift
→ Selection path
```

同一 pointer gesture 不能两边都写。

---

## 4.12 WorkView occupied

```text
WorkView open
→ local overlay body suppressed
→ camera unchanged
→ draft preserved
→ safe/occupied rect constrains future popovers
```

T3 不自己定义 occupied rect。

---

## 4.13 Takeover / collapsed mark

点击 mark：

```text
仍解析到同一 node / Core identity
```

floating Action Arc / Composer：

```text
anchor same mark geometry
```

不能突然跳回原 full-card bbox。

---

# 5. Round 5 · Contradiction / Recovery Audit

---

## C01 · Reference 4px slop vs Huabu threshold

状态：

```text
REAL_CONTRADICTION
```

解决：

```text
同源 threshold
```

不新增 token registry。

---

## C02 · `composerOpen = !dropActive`

状态：

```text
TRANSITIONAL_FALSE_OWNER
```

问题：

“非 drop”并不代表 Composer open。

解决：

```text
explicit local-affordance state
```

overlay arbitration 只消费，不生产 open。

---

## C03 · Action Arc / Composer 两个独立 boolean

`visibleOverlays()` 当前按：

```text
composer first
actionArc second
```

如果未来两个生产者都能置 true：

```text
Composer 永远遮住 Arc
```

这不是产品政策，是 if 顺序副作用。

解决：

```text
local affordance mode 是互斥 union
closed | arc(target) | composer(target)
```

转换给 arbitration：

```text
composerOpen = mode==='composer'
actionArcOpen = mode==='arc'
```

普通 union 足够，不需要状态机框架。

---

## C04 · Prompt local state vs Reference persistent presentation state

当前：

```text
prompt = React useState inside shell
References = Zustand store
```

WorkView/drop arbitration 可能 unmount shell。

结果：

```text
prompt lost
references survive
```

用户看到一个半残 draft。

解决：

需要一个**单一 ephemeral Composer draft owner**。

这里新增 store 是有具体失败场景支持的。

推荐迁移：

```text
ProjectionRefIndex
= nodeId → CoreEntityRef derived cache

ComposerDraft
= target + prompt + orderedRefs + selected skill/tool + voice transient metadata
```

纯 `referenceController` 算法继续复用。

不把 Selection/Relation 放进去。

---

## C05 · `lcosReferenceState` 同时装 identity cache + draft

现在一个 store 有：

```text
nodeEntityRefs
draft ordered refs
```

这在 Phase A 可用，但正式 Composer draft owner出现后应拆职责。

不一定必须两个 Zustand store。

可以：

```text
lcosProjectionRefIndex
纯 derived identity cache

lcosComposerDraftState
唯一 draft owner
```

或等价模块。

关键是：

```text
binding cache lifecycle
≠ draft lifecycle
```

项目 reconcile 可 reset identity cache，但不应无理由清正在编辑的 prompt。

---

## C06 · Semantic Drop destination 坐标语义混杂

pure machine 的注释混用：

```text
screen-space px
world/space placement
```

host state实际把 wrapper-relative px 塞进 `destination.place`，preview又直接 absolute left/top。

Phase A视觉能工作，但正式 durable commit 会危险：

```text
到底这个 point 是 screen、wrapper、flow、world？
```

解决：

最终 destination descriptor 分开：

```text
previewAnchor
= screen/wrapper presentation

semanticTarget
= identity / slot / Core target

worldPlacement
= 仅在确实需要自由落位时由 Huabu transformer生成
```

不要一个 `place:{x,y}` 承担三种坐标真相。

---

## C07 · `overDestination` production 永远 false

pure machine支持：

```text
preview carry zone + overDestination
```

但 current recognizer：

```text
advance(..., false, ...)
```

真实具体 target hit 从未接入。

解决：

```text
Huabu hit test
→ semantic target resolver
→ overDestination + target descriptor
```

不能只继续调 dwell token。

---

## C08 · Semantic Drop 没有真实 commit producer

状态机有：

```text
confirmDrop(transactionId)
```

但 current recognizer在 preview pointerup 时直接 cancel。

没有生产路径调用：

```text
commitAt
```

所以当前“committing”更像设计占位。

解决：

在 concrete target resolver + target adapter存在后：

```text
pointerup over confirmed target
→ host/core mutation
→ transaction id
→ committing
→ success idle / failure failed
```

不得 UI 先改状态再假装 Core 已写。

---

## C09 · Recoverable failed 没有 recovery transition

current failed：

```text
reason
recoverable
```

但 store没有：

```text
retry
backToPreview
backToTracking
```

最终若 UI显示“可恢复”却只能 reset，就语义虚假。

解决：

根据真正 commit API 的幂等/transaction语义，在第 05 册定义。

在证明前不随便加 retry button。

---

## C10 · Contextmenu 当前 root owner 吞掉事件

Huabu防浏览器菜单是正确的。

但 LCOS host无法正式消费。

解决：

扩现有 host seam，而不是 global listener。

这是 justified seam。

---

## C11 · Double-click species override

同上。

只在明确 LCOS species 与 stock Preview不同后添加。

不先加“为了以后”。

---

## C12 · WorkView suppression vs draft continuity

overlay arbitration workView exclusive 是对的。

但 visible body unmount 不能等于 draft销毁。

所以 draft owner必须在 replaceable Composer body之上。

---

## C13 · Voice recorder state vs transcript state

donor recorder state：

```text
idle/recording/processing
```

LCOS product state：

```text
Idle
Recording
Transcribing
Editable Text
Explicit Send
```

不要直接拿 donor `processing` 当产品 transcript truth。

adapter负责映射：

```text
recorder processing
→ audio blob ready
→ Core transcription request
→ transcript received
→ prompt text
```

---

## C14 · Voice failure recovery

失败场景：

```text
microphone denied
no mic
MediaRecorder failure
transcription 503/502
upload abort
```

要求：

- draft prompt 不清；
- references 不清；
- target 不清；
- recorder资源 dispose；
- permission错误局部展示；
- transcription retry不重复录音时可保留 audio blob 的策略必须明确，否则明确要求重录。

不引入后台自动 retry gate。

---

## C15 · Run failure vs Composer reset

POST Run可能 409。

不能：

```text
点击 Send
→ 先清空 prompt
→ 失败后 toast
```

正确：

```text
submit snapshot
→ Core accepted 201 后再按产品政策 clear/roll draft
```

失败：

```text
保留 draft
```

---

## C16 · Receiver guessing

Core已经有 active binding。

前端若根据 UI最近状态猜 receiver，会产生：

```text
UI target != Core active receiver
```

所以 Run adapter必须显式读取 receiver binding/selected receiver。

---

## C17 · Attachment mechanic vs Reference semantics

Huabu Chat attachment primitive很成熟。

但“附件”与 LCOS “Reference”不是自动同义词。

最终需要：

```text
attachment adapter
```

决定是：

- upload artifact then explicit Reference；
- ephemeral input；
- unsupported。

证据不足前不静默合并。

---

## C18 · Structural component generic Composer

最新冻结已经禁止 Structural Surface Component 因 selection自动弹 generic Composer。

action resolver必须先看 target capability/species。

不是“所有 node type都有 Compose”。

---

# 6. 推荐的 Presentation State 最小形态

为了让 recognizer、overlay、body 共享 transient UI，不得不有一个明确 owner。

不用做大 FSM。

概念形态：

```ts
type LocalAffordance =
  | { kind: 'closed' }
  | { kind: 'arc'; targetNodeId: string }
  | { kind: 'composer'; targetNodeId: string }
```

Composer draft另有：

```ts
type ComposerDraft = {
  target: CoreEntityRef | null
  prompt: string
  orderedReferences: readonly CoreEntityRef[]
  selectedSkillOrTool?: ...
}
```

Reference Pick：

```ts
type ReferencePickMode = 'idle' | 'composer-pick'
```

它可以作为 draft presentation 子状态。

不新增：

```text
ActionArcStore
ComposerVisibilityStore
ReferencePickStore
VoiceStore
```

四个互相同步的 store。

那会再次制造协调成本。

---

# 7. 为什么 Composer Draft Store 是少数合理新增 state owner

用户默认纪律是不随便新增 contract/baseline/gate。

这里新增 draft owner 有明确失败场景：

```text
当前 prompt 只在 LcosComposerShell React local state
当前 refs 在 Zustand
overlay arbitration 会因 drop/workview unmount shell
→ prompt 消失，refs 留下
```

React local state、Git、类型、普通测试都不能解决跨 body replacement/unmount 的 runtime continuity。

因此需要一个显式 ephemeral draft owner。

它：

```text
不持久化 Core truth
不取代 Run
不取代 Reference pure semantics
不取代 Selection
```

只是当前未提交 Composer 草稿。

---

# 8. Candidate Source-Level Boundaries

注意：这是 Current Owner Audit 导出的候选范围，不是第 04 册最终 patch 卡。

## KEEP

```text
apps/web-gen2/src/interaction/referenceController.ts
apps/web-gen2/src/interaction/overlayArbitration.ts
apps/web-gen2/src/interaction/semanticDropMachine.ts  # pure fabric only

huabu/apps/web/src/components/Common/CanvasFloatingPopover.tsx
huabu/apps/web/src/components/Common/Popover.tsx
huabu/apps/web/src/components/Common/DropdownMenu.tsx
huabu/apps/web/src/components/Panels/Canvas/FloatingToolbars/NodeFloatingToolbar.tsx
huabu/apps/web/src/components/Nodes/NodeWrapper.tsx
huabu/apps/web/src/lcos-seam/nodePresentation.tsx
```

## MODIFY / WRAP

```text
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/lcos/lcosRecognizers.ts
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
huabu/apps/web/src/lcos-seam/types.ts          # only justified neutral seams
huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx  # route host callbacks, no LCOS semantics
apps/web-gen2/src/backend/client.ts            # FormData/raw transport
```

## RETIRE / REPLACE BODY

```text
huabu/apps/web/src/lcos/LcosComposerShell.tsx
```

## SPLIT RESPONSIBILITY

```text
huabu/apps/web/src/lcos/lcosReferenceState.ts
```

把：

```text
ProjectionBinding-derived node index
```

与：

```text
Composer draft
```

生命周期解耦。

## REPLACE TRANSITIONAL ADAPTER

```text
huabu/apps/web/src/lcos/lcosDropState.ts
huabu/apps/web/src/lcos/LcosDropPreview.tsx
```

不是删除 pure machine，而是把 hardcoded edge destination 替成 real semantic target adapter。

## ADD, only if evidence remains

```text
web-gen2 backend Runs client
web-gen2 backend Receiver client
web-gen2 backend Voice transcription client
local affordance presentation owner
Composer draft owner
pure local action resolver
ActionArcBody
CompactComposerBody
Voice recorder adapter
semantic drop target resolver
```

具体文件名第 04 册再冻结，避免现在为了目录美学制造 contract。

---

# 9. Current Source “Don’t Rewrite” Ledger

| Area | Current owner | Decision |
|---|---|---|
| pointer routing | Huabu | PROTECT |
| drag threshold | Huabu | PROTECT; Reference align |
| selection | Huabu | PROTECT |
| multi select | Huabu | PROTECT |
| node geometry | ReactFlow/Huabu | PROTECT |
| takeover geometry | Huabu | PROTECT |
| flow→screen floating | CanvasFloatingPopover | PROTECT |
| generic popover | Huabu | PROTECT |
| menu primitive | Huabu | PROTECT |
| reference pure semantics | LCOS referenceController | PROTECT |
| node→Core identity | ProjectionBinding | PROTECT |
| Relation | Core | PROTECT |
| Run | Core | PROTECT |
| Receiver | Core | PROTECT |
| Voice transcription | Core | PROTECT |
| current Composer shell | LCOS Phase A shell | RETIRE |
| drop pure FSM | web-gen2 | PROTECT |
| drop edge destination adapter | LCOS Phase A bridge | RETIRE/REPLACE |

---

# 10. Current Source “Thin New Code Only” Ledger

真正合理的新增量必须满足：

```text
没有它就会出现第二 owner
或
现有 canonical owner 无法被 UI消费
```

## 10.1 Local affordance observer

理由：

selected-then-click 产品语义当前没有 producer。

但必须插现有 pointer router。

---

## 10.2 Local affordance presentation owner

理由：

recognizer 与 overlay/body需要共享：

```text
target + arc/composer mode
```

不能用事件 emitter 伪装状态。

---

## 10.3 Composer draft owner

理由：

当前 prompt/ref跨 unmount 不一致。

---

## 10.4 Contextmenu host callback

理由：

Huabu 已吞正式 contextmenu，host没有路径消费。

---

## 10.5 Optional activation callback

只在 species-specific double-click确实不同于 stock时。

---

## 10.6 Voice FormData transport

理由：

现 HttpClient强制 JSON。

---

## 10.7 Typed Run/Receiver/Voice clients

理由：

Core route已存在，但 web-gen2无 client。

这些 client只做：

```text
typed request
error normalization
AbortSignal
```

不持业务 state。

---

# 11. Recovery Ownership

T3 UI failure 不能污染 canonical truth。

## Action Arc

关闭/渲染失败：

```text
0 data side effect
```

## Composer body crash/unmount

draft owner仍在。

## Reference Pick cancel

已有 refs保留。

## Voice fail

draft/refs/target保留。

## Run submit fail

draft保留。

## Drop pre-commit fail/cancel

0 Core mutation。

## Drop post-commit network ambiguity

必须由 transaction/Core recovery处理，不能 UI reset假装成功或失败。

## WorkView open/close

target/draft continuity由 T3 presentation/draft owner保持，camera由 Huabu/T2/T4。

---

# 12. Cross-Thread Boundaries

## T1 Spatial/HUD

T3消费：

```text
takeover mark anchor
node body geometry
spatial hit result
```

不定义 camera。

---

## T2 Viewport/Chrome

T3消费：

```text
safe rect
occupied rect
global navigation conflicts
```

不实现 HUD truth。

---

## T4 Work View / Assembly / Context / Workflow / Skill

T3消费：

```text
WorkView open state
target action
Skill selection
Assembly action
```

不造 WorkView local copy。

---

## T5 Visual

T3输出：

```text
ActionArc contract
Composer contract
Reference satellite states
Voice states
motion ranges
```

T5换 visual body不能改 T3 semantics。

---

## T6 Runtime/Core

T3依赖：

```text
Run client
Receiver client
Voice client
Glyth context mutation adapter
Relation actions
```

T3不重新定义 Core payload。

---

# 13. Acceptance Scenarios

至少覆盖以下真实浏览器行为。

## A. 普通内容节点

1. first click only selects；
2. stable selected re-click reveals local affordance；
3. small movement over threshold starts drag, no reveal；
4. double click keeps native Preview unless LCOS handler explicitly handles；
5. right click menu appears at pointer；
6. click menu item does not alter Selection unless action semantics says so。

## B. Reference

1. Shift click additive selection；
2. Ctrl/Cmd click Reference；
3. Ctrl/Cmd tiny jitter follows same threshold policy；
4. reference pick does not select；
5. unbound node fail-close；
6. explicit Composer Pick uses same Reference controller；
7. Esc exits Pick, draft remains。

## C. Composer

1. reveal near target；
2. no auto focus on pointer reveal；
3. click textarea focuses；
4. 1–2 line idle；
5. grows to max 3–4 desired LCOS spec, then scroll；
6. WorkView suppresses body but draft survives；
7. target moves/pans/zooms and popover follows；
8. target collapses takeover and Composer anchors mark；
9. drag target suppresses Composer without clearing draft。

## D. Voice

1. mic denied local error；
2. recording resources dispose on cancel；
3. stop produces Blob；
4. transcription pending state；
5. transcript enters editable prompt；
6. no auto send；
7. transcription failure retains prior prompt；
8. abort cleans request/resource。

## E. Run

1. exact orderedReferences preserved；
2. explicit receiver used；
3. accepted run clears/rolls draft only after response；
4. 409 preserves draft；
5. retry does not duplicate Reference order；
6. run events/recovery owned by Core。

## F. Semantic Drop

1. no payload → recognizer inert；
2. ordinary Huabu external drop keeps native owner；
3. concrete LCOS target → semantic path；
4. dwell only reveals/maintains target affordance；
5. preview shows exact outcome；
6. cancel before commit = zero data mutation；
7. pointerup over confirmed target invokes one commit；
8. ambiguous network result enters recovery, not silent idle；
9. Glyth body drop writes context mapping, not Relation；
10. Ctrl/Cmd Reference remains separate。

---

# 14. 本册最终判定

T3 Current Source Audit 已经足够支持进入：

```text
03_Donor_Upstream_Adoption_Retirement_Matrix
04_Source_Level_Construction_Plan
```

当前没有发现需要“重新理解整个前端”才能继续的 blocker。

也没有发现必须新建：

```text
PointerRouter
SelectionStore
ContextMenuFramework
ActionCapabilityRegistry
VoiceWorkbench
ComposerFramework
DropManager
```

真正的施工主线已经缩成：

```text
P0
统一 gesture threshold / current owner contradiction
建立显式 local-affordance presentation owner
建立统一 Composer draft owner
退役 fixed bottom Composer shell

P1
接 selected-then-click
接 Action Arc
接 target-local Composer
接 explicit Reference Pick
接 right-click

P2
接 Run / Receiver typed client
接 Voice recorder + transcription client

P3
替换 Semantic Drop Phase-A destination resolver
接 Glyth body concrete target / commit

P4
WorkView / takeover / safe rect / three-surface cross review
```

重点不是写更多代码。

重点是把已经存在的成熟 owner 真正接到一起，同时让未来 donor body能换、canonical truth不动。

---

# 15. Source Evidence Index

本册关键 current source：

```text
DZWFLi/LCOS_Gen2

apps/web-gen2/src/interaction/referenceController.ts
apps/web-gen2/src/interaction/overlayArbitration.ts
apps/web-gen2/src/interaction/semanticDropMachine.ts
apps/web-gen2/src/backend/client.ts
apps/web-gen2/src/host/createLcosHostRuntime.ts

apps/local-core/src/routes/runs.ts
apps/local-core/src/routes/receiver.ts
apps/local-core/src/routes/voice-transcription.ts

huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx
huabu/apps/web/src/components/Nodes/NodeWrapper.tsx
huabu/apps/web/src/components/Common/CanvasFloatingPopover.tsx
huabu/apps/web/src/components/Common/Popover.tsx
huabu/apps/web/src/components/Common/DropdownMenu.tsx
huabu/apps/web/src/components/Panels/Canvas/FloatingToolbars/NodeFloatingToolbar.tsx
huabu/apps/web/src/components/Panels/ChatPanel/ChatInput.tsx

huabu/apps/web/src/lcos-seam/types.ts
huabu/apps/web/src/lcos-seam/nodePresentation.tsx
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/lcos/lcosRecognizers.ts
huabu/apps/web/src/lcos/lcosReferenceState.ts
huabu/apps/web/src/lcos/lcosDropState.ts
huabu/apps/web/src/lcos/LcosDropPreview.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
huabu/apps/web/src/lcos/LcosComposerShell.tsx
```

Huabu upstream additionally audited：

```text
microsoft/Huabu
apps/web/src/components/Panels/ChatPanel/ThreadChatInput.tsx
```

它证明 draft owner 与 input body 分离是当前 upstream 正在采用的方向。

---

# 16. Coordinator Summary

```text
T3 ROUND 2 CURRENT OWNER AUDIT: COMPLETE ENOUGH

POINTER:
single owner Huabu

SELECTION:
single owner Huabu

REFERENCE:
single semantic owner LCOS referenceController

RELATION:
Core

LOCAL AFFORDANCE:
missing producer/presentation owner

ACTION ARC:
arbitration slot exists, body/producer missing

COMPOSER:
current shell transitional, must retire

VOICE:
Core exists, recorder/client missing

RUN:
Core exists, frontend client missing

RECEIVER:
Core exists, frontend client missing

SEMANTIC DROP:
pure machine keep
Phase-A edge destination adapter retire/replace

MAIN ARCHITECTURE:
Huabu mechanics
→ LCOS semantic adapters
→ replaceable donor bodies
```


---

# Appendix A · 逐文件 Consumer → Owner → Mutation → Recovery 追踪

## A01 `Canvas.tsx`

Consumer：
- ReactFlow；
- canvasStore；
- pointer recognizers；
- hostExtension。

Owner：
- canvas interaction mechanics。

Mutation：
- selection、native node move/resize、native drop等经 Huabu store。

T3允许修改：
- 仅把中性 contextmenu / optional activation intent 暴露给 host；
- 继续把 host recognizers追加进现有 router。

禁止：
- import LCOS Core types；
- `if (glyth)`；
- Action Arc state；
- Composer state。

Recovery：
- gesture teardown沿现有 Huabu cleanup。

---

## A02 `CanvasHostExtension`

当前：
```text
nodeTypes
overlays
recognizers
connectIntent
```

允许的 seam 新增必须满足：
- Huabu 已经拥有事件；
- LCOS不可能通过现有 recognizer/overlay正式拿到；
- 不加就只能第二 global owner或 Huabu业务硬编码。

contextmenu满足这个条件。

double-click仅条件满足。

禁止把 seam扩成：
```text
LCOSAppAPI
```

---

## A03 `lcosRecognizers.ts`

现有：
- reference claim recognizer；
- drop observer。

新增候选：
- selected re-click observer；
- explicit Reference Pick复用现有 recognizer policy。

必须退掉：
- literal 4px slop。

禁止：
- Core mutation；
- Arc JSX；
- Composer state mutation以外的 presentation intent；
- direct Relation write。

---

## A04 `LcosHostOverlay.tsx`

正确职责：
```text
collect transient inputs
→ call pure overlay arbitration
→ compose bodies
```

错误职责：
```text
become all-T3 store
calculate target geometry
own Run
own Voice
own Reference truth
```

必须修：
```text
composerOpen = !dropActive
actionArcOpen=false
workViewOpen=false
```

为真实 input。

---

## A05 `overlayArbitration.ts`

继续 pure。

若新增 input：
必须是：
```text
外部事实
```

不是：
```text
业务命令
```

例如 safe：
```text
dragging
workViewOpen
```

不安全：
```text
shouldSubmitRun
```

---

## A06 `LcosComposerShell.tsx`

当前只可作为迁移参考。

不要继续渐进堆：
```text
voice
run
skill
target anchor
attachment
```

否则 transitional shell 会变成 permanent monolith。

正式 body上线后删除或完全停止生产。

---

## A07 `lcosReferenceState.ts`

保留 ProjectionBinding identity bridge 的逻辑价值。

draft 部分迁入统一 Composer draft owner后，避免两个 draft source。

Projection identity cache必须：
```text
reconcile-derived
fail-close
```

不从 title/id prefix猜。

---

## A08 `referenceController.ts`

保持纯函数。

不塞：
```text
React
Zustand
target
voice
run
```

它只负责有序 Reference 语义。

---

## A09 `ChatInput.tsx`

不要整颗复制。

优先复用/抽取：
```text
textarea sizing
IME keyboard
input chrome
attachment mechanics
```

不要搬：
```text
threadId
chatStore
selectionAttachment
agent session ownership
```

---

## A10 upstream `ThreadChatInput.tsx`

价值不是直接替代 LCOS Composer。

价值是证明：
```text
input body
≠ draft owner
```

这个拆法应该被 Gen2采用。

---

## A11 `CanvasFloatingPopover.tsx`

作为 target-local floating唯一基础。

Action Arc、Composer应提供：
```text
anchor rect
open
body
```

而不重写 placement。

未来 T2 safeRect若扩展边界规则：
优先在这一层或其输入边界统一处理。

---

## A12 `NodeFloatingToolbar.tsx`

是 live target anchor 的成熟示范。

尤其复用：
- internal node geometry；
- pinned style优先；
- measured fallback；
- takeover mark；
- modifier suppression。

不要复制实现成 `LcosFloatingAnchor.ts`，除非最终抽成真正通用 primitive有多个 consumer。

---

## A13 `Popover.tsx`

右键等 screen-space panel直接复用。

不要 Action Arc使用它做 radial positioning，因为 Arc target是 flow-space node，更适合 CanvasFloatingPopover。

---

## A14 `DropdownMenu.tsx`

负责 menu mechanics。

action semantics来自纯 resolver。

不要在 DropdownMenu里写：
```text
if artifact
if glyth
```

---

## A15 `semanticDropMachine.ts`

keep pure reducer。

未来如果 destination descriptor丰富，优先扩纯 type/reducer。

不要把 DOM hit test塞进去。

---

## A16 `lcosDropState.ts`

当前 hardcode边缘 surface要退役。

新的 adapter只承担：
```text
current payload
current target preview
machine state
```

真正 target identity来自 hit/adapter。

---

## A17 `LcosDropPreview.tsx`

视觉 body可换。

不应该知道：
```text
左侧导航坞
底部停靠区
```

这些是 product destination adapter给它的 label/outcome。

---

## A18 `backend/client.ts`

当前 JSON transport。

添加 multipart/raw支持时：
- 不存业务 state；
- 不猜 endpoint；
- 不手动设置 FormData boundary；
- 保持 AbortSignal；
- 保持统一 error normalization。

---

## A19 `runs.ts` Core route

T3不改 Core contract。

前端只精确映射已有字段。

若 Product UI需求字段不在 route：
先跨 T6核 contract，不在 UI偷偷加。

---

## A20 `receiver.ts` Core route

active receiver / handoff是 authoritative。

Composer只读/选择正式 receiver，不造“最近一次对话”缓存作 truth。

---

## A21 `voice-transcription.ts`

只负责 transcription。

录音 lifecycle在前端 primitive。

两者通过 Blob/FormData adapter连接。

---

# Appendix B · “普通测试为什么足够 / 什么时候不够”

本 T3 当前不新增 hash、baseline、release gate。

大部分风险通过：
```text
TypeScript
unit tests
pointer simulation
browser e2e
manual interaction measurement
```
足够。

只有跨系统/不可逆边界才需要额外 gate。

例如 Semantic Drop durable commit：
若一次用户 pointerup会同时触发：
```text
Core mutation
projection update
external receiver side effect
```
且网络中断可能造成部分成功，那么需要依赖 Core transaction/idempotency contract，而不是 UI gate。

Run submit：
Core已经拥有 Run identity/状态，不需要 UI自建幂等 hash。

Reference：
纯 draft presentation，不需要数据库唯一约束。

Action Arc：
纯 transient UI，不需要任何持久 gate。

Voice：
录音 upload可 Abort，失败不写 canonical truth，不需要 gate。

---

# Appendix C · Anti-Reinvention Checklist

施工前逐项问：

```text
这个 pointer event Huabu 已经有 owner 吗？
有 → 不新建。

这个 floating position Huabu 已经算了吗？
有 → 不新算。

这个 menu primitive Huabu 已经有吗？
有 → 不新造。

这个 input mechanic Huabu已有吗？
有 → 抽/包，不复制整份。

这个 recorder OSS upstream已有吗？
有 → LIFT。

这个 backend semantic route Core已有吗？
有 → 补 typed client，不再造 domain。

这个 proprietary donor只是更好看吗？
是 → 高保真转 implementation spec，不抄 code。

这个状态是否 canonical？
不是 → 不持久化成新 truth。

这个新 registry真需要 runtime plugin registration吗？
不是 → pure function。

这个新 contract不加会具体失败吗？
说不出 → 不加。
```

---

# Appendix D · T3最终源代码路径预估 blast radius

理想情况下，本线程真正新增/改动的核心文件数量应该是有限的。

如果最后施工计划突然需要：
```text
30+ 个新的 interaction framework files
```
说明偏离 thin seam。

合理 blast radius大致应集中：

```text
web-gen2 interaction
2–4 个小 pure/presentation modules

web-gen2 backend
2–3 个 typed clients + transport小改

huabu lcos seam
1–2 个 neutral host hook

huabu lcos composition
overlay/recognizers/composer replacement

UI bodies
Action Arc
Compact Composer
Voice Recorder adapter
Reference Pick indicator

tests
对应 unit + integration + Playwright
```

不是：
```text
重构整个 Huabu Canvas
替换 ReactFlow
建立第二 overlay framework
```

---

# Appendix E · 退出本册进入第 03 / 04 册的条件

已满足：

- Mandatory originals recovered；
- current Gen2 HEAD核验；
- vendored Huabu pin核验；
- upstream delta识别；
- 26项 owner audit完成；
- gesture target matrix完成；
- 主要 contradiction识别；
- Run/Receiver/Voice Core routes确认；
- donor可替换边界明确。

仍需在第 03 册冻结：

- Orbit exact source/file/license/copy范围；
- CopilotKit recorder exact lift范围；
- Lovart/TapNow/Spatial high-fidelity design measurements；
- Huabu upstream ThreadChatInput/ChatInput delta；
- donor reject/retire表。

第 04 册才冻结：

- exact target filenames；
- props；
- JSX；
- CSS tokens；
- state union；
- motion values；
- browser acceptance scripts；
- retirement order。
