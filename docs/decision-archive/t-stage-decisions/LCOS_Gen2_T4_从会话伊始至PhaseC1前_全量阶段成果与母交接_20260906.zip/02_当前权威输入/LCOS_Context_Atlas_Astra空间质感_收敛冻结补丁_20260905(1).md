# LCOS Gen2 · Context Atlas 空间形态收敛冻结补丁
## Astra 原视频复核后的视觉边界 · 2026-09-05

> **文档性质：补充冻结 / Product-Visual Constraint Patch**
>
> 本稿用于补充 `LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905` 中 Context Atlas 的空间形态约束。
>
> **本稿不是新的总产品正本，不覆盖 V2 已冻结的 Context / Workflow / Glyth / Work View / Navigation 语义。**
>
> 总规划线程应以 V2 为上位 authority，把本稿作为 Context Atlas 视觉空间语言与跨线程排单输入。
>
> **实现方式、具体 donor、算法、比例、动画仍由对应施工线程继续源码级寻找最优解。**
>
> 本稿只冻结：什么方向成立、什么信息必须稳定、什么复杂化明确不要做。

---

# 0. 本轮新增证据

本轮新增直接证据：

1. 原视频：`435c2aeec0a705a8813fae7b7bd876d5.mp4`
2. `GPT6Astra地图形态拆解_含帧图_20260905`
3. `Spatial_画布形态与动效收敛包_含帧图_20260905`
4. `LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905`

特别说明：

- Astra 视频不是 Spatial 证据；
- Astra 只作为 **Context Atlas 总览空间质感 / Pin / Label / 2D→轻立体表达** 的视觉行为参考；
- Spatial 继续作为 **Canvas 打开、聚焦、退场、拖拽让位、Stack、Transition** 等空间交互 donor；
- 两者不得混写成同一个产品来源。

---

# 1. 一句话冻结

> **Context Atlas 是一张“有轻微高度和纵深的项目 Context 地图”，不是一个复杂 3D 世界。**

它首先必须做到：

- 少字；
- 图形优先；
- 层级清楚；
- 区域边界清楚；
- 大小关系稳定；
- 重点明确；
- 直接拖动 / 缩放 / 点选；
- 必要信息持久可读；
- 专业编辑按需进入，不在 Atlas 上叠满。

Astra 只帮助确定：

> **“总览时应该有一点真实空间感。”**

不是授权把 Context 做成三维信息城市、游戏地图或复杂数据可视化场景。

---

# 2. V2 上位冻结继续原样成立

以下不能被本稿覆盖。

## 2.1 Context 默认时间地图

Context 稳定底盘仍然首先按真实时间组织。

时间颗粒度可调：

- 小时；
- 6 小时；
- 12 小时；
- 24 小时；
- 天；
- 数天；
- 周；
- 更长区间。

每块首先表示：

> **一段真实时间。**

区域面积 / 密度可以随该时间段内容量增长。

---

## 2.2 第二种地图仍然是“事情地图”

事情地图由 Agent 根据：

- Conversation；
- Artifact；
- Run；
- Decision；
- Result；
- 时间；
- 引用；
- Relation；
- 语义连续性；

派生整理。

它与时间地图是：

> **同一批 Context 的两种视图。**

不是两套 Context truth。

默认仍然是：

> **时间地图。**

---

# 3. 点 / 线 / 面继续明确分工

本轮不改变此前冻结：

```text
面
Context Atlas
= 看整个项目 Context 的全局结构

线
Evolution / Context evolution view
= 看某件事情、判断、版本如何变化

点
Context Spatial Canvas
= 进入具体范围继续自由整理和工作
```

一句话保持：

> **面看全局，线看变化，点做细活。**

---

# 4. 本轮关键收敛：不要把点 / 线 / 面强行叠在一起

Astra 原视频说明“空间总览”可以非常直观。

但这不意味着：

```text
Atlas 上直接长出复杂时间 Ribbon
+ Relationship 三维道路
+ Provenance 地层
+ 可编辑 branch
+ 多层窗口
```

同时出现。

这会破坏 LCOS 已冻结的：

- 图形优先；
- 信息层级明确；
- 直觉操作；
- 少系统 Chrome；
- 不做管理后台；
- 不让专业视图互相打架。

因此正式冻结：

### Atlas 负责 Atlas

默认只解决：

> **“我现在整个 Context 大概是什么结构？”**

### Wave / Evolution 继续适合 2D

时间演进、range、版本、compare 等专业信息：

> **默认仍然独立进入更适合阅读和编辑的 2D 专业视图。**

不为了视觉炫技把时间轴强塞进 2.5D Atlas。

### Spatial Canvas 继续做自由编辑

当用户要真正整理对象：

> **进入 Context 自由空间。**

---

# 5. Astra 给 LCOS 的正确参考范围

## 5.1 可以直接借鉴的感觉

Astra 原视频最值得参考的是：

### A. 平面获得轻微厚度

同一张图不需要复杂三维结构。

只要区域：

- 有很轻的高度；
- 有克制的 AO / 接触阴影；
- 与底面有清楚关系；
- 大区块之间有明确空间间隔；

就能产生：

> “这是一个可以俯瞰的空间。”

这已经足够。

---

### B. 总图层级非常清楚

远看时：

- 只看到大块；
- 不展示所有细项；
- 不出现大量文字；
- 不出现大量关系线。

靠近 / 选中后：

- 才逐渐增加下一级信息。

这与 LCOS LOD 原则完全一致。

---

### C. World geometry 与 screen information 分离

Astra 中最值得借的结构是：

```text
底图 / 区块
= world-space

Pin / POI / Label
= world-anchored + screen-readable
```

即使底图有透视：

- 标签仍容易读；
- Pin 不跟着世界缩成噪点；
- 定位信息不会因为角度而失真。

这与 LCOS 的：

```text
World body
+
Screen-space / Hybrid identity
```

方向一致。

---

# 6. Astra 不应该被借走的东西

本轮明确禁止因为参考 Astra 而自动增加：

- 城市隐喻；
- 建筑隐喻；
- 街道路网；
- 三维 Relation network；
- 三维时间地层；
- 自由飞行 Camera；
- Blender 式 Orbit；
- 多层 3D 编辑器；
- 动态人物 / 车辆；
- 复杂地形；
- 复杂光照；
- PBR；
- 大量 3D text；
- 为了 3D 再建立第二套 Canvas / Camera / geometry truth。

Astra 是：

> **空间质感参考。**

不是 LCOS Context 的新领域模型。

---

# 7. Context Atlas 默认视觉结构

默认 Atlas 应尽可能简单。

建议基本视觉元素只包含：

```text
1. Context 大区域 / 时间块
2. 必要的区域名称
3. 当前 Selection / Focus
4. 少量 Glyth 来源标识
5. 用户显式 Pin
6. 必要层级边界
```

默认不要同时展示：

```text
所有 Artifact
所有 Relation
所有 Provenance
所有 Run
所有 Skill
所有 Decision
所有 Agent
所有 Version
所有状态长句
```

这些应在：

- Focus；
- Hover；
- 临时查看；
- 专业 Instrument；
- Work View；

中按需出现。

---

# 8. 信息层级优先于空间炫技

这条是硬冻结。

任何 Atlas 形态评审，优先顺序必须是：

```text
1. 我一眼知道哪里大、哪里小
2. 我一眼知道当前在哪
3. 我一眼知道什么被选中
4. 我知道哪些东西是长期标记
5. 我可以直接进入目标
6. 最后才是“看起来有没有 3D 感”
```

如果：

> 3D 感损害前五项，

立即牺牲 3D 感。

---

# 9. 区域面积 / 高度 / 颜色不能同时乱编码

Context Atlas 不应成为“每个视觉通道都代表一个指标”的数据大屏。

本轮冻结：

## 面积

可以继续表达：

> Context 的体量 / 时间段内容量。

具体公式由总规划 / Context owner / Core 确认。

不要由视觉线程自行定义 canonical importance。

## 高度

只允许承担：

> **次一级的空间层级 / 体量强化。**

默认必须很克制。

不要：

```text
activity = 高度
importance = 高度
version = 高度
Agent count = 高度
```

四种含义同时争抢 Z 轴。

## 颜色

默认保持克制。

颜色首先服务：

- Selection；
- Focus；
- identity；
- 状态；
- 必要 provenance cue。

不要把 Atlas 做成热力图大拼盘。

---

# 10. Camera 收敛

Astra 原视频具备明显空间观察感。

但 LCOS 不需要照搬其全部 3D Camera 能力。

默认心智冻结为：

> **“我在拖动 / 缩放一张有纵深的地图。”**

不是：

> “我在操纵一个三维场景。”

因此默认优先：

- Pan；
- Zoom；
- 稳定鸟瞰；
- 轻微透视。

有限 rotate / tilt：

> **是否保留，由 donor / prototype / smoke test 再裁决。**

当前不作为硬需求。

明确不优先：

- roll；
- 自由翻转；
- underside view；
- FPS navigation；
- 复杂 Orbit controls。

---

# 11. Glyth 在 Context Atlas 上怎么出现

继续遵守 V2：

> Context 不按 Agent 分区。

不能形成：

```text
GPT 区
Codex 区
Buddy 区
```

Glyth / Conversation 只作为：

- 来源；
- 贡献者；
- 历史参与者；
- provenance cue。

Atlas 上最合适的形态是：

> **极轻的地图 POI / Identity Glyph。**

例如视觉心智：

```text
[Glyth Glyph] + 极短 Conversation Name
```

不要变成：

```text
Agent Card
Provider
Model
Token
Last Active
Status
```

这些都不属于 Atlas 第一层。

---

# 12. Glyth 标签的空间规则

Glyth 来源标识建议采用：

```text
world anchor
+
screen-space / billboard identity body
```

目标：

- Anchor 和真实 Context 区域绑定；
- 远近仍可辨识；
- 文字不因透视歪斜；
- 不随世界缩成背景点；
- 不与 Context region body 争夺视觉重量。

远距离：

> 只保留 Glyph。

中距离：

> Glyph + 极短名字。

靠近 / Hover / Focus：

> 再增加完整来源信息。

---

# 13. Pin 在 Atlas 上的形态

本轮认为 Astra 的地图 Pin / POI 语言可以作为强视觉参考。

但必须区分：

```text
Huabu World Portal Pin
≠
LCOS durable wayfinding Pin
```

这里讨论的是后者的 **视觉 presenter**。

建议：

```text
world anchored
+
screen rendered
+
stable CSS-px size
```

Pin 应：

- 落点明确；
- 比普通 Glyth provenance cue 更持久；
- 远距仍可读；
- 不跟着区块缩放；
- 可以进入 Locator / Minimap family；
- 不变成信息卡。

---

# 14. Pin / Glyth / Locator / Far Identity 必须是同一视觉家族，但语义不同

允许共享：

- Glyph 设计语言；
- screen-space body；
- anchor point；
- label grammar；
- motion rhythm。

但不能语义合并。

至少区分：

```text
Far Identity
= 对象自动远距身份

Glyth provenance cue
= 谁参与 / 来源

Pin
= 用户持久标记

Locator
= 当前对象 / Pin 在屏幕边界之外时的方向定位
```

产品语义不同。

不得因为视觉像就共用 canonical state。

---

# 15. Focus 在 Atlas 上的收敛表达

本轮不把 Focus 做成复杂三维动画系统。

Focus 只要求：

1. 目标更明确；
2. 周边降级；
3. 必要时 Camera 做显式 framing；
4. Label / Pin / Locator 保持可读；
5. 用户能清楚知道下一步是临时看还是深入做。

Spatial 可以继续作为：

> **聚焦时周围元素让路 / 淡化 / 退场**

的行为 donor。

Huabu 继续负责：

> **真实 bounds / camera / viewport mechanics。**

LCOS 负责：

> **显式 Focus intent 和 framing policy。**

不要求：

- 目标突然长成复杂三维建筑；
- 时间 Wave 从地面升起；
- Relation 全部铺成道路。

---

# 16. 点击 Atlas 区域后的行为继续遵守 V2

V2 已冻结：

```text
点击时间块
→ 先进入临时详细查看
```

不是：

```text
一点击
→ 立刻创建长期子画布
```

临时查看可以：

- 看；
- Search；
- Focus；
- Reference；
- 给 Agent；
- 看来源；
- 看演进；
- 看底层对象；
- 恢复归档对象；
- 拖出真实对象。

如果用户明确要继续长期工作：

- Restore；
- 拖出；
- 形成 Collection；
- 整理成 Workflow；
- 建立长期工作区。

本轮 Astra 空间形态不得改变这条行为。

---

# 17. Wave / Evolution 继续保持 2D 优先

时间和版本的编辑具有明显二维优势：

- 顺序；
- range；
- compare；
- trim；
- branch；
- revision；
- before / after。

所以当前冻结：

> **Evolution Wave 继续以 2D 专业视图优先。**

Atlas 只负责让用户：

> “找到我要看的那一块。”

然后：

```text
Atlas region
→ 临时详情
→ Evolution / Wave
```

不要默认：

> Wave 直接叠在 Atlas 3D 地图中。

除非后续找到一个非常成熟、经过长期产品验证、不会破坏信息层级的 donor。

在没有 donor 前：

> **不主动创新这层复杂交互。**

---

# 18. Relationship / Provenance 同样不默认铺满 Atlas

Relation / Provenance 可以继续作为：

- 专业 Lens；
- Focus overlay；
- 临时 inspection；
- Work View。

但不作为 Atlas 默认背景。

默认 Atlas 不能变成：

> 满屏线条 + 标签 + Pin + 关系图 + 时间轨迹。

Atlas 首要任务永远是：

> **总观。**

---

# 19. Context Atlas 与 Spatial Canvas 的关系

当前建议继续保持：

```text
Atlas
= 总览

Context Spatial Canvas
= 具体工作
```

用户可以：

```text
Atlas
→ 选区域
→ 临时查看
→ 明确进入
→ Context Spatial Canvas
```

不要求在本轮实现：

> Atlas world 无缝 morph 成任意自由 Canvas。

如果未来 donor 能低成本、稳定地做连续转场：

> 可以作为高保真增强研究。

但不是当前产品硬需求。

---

# 20. Atlas 与 Work View 的关系

Atlas 本身可以作为 Context 的大面积总览工作态。

复杂专业内容仍复用统一窗口能力：

```text
Float
Dock
Undock
Resize
Move
Horizontal / Vertical composition
Close
Restore
```

不要再为：

- Evolution；
- Provenance；
- Relationship；
- Context detail；

各写一套窗口。

---

# 21. 主画布稳定底盘继续是硬规则

无论 Context Atlas、Wave、专业 Work View 怎么打开：

- Canvas world 不自动移动；
- Camera 不因 Work View open/resize 自动移动；
- Node 不自动重排。

只有用户明确：

> **Focus**

时，才允许 camera framing。

Work View / window geometry 只影响：

- HUD；
- Pin；
- Locator；
- Composer；
- Action Arc；
- transient controls；

的 screen-space 避让。

---

# 22. Astra / Spatial / TapNow 的 donor 分工

本轮建议总规划不要写成：

> “照 Astra 做。”

而应明确：

## Astra

主要参考：

- Atlas 总观空间感；
- 轻 2.5D 白模 / massing；
- AO / 接触阴影的深度增强；
- Pin / POI / Label 层级；
- world geometry + screen-readable information。

**视觉/行为参考为主。**

---

## Spatial

主要参考：

- Focus 让路；
- 原位 morph；
- present / restore transition；
- Stack；
- scatter；
- pull-out；
- settle；
- drag 时邻居让位；
- 低 chrome；
- 空间组织。

**行为 donor。**

---

## TapNow

继续重点参考：

- world-plan；
- marker；
- fixed-screen label；
- hit priority；
- Pin / waypoint；
- world→screen overlay；
- 3D / plan view 中的导航信息层级。

**高保真导航 / HUD donor。**

---

## Huabu

继续是：

> **唯一空间物理底盘。**

拥有：

- world geometry；
- Camera；
- viewport；
- node；
- selection；
- snap；
- layout；
- spatial persistence；
- floating mechanics。

不得因为 Atlas 需要空间感再建第二个 Canvas engine。

---

# 23. 技术实现不在本稿冻结

以下全部留给施工线程 donor census / prototype：

- CSS 3D；
- Canvas 2D；
- SVG；
- WebGL；
- Three.js；
- React Three Fiber；
- DOM + transform；
- d3-hierarchy；
- Huabu Frame/Grid solver；
- 自定义 lightweight extrusion renderer；
- billboard label implementation；
- marker library；
- animation library。

本稿只冻结：

> **结果必须简单、可读、直觉。**

不能因为某种技术“很酷”反向决定产品。

---

# 24. Context Atlas 第一版复杂度上限

第一版建议严格限制成：

```text
Region
+ hierarchy
+ area
+ slight height
+ selected/focus state
+ short label
+ Glyth provenance cue
+ Pin
```

第一版明确不要：

```text
3D Evolution Ribbon
3D Relation roads
3D Provenance layers
dynamic agents
complex lighting
free orbit
3D editing
multi-layer persistent panels
complex topology animation
```

这条是为了防止施工线程拿到 Astra 后集体兴奋，然后把一个总览地图做成毕业设计。

---

# 25. UI 直觉验收

Context Atlas 每一轮设计必须过以下检查。

### 1

不看说明文字：

> 我能不能大概知道这张地图哪里大、哪里小？

### 2

我能不能一眼看出：

> 当前 Selection / Focus 在哪？

### 3

Pin 和来源 Glyth：

> 远距离还看得见吗？

### 4

它们会不会：

> 跟着世界缩成小黑点？

### 5

Atlas 默认有没有同时出现：

> 太多文字、关系线、状态、版本、Agent 信息？

如果有，继续删。

### 6

用户想细看：

> 是不是直接点目标，而不是先选 Mode？

### 7

用户想看演进：

> 是否进入 2D Wave / 专业视图，而不是在地图上和其它层打架？

### 8

用户想继续整理：

> 是否进入 Context Spatial Canvas，而不是把 Atlas 变成另一套编辑器？

### 9

是否继续共享：

- Search；
- Focus；
- Pin；
- Locator；
- Composer；
- Work View；
- Rail；
- Selection；
- Drag / Drop；

的三 Surface 通用心智？

### 10

如果移除所有 3D 高度：

> 产品是否仍然可理解、可工作？

如果答案是否：

> 说明 3D 已经承担了不该承担的业务语义。

---

# 26. 给总规划的责任拆分提示

> **这里只给拆分关注点，不替总规划锁死线程 owner。**

需要至少覆盖以下责任：

## Context 产品语义

- 时间地图；
- 事情地图；
- region / scope 对应关系；
- 临时查看；
- Atlas → Wave / Canvas；
- Agent 派生与人工修正。

## Spatial / T1 类能力

- world/screen projection；
- fixed-size identity；
- Focus framing；
- Pin / Locator presenter；
- LOD；
- Atlas hierarchy presentation；
- 轻 2.5D renderer mechanics；
- motion；
- Work View geometry avoidance；
- Huabu integration。

## Context / Work View 类能力

- Atlas entry / session；
- 临时详情；
- Evolution；
- Relationship；
- Provenance；
- deep work lifecycle。

## Navigation 类能力

- Rail；
- Search；
- Focus；
- Pin；
- Locator；
- Back / Arrival；
- Atlas 入口与返回。

## Core / 后端

- 时间 region truth；
- Context grouping；
- thing-map Agent derivation；
- provenance；
- canonical identity；
- persistent Pin target；
- projection bindings。

最终 exact owner 由总规划按六线程最新分工重新排单。

---

# 27. 本轮明确冻结 vs 仍然开放

## HARD FREEZE

以下进入本轮补充冻结：

1. Atlas 首先是 Context 总览，不是复杂 3D 世界。
2. 空间感采用轻 2.5D / 高度 / 深度即可。
3. UI 继续少字、图形优先、直接点选。
4. 信息层级优先于 3D 表现。
5. 点 / 线 / 面继续分工，不默认叠在同一界面。
6. Evolution / Wave 当前继续 2D 优先。
7. Glyth 在 Atlas 中是来源 / provenance cue，不用于 Agent 分区。
8. Glyth / Pin / Label 优先 screen-readable。
9. Pin / Glyth / Locator / Far Identity 可以视觉同族，但 canonical semantics 必须分开。
10. Atlas 第一层不铺满 Relationship / Provenance / Run / Skill / Version。
11. Camera 默认是地图心智，不是 3D 编辑器心智。
12. 没成熟 donor 的复杂 3D 编辑交互不主动施工。
13. Huabu 继续是唯一空间物理底盘。
14. 大专业视图继续复用统一 Work View。
15. Work View open/resize 不移动主画布 Camera。

---

## OPEN / DONOR-DRIVEN

以下继续开放，由对应线程找最优实现：

1. Atlas 最终是纯 2D、2.5D 还是可切 2D/2.5D；
2. 高度具体范围；
3. 是否允许有限 tilt / rotate；
4. Region 最终是矩形、organic partition 还是混合；
5. d3-hierarchy 是否使用；
6. Huabu structured layout 是否足够承担 Atlas partition；
7. 2.5D renderer 技术；
8. AO / 阴影程度；
9. Pin / POI 的最终图形；
10. Glyth provenance glyph 最终形态；
11. Label collision / declutter 算法；
12. Focus 具体镜头参数；
13. Atlas → detail 的 transition；
14. Spatial / TapNow / Lovart / OSS 各自最终采用比例。

---

# 28. 反复杂化红线

如果后续任何设计稿出现以下症状，应视为偏离本冻结：

```text
“功能很多，看起来很强”
```

但用户不知道：

> 第一眼应该看哪里。

或者：

```text
“3D 很漂亮”
```

但用户需要旋转半天才找到对象。

或者：

```text
“所有信息都能同时看”
```

但任何信息都没有视觉主次。

或者：

```text
“Atlas 已经能直接编辑一切”
```

于是 Wave / Canvas / Work View 全部失去边界。

这四种情况都应回退。

---

# 29. 最终产品口令

Context Atlas：

> **像一张有轻微纵深的项目地图。**

不是：

> 一个三维信息城市。

默认：

> **远看结构，点开细看，需要编辑再进入对应专业视图。**

Glyth / Pin：

> **像地图路标一样稳定、轻、可辨认。**

Wave：

> **继续用最舒服的 2D 看变化。**

Canvas：

> **继续用三 Surface 共用的自由空间做细活。**

最终仍然遵守 LCOS 总原则：

> **点、拖、丢、拉、直接打字、说一句话。**

以及：

> **能用图形表达就不常驻文字；需要解释时 Hover / Focus 再出现。**

---

# 30. 总规划接收时的建议处理方式

总规划线程收到本稿后建议：

1. 不把它作为新的“Context 功能扩展单”；
2. 把它作为 `Context Atlas visual/spatial constraint`；
3. 与 V2 的 Context 时间地图 / 事情地图 / 点线面一起合并；
4. 重新确认 T1 / Context owner / Navigation / Core 的分工；
5. 只把确定性需求拆成施工任务；
6. 具体视觉/算法继续要求每个线程自己做 donor/source-level census；
7. 不因为本文提到 Astra 就指定某个 3D framework；
8. 所有方案必须以“更简单、更直觉、更稳定”为优化目标，而不是“更完整”。

---

## Authority

上位产品冻结：

`LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905`

本稿地位：

`Context Atlas 空间形态补充冻结`

证据：

- `435c2aeec0a705a8813fae7b7bd876d5.mp4` 原视频直接复核
- `GPT6Astra地图形态拆解_含帧图_20260905`
- `Spatial_画布形态与动效收敛包_含帧图_20260905`

**若本稿与 V2 产品语义冲突，以 V2 为准。**

**若后续总规划产出更晚的正式产品裁决，则以更晚正式裁决为准。**
