# LCOS Gen2 · T3
# V2 最终产品冻结之后的 Donor 深挖与最优呈现裁决
## Action Arc / Multi-selection / Compact Composer / Reference / Receiver / Run / Voice / Semantic Give / Right-drag / Relation / Glyth

> 日期：2026-09-05  
> 性质：T3 产品冻结之后的 UX / Donor 深挖，不是新的上位产品定义，也不是源码 patch。  
> 上位产品冻结：`LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905.md`
>
> 本文遵循：
>
> ```text
> V2 冻结
> → 决定不能改的产品语义
>
> Lovart / TapNow / Spatial
> → 寻找已经验证过的最好呈现、交互节奏、信息密度
>
> Huabu / legal OSS
> → 找成熟实现机制
>
> LCOS
> → 只保留自己的 canonical semantics / owner / 最薄适配
> ```
>
> Proprietary donor（Lovart / TapNow / Spatial）只作为高保真 UX / 行为 / 职责参考，不复制其 proprietary bundle 实现代码。
>
> 当前结论不是“找一家全抄”，而是：
>
> > **对每一段交互选择最成熟的 donor，再用 LCOS 的统一语义把它们拼成一个产品。**

---

# 0. 本轮最重要的新结论

这轮继续深挖以后，T3 的“最佳答案”不再是：

```text
Action Arc 像 Spatial
Composer 像 Lovart
Agent 像 TapNow
```

这种模糊说法。

而是已经可以细到：

```text
Action Arc：
几何 = Orbit satellite
按钮密度 = Lovart
显隐/tooltip = Lovart
进入/退出 = Spatial
定位 = Huabu
语义 = LCOS

Multi-selection：
selection mechanics = Huabu
toolbar anatomy = Lovart
自动 Composer = REJECT（V2 已冻结不自动开）
AI Work = LCOS explicit capability

Reference：
source picker = Lovart / TapNow
canvas pick = Lovart / TapNow
chip anatomy = Lovart
Selection 自动带入 = REJECT
ordered Reference truth = LCOS

Run：
Conversation continuity = TapNow
running / stop / queue presentation = TapNow candidate
draft ownership = Huabu ThreadChatInput pattern
Receiver / Active Receiver distinction = LCOS

Semantic Give：
drag mechanics = Huabu
approach / receptive / settle = Spatial
ghost / proxy + return home = Spatial principles + LCOS grammar
semantic outcome = LCOS / target owner

Glyth：
creature body = T5
attention / gaze / squash / settle = Spatial
Context Mapping / Relation / Receiver = LCOS
```

这才是后续 exact-file 施工应该用的 donor 粒度。

---

# 1. 当前 Authority

## 1.1 已被冻结，T3 不再设计

以下直接来自 V2 / 后续用户裁决：

### Multi-selection

```text
多选
→ 保持 Selection
→ 不自动开 Composer

用户明确点 AI Work / Composer
→ 才打开 Composer
```

### Glyth click

```text
第一次点
→ Select

已经 selected 再点
→ Action Arc + Compact Composer

双击
→ 同一 Conversation 的深度工作状态
```

### Drag Grammar

```text
左拖到空白
= 搬

左拖身体碰明确目标
= 给 / 加入 / 使用

右拖
= 借过去用，但 source 本体不动

Relation handle
= 明确建立 Project Relation
```

### Voice transcript insertion

```text
有选中文字
→ replace selection

有 caret
→ insert at caret

无 selection / caret
→ append end
```

### Remove / Archive / Delete

```text
Remove
→ current projection / membership / mapping
→ immediate + Undo

Archive
→ keep canonical truth, leave active spatial workspace

Delete
→ real canonical entity / file / important long-lived structure
→ explicit confirmation
```

### UI

```text
non-essential system chrome
→ icon / glyph / shape / motion first

text
→ hover / focus / selected / explicit expand
```

因此以下 donor 研究不得反向推翻上述语义。

---

# 2. Action Arc 深挖
## 结论：不是抄一个“圆形菜单”，而是组合四个成熟答案

---

## 2.1 Orbit：只拿 satellite geometry，不拿 visible wedge menu

本轮重新核对 Orbit 源码：

```text
repo:
zumerlab/orbit

current main:
03f8b4de2c79e6c697f4a5757f71dcdb2539ce26

version:
v1.4.12
```

本地 donor 与当前 upstream 对齐。

Orbit `satellite` 使用 CSS trig：

```text
angle
+ sin()
+ cos()
→ 在中心对象外围放置离散 satellite
```

而 `o-arc` 本身：

```text
pointer-events: none
```

其示例的 radial menu 有明显 wedge / sector。

### T3 裁决

LCOS Action Arc：

```text
ADOPT / LIFT:
Orbit satellite geometry

REJECT:
visible wedge / pie menu
visible full orbit track
large radial menu mode
```

为什么：

V2 要求：

```text
3 normal / 4 max
icon-first
low chrome
object remains visual protagonist
```

因此最终 Arc 应像：

```text
     ○
  ○     ○

     [Object]
       ○
```

而不是：

```text
╭───────────╮
│ 大型圆盘菜单 │
╰───────────╯
```

---

## 2.2 Lovart：按钮密度比 Orbit 示例更值得直接借

Lovart production evidence 中，SelectionToolbar / MultiSelectionItems 等大量 quick action 使用：

```text
32×32 左右 icon button
小间距
compact floating surface
hover 才补可读信息
```

另外 `AddToReference` 是非常有价值的 micro-affordance：

```text
absolute
right-1
top-1.5
rest hidden
group hover/focus reveal

button:
24×24

icon:
16×16

popover:
bottom/end
sideOffset ≈ 4
```

### T3 Action Arc 直接借什么

```text
button optical size:
约 28–32px 级

icon:
约 15–17px

persistent label:
none

hover:
tooltip / tiny label

background:
small isolated satellite
not toolbar text pill
```

这非常符合 V2 的：

> 非必要不显示字。

---

## 2.3 Spatial：拿动效，不拿整个 interaction owner

Spatial 实测/拆解：

```text
local open/close
≈ 180–240ms

明确实测到位
≈ 220–260ms

menu / lightweight state
≈ 200ms

snappy spring
response ≈ .25
damping ≈ .8
```

### 推荐 Arc choreography

```text
selected-reclick confirmed
0ms
→ satellites begin from near-target origin

~60ms
→ opacity becomes readable

~160–220ms
→ satellites settle

hover
→ only hovered satellite gets slight scale / optical lift

dismiss
→ faster than entry
~120–180ms
```

不要：

```text
弹跳两三次
大幅 overshoot
整条 orbit track rotate in
按钮逐个花哨 stagger 500ms
```

Arc 是工具，不是开机动画。

---

## 2.4 Huabu：继续做 anchor / boundary owner

Action Arc 不应自己算：

```text
viewport edge
Work View occupied rect
node measured rect
takeover mark rect
zoom transform
```

继续由 Huabu floating / node anchor primitive 解决。

---

## 2.5 Action Arc 最优组合

最终：

```text
Geometry:
Orbit satellite trig

Button anatomy:
Lovart compact icon action

Motion:
Spatial snappy / low overshoot

Placement:
Huabu CanvasFloatingPopover / NodeFloatingToolbar family

Capability:
LCOS pure local action resolver
```

### 状态

`HIGH CONFIDENCE`

这一块已经不需要再“创意设计”。

---

# 3. Multi-selection 深挖
## V2 关闭了最关键的歧义

Lovart 官方与 production evidence 都支持：

```text
Shift + click
或
drag select

→ multi selection

→ top / local quick actions

right-click
→ management
```

这与 V2 完全同向。

---

## 3.1 Lovart 值得拿的不是按钮列表，而是 capability-driven toolbar

其 production bundle 中可以看到：

```text
SelectionToolbar
MultiSelectionItems
SmartSelection
```

MultiSelectionItems 并不是：

```text
永远固定 12 个按钮
```

而是根据 selection 内容动态组合：

```text
group
ungroup
merge
auto-layout
align
distribute
vector-specific action
...
```

### LCOS 应采用

建立：

```text
selection capability
→ resolve visible immediate batch actions
```

而不是：

```text
multi-select toolbar hardcoded all actions
```

---

## 3.2 LCOS toolbar 应比 Lovart 更克制

Lovart 是视觉设计工具，所以 SelectionToolbar 会出现：

```text
Upscale
Remove BG
Mockup
Crop
...
```

LCOS 多选的主要真实用户意图更广：

```text
Move
Arrange
Group / Collection
Batch Give
Archive
AI Work
```

因此不应该抄 action taxonomy。

应该只抄：

```text
anatomy
density
placement
capability-driven reveal
right-click separation
```

---

## 3.3 推荐连续 UX

```text
Frame A
用户 Shift+click / 框选 A+B+C

Frame B
三个对象共同 Selection outline
不弹 Composer

Frame C
selection bounds 上方出现 compact toolbar

默认只出现高概率 immediate actions
例如：
Arrange
Group/Collection
AI Work
More

Frame D
用户只想拖
→ 直接拖 selection
→ toolbar 在 drag 中收起

Frame E
用户点 AI Work
→ 才出现 Compact Composer

Composer target line:
“3 selected”
不把 A/B/C 自动列成 Reference
```

### 状态

`FROZEN + DONOR FOUND`

---

# 4. Compact Composer 深挖
## 结论：Lovart 给外壳，Huabu 给输入机械，LCOS 给 target / Reference / Run 语义

---

## 4.1 Lovart 可高保真借的部分

Lovart 的成熟输入体系可以借：

```text
compact shell
inline mention/reference
small source chooser
input-local action
low chrome
inline token/chip
hover-driven affordance
```

其 mention 使用 inline token，而不是整块附件卡。

这对 LCOS 很重要：

> Reference 的任务是确认“是谁”，不是把节点复制进输入框。

---

## 4.2 Huabu ThreadChatInput 更适合做实现骨架

当前 Huabu upstream 已经把：

```text
draft owner
```

从输入体里外移。

`ThreadChatInput` 读取 thread draft，再把：

```text
value
onChange
onSubmit
```

传给 ChatInput。

这与 T3 当前 ComposerDraft 方向非常一致。

### T3 裁决

```text
DON'T:
把 Huabu ChatInput 整体变成 LCOS canonical owner

DO:
复用其：
textarea mechanics
IME safe Enter
attachment/paste/drop
send/stop
history
controlled input pattern
```

LCOS 外层持有：

```text
target
ordered References
receiver
skill / parameters
voice transcript insertion
draft recovery
```

---

## 4.3 Composer 的视觉层级应该更像“输入面”而不是“卡片”

推荐：

```text
top:
极轻 target identity

middle:
References, only if present

body:
1–2 line prompt
max 3–4 lines

footer:
icon-first controls

advanced:
anchored popover
```

不要：

```text
标题栏
卡片标题
说明文字
Receiver: xxx
Model: xxx
Reference: xxx
Run status: xxx
```

一排系统自己解释自己的字。

---

## 4.4 Target identity

V2 的“非必要不显示字”意味着 target identity 也不应总是一大 pill。

推荐：

rest / obvious anchor 时：

```text
小 identity glyph / thumbnail
```

只有：

```text
multi-selection
ambiguous target
receiver mismatch
hover
```

才显示短 label。

---

# 5. Reference 深挖
## Lovart + TapNow 都给出了成熟“从画布挑”的答案，但 LCOS 必须删掉自动 Selection→Context

---

## 5.1 Lovart

官方 `@ Mention`：

```text
可引用 Canvas elements
选中 element 可以进入 input
```

production 里又有：

```text
SelectFromCanvas
AddToReference
```

这说明它不是靠一个大“附件管理器”完成 Reference。

---

## 5.2 TapNow

官方当前交互：

```text
input旁 +
→ Insert from canvas
→ canvas pick
→ selected nodes会先进入
→ 再继续点击
→ references appear above input
```

其“chips above input + canvas stays active”的呈现非常成熟。

但：

```text
selected nodes automatically added first
```

与 LCOS 冻结冲突。

### LCOS 只借：

```text
picker remains on canvas
chip strip above input
picker lifecycle
clear exit
```

### LCOS 拒绝：

```text
Selection automatically becomes Reference
```

---

## 5.3 建议的 LCOS Reference Pick 最优解

### Entry

Composer footer：

```text
[reference glyph]
```

hover：

```text
参考
```

click：

small popover：

```text
Canvas
Upload
Paste
```

不需要长期文字按钮。

---

## 5.4 Canvas Pick

```text
click Canvas
→ Composer stays

eligible project objects
→ only subtle hover/focus readiness

cursor / top tiny state
→ enough to tell user “现在点的是参考”

click object
→ object does NOT become Selection target
→ compact thumb/chip enters Composer

repeat
→ ordered refs

Esc
→ exits Reference Pick only
→ Composer / Selection / existing refs remain
```

---

## 5.5 AddToReference micro-satellite 值得借，但不能永久出现

Lovart 的 24px satellite 很适合：

```text
Reference Pick active
+
hover eligible object

→ top-right reveal tiny Add Reference button
```

这比：

```text
所有对象永久显示 +Reference
```

高明太多。

### 状态

`HIGH CONFIDENCE`

---

# 6. Receiver + Run 深挖
## TapNow 是目前最强 donor，但 LCOS 不应变成 TapNow Agent

---

## 6.1 TapNow 的关键优点不是“有 Agent”，而是状态被拆得很干净

从 production bundle 可看到 session 级状态分别存在：

```text
conversationId
runId
lastEventId
streamState

messages
inputValue

attachments
contextNodeIds
quotedText

pendingQuestion
pendingConfirmation

queuedMessages
queuePauseReason

stoppedMessageIds
```

这里最重要的启发是：

> **draft、reference、conversation、run、confirmation、queue、reconnect 不应该揉进一个 Mega state。**

这正好符合 T3 目前的模块化方向。

---

## 6.2 Receiver presentation

LCOS 用户心智：

```text
这次交给哪段 Conversation
```

不是：

```text
这次选哪个 provider
```

因此 Receiver 应像：

```text
tiny Glyth identity / avatar
```

而不是一个表单 field。

推荐：

```text
footer:
[Glyth glyph] ▾
```

hover：

```text
创意总控
```

展开以后：

```text
最近 / 当前可用 Conversation
```

必要时显示：

```text
current
working
offline
```

但 provider/model 属于深层。

---

## 6.3 Run 状态不要抢 Composer

TapNow 很值得借的是：

```text
Agent running
→ input仍然存在
→ stop
→ 可以继续整理 canvas
→ 下一条 instruction 可以进 Queue
```

这与 LCOS 主画布始终活着的哲学非常一致。

---

# 7. Queue 深挖
## 这是很好的 donor candidate，但目前不是 V2 强制产品能力

重要：

> Queue 目前应当标 `CANDIDATE`，不能因为 TapNow 做得好就自行升级成 LCOS frozen feature。

但如果总规划 / Run 系统最终接受 Queue，TapNow 几乎可以直接作为体验答案。

---

## 7.1 TapNow production 中 Queue 的具体成熟点

Queue 不是右侧栏。

它是：

```text
input 上方的 lightweight top sheet
```

大致：

```text
max-height ≈ 148px
vertical scroll
```

row：

```text
one-line summary
truncate
pending
edit
cancel
drag reorder
```

拖拽排序：

```text
small activation distance ≈ 4px
vertical only
```

---

## 7.2 Queue 最成熟的一点：Edit 不是只把文字放回来

TapNow 编辑 queued item 时会恢复：

```text
text
attachments
contextNodeIds
quotedText
```

再把 queued item 移除。

这说明：

> **一条待执行任务是一份完整 draft snapshot，不是一串 string。**

如果 LCOS 将来有 Queue：

```text
queued Work Item
```

至少要保留：

```text
prompt
References
receiver
skill
params
target
```

不能只排队 prompt text。

---

## 7.3 TapNow top-sheet motion

bundle 中的 top-sheet motion 约为：

```text
spring
stiffness ≈ 420
damping ≈ 34
mass ≈ .82

entry:
opacity 0→1
y 10→0
scale .98→1

exit:
faster ~160ms
```

这非常适合作为：

```text
pending confirmation
queue
input request
recoverable error
```

这类 Composer 邻接状态的视觉模板。

### 结论

`DONOR CANDIDATE — NOT PRODUCT FROZEN`

---

# 8. Voice 深挖
## 产品语义已经冻结，现在只剩视觉和 editing correctness

V2 + 用户后续已经明确：

```text
selected text
→ replace

caret
→ insert

none
→ append
```

因此 Voice 不再是产品开放题。

---

## 8.1 推荐呈现

Composer footer：

```text
mic glyph
```

recording：

```text
mic region
→ short waveform
+ cancel
+ finish
```

而不是整个 Composer 换皮。

transcribing：

```text
tiny local progress
```

转写成功：

```text
apply exact editing rule
→ return to ordinary text edit
```

---

## 8.2 一个必须避免的 donor trap

很多 AI 产品：

```text
voice complete
→ immediately send
```

LCOS 不允许。

LCOS：

```text
voice
→ editable prompt
→ explicit Run
```

---

# 9. Semantic Give 深挖
## 这是目前最有 LCOS 味道、也是最不能整套抄 donor 的部分

V2 已经冻结：

```text
body touch target
= give / join / use
```

继续深挖 Spatial 后，这条可以变成非常具体的 motion choreography。

---

## 9.1 最优动作分段

### Phase A — Carry

左拖 source：

```text
source跟手
```

仍然是普通 direct manipulation。

---

### Phase B — Approach

source 进入 receiver proximity：

receiver 不应该等到真正 overlap 才突然亮。

应该逐步：

```text
subtle readiness
```

但不能像旧 sensor zone 那样在屏幕边缘冒一个大型投放区。

---

### Phase C — Hit

Spatial 的 drop 反馈有很好的“两阶段”思路：

```text
hit
→ immediate feedback

settle
→ spring
```

因此：

```text
真正进入 receptive body / field
0ms
→ receiver立即有 hit response
```

用户必须在松手前知道：

> “这里真的能接。”

---

### Phase D — Commit

pointerup：

先 commit semantic intent。

若不是 Move / Reparent：

```text
source不留在 receiver 位置
```

---

### Phase E — Transfer Illusion

一个轻 proxy / thumbnail / information shadow：

```text
从 source 当前位置继续流向 receiver
```

同时完整 source：

```text
spring 回 home
```

这两个 motion 同时发生，会让因果非常清楚：

> **东西没有搬家，但它的信息被给过去了。**

---

### Phase F — Receipt

receiver根据 species 给最小 receipt：

```text
Glyth
→ absorb + context hint

Collection
→ count / stack receipt

Scope
→ field inclusion

Workflow
→ input/work receipt

Assembly
→ source slot / target receipt
```

---

## 9.2 为什么“source return”应该是 home spring，而不是瞬间 teleport

Spatial 的 stack / gather / home 机制说明：

```text
return to stable position
```

用短 spring 比 snap 更自然。

推荐：

```text
~220–300ms
low overshoot
```

不要 source 突然闪现回去。

---

# 10. Right-drag 深挖
## 现在可以把“右键菜单”和“右拖 Semantic Carry”放在同一条 gesture grammar 里

V2 已冻结：

```text
Right-drag
= 借过去用，但 source不动
```

但工程 / UX 上必须解决：

```text
普通右键
vs
右键拖
```

---

## 10.1 推荐分叉

```text
right pointerdown on object
→ 暂时不立即打开 context menu

movement < drag threshold
+
pointerup
→ right-click management menu

movement >= Huabu drag threshold
→ semantic-carry recognizer wins
→ suppress management menu
```

这样没有“右键 Drop 模式”。

---

## 10.2 Right-drag 的 visual

activation：

```text
source stays fixed
```

从 source body 分离：

```text
small ghost / proxy
```

proxy：

```text
thumbnail / identity glyph
+
very slight tether to source only during carry
```

不要复制完整 node card。

---

## 10.3 Target receive

和 left Semantic Give 共用：

```text
receiver readiness
hit feedback
commit
receipt
```

不同只在 source：

```text
left give:
full object was carried
→ returns home

right give:
full object never moved
→ only proxy disappears/absorbs
```

---

## 10.4 极重要的实现纪律

Right-drag 不能：

```text
add window pointermove
add second gesture owner
add independent drag threshold
```

必须进入 Huabu existing pointer router / recognizer lifecycle。

本轮 recheck 也确认 Huabu 仍然有集中 CanvasGestures / pointer router，而且 current Canvas 继续依赖统一 `getDragActivationDistance()`。

所以 T3 应增加一个 neutral host recognizer，而不是自己写事件系统。

---

## 10.5 需要跨 T1 再核的一个冲突

一些成熟 canvas（包括 TapNow 官方操作）会让：

```text
right mouse drag
= pan
```

LCOS V2 已明确把 object right-drag 赋予 Semantic Carry。

因此最终必须冻结：

```text
right drag ON object
→ Semantic Carry

right drag ON blank canvas
→ 是否保留 pan，由 T1 输入 grammar 决定
```

这两者可以共存，只要 hit target 不同。

这个应作为：

`T1 × T3 GESTURE CROSS-REVIEW`

而不是让某个 recognizer“抢赢就算”。

---

# 11. Relation handle 深挖
## 关键不是做一个漂亮端口，而是只在“明确要连”时出现

TapNow 当前 canvas 使用连接点建立生成链：

```text
selected node
→ side +
→ drag connection
```

这个 mechanics 可以参考。

但 TapNow 的 connection 表示：

```text
upstream reference / generation lineage
```

不是 LCOS general Project Relation。

因此只借：

```text
small side receptor
drag line
valid target feedback
```

不借：

```text
默认所有 selected node 都常驻 + connector
```

---

## 11.1 LCOS Relation handle 推荐

default：

```text
hidden
```

进入 Relation intent 后：

```text
target edge
→ one or few small handle(s)
```

drag：

```text
quiet live line
```

valid target：

```text
receptor appears / lights
```

drop：

```text
line settle
```

---

## 11.2 与 Semantic Give 必须肉眼不同

Semantic Give：

```text
receiver “接东西”
```

视觉词：

```text
attention
absorb
receive
settle
```

Relation：

```text
receiver “接线”
```

视觉词：

```text
port
line
snap
connection settle
```

不能用同一套 halo/absorb。

---

# 12. Glyth 深挖
## Spatial 最值得借的是“生命感来自局部参数，不是整个身体不停变形”

Spatial creature/glyph 系统里，几何和 motion 分开：

```text
body geometry
= stable

motion layer
= squash
gazeX / gazeY
blink
eye morph
spin / translation
overlay
```

这是 Glyth 非常重要的设计答案。

---

## 12.1 Glyth 不应该如何反应

不要：

```text
拖东西靠近
→ 整个 Glyth 放大 1.3x
→ 紫色强光
→ 抖两下
→ 大标签“DROP HERE”
```

这会瞬间从“空间生命体”变成手游签到按钮。

---

## 12.2 Semantic Give → Glyth 推荐 choreography

### Far

```text
Glyth resting
```

### Approach

incoming source 接近：

```text
gaze toward source
```

必要时：

```text
tiny orientation shift
```

### Receptive

进入真正 receive range：

```text
slight squash / breath
subtle local field / halo
```

### Commit

pointerup：

```text
proxy shrink / travel into Glyth
```

### Settle

```text
tiny blink
or
short relaxed rebound
```

### Durable receipt

```text
context count / local context field
```

tether 是否 persistent，应继续服从 T5 的低 chrome 策略。

如果 persistent tether 太吵，可以只：

```text
select Glyth
→ reveal nearby mapped context
```

这比 Main 永久蜘蛛网更合理。

---

## 12.3 Relation → Glyth

完全不同：

```text
no gaze-to-absorb
no context count
no “eat” motion

Relation receptor
→ catches line
→ line settles
```

这能一眼区分：

```text
喂给 Conversation
vs
和 Conversation 建项目关系
```

---

# 13. 其它 Receiver 统一语法，但 receipt 不统一外形

这是本轮值得回传 T4/T5 的一条。

统一：

```text
approach
→ receptive
→ commit
→ source return / stay according to semantic
→ receipt
```

但 receipt 应 species-specific。

---

## 13.1 Collection

推荐：

```text
container/stack identity light response
→ miniature proxy sinks into stack
→ count +1
```

一般不留 line。

---

## 13.2 Scope

推荐：

```text
scope boundary / field acknowledges
→ object gains scoped state
```

不需要“被吃进去”的感觉。

---

## 13.3 Workflow

推荐：

```text
current work / input region receptive
→ input identity receipt
```

是否落入具体 slot，由 T4 Workflow UX 决定。

---

## 13.4 Assembly

推荐：

```text
current target / slot receptive
→ source identity attaches to current assembly task
```

不要把 source 从 Main 真搬走。

---

# 14. 当前 donor 的责任表

| 体验 | 最佳 donor | 借什么 | 不借什么 |
|---|---|---|---|
| Action Arc geometry | Orbit | satellite trig | visible wedge menu |
| Action Arc button | Lovart | 28–32px icon density | Lovart action taxonomy |
| Arc motion | Spatial | snappy settle | over-animated creature behavior |
| Multi-selection | Lovart | toolbar anatomy/capability reveal | design-tool-specific actions |
| Selection mechanics | Huabu | pointer/selection | second state owner |
| Composer visual | Lovart | compact shell/chips/popover | proprietary code |
| Composer mechanics | Huabu | controlled input/IME/send-stop | Huabu chat domain owner |
| Reference | Lovart + TapNow | canvas picker/chips | Selection auto→Reference |
| Receiver | TapNow | conversation identity/status | provider-first UX |
| Run | TapNow | stop/continuity | wholesale Agent product |
| Queue | TapNow | top-sheet/row/edit-rehydrate | not frozen yet |
| Voice visual | TapNow/Lovart patterns | footer-local state | auto-send |
| Semantic Give | Spatial | hit/settle/home spring | Spatial business semantics |
| Right-drag | LCOS + Huabu | one router/threshold | separate event system |
| Relation | TapNow mechanics | small receptor/line | generation lineage meaning |
| Glyth motion | Spatial | gaze/squash/blink/overlay | Spatial entity semantics |

---

# 15. 本轮发现的一个重要工程供应商更新

Huabu upstream 已从之前 audit 的：

```text
dc128fff...
```

推进到：

```text
538f3776ea57db40140a6265b8cf54811a4f296d
```

最新提交主要是：

```text
desktop DevTools
frame label ellipsis
```

没有发现 T3 需要改 donor 结论的 interaction shift。

当前 Huabu 仍保有：

```text
CanvasGestures
central pointer router
getDragActivationDistance()
ThreadChatInput
```

所以：

```text
T3 不需要因为 upstream 更新重新设计 pointer/input ownership
```

---

# 16. Orbit provenance 更新

Orbit 当前 GitHub main：

```text
03f8b4de2c79e6c697f4a5757f71dcdb2539ce26
```

与本地 donor pin 一致。

因此：

```text
Orbit satellite geometry
```

目前 provenance 和版本都稳定。

---

# 17. 当前真正还没有完全冻结的 T3 相关项

随着 V2 到来，之前很多 OPEN 已经关闭。

现在剩下的真正产品开放项已经很少。

---

## OPEN-A — Queue 是否进入 LCOS 默认 Run UX

TapNow 的答案很好。

但：

```text
Queue
```

目前不是 V2 明确要求。

建议总规划裁决：

```text
KEEP AS FUTURE CAPABILITY
or
GEN2 default
```

T3 不自行添加。

---

## OPEN-B — Relation-only object pair 的 body collision 具体范围

目前讨论已经形成原则：

```text
如果没有 membership/context/use 冲突
→ body碰撞可以直接 Relation
```

但需要 source × target matrix 正式列 species。

否则 Agent 会自己猜：

```text
Artifact → Artifact?
Result → Artifact?
Skill → Artifact?
Workflow → Context item?
```

---

## OPEN-C — right-drag blank canvas 与 pan

V2：

```text
object right-drag
= Semantic Carry
```

T1 仍需确认：

```text
blank right-drag
```

是否继续做 pan。

---

## OPEN-D — Glyth context receipt 的 persistent 程度

Context Mapping 真相已冻。

但视觉上：

```text
always tether
selected-only tether
count only
local field
```

属于 T5 / T3 high-fidelity cross-review。

---

## OPEN-E — Work View open 时 local Composer coexistence

仍是：

`T3 × T4`

V2 已冻：

```text
camera不动
screen UI让位
```

但 local Composer 与现有 Docked work region 的优先级还需要具体 scene 裁决。

---

# 18. 下一版 Demo 应该怎样重做

如果再做 T3 Demo，不应该只是 v2 polish。

应该验证以下 8 个真实场景：

---

## Scene 1 — 单对象

```text
first click
→ Selection only / according to species

content local work entry
→ exact V2 click hierarchy

Arc:
icon only
hover label
```

---

## Scene 2 — Multi-selection

```text
box select
→ compact Lovart-like toolbar
→ no Composer

AI Work
→ Composer
```

---

## Scene 3 — Reference Pick

```text
Composer
→ ref glyph
→ Canvas

hover object
→ tiny AddReference affordance
→ click
→ chip
```

---

## Scene 4 — Run

```text
Receiver = tiny Glyth identity
→ send
→ running
→ canvas remains usable
```

Queue only做：

```text
optional donor experiment
```

不能当 frozen UI。

---

## Scene 5 — Left Semantic Give

```text
drag Artifact
→ Glyth gaze
→ receptive
→ release
→ proxy absorbed
→ source home spring
→ context receipt
```

---

## Scene 6 — Right Semantic Carry

```text
right drag source
→ source fixed
→ ghost separates
→ receiver
→ absorb
```

---

## Scene 7 — Relation

```text
explicit relation intent
→ handle
→ line
→ Glyth receptor
→ connection settle
```

与 Scene 5 肉眼完全不同。

---

## Scene 8 — Work View

```text
dock right
→ camera/node unchanged

click local object
→ local UI fits remaining safe rect
```

用于交叉裁决 coexistence。

---

# 19. 当前 T3 最优 UX 总图

可以把现在的用户体验压成：

```text
REST
对象就是内容，不堆系统字

SELECT
Selection只说明“我现在碰谁”

LOCAL WORK
需要时 Arc / Composer 才围绕对象出现

MULTI
Selection toolbar，Composer不自作主张

REFERENCE
从画布明确挑，本轮使用，不改Selection

VOICE
说话变成可编辑文字

RUN
交给一段Conversation，不把provider推到用户脸上

GIVE
把东西给目标，目标接收，源对象按语义回位

RIGHT-GIVE
原对象完全不动，只拿proxy过去

RELATION
拉线，不“喂进去”

GLYTH
看、接、吃、连、说话分别有不同身体反馈
```

---

# 20. 本轮推荐冻结 / 不冻结

## 可以直接进入下一轮施工规划的

```text
Action Arc donor composition
Multi-selection toolbar anatomy
Reference picker anatomy
Compact Composer anatomy
Receiver identity anatomy
Voice presentation
Semantic Give motion grammar
Right-drag gesture split
Glyth receive vs relation motion distinction
```

---

## 仍不要进 exact implementation 的

```text
Queue as default product capability
unresolved source×target direct Relation matrix
blank right-drag pan conflict
Work View coexistence exact policy
Glyth persistent context visualization degree
```

---

# 21. 最后结论

这轮深挖以后，T3 已经不应该继续“设计一套新的 AI Canvas 控件”。

成熟答案已经足够多：

> **Lovart 提供局部工具和输入密度；TapNow 提供 Conversation / Run 连续性；Spatial 提供空间动作和生命感；Orbit 提供最薄的 Arc 几何；Huabu 提供真实 pointer / selection / floating / input mechanics。**

LCOS 自己真正要保留的只有：

```text
Selection
Reference
Relation
Context Mapping
Receiver
canonical identity
semantic target
搬 / 给 / 右拖 / 连
```

也就是：

> **不要重新发明按钮。  
> 只认真设计“这个动作到底是什么意思”。**

当语义已经被 V2 冻结以后，后面的工作就应该越来越像成熟产品收编和薄适配，而不是继续抽象讨论。
