# LCOS Gen2 · T3 第三路
## V6 反惰性更新 · Donor 深挖 · 模块化直接复用审计 V1

> 日期：2026-09-04  
> 线程：T3 · Local Object Interaction / Action Arc / Compact Composer / Reference / Voice  
> 性质：**中间审计正本，不是最终五册 Source-Level Construction Plan**  
> 当前阶段：`ROUND_1_CLOSED → ROUND_2/3_COMPLETE_ENOUGH → ROUND_4_DONOR_DEEP_DIVE → ROUND_5_CROSS_BOUNDARY_PRELIMINARY`

---

# 0. 结论先行

这一批补充以后，第三路原先的 ExactFile blocker 已经解除。

更重要的是，T3 现在已经能看出一条非常明确的 Gen2 模块化复用路线：

```text
Huabu
= 唯一 pointer / selection / drag / geometry / popover placement mechanics

LCOS
= Reference / Relation / target / action semantics / Run / Core identity

成熟 proprietary donor
= “应该长什么样、什么时候出现、怎么动、怎么显隐”

成熟 OSS donor
= “通用 UI body / radial geometry / recorder primitive 怎么实现”

最终组合
= Huabu mechanics
  → LCOS thin semantic adapter
  → replaceable donor body
```

因此：

> **T3 完全可以通过模块化，直接吃现成成熟设计和成熟轮子。**

但“模块化”不能理解成新增一个巨型：

```text
SpatialInteractionKernel
InteractionManager
ActionCapabilityRegistry
ComposerFramework
```

那只是换一种方式重新造轮子。

T3 正确的模块化是：

> **canonical owner 稳定，placement/mechanics 稳定，supplier body 可替换。**

目前最值得保护的现成 seam：

```text
Huabu pointer router
Huabu selection truth
CanvasHostExtension
ProjectionBinding
referenceController
CanvasFloatingPopover
NodeFloatingToolbar
Popover / DropdownMenu
Local Core voice transcription
```

目前最应该整块替换的 transitional UI：

```text
LcosComposerShell.tsx
```

目前最应该新增、但必须保持极薄的 LCOS 增量：

```text
local action semantic policy
Action Arc replaceable body
target-local Composer composition
temporary Reference Pick presentation mode
Voice recorder adapter
Core multipart voice client seam
```

---

# 1. 本轮 V6 对 T3 的真正变化

V6 不是简单地“多了几个 donor”。

它把 donor 工作正式升级成了：

```text
product build archaeology
→ wheel provenance
→ exact upstream
→ license
→ direct-use / wrap / lift
→ LCOS replacement boundary
```

也就是说以后看到 LibTV / TapNow / Lovart bundle 中一个成熟交互，不能直接得出：

```text
“照着写一个”
```

而应该先问：

```text
它背后是不是已有成熟 OSS wheel？
Huabu 自己是不是已经有同类 mechanic？
如果有，为什么还要自写？
```

T3 本轮已经验证出三个非常典型的例子：

1. Action Arc 的 positioning 不该自己写；
2. Voice recorder 不该自己写；
3. Composer 也不能因为发现 CopilotKit 就把整颗 chat ownership 搬进来。

这就是 V6“反惰性”的实际意义。

---

# 2. Round 1 · ExactFile blocker 已解除

上一轮 T3 缺失的 mandatory originals 已通过本轮 `Library补充` + File Library recovery 闭合。

已重新取得并纳入当前权威链的关键原文包括：

```text
LCOS_v015_原文到后续施工计划_差分审计_20260831.md
LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md
LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md
LCOS_v0.15_UX冻结_Relation_Glyth_Colony_SpatialNavigation_20260829.md
LCOS_v015_三Surface交互同构硬规则_20260831.md
LCOS_v015_Lovart_Composer_ReferencePick_补充拆解_20260831.md
LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md
LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md
LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md
```

同时重新承接：

```text
Unified Compact Composer freeze
全功能最新冻结总账
Mandatory Preconstruction Context
三 Surface interaction grammar
Semantic Drop genealogy
MD2 / MD3 source audit
Phase A / Phase C historical plans
D03g Glyth interaction grammar
GUI SOP
Context Recovery Census
```

因此当前不再有：

```text
MISSING_RAW_IN_CURRENT_SESSION
```

阻止 T3 进入源码与 donor 审计。

---

# 3. T3 当前不可回滚的产品语义

## 3.1 Selection / Reference / Relation 三分

```text
Selection
= Huabu 当前空间操作集合

Reference
= 当前 Composer / Run 用户显式选择的有序输入

Relation
= Local Core 中长期存在的 canonical semantic truth
```

禁止：

```text
Selection → 自动 Reference
Reference → 自动 Relation
靠近 → 自动 Relation
```

当前 `referenceController.ts` 已经正确体现这个纪律：

- ordered list；
- 不用 Set round-trip；
- opening Composer 不复制 Selection；
- identity 只比较 `entityType + entityId`。

这一层应该 `PROTECT`，不是 donor replacement target。

---

## 3.2 三 Surface 同一套 pointer mechanics

Main / Context / Workflow：

```text
共享：
Huabu pointer
selection
drag
resize
popover
reference grammar
Composer grammar

不同：
对象含义
Relation 语义
Surface-specific Component
Glyth / Workflow target action
```

因此 T3 禁止：

```text
MainInteraction.ts
ContextInteraction.ts
WorkflowInteraction.ts
```

各写一套手势。

---

## 3.3 Action Arc 不是管理菜单

Action Arc：

```text
3–5 个最高频 direct actions
```

Right-click / More：

```text
Open / Focus
Pin
Add Reference
Assembly
Duplicate（允许时）
Reveal / Source
Delete / Remove Projection
More
```

也就是说：

> Arc 是“下一步最可能做什么”，右键是“这个对象还能怎么管”。

两者不能合并成一个大型 CRUD 花盘。

---

## 3.4 Composer 必须 target-local

正确：

```text
target object
  ↓
附近 Compact Composer
  ↓
Prompt / Reference / Skill / Run / Voice
```

错误：

```text
selection
→ 固定底部全局输入框

或

selection
→ 固定右侧大栏
```

Composer：

- idle 1–2 行；
- 3–4 行 max；
- 超出内部 scroll；
- explicit reference chips / thumbnail；
- Add Reference 进入轻量 temporary pick；
- picking 时 Composer 保持原位；
- pointerdown 不抢 focus；
- drag 继续属于 drag；
- Voice 是输入 modality，不是新 panel。

---

# 4. Current Source 动态基线

本轮重新核验：

## LCOS Gen2

```text
repo:
DZWFLi/LCOS_Gen2

main:
c2ff890a867922a1256572199458438572eb0a8c
```

## Vendored Huabu pin

```text
58339e269b784728d67730c70bfe7792cae2457d
```

construction host：

```text
DZWFLi/LCOS_Gen2/huabu/
```

## Huabu upstream current

```text
microsoft/Huabu
dc128fff2d37b5481ec305070a7e86d3de85f7d2
```

当前 upstream 相对 pin 已有后续 delta。

T3 直接相关变化包括：

```text
DropdownMenu
NodeFloatingToolbar
ChatInput
new ThreadChatInput
Canvas
ChatInput / ThreadChatInput tests
chat-composer-performance e2e
```

因此 final plan 必须同时面对：

```text
vendored current construction host
+
Huabu upstream current supplier
```

不能只看旧 pin。

---

# 5. Current Source · 已经成熟到不应该重写的 mechanics

# 5.1 `CanvasFloatingPopover`

当前已经解决：

```text
flow rect → screen rect
document.body portal
@floating-ui
offset
flip
shift
canvas boundary
viewport clamp
ResizeObserver
side panel / attention arbitration
takeover geometry compatibility
```

结论：

```text
ADOPT
```

T3 绝不再写：

```text
getBoundingClientRect
+ magic offset
+ viewport clamp
+ window resize listener
```

去定位 Action Arc / Composer。

---

# 5.2 `NodeFloatingToolbar`

当前已经：

- 使用 live internal node geometry；
- resize 时优先 authoritative style rect；
- auto-sized node fallback measured；
- takeover/collapse 后 anchor 跟 mark；
- multi-select modifier 时主动让位；
- 通过 `CanvasFloatingPopover` 定位。

结论：

```text
ADOPT / WRAP
```

Action Arc 只应该学习它的：

```text
anchor lifecycle
placement
takeover support
attention suppression
```

而不是再造一个 toolbar positioning subsystem。

---

# 5.3 `Popover`

当前已有：

```text
screen-space position
mouse fallback
viewport / boundary clamp
portal
outside pointer dismiss
Escape dismiss
nested portal safety
ResizeObserver
```

因此 blank-area / node right-click menu 不需要新菜单引擎。

---

# 5.4 `DropdownMenu`

当前已有：

```text
controlled / uncontrolled open
trigger
outside dismiss
Escape
nested submenu
hover
ArrowRight keyboard activation
shortcut / trailing slot
```

结论：

```text
ADOPT
```

LCOS 只提供：

```text
menu semantic action list
```

不提供第二个 menu framework。

---

# 5.5 Huabu pointer router

当前 Huabu `Canvas.tsx` 已经：

```text
stock recognizers
...
hostExtension.recognizers
```

追加进**同一个 pointer router**。

已有 LCOS：

```text
reference-pick recognizer
drop observer
```

因此新的：

```text
selected-then-click
right-click
local affordance intent
```

若需要 pointer-level 判断，也必须进入：

```text
hostExtension.recognizers
```

不能：

```text
document.addEventListener('pointerdown', ...)
window.addEventListener('click', ...)
```

再起一套 interaction lifecycle。

---

# 6. Reference current source：KEEP，而不是重写

当前正确链：

```text
ProjectionBinding
→ reconcile
→ nodeId → CoreEntityRef cache
→ referenceController ordered draft
→ reference recognizer
→ Composer reference strip
```

当前 recognizer 已经做到：

- Ctrl/Cmd mouse only；
- Shift 永远留给 additive Selection；
- only LCOS projected/bound node；
- unbound native node fail-close；
- 4px drag slop；
- pointerup 才 toggle；
- 避免 trailing click 把 Reference 变 Selection。

结论：

```text
REFERENCE SEMANTIC:
PROTECT

REFERENCE VISUAL:
REPLACEABLE

REFERENCE PICK UX:
EXTEND
```

---

# 7. Reference Pick 缺的不是第二套 Reference store

Composer `Add Reference` 需要：

```text
REST
→ COMPOSE
→ REFERENCE_PICK
→ COMPOSE
```

Reference Pick mode：

```text
Composer 位置不动
tiny “Reference Pick · Esc”
点击 eligible object → toggle ordered ref
canvas object 给轻反馈
Reference Strip 立即更新
Esc → 退出
```

当前 Ctrl/Cmd Quick Reference 已经有。

所以正确扩展应是：

> 在**现有 Reference presentation owner** 中增加一个极小的 temporary picking intent，而不是新建 SelectionLikeReferenceStore。

例如概念状态：

```ts
referencePickMode:
'idle' | 'composer-pick'
```

它不是 canonical truth。

它不持久化。

它不能改变 Huabu Selection。

它只决定：

```text
同一个 reference recognizer
是否接受：
Ctrl/Cmd click
或 explicit composer-pick click
```

---

# 8. Action Arc · 模块化复用结论

## 8.1 Semantic owner

Action Arc 不应该自己拥有 capability universe。

推荐：

```text
Core / ProjectionBinding / surface context
→ small pure action resolver
→ top 3–5 direct actions
→ ActionArcBody
```

不要做：

```text
one giant ActionCapabilityRegistry
```

resolver 只回答：

```text
这个 target 当前最高频能做什么？
```

例如：

```text
Artifact
→ Open / Relation / Pin / Assembly / More

Glyth
→ Speak / Relation / Pin / Set Current / More

Workflow Action
→ Open Work / Reference / Run / More
```

具体动作仍去各自正式 owner。

---

## 8.2 Placement

```text
target node / takeover mark
→ CanvasFloatingPopover
→ ActionArcBody
```

禁止 Action Arc body 自己知道：

```text
camera
viewport
canvas transform
WorkView geometry
```

这些都由 L5 placement 输入解决。

---

## 8.3 `orbit-css` 深挖结论

本轮源码：

```text
repo:
zumerlab/orbit

package:
@zumer/orbit

version:
1.4.12

commit:
9b8906713a9e8d5fb48e04df824401c65acf6a16

license:
MIT
```

源码职责主要是：

```text
CSS radial geometry
orbit radius
satellite angular layout
arc display
ResizeObserver ratio helper
```

关键好处：

```text
.orbit
pointer-events: none

.satellite
pointer-events: all
```

它没有自己的：

```text
selection store
action semantics
click state machine
canvas camera
```

因此非常符合 T3。

### 当前建议

```text
ENGINEERING_STATUS:
LIFT / DIRECT_STYLE_USE_CANDIDATE

VISUAL_STATUS:
STYLE_STRUCTURE_DONOR
```

最稳的落法：

```text
保留 Huabu/React 事件
保留 LCOS action state
只采用 Orbit radial geometry / CSS variables
不用它管理 interaction state
不用它接 canvas lifecycle
```

不建议直接把：

```text
window.Orbit
custom element lifecycle
global themes
```

作为 LCOS Action Arc owner。

Replacement boundary：

```text
ActionArcBody only
```

最大爆炸半径：

```text
L4–L6
```

---

# 9. Right-click · 不需要新 context-menu framework

当前 Huabu Canvas 根容器：

```text
onContextMenu
→ 对非编辑区域阻止浏览器默认菜单
```

但还没有 LCOS 业务菜单。

正确扩展有两种成熟机械可以直接用：

```text
Pointer Router:
识别右键 target / position

Popover:
screen-space placement

DropdownMenuItem:
menu row / shortcut / nested structure
```

因此：

```text
right-button pointer
→ Huabu router
→ target resolve
→ LCOS action resolver(management mode)
→ Popover at clientX/clientY
→ DropdownMenuItem body
```

不需要：

```text
ContextMenuManager
ContextMenuStore
new global window contextmenu listener
```

编辑器/input/contenteditable 继续保留 native menu。

---

# 10. selected-then-click / double-click

## 10.1 selected-then-click

建议仍走：

```text
Huabu pointer router
→ LCOS observer recognizer
```

recognizer：

```text
pointerdown:
记录 target + 是否已 selected + start point

move:
超过 stock drag threshold → cancel affordance candidate

pointerup:
stable + target was selected
→ reveal local affordance
```

它：

```text
canClaim = false
```

除非进入明确的 LCOS exclusive gesture。

因此不会抢：

```text
selection
drag
resize
pan
```

---

## 10.2 double-click

Huabu 当前已有 stock：

```text
onNodeDoubleClick
→ expandable node → Preview
```

普通 content species 这可能直接复用。

但 Glyth / future LCOS-specific species 必须支持：

```text
species-specific open/edit/work
```

### 当前唯一值得考虑的极窄 Host seam

如果 LCOS species 需要覆盖 stock double-click：

```text
hostExtension.activationIntent?.onNodeDoubleClick(...)
```

返回：

```text
handled
native
```

具体失败场景：

```text
Glyth double-click
需要进入 Glyth-specific work/open

但 Huabu Canvas 只认识 native node type
```

如果没有 seam，只有两个坏选择：

1. 把 `Glyth` 业务判断硬编码进 Huabu `Canvas.tsx`；
2. 再加 document/window dblclick listener，与 ReactFlow/PointerRouter 平行。

所以这一处如果最终确认需要，是合理的**极窄已有 HostSeam 扩展**。

它不是新 interaction framework。

---

# 11. Composer current source：壳应该整块退役

当前：

```text
huabu/apps/web/src/lcos/LcosComposerShell.tsx
```

真实状态：

```text
fixed bottom-center
width 360
inline style
local prompt state
Reference strip
无正式 submit
无 Voice
无 target-local anchor
```

源码自身已经写明后续会被接管。

结论：

```text
LcosComposerShell UI:
RETIRE / REPLACE

Reference semantics:
KEEP
```

不要继续给 interim shell 打补丁直到它变成另一座历史遗迹。

---

# 12. Huabu ChatInput 到底能复用多少

当前 Huabu `ChatInput` 已有：

```text
controlled value
onChange
submit
stop streaming
IME safe Enter
2–5 line auto-grow
attachment upload
paste
drop
source/ref presentation
slash command
history
focus request
agent/session slots
```

这证明：

> Composer 的大量通用 input mechanics 已经成熟。

但是 `ChatInput` 还直接依赖：

```text
useChatSession
useChatStore
thread pending attachments
Huabu chat session semantics
```

所以不能简单：

```tsx
<LcosComposer>
  <ChatInput />
</LcosComposer>
```

然后假装完成。

那会把：

```text
LCOS Run draft
```

错误绑定成：

```text
Huabu Chat thread draft
```

---

# 13. Huabu upstream `ThreadChatInput` 的意义

upstream main 已新增：

```text
ThreadChatInput.tsx
```

它把：

```text
draft owner
```

从 `ChatInput` body 外提到：

```text
chatStore/threadId
```

再把：

```text
value
onChange
onSubmit
```

喂给 `ChatInput`。

这是一个非常好的 upstream direction signal：

> 输入 body 与 draft owner 正在解耦。

T3 final plan 应优先审计：

```text
能否在同步 upstream 后
进一步把 generic composer body 抽成 Huabu Common primitive
```

而不是 LCOS 自己复制一份 ChatInput。

### 当前裁决

```text
Huabu ChatInput:
WRAP / MECHANICS_DONOR

ThreadChatInput:
UPSTREAM_ADOPT_PATTERN

Whole Huabu chat ownership:
REJECT for LCOS Composer
```

---

# 14. LibTV 深挖：发现的真正价值是 CopilotKit provenance

V6 指定 T3 LibTV chunks 中已经确认：

```text
CopilotKit Chat UI
AudioRecorder
Transcribe
attachments
MediaRecorder
AudioContext
waveform
Radix/Floating primitives
Slate
ReactFlow
```

这不意味着：

```text
COPY LibTV bundle
```

正确 provenance：

```text
LibTV product build
→ 识别 CopilotKit
→ 回到 CopilotKit upstream
→ license / exact file audit
```

---

# 15. CopilotKit upstream · Voice recorder 可以真正 LIFT

本轮动态核验：

```text
repo:
CopilotKit/CopilotKit

current observed main:
3472104d06eb53ae9d23541d8b60ff81c0c7684a

license:
MIT
```

关键文件：

```text
packages/react-core/src/v2/components/chat/CopilotChatAudioRecorder.tsx
```

它已经成熟解决：

```text
idle / recording / processing FSM
navigator.mediaDevices.getUserMedia
MediaRecorder
audio/webm;codecs=opus
audio/webm
audio/mp4 fallback
permission denied
no microphone
recording failure
stream track cleanup
AudioContext cleanup
requestAnimationFrame cleanup
waveform
DPR resize
imperative start / stop / dispose
```

### 当前裁决

```text
CopilotChatAudioRecorder:
LIFT CANDIDATE

Whole CopilotChatInput:
REJECT
```

原因：

Whole CopilotChatInput 还会带进：

```text
CopilotKit provider semantics
chat ownership
tooling assumptions
styling namespace
input mode structure
```

LCOS 不需要。

Voice recorder 本身却是高度独立的成熟 primitive。

---

# 16. Voice backend 其实已经存在

Current Core 已经有：

```text
POST /runtime/voice/transcriptions
```

支持：

```text
multipart/form-data
audio/*
durationMs
language
prompt
timestamps
providerId
AbortSignal
typed error mapping
typed response
```

因此 Voice 不需要再建：

```text
VoiceServiceV2
VoiceWorkbench
Voice panel
Voice entity
```

正确链：

```text
CopilotKit recorder primitive
→ Blob
→ Local Core voice transcription route
→ transcript
→ SAME Composer prompt draft
→ user edits
→ explicit Send
```

冻结状态：

```text
Idle
→ Recording
→ Transcribing
→ Editable Text
→ Explicit Send
```

---

# 17. Voice 当前唯一明显 transport gap

当前 `HttpClient`：

```text
body
→ JSON.stringify
Content-Type: application/json
```

所以不能直接拿它发 multipart audio。

最薄的正确增量是：

```text
postFormData<T>()
```

或等价 raw-body transport support。

硬规则：

```text
FormData 请求不得手动设置 Content-Type boundary
```

浏览器必须自己生成 multipart boundary。

这个增量：

```text
只属于 transport
不持有 Voice state
不持有 Composer state
不持有业务 truth
```

Replacement boundary：

```text
backend client transport method
```

然后 T3 Voice adapter 只负责：

```text
Blob
→ FormData
→ transcribe
→ text
```

---

# 18. Lovart · 工程不能抄，但 UI 可以高保真借

## 18.1 `AddToReference`

bundle 中确认成熟设计：

```text
image cell top-right local satellite
默认隐藏
group hover / focus-within reveal
trigger 约 24×24
icon 约 16
popover bottom / end
side offset 约 4
menu 中明确 Add to Reference
```

这不是让 LCOS 抄 Lovart JS/CSS。

它可以转成 LCOS implementation spec：

```text
reference satellite:
24px hit target
16px icon
贴 target 右上
rest hidden
hover/focus reveal
120–180ms opacity
popover offset 4–6px
```

然后实现用：

```text
Huabu Popover
Huabu Button/Common
LCOS icon/token
```

---

## 18.2 `SelectFromCanvas`

Lovart 也确认：

```text
Reference input
→ Upload
→ Paste
→ Select From Canvas
```

Canvas reference pick 不是弹大 modal。

它是轻量 temporary interaction state。

这与 LCOS freeze 完全一致。

### 裁决

```text
ENGINEERING:
PROPRIETARY_REFERENCE_ONLY

VISUAL:
HIGH_FIDELITY_UI_DONOR
```

---

# 19. TapNow · 最大价值不是“抄一个菜单”

TapNow bundle 中 T3 相关证据显示它成熟地区分了：

```text
selectionToolbar policy
contextMenu policy
attachments
contextNodeIds
quotedText
pendingVoiceInput
isVoiceRecording
pendingVoiceStop
isUploading
streamingMessageId
thinkingActivity
toolActivity
run event recovery
last_event_id
```

价值是：

> local interaction、input、run、voice、recovery 被分成不同责任，不挤进一个 UI store。

对 T3 的启发：

```text
Arc open
≠ Run state

Voice recording
≠ transcript

Reference
≠ Selection

attachment
≠ target identity

stream recovery
≠ Composer presentation
```

### 裁决

```text
ENGINEERING:
PROPRIETARY_REFERENCE_ONLY

ARCHITECTURE:
RESPONSIBILITY_DONOR

VISUAL:
HIGH_FIDELITY_LOCAL_INTERACTION_DONOR
```

---

# 20. Spatial v4 · 只校准空间因果，不接管 pointer

Spatial v4 新证据仍指向：

```text
full-screen immersive canvas
低 chrome
in-place edit
selected block local menu
~200ms lightweight reveal
~220–260ms low-overshoot direct manipulation transition
```

它还明确强化：

```text
不要第二 gesture owner
不要第二 animator
不要第二 zoom store
```

因此：

```text
ENGINEERING:
BEHAVIOR_REFERENCE

VISUAL / MOTION:
HIGH_FIDELITY_INTERACTION_DONOR
```

T3 只拿：

```text
timing
easing direction
local causal reveal
control distance
low-bounce feel
```

不拿：

```text
runtime ownership
canvas implementation
gesture engine
```

---

# 21. LibTV Skills：MIT，但第三路当前不硬吃

`libtv-skills`：

```text
MIT
```

当前可见能力集中在：

```text
create_session
query_session
change_project
upload_file
download_results
```

它们更接近：

```text
Run / external execution / session integration
```

不是 T3 local Composer visual/mechanics 的直接 body。

所以第三路当前标：

```text
ENGINEERING_STATUS:
DIRECT_USE_ALLOWED

T3_RELEVANCE:
LOW / CROSS_THREAD_T4_T6
```

不因为“MIT”就强行塞进 T3。

---

# 22. T3 Donor Adoption Ledger · 当前初裁

| 能力 | Supplier / Donor | Engineering | Visual | T3 裁决 |
|---|---|---|---|---|
| Pointer lifecycle | Huabu | ADOPT | — | PROTECT |
| Selection truth | Huabu | ADOPT | — | PROTECT |
| Projection identity | ProjectionBinding | ADOPT | — | PROTECT |
| Reference semantics | LCOS referenceController | ADOPT | — | PROTECT |
| Floating placement | CanvasFloatingPopover | ADOPT | tune | PROTECT |
| Node anchor | NodeFloatingToolbar | ADOPT/WRAP | tune | PROTECT |
| Generic popover | Huabu Popover | ADOPT | tune | PROTECT |
| Right-click menu rows | Huabu DropdownMenu | ADOPT | tune | PROTECT |
| Action Arc radial geometry | `@zumer/orbit@1.4.12` | LIFT / style-use candidate | tune LCOS | STRONG |
| Action Arc look/reveal | Lovart/TapNow/Spatial | reference only | HIGH_FIDELITY | STRONG |
| Composer current shell | LcosComposerShell | — | — | RETIRE |
| Textarea/input mechanics | Huabu ChatInput | WRAP | tune | STRONG |
| Draft/body separation | Huabu upstream ThreadChatInput | ADOPT PATTERN | — | STRONG |
| Whole Huabu chat ownership | Huabu ChatPanel | REJECT | — | DO NOT IMPORT |
| Whole CopilotKit input | CopilotKit | REJECT | style ref | TOO MUCH OWNER |
| Audio recorder | CopilotKit AudioRecorder | LIFT | LCOS tune | STRONG |
| Voice transcription | Local Core route | ADOPT | — | PROTECT |
| Lovart AddToReference | Lovart bundle | REFERENCE_ONLY | HIGH_FIDELITY | STRONG |
| Lovart SelectFromCanvas | Lovart bundle | REFERENCE_ONLY | HIGH_FIDELITY | STRONG |
| TapNow local UI/state | TapNow bundle | REFERENCE_ONLY | HIGH_FIDELITY | STRONG |
| Spatial local motion | Spatial v4 | BEHAVIOR_REFERENCE | HIGH_FIDELITY | STRONG |
| LibTV product bundle | LibTV | WHEEL_PROVENANCE_ONLY | design evidence | NO COPY |
| libtv-skills | libtv-labs | DIRECT_USE_ALLOWED | — | LOW T3 RELEVANCE |

---

# 23. 推荐的 T3 模块结构

重点：

> 以下是责任结构，不要求为了漂亮目录强行一层一个 package。

```text
┌────────────────────────────────────────────┐
│ Local Core                                 │
│ Relation / Run / Voice / canonical entity  │
└───────────────────┬────────────────────────┘
                    │
┌───────────────────▼────────────────────────┐
│ ProjectionBinding / Gen2 Host              │
│ nodeId ↔ CoreEntityRef                     │
└───────────────────┬────────────────────────┘
                    │
┌───────────────────▼────────────────────────┐
│ T3 Semantic Layer                          │
│ Reference                                  │
│ Local Action resolver                      │
│ target / Run adapter                       │
└───────────────────┬────────────────────────┘
                    │
┌───────────────────▼────────────────────────┐
│ Huabu Mechanics                            │
│ pointer / selection / drag                 │
│ Popover / Node anchor / input mechanics    │
└───────────────────┬────────────────────────┘
                    │
┌───────────────────▼────────────────────────┐
│ Replaceable Bodies                         │
│ ActionArcBody                              │
│ CompactComposerBody                        │
│ Reference satellite                        │
│ Voice recorder body                        │
└────────────────────────────────────────────┘
```

视觉 donor 以后换掉：

```text
只动最后一层
```

radial supplier 换掉：

```text
只动 ActionArcBody
```

Voice waveform 做丑：

```text
只动 recorder body
```

Composer geometry 做歪：

```text
只动 Composer body / placement
```

不能连带：

```text
Reference truth
ProjectionBinding
Selection
Pointer
Core
```

---

# 24. 建议的源码 replacement boundaries

## 24.1 Action Arc

```text
Canonical truth:
none

Semantic owner:
LCOS small local-action policy

Pointer:
Huabu router

Anchor:
CanvasFloatingPopover / NodeFloatingToolbar geometry

Body:
replaceable

Donor:
Orbit CSS + Lovart/TapNow/Spatial visual evidence

Max blast radius:
L3–L6
```

---

## 24.2 Right-click

```text
Target resolve:
Huabu pointer route

Action semantics:
same LCOS action resolver
management mode

Placement:
Huabu Popover

Rows:
Huabu DropdownMenuItem

Max blast radius:
menu body / action policy
```

---

## 24.3 Composer

```text
Target identity:
ProjectionBinding / CoreEntityRef

Reference:
existing referenceController

Input mechanics:
Huabu reusable ChatInput mechanics

Draft:
LCOS Composer/Run draft owner

Placement:
CanvasFloatingPopover

Body:
replaceable

Voice:
input slot

Run:
Core client

Max blast radius:
L3–L6
```

---

## 24.4 Voice

```text
Recorder:
CopilotKit MIT primitive

Transcription:
Local Core

Draft insertion:
same Composer draft

Auto-send:
NO

Max blast radius:
recorder / adapter / transport
```

---

# 25. T3 最重要的“不要新增”

当前没有证据支持新增：

```text
InteractionKernel
ActionCapabilityRegistry
ComposerFramework
VoiceWorkbench
VoicePanel
ReferenceSelectionStore
ContextMenuFramework
PopoverEngine
PositioningEngine
second Selection store
second pointer lifecycle
second canvas event bus
```

尤其：

> `LcosHostOverlay` 已经是一个热点，不能继续把所有业务状态、action、Composer、WorkView、HUD 都塞进去。

它只应继续作为：

```text
composition + overlay arbitration
```

body 自己分模块。

---

# 26. 当前唯一可能合理新增的很薄能力

## A. local action pure resolver

前提：

```text
只输出 action descriptors
不存 state
不 dispatch pointer
不做 Core truth
```

这是为避免：

```text
Action Arc
Right-click
More menu
```

各自复制一份 action policy。

---

## B. Reference Pick temporary intent

放进现有 Reference presentation owner。

不新建 canonical store。

---

## C. Voice multipart transport method

因为当前 HttpClient JSON body 无法上传 audio multipart。

这是 transport gap，不是新业务层。

---

## D. 极窄 double-click Host seam（仅在必要时）

只在：

```text
LCOS species-specific dblclick
无法通过 stock Huabu Preview 行为表达
```

时增加。

失败场景已明确：

```text
Glyth 双击应进入 Glyth-specific work
stock Huabu expandable node 只会 Preview
```

如果不加 seam：

```text
Huabu Canvas 硬编码 LCOS
或
第二 global dblclick listener
```

二者都更坏。

---

# 27. Preliminary High-Fidelity UI implementation targets

这还不是最终 T5 视觉稿，但 T3 已经能把交互规格压到施工级。

## Action Arc

建议交互尺寸范围：

```text
satellite button:
28–32px visual body
32–36px practical hit region

icon:
14–16px

target gap:
8–12px

actions:
3–5

reveal:
120–180ms opacity/scale
```

Spatial calibration：

```text
no springy bounce
low overshoot
causal local reveal
```

Orbit geometry：

```text
radial only
no pointer ownership
```

---

## Reference satellite

Lovart-derived high-fidelity target：

```text
rest:
hidden / near-hidden

hover/focus:
reveal

trigger:
~24px

icon:
~16px

local popover:
4–6px offset

feedback:
reference strip update
object reference badge
no toast
```

---

## Compact Composer

```text
width:
target-relative, not global 360px fixed

idle:
1–2 lines

max:
3–4 lines

overflow:
internal scroll

reference:
inline chips/thumb

bottom row:
Reference / Skill / Voice / Send-or-Run

placement:
near target
flip / shift via CanvasFloatingPopover
```

禁止：

```text
big fixed panel
large toolbar chrome
mode button zoo
automatic focus
```

---

# 28. Gesture architecture · 当前推荐

```text
pointerdown
↓
Huabu pointer router

├─ existing native selection/drag
├─ reference recognizer
├─ semantic drop observer
└─ local affordance observer
```

### stable first click

```text
Huabu Selection
→ feedback
```

### selected object stable re-click

```text
local affordance observer
→ Arc / Compact Composer reveal policy
```

### movement over stock threshold

```text
cancel local reveal
→ drag continues
```

### double-click

```text
native species:
Huabu stock behavior

LCOS special species:
optional host activation seam
```

### right-click

```text
Huabu router
→ local menu target
→ Popover
```

### Ctrl/Cmd click

```text
Reference
```

### Shift click

```text
Huabu additive Selection
```

### Composer Reference Pick

```text
same reference recognizer
+ temporary pick intent
```

---

# 29. Cross-thread handoff

## 给 T1

T3 依赖：

```text
collapsed / takeover mark anchor rect
```

不得自己算 mark geometry。

---

## 给 T2

T3 需要：

```text
WorkView occupied/safe rect
global command entry
context menu/global shortcut ownership
```

但 T3 不实现 viewport/chrome truth。

---

## 给 T4

Composer：

```text
Skill target
Assembly target
Run target
WorkView launch
```

只接 T4 正式 owner。

T3 不造 WorkView。

---

## 给 T5

T3 会给：

```text
Action Arc contract
Composer contract
Reference satellite contract
Voice state contract
motion range
replacement boundary
```

T5 决定最终视觉 body。

---

## 给 T6

需要复核：

```text
Run submit client
Voice multipart client
Core failure / retry / abort
Relation / Reference contracts
```

T3 不自造 Core 语义。

---

# 30. 当前不是最终五册的原因

V6 要求最终 T3 交付至少：

```text
01_Evidence_Census_Authority_Recovery.md
02_Current_Source_Consumer_Owner_Audit.md
03_Donor_Upstream_Adoption_Retirement_Matrix.md
04_Source_Level_Construction_Plan.md
05_Acceptance_Recovery_CrossReview_Plan.md
99_COORDINATOR_HANDOFF.md
```

本稿已经完成：

```text
Round 1 blocker close
Current source owner skeleton
major donor wheel provenance
major replacement boundary
initial adoption ledger
cross-thread preliminary
```

但还没有把 V6 的全部 gesture checklist：

```text
blank
content node
functional node
Glyth
multi selection
frame
edge/path
editing text
external drop
WorkView occupied
...
```

逐项压成：

```text
pointerdown
pointermove
pointerup
dblclick
contextmenu
Escape
failure
recovery
```

所以当前**不冒充最终施工正本**。

---

# 31. 当前总裁决

T3 不需要重建。

而且这一轮 donor 增量反而证明：

> **越深挖，越应该少写代码。**

现有成熟链已经足够接近：

```text
Huabu pointer/selection
+
Huabu Floating/Popover
+
Huabu input mechanics
+
LCOS Reference semantics
+
Local Core Run/Voice
+
Orbit radial geometry
+
CopilotKit recorder
+
Lovart/TapNow/Spatial high-fidelity design answer
```

真正需要 LCOS 自己写的主要是：

```text
1. 少量 semantic action resolution
2. target/reference/run binding
3. temporary UI intent
4. thin donor adapters
5. LCOS visual token / body composition
```

这正是当前 Gen2 最理想的状态：

```text
成熟视觉
+
成熟实现
+
LCOS canonical semantics
+
很薄的 glue
+
可替换 supplier body
```

不要再把“设计一个 Arc”“设计一个 Composer”理解成“从 div 开始”。

---

# 32. 当前状态

```text
ROUND_1_EXACT_CONTEXT = CLOSED
CURRENT_GITHUB = VERIFIED
HUABU_MECHANICS = AUDITED
REFERENCE_OWNER = PROTECT
COMPOSER_SHELL = RETIRE
ORBIT_WHEEL = VERIFIED_MIT
COPILOTKIT_AUDIO = VERIFIED_MIT
LOVART = HIGH_FIDELITY_VISUAL_DONOR
TAPNOW = HIGH_FIDELITY_VISUAL + RESPONSIBILITY_DONOR
SPATIAL_V4 = MOTION / INTERACTION_DONOR
LIBTV_PRODUCT = WHEEL_PROVENANCE_ONLY
LIBTV_SKILLS = DIRECT_USE_ALLOWED_BUT_LOW_T3_RELEVANCE

NEXT:
complete V6 gesture-by-gesture matrix
→ finish Round 5 contradiction/recovery audit
→ emit T3 five-volume final source-level plan
```
