# Context Atlas · Astra 空间质感冻结关键摘录
> 来源原件：`LCOS_Context_Atlas_Astra空间质感_收敛冻结补丁_20260905.md`（File Library）
> 本文件是可确认关键条款摘录，不是完整原件。

核心冻结：
> “Context Atlas 是一张‘有轻微高度和纵深的项目 Context 地图’，不是一个复杂 3D 世界。”

必须做到：
- 少字；
- 图形优先；
- 层级清楚；
- 区域边界清楚；
- 大小关系稳定；
- 重点明确；
- 直接拖动 / 缩放 / 点选；
- 必要信息持久可读；
- 专业编辑按需进入，不在 Atlas 上叠满。

点 / 线 / 面：
- 面 = Context Atlas，看项目 Context 全局结构；
- 线 = Evolution / Wave，看变化；
- 点 = Context Spatial Canvas，做细活。

Astra 可借：
- 平面轻微厚度；
- 克制 AO / 接触阴影；
- 大区块清楚；
- world geometry 与 screen-readable Pin/Label 分离；
- 远看大块，靠近/选中再增加信息。

明确不要：
- 复杂 3D 世界；
- 城市/建筑/道路隐喻；
- 3D Relation network；
- 3D 时间地层；
- Blender 式自由 Orbit；
- 为视觉 3D 再造第二 Canvas / Camera / geometry truth。

Glyth 在 Atlas 上应是极轻 POI / identity glyph，不变成 Agent 信息卡。Pin/Glyth/Locator/Far Identity 可共享视觉家族，但语义保持分离。
