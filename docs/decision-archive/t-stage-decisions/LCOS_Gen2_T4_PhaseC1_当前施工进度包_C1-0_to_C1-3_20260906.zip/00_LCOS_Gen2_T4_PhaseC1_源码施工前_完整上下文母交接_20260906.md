# LCOS Gen2 · T4 第四路
# Phase C1 源码施工前 · 完整上下文母交接
## Work View / Context / Workflow / Assembly / Skill / Professional Window
日期：2026-09-06

状态：

```text
PHASE B CLOSED
T4 PHASE A CLOSED
READY FOR PHASE C1 SOURCE-LEVEL PLAN
NO PRODUCTION CODING YET
```

> **这份文件是当前 T4 会话的母交接。**
>
> 如果当前对话后续因为上下文窗口/额度限制必须切换新会话，新会话应把本文件当作第一优先级承接材料。
>
> 它不是最终源码施工正本。
>
> 它的作用是：
>
> 1. 保存当前 T4 已经形成的完整理解；
> 2. 保存用户在本线程中对施工方法、donor、模块化、语义考古、Phase B 后工作方式的原始要求；
> 3. 保存此前所有 T4 产出、哪些继续有效、哪些被覆盖；
> 4. 把 Phase B 已经关闭的跨线程 OPEN 直接回填成当前 CLOSED truth；
> 5. 固定下一步 Phase C1 的“小步快跑”源码施工方案写法；
> 6. 给 T5 提供第一版 engineering seams / 工程接缝；
> 7. 防止新会话重复考古、重新讨论产品、或者因为旧代码看起来顺手就把旧 Scope / Workspace / Workbench 复活。

---

# 0. 新会话第一条纪律

如果新会话接管本线程，第一件事不是重新“理解 LCOS”。

先按以下顺序读：

```text
1. 本文件
2. LCOS_Gen2_PhaseB_四路合并_最终跨线程裁决稿_20260906
3. LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905
4. T4_Context_Workflow_Scope_WorkView_Archaeology_20260905
5. T4_Patched_Professional_Work_Plan_20260905
6. T4 已有 source/donor audit 系列
7. current GitHub exact source
```

然后直接继续：

```text
PHASE C1 · SOURCE-LEVEL CONSTRUCTION PLAN
```

不要重新开启：

```text
Scope 是不是 durable container
Work View 是不是 child canvas
Context 顶层要不要人工 membership
Workflow 是不是 DAG
Workspace 要不要原样复活
Archive 是不是第二仓库
Skill 使用是不是 membership
```

这些已经被 Phase B 关闭。

---

# 1. 用户本线程最新原始要求 · 必须原样继承的施工纪律

以下不是助手总结出来的“偏好”，而是用户在当前推进过程中反复明确的施工要求。

## 1.1 最新 Phase B 后施工要求

用户原话核心：

> “先完整阅读最新《Phase B 四路合并最终跨线程裁决稿》，其结论覆盖本线程此前尚未关闭的跨线程 OPEN。”

> “不要重新进行产品语义讨论，也不要越权重新裁决其它线程职责。”

> “基于本线程已经完成的历史考古、源码审计、donor 深挖和现有修正版，立即进入正式源码级施工方案阶段。”

> “施工方案必须 exact-file、exact-owner、exact-consumer，明确复用、迁移、退休、测试、浏览器验收、恢复与 blast radius。”

> “遇到裁决稿已关闭的问题不得重新 OPEN；只有发现 current source 存在真实技术冲突且无法通过薄适配解决时，才回报 Coordinator。”

这些现在是 T4 Phase C1 的最高施工纪律。

---

## 1.2 源码施工必须小步快跑

用户原话核心：

> “写源码级别施工稿我建议分小步快跑的机制，以免出现思考过程当中出现上下文限制情况导致思考丢失。”

因此不一次性在脑中憋完整 100KB 正本。

固定使用：

```text
C1-0  Engineering Seam Skeleton
C1-1  ProjectSession / Professional Window
C1-2  Assembly
C1-3  Context
C1-4  Workflow
C1-5  Skill / Run Review
C1-6  Archive / Recovery integration
C1-7  Cross-surface / Browser acceptance
C1-8  Consolidated Source Plan
```

每一小步都必须独立落盘成 MD。

这样即使当前会话突然结束：

> 已完成的 reasoning 不会只留在聊天上下文里。

---

## 1.3 donor 不是方向指令，而是直接收成熟 mechanics

用户此前明确：

> “这个不是说具体方向的指引啊，具体方向指引仍然需要你们自己去挖，找到最适配最优的解。”

> “哪些是 Tap Now、Lovart，还有 SPATIAL，它们上面最好的呈现方式你就直接拿过来用，还是这个原则。”

所以 donor 使用规则是：

```text
产品语义
→ Phase B 已冻结

具体工程 mechanics / UI morphology / motion / body
→ T4/T5 自己继续 donor census
→ 成熟的直接 ADOPT / WRAP / LIFT
→ 不因 donor 反向修改产品
```

---

## 1.4 模块化不是文件多，而是爆炸半径小

用户再次强调：

> “反正我觉得你就是得给得够模块化结构化，这些东西给清楚。”

此前 T4 已形成：

```text
模块化
≠ 多造 store/manager/registry/framework

模块化
= donor 可替换
= owner 清楚
= consumer 清楚
= failure blast radius 被限制
```

例如：

```text
Dockview 换掉
→ 不碰 Core / SurfaceRegistry / Context truth

Timeline donor 换掉
→ 不碰 ContextSnapshot truth

Lovart presentation 换掉
→ 不碰 AssemblyApply / Warehouse

Skill mind map donor 换掉
→ 不碰 SkillPackage truth
```

---

## 1.5 考古摘要不能代替原始证据

用户此前明确：

> “禁止仅依据总规划提供的考古摘要下施工结论；摘要只用于定位风险。”

> “涉及本线程 owner 的关键定义，必须回到原始用户原话、历史冻结、closeout 与对应源码重新验证。”

T4 Phase A 已执行。

现在 Phase B 已经完成跨线程最终裁决，因此：

```text
Phase A 的历史考古
= 用来理解 migration / legacy debt

Phase B
= 当前唯一产品/owner答案
```

不再重新考古产品语义。

---

# 2. 当前 Authority Stack

从 2026-09-06 起：

```text
A0
用户最新明确要求

A1
LCOS_Gen2_PhaseB_四路合并_最终跨线程裁决稿_20260906
= CURRENT CROSS-THREAD PRODUCT / OWNER AUTHORITY

A2
LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905
= PRODUCT FREEZE

A3
Context Atlas / Spatial visual-spatial patch
= subordinate visual/spatial constraint

A4
T4 historical archaeology
= migration / legacy evidence

A5
current Gen2 source
= current implementation fact

A6
Gen1/v0.15 source/history
= legacy implementation evidence only

A7
donor
= implementation / presentation supplier
```

重要：

```text
source 不得覆盖 product semantics
donor 不得覆盖 product semantics
历史原话不得覆盖更晚 Phase B
```

---

# 3. Phase B 已正式关闭 T4 的所有旧 OPEN

T4 Phase A 曾经有 18 条 Cross-Thread Questions。

Phase B 现在已经关闭其中真正的产品/owner问题。

## D01 · Scope

当前：

```text
Scope
= 这一次只处理谁
```

它没有 durable canonical identity。

如果用户要长期留下当前范围：

```text
长期算一组
→ Collection

正式留下一段工作
→ Workflow

单独开另一张长期桌子
→ Worksite

只是 Agent/Run 当前使用
→ Scope结束后消失
```

禁止：

```text
DurableScope
ScopeContainerEngine
ContextScopeDB
WorkflowScopeDB
```

---

## D05 · Context top-level

Context：

```text
= 项目到现在知道了什么
```

顶层 Atlas：

```text
时间地图
事情地图
来源
演进
关系
```

都属于对整个 Project canonical truth 的派生理解。

正式关闭：

```text
Context top-level canonical membership list
```

这个概念不做。

Context block：

```text
默认 derived
temporary detail
```

只有用户明确要长期留下时：

```text
Collection
Workflow
Worksite
canonical Context artifact
```

不能偷偷建 Context Scope。

---

## D06 / D19 · Workflow

Workflow：

```text
= 一段被用户正式抽出来的长期工作
```

它有 durable typed working composition。

至少可引用：

```text
input materials
Conversation/Glyth
Result
key user-perceived work round
Review
Skill usage
```

必须拆开：

```text
semantic composition
≠ Presentation layout
≠ ProjectionBinding
```

Workflow identity：

```text
存在
≠ 自动有 child canvas
```

只有明确“单独开桌长期做”才 materialize Worksite。

Workflow extraction：

```text
selection
→ Agent/UX整理proposal
→ user正式采用
→ canonical Workflow identity/composition
→ Workflow Surface projection
```

不 clone source entity。

Main/Context source projection 不删。

---

## D07 / D08 · Worksite

Worksite：

> “一份以后还能回来继续的长期工作现场。”

Core 保存：

```text
identity
projectId
name / intent
stable canvasId
durable working-set refs
home/origin Surface or parent worksite ref
lifecycle
timestamps
```

Huabu 保存：

```text
camera
node geometry
layout
spatial history
frame/body geometry
```

实现策略：

```text
优先瘦身 / 迁移旧 Workspace
```

禁止：

```text
旧 Workspace + 新 Worksite 双系统
```

也禁止：

```text
完整复活 old Workspace interface
```

Materialization：

```text
只由明确用户动作触发
```

不能靠：

```text
点击次数
停留时间
内容数量
Collection创建
```

自动 materialize。

---

## D10 · Conversation deep work

Glyth 双击：

```text
same Conversation deep work
```

三块可以同时存在：

```text
Conversation Child Canvas
= nested Worksite

Conversation Preview
= Professional Window

Assembly
= Project-shared Professional Window
  target=current Conversation
```

共享 Conversation identity。

但：

```text
绝不共享 state owner
```

T4负责：

```text
Preview/Assembly与child canvas的组合呈现
```

不负责：

```text
child Worksite persistence/navigation/spatial truth
```

---

## D13 · Archive

Archive：

```text
canonical lifecycle
```

不是：

```text
hide
Delete
Assembly
第二仓库
```

Archive顺序：

```text
Core archived/archivedAt
→ keep membership/relation/history
→ event archived
→ Main projection eligibility false
→ projection removed
→ old x/y不保存
```

Restore：

```text
Core clear archived
→ event restored(batch)
→ Main projection eligibility true
→ Reconcile creates projection
→ Huabu fresh layout
```

不能读旧 x/y。

Archive UI T4负责：

```text
date grouped
Masonry
single restore
multi restore
Restore All
```

canonical lifecycle由 T6 source plan承接。

---

## D18 · ContextSnapshot branch

current legacy：

```text
checkpoint
→ collection scope
→ cloned/new ArtifactView
→ x/y
```

正式退休为 Gen2产品 mutation。

以后若保留 fork/branch：

```text
history fork
≠ Collection membership
≠ spatial placement
≠ Worksite materialization
```

T4 Context UI：

```text
不得依赖旧 branch副作用
```

---

## D20 · Skill usage

Skill package唯一。

Composer Skill：

```text
per-run/current composer selection
```

不自动形成 durable Project binding。

Workflow/Glyth明确长期使用 Skill：

```text
durable typed capability-use relation
```

至少引用：

```text
skillId
version / compatible version
target ref
```

不复制 Skill package。

T4绝不新增：

```text
frontend SkillBindingStore
```

---

## D21 · Assembly scope compatibility

Assembly：

```text
Project-shared Source Bay + Target
```

仍然成立。

current：

```text
context/workflow/collection
→ scope compatibility endpoint
```

只保留 migration。

T6 source plan逐目标迁移真实 target command。

Assembly永远不拥有：

```text
membership
relation
Skill binding
Collection containment
```

只路由 canonical services。

---

## D04 · Give / Drop 到 T4 targets

T4不重新定义手势。

统一：

```text
Visible Host + left drop
→ target natural semantic commit
→ current projection stay at target

Remote Target + left drop
→ canonical semantic/mapping/target projection
→ source projection stays source scene

Right-drag
→ source spatial placement从头到尾不动
→ target按唯一natural semantic commit

Relation handle
→ Project Relation
```

T3负责 gesture presentation。

---

# 4. T4 当前职责 · 白话版

一句话：

> **T4 管“用户进入专业工作以后，这些工作怎么展开、并存、持续和返回”。**

不是管：

```text
空间底层怎么算
用户手势怎么识别
真实数据表怎么存
最后视觉长什么样
```

T4当前主责：

```text
Professional Window
Context professional work
Workflow professional work
Assembly
Skill Builder
Run Review presentation
Conversation deep-work adjacent regions
ProjectSession / Professional lifecycle seam
```

---

# 5. T4 当前模块图 · Phase B 后版本

```text
M0 Project Session / Professional lifecycle coordinator

M1 Professional Window Layer
   Float / Dock / Undock / Resize / Split / Close / Restore

M2 Assembly
   Source Bay + target + canonical apply adapter

M3 Context Atlas Entry / Temporary Detail

M4 Context Professional Instruments
   Evolution / Relationship / Provenance / detail

M5 Workflow Deep Work
   composition-facing professional UI / Review / Run detail

M6 Skill Builder + Run Review

M7 Professional Window Environment
   occupiedRects / safeRect seam / activeRegions

M8 Archive Viewer

M9 Thin Donor / Canonical Adapters
```

另外：

```text
Nested Worksite
```

是邻接模块，不由 T4拥有 canonical/spatial/navigation truth。

T4只负责其与 professional regions 的组合边界。

---

# 6. Engineering Seam 到底是什么

用户问：

> “各路线程工程 seam 这个是啥意思？等于说我要先把这个东西让各路工程先产出来再给T5，是吧。”

答案现在正式冻结为：

> **Engineering Seam = 工程接缝 / 接口边界。**

它不是：

```text
新产品
新 domain
新 manager
```

它是每条工程线先告诉 T5：

```text
这个 UI/产品能力现在由什么源码长出来
哪个 owner拥有真实状态
哪个 component / primitive可复用
会出现哪些真实状态
哪些状态是UI能看见的
哪些操作当前代码支持
哪些必须迁移
哪些旧body必须退休
哪个区域会占屏幕
哪个东西会留在drop位置
哪个会source home
LOD能提供几级
Camera会不会动
```

T5拿这些约束设计最终视觉。

---

# 7. 为什么先给 T5 Seam，而不是等最终施工正本

正确流程：

```text
Phase B
↓
T1/T2/T3/T4/T6
先各自写 Source-level Engineering Seam Skeleton
↓
把视觉相关 engineering constraints 给 T5
↓
T5 Final Visual Plan
↓
视觉结果回填各路线程
↓
FINAL SOURCE CONSTRUCTION PLAN
↓
production coding
```

T5现在已经可以继续：

```text
visual research
donor comparison
motion language
window morphology
HUD density
LOD
glyph/icon
```

但最终 body/proportion/motion不要在没看到 engineering seam 前锁死。

---

# 8. T4 应该给 T5 的 Engineering Seam 内容

T4不把几百KB源码丢给T5。

只给它：

```text
A. Professional Window
- region types
- Float/Dock/Undock/Resize/Split states
- Canvas protected/stable
- window occupancy states
- Close/Restore
- same body identity continuity

B. Context
- Atlas = derived Context Home/Instrument
- region → temporary detail
- Evolution = 2D professional view
- Relationship/Provenance = professional lens
- Worksite != Work View

C. Workflow
- real material
- one user-perceived action round
- real Result
- Review
- deep detail states

D. Assembly
- Source Bay sections
- target presence
- visible/remote drop result
- loading/unsupported/error
- no fake membership

E. Skill
- canonical Skill
- Builder states
- version/composition/proposal
- skill-use admission state

F. Archive
- cold/read-only
- date groups
- selection
- restore
- restoring
- restored

G. Occupancy
- occupiedRects
- safeRect
- floating collision
```

---

# 9. 当前 Source Baseline

2026-09-06 再核：

```text
Repo:
DZWFLi/LCOS_Gen2

HEAD:
c2ff890a867922a1256572199458438572eb0a8c

Commit:
fix(audit): P2 — click suppressor bound to runtime lifecycle (disposable)

Commit date:
2026-09-03
```

此前 Huabu pin：

```text
58339e269b784728d67730c70bfe7792cae2457d
```

此前看到 upstream Huabu：

```text
dc128fff2d37b5481ec305070a7e86d3de85f7d2
```

正式 final source plan前：

```text
再核 vendored pin / upstream
```

但 current LCOS HEAD 已重新确认没有变化。

---

# 10. Current Source · 已经核实的 T4 关键事实

## 10.1 Runtime

current：

```text
useLcosCanvasProps
```

目前把 runtime 生命周期放在 Canvas-side hook。

cleanup：

```text
runtime.dispose()
```

current `runtime.retarget({canvasId})`：

```text
same runtime object
dispose old host
build new host
```

current seam：

```text
createHostSeam(() => rt.host)
```

可保持同一 hostExtension/seam读取最新 underlying host。

Phase C1 implication：

```text
LIFT runtime/seam lifecycle upward
不要重写 runtime
```

---

## 10.2 Project identity

Core已有：

```text
ProjectCatalog
GET /projects
POST /projects create/open
Project Summary
Project Visual Profile
```

web-gen2已有：

```text
CoreProjectClient.listProjects()
CoreProjectClient.getProjectGraph()
```

current Huabu `CenterArea` 仍通过：

```text
PROJECT_ID env
disposable-mvp-sample
```

接 runtime。

Phase C1：

```text
retire production env project selector
consume canonical projectId
```

---

## 10.3 SurfaceRegistry

已有：

```text
apps/web-gen2/src/spatial/surfacePort.ts
apps/web-gen2/test/surfacePort.test.ts
```

已验证：

```text
same project
main/context/workflow
distinct canvasId
collision fail-close
```

产品 consumer尚未完整接入。

Phase C1：

```text
WIRE
不造 SurfaceManagerV2
```

---

## 10.4 Current MainLayout

现状：

```text
left
+ center Canvas
+ one right Preview panel
```

并有：

```text
right resize
fullscreen
```

旧 fullscreen 会卸载 Canvas subtree。

V2 + Phase B 后：

```text
MainLayout不能继续承担所有professional region topology
```

---

## 10.5 PreviewWorkspace

已有成熟：

```text
tabs
two groups
split
dnd-kit
keyboard resize
scroll memory
```

正确复用：

```text
作为 Preview body内部工作区
```

不升格成全局 ProfessionalWindow truth。

---

# 11. Professional Window · 当前工程方向

V2要求 N professional regions同时存在。

此前 donor census第一候选：

```text
Dockview React/Core
```

理由：

```text
MIT core/react
panel/group
split
float
dock/undock
resize
move
close
serialization
renderer='always'
```

当前状态：

```text
STRONG ADOPT CANDIDATE
PROTOTYPE REQUIRED
```

不把 Dockview当产品 owner。

它只管：

```text
screen-space topology
```

---

# 12. Protected Canvas 原则

如果 Dockview proof成立：

```text
Professional Window Stage
├─ Protected Spatial Canvas
├─ Assembly
├─ Conversation Preview
├─ Context professional region
├─ Workflow professional region
├─ Skill Builder
├─ Run Review
├─ Archive
└─ Web/PDF/HTML
```

Protected Canvas：

```text
not closeable
not floating
not normal tab
not removable by persisted layout
stable host
```

Phase B D15进一步冻结：

```text
Professional Window host resize
→ camera不得自动 compensation
```

需要：

```text
LCOS host-level policy override
```

不要改 Huabu global default，除非以后 upstream另裁。

---

# 13. Professional Window Environment · Phase B 必须输出的公共 seam

Phase B D14已经关闭。

T4必须对外只提供一套公共 screen-space occupancy seam。

语义建议：

```ts
ProfessionalWindowEnvironment {
  occupiedRects
  safeRect / safeInsets
  activeRegions
}
```

名字可复用现有环境。

不要求新 Store。

T1/T2/T3消费：

```text
HUD
Pin
Locator
Minimap
Action Arc
Composer
edge drop band
explicit Focus framing
```

禁止：

```text
多处DOM query
hardcoded right panel width
persist safeRect truth
```

---

# 14. Assembly · 当前工程事实

Assembly contract已经有：

```text
AssemblySourceRefV1
AssemblyTargetRefV1
WarehouseSnapshotV1
AssemblyApplyRequestV1
```

Source Bay四来源：

```text
Project
Capture
Sources
Skills
```

真实 owner：

```text
Project
→ Warehouse

Capture
→ Capture staging

Sources
→ Resource/connector

Skills
→ Skill Catalog
```

Assembly不是第二DB。

---

## 14.1 AssemblyApply

current：

```text
AssemblyApplyService
```

不拥有mutation。

只路由：

```text
CaptureSpaceService
CurationCommandService
MutationSafetyService
Relation
PresentationApplicationService
```

Phase B继续 KEEP 这个架构。

---

## 14.2 Assembly current legacy debt

current：

```text
context/workflow/collection
→ legacy scope compatibility
```

Phase B：

```text
LEGACY_COMPAT ONLY
```

T4 Source Plan：

```text
UI / adapter不得依赖scope ontology
consumer使用typed canonical target ref
T6负责目标命令迁移
```

---

# 15. Context · Phase B 后 current T4 plan

## Atlas

```text
Context Home / Instrument
derived over Project truth
```

默认：

```text
时间地图
```

第二：

```text
Agent事情地图
```

不建立顶层人工 membership。

---

## Temporary Detail

```text
Atlas region click
→ temporary detail
```

不是 Worksite。

temporary detail可：

```text
view
Search
Focus
Reference
Agent
source
Evolution
underlying real objects
Archive restore entry
```

---

## Evolution

```text
2D professional view first
```

适合：

```text
sequence
range
compare
branch/fork reading
before/after
```

---

## Relationship / Provenance

```text
professional lens / Work View
```

不默认铺满Atlas。

---

# 16. Context donor方向

此前候选：

```text
Structure
→ react-arborist

Evolution
→ vis-timeline

Relationship
→ Cytoscape.js stable

Source/Provenance
→ native + react-virtuoso
```

但 Phase B 后：

```text
不要机械固定“四个永久tab”
```

这些是 body supplier候选。

最终T5负责视觉 body。

T4负责 adapter / state / lifecycle。

---

# 17. ContextSnapshot

current：

```text
Checkpoint-backed snapshot
compare
history refs
```

KEEP。

current `branch()`：

```text
collection scope
new/cloned views
generated x/y
```

Phase B D18：

```text
RETIRE AS GEN2 PRODUCT MUTATION
```

T4 Context UI：

```text
不得依赖旧branch副作用
```

T6负责legacy read/migration。

---

# 18. Workflow · Phase B 后 current T4 plan

Workflow：

```text
durable canonical identity
+ durable typed semantic composition
```

不等于：

```text
DAG
BPMN
Run log
child canvas
```

Workflow Surface：

```text
一级 Surface
```

Professional deep regions：

```text
round detail
Review
Run detail
logs
tool calls
provider
retry
```

这些是：

```text
Professional Window / Instrument
```

---

# 19. Workflow extraction

用户：

```text
选中真实材料
→ 整理为Workflow
```

T4负责：

```text
UX
Agent proposal presentation
adoption flow
```

T6负责：

```text
canonical transaction
durable composition
```

T1：

```text
projection placement
```

T3：

```text
gesture
```

T4不使用：

```text
local WorkflowStore
old scopeId as final identity
```

---

# 20. Typed Core Clients · current方向

既有 `Gen2Host` 不扩成 mega facade。

继续小 clients：

```text
CoreAssemblyClient
CoreContextClient
CoreRunClient
CoreSkillClient
CoreWorkflowClient
```

current HttpClient：

```text
JSON body-oriented
```

Workflow import需要：

```text
multipart/FormData seam
```

因此 Phase C1需重新核 current：

```text
apps/web-gen2/src/backend/client.ts
```

再做最薄 raw/FormData extension。

不为 Workflow造第二 HTTP client framework。

---

# 21. Run / Review

T4不拥有 Run engine。

T4负责：

```text
Run Review professional body
waiting_input presentation
events
ArtifactReturn
accept/reject/retry presentation
```

current contracts已有：

```text
RunReview
RunEvent.sequence
input request
ArtifactReturn
capability/reason
```

第一阶段不硬要求 SSE：

```text
sequence cursor polling可满足
```

除非 current source现状改变。

---

# 22. Skill Builder

Skill canonical package current source成熟：

```text
list
create
update
version bump
rename
install
disable/enable
composition
subskills
dependency graph
provenance
```

Skill Builder：

```text
Instrument / Professional Window
```

不是 Worksite。

不是 Harness Run。

---

## 22.1 Donor

此前：

```text
react-arborist
→ Outline

Mind Elixir stable 5.15.1
→ Mind-map body

LibTV MIT skills
→ direct vendor candidate / system skill donor
```

Mind Elixir：

```text
sealed interaction island
```

不可抢全局drag/keyboard。

---

## 22.2 Skill use

Phase B D20：

```text
Composer
→ per-run selection

Workflow/Glyth durable use
→ typed capability-use relation
```

不复制 package。

T4只消费 T6最终 seam。

不再把它视为产品 OPEN。

---

# 23. Archive Viewer

Phase B D13已经关闭 lifecycle。

T4可以正式设计 Source Plan。

UI：

```text
按archivedAt日期分组
Masonry
single select
multi select
Restore
Restore All
cold/read-only states
```

Lovart：

```text
strong visual donor
```

Huabu已有：

```text
react-virtuoso
```

可作为大型浏览列表基础。

T4不保存archive truth。

---

# 24. Donor Map · 当前完整版本

## Huabu

```text
sole spatial physics
camera
geometry
selection
canvas persistence
layout mechanics
host
```

---

## Dockview

候选：

```text
Professional Window topology
```

只做mechanics。

---

## Spatial

主要拿：

```text
focus yielding
origin morph
present/restore
stack
scatter
pull-out
settle
drag neighbor reflow feeling
low chrome
```

不复制其domain。

---

## Lovart

主要拿：

```text
Assembly browsing
Archive Masonry
material density
source hierarchy
thumbnail hierarchy
```

proprietary source不复制。

---

## TapNow

主要拿：

```text
marker
Pin
fixed-screen label
HUD
hit priority
world→screen overlay
wayfinding
```

T4主要作为相邻 visual seam参考。

---

## Astra

只给 Context Atlas：

```text
light 2.5D massing
AO/contact depth
low information density
screen-readable pin/label
```

不借：

```text
3D city
road network
free orbit
3D relation
```

---

## LibTV

最强 direct-engineering donor之一：

```text
MIT Skill package
skill structures
```

provider/runtime integration不归T4。

---

## Leap / 其它 donor

继续按：

```text
mechanic-level census
```

不得“整产品套过来”。

---

# 25. 旧方案中已经退休的内容

以下在新会话中不要复活：

```text
ONE dominant Work View

Scope = durable container

Scope = child canvas

Context top-level membership list

Workflow = Scope

Workflow = DAG editor

Work View = Worksite

old WorkbenchService = new WorkView owner

CanvasPage/CenterArea owns project lifetime

PROJECT_ID env = production project identity

MainLayout.rightPanel = sole professional destination

WorkView stores Camera

second safeRegion truth

Assembly DB

Context history DB

Workflow DAG engine

frontend SkillBindingStore

ArchiveWarehouse

ContextComposer / WorkflowComposer

old ContextSnapshot branch side effects
```

---

# 26. 所有 T4 已产出 MD · 当前状态总账

## 2026-09-04

### `LCOS_Gen2_T4_Round1_Context_Blocker_20260904.md`

历史价值：

```text
Mandatory Read Gate
9 missing raws
stop discipline
```

当前：

```text
HISTORICAL
BLOCKER mostly closed
```

不能作为现在的stop理由。

---

### `LCOS_Gen2_T4_V6_反惰性_Donor_模块化复用深挖_20260904.md`

仍有价值：

```text
donor census
module blast-radius principle
typed body supplier candidates
LibTV direct-use
Context donor candidates
Skill donor candidates
anti-build list
```

部分旧 WorkView placement assumptions 已被后续V2/Dockview方案覆盖。

状态：

```text
KEEP SOURCE/DONOR EVIDENCE
PATCH PRODUCT TO PHASE B
```

---

### `LCOS_Gen2_T4_ExactFile前置施工表_KEEP_ADOPT_WRAP_RETIRE_20260904.md`

仍有价值：

```text
initial exact-file census
typed clients
Current MainLayout risk
body supplier
transport gaps
```

旧：

```text
runtime owner CanvasPage
MainLayout/no-modify assumptions
single-workview era
```

已被后续审计覆盖。

状态：

```text
SOURCE INVENTORY DONOR
DO NOT COPY FINAL ARCHITECTURE
```

---

### `LCOS_Gen2_T4_TypedClients_ExactRoute_TransportGap_审计_20260904.md`

高价值 KEEP：

```text
small typed clients
HttpClient multipart gap
Core routes
Run/Review contracts
Skill routes
Workflow import/export
browser-risk-driven tests
```

状态：

```text
KEEP / REVERIFY CURRENT SOURCE
```

---

### `LCOS_Gen2_T4_WorkViewStableLayer_ProjectSession_ActionArc_DonorWrapper_收敛审计_20260904.md`

高价值：

```text
runtime/project-session lifetime
stable seam
workview key discipline
camera no-owner
occupied rect legacy donor
ActionArc physical slot
donor wrapper cleanup
```

但：

```text
single WorkView session
right dock body architecture
```

被V2多窗口进一步覆盖。

状态：

```text
KEEP LIFECYCLE/SOURCE FACTS
PATCH WINDOW TO MULTI-REGION
```

---

### `LCOS_Gen2_T4_Assembly_ProjectIdentity_SurfaceRegistry_SkillBinding_ExactHandoff_20260904.md`

高价值：

```text
current Assembly exact contract
Project identity
SurfaceRegistry
Skill gap
T1 handoff
```

Skill gap产品回答现被Phase B D20关闭。

状态：

```text
KEEP CURRENT SOURCE FACTS
PATCH T6 TARGET COMMANDS
```

---

## 2026-09-05

### `LCOS_Gen2_T4_V2冻结_统一多工作区窗口_Dockview_Donor裁决与架构纠偏_20260905.md`

高价值：

```text
N professional regions
Dockview candidate
Protected Canvas
DnD coexistence
PreviewWorkspace body
failure blast radius
```

Archive Core “OPEN”已经被Phase B D13关闭产品语义。

状态：

```text
KEEP / PROMOTE TO C1 DONOR INPUT
```

---

### `LCOS_Gen2_T4_ProjectIdentity_SurfaceRetarget_WorkbenchStage_ExactHandoff_20260905.md`

高价值：

```text
Core Project identity exists
workspaceId != projectId
env retirement
SurfaceRegistry consumer
runtime retarget
reconcile dedupe
Project change vs Surface change
```

Router/Worksite等旧OPEN已由PhaseB/T2关闭产品层。

状态：

```text
KEEP / PATCH AGAINST PHASE B
```

---

### `LCOS_Gen2_T4_Assembly_SourceBay_CanonicalApply_SkillBinding_GapMatrix_20260905.md`

高价值：

```text
Source Bay adapters
AssemblyApply routes
Warehouse != Skills
Skill read green
```

Skill use gap产品层由PhaseB D20关闭。

状态：

```text
KEEP SOURCE MATRIX
PATCH MUTATION CONSUMER TO T6 FINAL SEAM
```

---

### `LCOS_Gen2_T4_模块化职责与Donor映射_吸收Spatial_ContextAtlas补丁_20260905.md`

高价值：

```text
M0-M9 modular structure
Spatial/Astra/Lovart donor map
Atlas boundary
failure blast radius
```

状态：

```text
KEEP
UPDATE M3/M5/M8 WITH PHASE B CLOSED TRUTH
```

---

### `T4_Context_Workflow_Scope_WorkView_Archaeology_20260905.md`

价值：

```text
historical semantic migration evidence
Scope historical override
old Workbench/CanvasScope debts
```

其中所有 `WAIT_CROSS_THREAD`：

```text
HISTORICAL ONLY
```

当前被Phase B关闭。

状态：

```text
KEEP AS ARCHAEOLOGY
DO NOT USE OPEN STATUS
```

---

### `T4_Patched_Professional_Work_Plan_20260905.md`

价值：

```text
Phase A patch ledger
```

所有：

```text
WAIT_CROSS_THREAD
```

必须按PhaseB回填为 CLOSED decision。

状态：

```text
INPUT TO C1
NOT CURRENT FINAL STATUS
```

---

### `T4_CrossThread_Questions_20260905.md`

现在是：

```text
HISTORICAL QUESTION LOG
```

不是当前待办。

其中产品问题已由PhaseB关闭。

唯一可能保留的：

```text
direct technical evidence gap
```

只能在 current source确实有不可薄适配冲突时再升级Coordinator。

---

# 27. Phase C1 源码方案统一格式

每张施工卡必须有：

```text
CARD ID

Product Decision Source
- Phase B Dx

Goal

Exact Current Files

Current Owner

Current Consumers

Existing Primitive / Donor

KEEP

ADOPT / WRAP / LIFT

NEW THIN SEAM

MIGRATION

RETIRE

DO NOT TOUCH

Exact State Flow

Exact Failure Mode

Unit / Integration Tests

Browser Acceptance

Recovery / Rollback

Blast Radius

T5 Visual Inputs

Technical Conflict Gate
```

禁止少：

```text
owner
consumer
recovery
blast radius
```

---

# 28. C1-0 · T4 Engineering Seam Skeleton · 第一阶段先产这个

这是用户要求的第一小步。

不写所有实现细节。

先给 T5 和后续T4自己一个稳定骨架。

建议包含以下六张 seam card。

---

## SEAM-T4-01 · Project Session → Professional Window

要回答：

```text
canonical projectId从哪来
runtime owner在哪
SurfaceRegistry谁消费
professional regions谁持有
Surface切换什么保持
Project切换什么dispose
```

current candidate exact files：

```text
huabu/apps/web/src/App.tsx
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/pages/CanvasPage/CenterArea.tsx
huabu/apps/web/src/pages/CanvasPage/CanvasPage.tsx
apps/web-gen2/src/spatial/surfacePort.ts
apps/web-gen2/src/host/createLcosHostRuntime.ts
apps/web-gen2/src/backend/projects.ts
```

可能 ADD：

```text
huabu/apps/web/src/lcos/session/LcosProjectSessionProvider.tsx
```

但正式 C1-0 先再次 exact-source read，再锁文件名。

T5只需要：

```text
专业窗口可跨Surface保留
Project切换重置
Canvas稳定
```

---

## SEAM-T4-02 · Professional Window Environment

Phase B：

```text
D14/D15
```

输出：

```text
occupiedRects
safeRect/safeInsets
activeRegions
floating collision
```

current candidates：

```text
LcosHostOverlay.tsx
overlayArbitration.ts
MainLayout.tsx
old activeSpatialViewport donor
```

目标：

```text
T1/T2/T3只消费公共seam
```

不DOM-query具体Dockview。

T5需要：

```text
窗口占屏状态
HUD可用区域
Dock/Float active region states
```

---

## SEAM-T4-03 · Professional Window Topology

Phase B：

```text
Work View != Child Worksite
N professional regions
```

候选 engineering donor：

```text
Dockview React/Core
```

需要 isolated prototype：

```text
Protected Canvas
N panels
Float
Dock
Undock
Resize
split
close
restore
stable body
camera unchanged
```

T5需要：

```text
哪些window state真实存在
哪些window chrome状态可设计
```

---

## SEAM-T4-04 · Assembly Target / Source Adapter

Phase B：

```text
D21 + D04
```

T4输入：

```text
typed canonical target
Source Bay
```

current files：

```text
packages/contracts/src/assembly.ts
apps/local-core/src/assembly-apply-service.ts
apps/web-gen2/src/backend/assembly.ts (candidate add)
```

T5需要：

```text
Project/Capture/Sources/Skills sections
target identity
drag eligible
unsupported
applied
partial
error
```

---

## SEAM-T4-05 · Context Instrument Lifecycle

Phase B：

```text
D05 / D08 / D18
```

状态：

```text
Atlas Home
temporary detail
Evolution
Relationship
Provenance
optional explicit Worksite transition
```

T4不创建：

```text
Context membership DB
Context Scope
```

T5需要：

```text
Atlas region rest/hover/selected/focus
temporary detail transition
professional view transition
```

---

## SEAM-T4-06 · Workflow / Skill / Run Professional Bodies

Phase B：

```text
D06 / D19 / D20
```

需要明确：

```text
Workflow composition read/adoption seam
Run Review seam
Skill Builder seam
Skill-use admission/result seam
```

T5需要：

```text
Workflow action-round states
Result
Review
Glyth handoff
Skill selected/attached/proposed/version states
Run waiting/review/returned states
```

---

# 29. C1-1 之后的小步计划

C1-0交付给T5之后，T4继续：

```text
C1-1 ProjectSession + Window environment exact plan

C1-2 Dockview/Window prototype exact plan

C1-3 Assembly exact source plan

C1-4 Context exact source plan

C1-5 Workflow exact source plan

C1-6 Skill / Run Review exact source plan

C1-7 Archive + recovery exact source plan

C1-8 browser acceptance + rollback + integrated blast-radius matrix
```

T5不需要等 C1-8。

T5拿到C1-0即可正式锁视觉方向。

---

# 30. Phase C1 必须做的 current-source reread

虽然Phase A已经审过，但正式 exact plan前，每张卡都要重新读 exact current file。

最低：

```text
App.tsx
CanvasPage.tsx
CenterArea.tsx
MainLayout.tsx
useLcosCanvasProps.tsx
LcosHostOverlay.tsx
overlayArbitration.ts
PreviewWorkspace*

surfacePort.ts
createLcosHostRuntime.ts
hostSeam / Gen2Host relevant ports

backend/client.ts
backend/projects.ts

contracts/assembly.ts
assembly-apply-service.ts

context-snapshot-service.ts
workflow routes/export
skill-package-service.ts
skill routes
run/review routes/contracts
archive/recovery current T6 landing when available
```

不能引用 09-04 的 path assumption 当 exact current proof。

---

# 31. 什么时候可以报告 Coordinator 技术冲突

Phase B明确：

```text
已关闭产品问题不得重新OPEN
```

所以 T4只有满足全部条件才升级：

```text
1. current source exact file已读
2. current owner/consumer已追完
3. existing primitive/donor已评估
4. thin adapter / compatibility shim已尝试
5. migration-only path已评估
6. 仍然存在：
   - data loss
   - identity collision
   - impossible lifecycle
   - impossible recovery
   - unavoidable second truth
   - unresolvable owner collision
```

才写：

```text
TECHNICAL CONFLICT → Coordinator
```

不能因为：

```text
“不太好写”
“旧字段名难看”
“我更喜欢另一个架构”
```

重开产品。

---

# 32. T4 anti-overbuild 红线

Phase C1继续禁止：

```text
DurableScope
ScopeContainerEngine
ContextScopeDB
WorkflowScopeDB
WorkViewCanvasOwner
WorkspaceRuntimeV2 parallel system
SurfaceManagerV2
WorkView global mega Zustand
WorkView Camera store
Assembly DB
Assembly membership store
Context history DB
Context second truth
Workflow DAG engine
second ReactFlow
Run event duplicate store
SkillBindingStore frontend truth
ArchiveWarehouse
new safeRegion truth
```

---

# 33. Browser Acceptance 总纪律

不只unit test。

T4 final source plan必须有真实 browser proof。

至少：

## Project / Surface

```text
Project A Main
→ Context
→ Workflow
same ProjectSession
correct canvas retarget
professional windows stay
```

---

## Professional Window

```text
open
float
dock
undock
resize
split
close
restore
```

body状态连续。

---

## Camera

记录：

```text
x/y/zoom
```

Professional Window操作后：

```text
unchanged
```

除 explicit Focus。

---

## Assembly

```text
open from Main
open from Context
open from Workflow
open from Conversation
target正确
drop成功后canonical reload一致
```

---

## Context

```text
Atlas
→ temporary detail
→ Evolution
→ back
```

不创建隐藏Scope/Worksite。

---

## Workflow

```text
proposal
→ user adopt
→ canonical composition
→ reload
```

不clone source。

---

## Skill

```text
edit Skill
version
reopen
Run proposal
Skill-use relation
reload
```

无copy/fake binding。

---

## Archive

```text
archive
reload
search/read-only
restore batch
fresh Main layout
```

不恢复old x/y。

---

# 34. Recovery / Rollback 总纪律

每张卡必须说明：

```text
失败后如何恢复
```

至少区分：

```text
UI presentation state
canonical mutation
spatial projection
runtime lifecycle
```

示例：

Professional Window donor坏：

```text
退回窗口adapter
不动Core
不动Huabu canvas truth
```

Assembly apply失败：

```text
Core result fail/partial
UI如实reconcile
不local fake
```

Surface retarget失败：

```text
保持Project identity
不dispose新旧混杂
fail-close
```

---

# 35. Blast Radius 总纪律

每个模块必须写：

```text
允许影响哪些文件
禁止影响哪些 owner
```

例如：

## Window

允许：

```text
Huabu shell/lcos window adapter
```

禁止：

```text
Core Project
Context truth
Workflow truth
Skill truth
```

## Context Timeline

允许：

```text
Context projection/body adapter
```

禁止：

```text
Checkpoint storage
Project canonical entity
```

## Skill mindmap

允许：

```text
Skill Builder body
```

禁止：

```text
Skill Package schema
Run
```

---

# 36. 给 T5 的最终 seam 交付格式

T4 C1-0最后附一份：

```text
T4_TO_T5_ENGINEERING_SEAMS
```

每条只写：

```text
Feature
Canonical owner
Current render host
Real states
Real interaction states
Screen occupancy
LOD inputs
Motion-compatible state changes
Donor mechanic
Must-retire visual body
Must-not-visualize internal detail
```

不要把：

```text
Core route
repository method
SQL
```

全塞给T5。

---

# 37. 当前对话如果即将耗尽上下文，怎么交接

如果出现：

```text
上下文窗口即将用完
额度不足
需要切新会话
```

不要在旧会话里继续硬写一半施工稿。

正确：

```text
1. 把当前C1小步立刻落MD
2. 更新本母交接的Current Progress
3. 把新产出的MD加入交接ZIP
4. 新会话先全文读本母交接
5. 再全文读最后一个C1增量
6. 继续下一小步
```

---

# 38. 新会话禁止做的第一件事

禁止开场：

> “我先重新理解一下 Work View 是什么。”

因为当前产品已经冻结。

正确开场：

> “读取 Phase B + T4母交接，确认当前停在 C1-x，然后核 current source exact files，继续该卡。”

---

# 39. 新会话启动指令 · 可直接贴

```text
你现在接管 LCOS Gen2 T4 Phase C1 源码施工规划。

先完整阅读：
1. LCOS_Gen2_T4_PhaseC1_源码施工前_完整上下文母交接_20260906.md
2. LCOS_Gen2_PhaseB_四路合并_最终跨线程裁决稿_20260906.md
3. 当前最新 T4 C1-x 增量稿

Phase B 已关闭的产品/owner问题禁止重新 OPEN。
不要重新做产品语义考古。
不要越权替 T1/T2/T3/T5/T6 改定义。

从当前 C1 进度继续。
每一小步必须：
exact-file
exact-owner
exact-consumer
KEEP/ADOPT/WRAP/LIFT
migration
retirement
tests
browser acceptance
recovery
blast radius

只有 current source 存在真实不可薄适配技术冲突时，才回报 Coordinator。

先核 current GitHub HEAD，再继续施工方案。
不写 production patch。
```

---

# 40. 当前进度快照 · 2026-09-06

```text
Phase A Archaeology
CLOSED

Phase B Coordinator Decision
READ FULL / CLOSED

T4 old Cross-thread OPEN
CLOSED BY PHASE B

Current LCOS source HEAD
c2ff890a867922a1256572199458438572eb0a8c

Donor census
STRONGLY CONVERGED

T4 final source-level construction plan
NOT YET WRITTEN

Next
C1-0 Engineering Seam Skeleton
```

---

# 41. 当前最短白话总结

T4现在不再研究“这些产品到底是什么”。

那部分结束了。

现在做的是：

> **沿着已经冻结的产品答案，把现有 Core、Huabu、SurfaceRegistry、ProjectSession、AssemblyApply、ContextSnapshot、Workflow、Skill、Run，以及 Dockview/Spatial/Lovart/TapNow/Astra/LibTV 等 donor，精确接成一套可施工的工程方案。**

每一处都要写清：

```text
谁拥有
谁消费
复用谁
新接缝在哪
旧东西怎么退
失败怎么恢复
最多炸到哪
浏览器怎么验
```

第一步不是最终大施工稿。

第一步是：

> **T4 Engineering Seam Skeleton。**

它出来以后，T5就有足够真实的工程边界去锁最终高保真视觉。

然后T4再继续把每个 seam 展开成 exact-file 源码施工卡。

---

# 42. 最终提醒

这份母交接的优先级：

```text
高于旧T4聊天上下文中的临时判断
低于后续用户新明确指令 / 新Coordinator正式裁决
```

所有旧 T4 文件仍然有 source/donor/历史证据价值。

但任何旧文件出现：

```text
OPEN
WAIT_CROSS_THREAD
single WorkView
durable Scope
Scope-as-Container
Scope-as-Worksite
old Workflow scope identity
old Context membership assumption
```

必须先对照 Phase B。

不要直接复活。
