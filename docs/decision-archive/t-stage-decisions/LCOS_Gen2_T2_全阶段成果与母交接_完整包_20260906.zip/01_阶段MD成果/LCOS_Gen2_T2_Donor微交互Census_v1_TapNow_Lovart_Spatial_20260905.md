# LCOS Gen2 · T2 Donor 微交互 Census v1
## TapNow / Lovart / Spatial / Morphicons / Amicro
### Pin / Search↔Focus Glyph / Camera Locate / Locator / Minimap / FOCUS Transition

日期：2026-09-05  
线程：T2 · Viewport / Navigation / Screen-space HUD  
上位产品输入：`LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905`

> 目的：不再用“参考 TapNow”“像 Lovart”“Spatial 感”这种不能施工的话。
> 本文把 T2 每个用户可感知状态拆开，明确：
>
> 1. 哪个 donor 在这个微状态里最好；
> 2. donor 实际做了什么；
> 3. 哪些可以合法直接用；
> 4. 哪些只能高保真复现视觉/交互；
> 5. LCOS 自己只需要保留什么。

---

# 0. 总裁决

T2 不采用“一整套抄一家”的方式。

正确模式：

```text
产品冻结
↓
拆成微交互状态
↓
每个状态找最佳 donor
↓
合法 OSS 直接 COPY / WRAP
↓
专有产品只高保真复现行为与视觉参数
↓
Huabu 保留空间机械
↓
LCOS 做最薄语义 glue
```

当前第一轮结论：

| 微系统 | 当前最佳答案 | 用法 |
|---|---|---|
| Pin Trigger | TapNow | HIGH_FIDELITY_VISUAL |
| Pin 多色点簇 | TapNow | HIGH_FIDELITY_VISUAL |
| Pin Group Filter | TapNow | HIGH_FIDELITY_INTERACTION |
| Pin Member → Camera Locate | TapNow | HIGH_FIDELITY_INTERACTION + Huabu mechanic |
| Search ↔ Focus 动态图标 | Morphicons | DIRECT_USE candidate |
| 非 path-compatible icon swap | Amicro IconSwap | DIRECT_USE candidate |
| Minimap world/viewport | Huabu ReactFlow | KEEP |
| Minimap 行为 | TapNow | HIGH_FIDELITY_INTERACTION |
| Minimap 外壳低 Chrome | Lovart/tldraw | HIGH_FIDELITY_VISUAL |
| FOCUS 对象进入/退出 | Spatial | HIGH_FIDELITY_INTERACTION |
| Locator 产品语义 | LCOS freeze | FROZEN |
| Locator exact visual donor | 尚未闭合 | OPEN |
| Locator camera implementation | Huabu | KEEP |
| Arrival / presented transition | Spatial + LCOS | REFERENCE / to freeze |

---

# 1. Pin：TapNow 已经足够具体，可以停止“自己设计 Pin”

## 1.1 TapNow Pin palette

实际 donor 固定六色：

```text
Red     #F0606B
Orange  #F4A14B
Yellow  #EDC63D
Green   #4FC978
Blue    #4EA8FF
Purple  #A55CF0
```

注意：

这六色是 TapNow donor 的 exact values。

LCOS 是否 1:1 使用 palette：

```text
VISUAL DECISION
```

而不是产品语义。

如果 T5 有更统一的 LCOS 色彩系统，可以做最小色相/明度适配。

但：

```text
“六个清晰离散 user-authored color groups”
```

这个视觉结构非常成熟，不需要重新发明。

---

# 2. Pin Trigger：直接复现 TapNow 的微运动

TapNow Pin Trigger 不是普通 Pin 图标。

其结构：

```text
26 × 26 motion stage
↓
18px pin icon
stroke-width = 2
↓
背后/周围 6px color dots
```

实际 class 证据：

```text
size-[26px]
icon size = 18
strokeWidth = 2
dot size = 1.5 Tailwind unit ≈ 6px
```

## Rest

未 Pin：

```text
主 icon 稳定
color dots 基本收在 icon 附近
```

已有 Pin：

```text
stage 整体约 +1px / +1px 偏移
selected dots visible
```

## Hover / Focus / Popover Open

TapNow：

```text
stage translate(-1px, -1px)
pin icon rotate(-5deg)
selected dots 再向外移动一点
```

transition：

```text
200ms
cubic-bezier(0.2, 0.85, 0.2, 1)
```

## Pressed

```text
scale(0.90)
```

## Pin set 发生变化

整个 26px stage：

```text
scale 0.88
→ scale 1.06
→ scale 1
```

其中：

```text
offset ≈ 58%
duration = 320ms
easing = cubic-bezier(0.2, 0.85, 0.2, 1)
```

### T2 verdict

这个交互已经成熟。

LCOS 不应重新设计一个：

```text
点击 Pin
→ 图标变蓝
```

这种廉价状态。

应该直接高保真复现：

```text
Rest
Hover
Pressed
Popover Open
Membership Changed
Reduced Motion
```

---

# 3. Node-local Pin：TapNow 的多 Pin 表达比我们之前自己画的更好

TapNow 对节点多 Pin 使用：

## 只有一个 Pin

```text
diameter ≈ 18px
```

## 多个 Pin

```text
diameter ≈ 14px
margin-left ≈ -10px
```

即：

```text
●
```

或者：

```text
●●●
```

但后两个明显重叠。

这比：

```text
每个 Pin 都隔开 6px
```

更省空间。

---

# 4. Pin Group 激活后的节点视觉：TapNow 可以基本原样借设计

TapNow 当前 group filter：

## 不属于 active group 的 Pin

```text
saturate(0.35)
brightness(0.55)
```

而 active group：

```text
保持 saturate(1)
brightness(1)
```

## 属于该 Group 的 Node

会出现：

```text
3px solid group color border
+
0 0 22px group-color glow
```

glow alpha：

约：

```text
0.6
```

transition：

```text
opacity 300ms ease
border-color 300ms ease
box-shadow 300ms ease
```

### T2 决定

这里不再让施工者自己写：

```text
.highlighted { box-shadow: ... }
```

而是必须从 donor 结构下压。

LCOS 可调：

- glow alpha；
- 是否保留完整 22px；
- LCOS light/dark material 下的 border contrast。

但状态结构不重新发明。

---

# 5. Pin Group 本身：不要做成长期文字标签

TapNow 的 Group identity 核心仍然是：

```text
color core
```

而不是：

```text
[蓝色重要素材]
```

这跟最新 V2：

> 图形优先，文字按需出现

完全一致。

因此 LCOS Pin top index 应坚持：

## Rest

```text
● ● ●
```

## Hover

才出现：

```text
蓝 · 重要 · 4
```

## Active

active color core：

```text
轻描边 / rim
其它 group / local pins 降饱和
```

---

# 6. Pin Member → Camera：TapNow 提供了非常明确的定位参数

这是目前最重要的 donor 证据之一。

TapNow 对 Pin member / mention node locate 使用：

```ts
fitView({
  nodes: [{ id }],
  padding: 1,
  maxZoom: 2,
  minZoom: 0.5,
  duration: 500
})
```

所以：

```text
padding = 1
minZoom = 0.5
maxZoom = 2
duration = 500ms
```

不是我们拍脑袋出来的。

---

# 7. LCOS 对 TapNow Camera Locate 的唯一必要扩展

TapNow 默认 fit 当前 ReactFlow viewport。

LCOS 必须多一层：

```text
activeSpatialViewport / safeRect
```

即：

```text
TapNow:
target bounds
→ fit viewport

LCOS:
target bounds
→ remove occupied regions
→ derive active safe rect
→ fit target inside safe rect
```

因此 donor 行为保留：

```text
direct
500ms class
padding-aware
bounded zoom
no modal
```

但计算区域换成 LCOS 的 active spatial viewport。

---

# 8. Camera Locate 不应该自动发生在 Dock 打开时

V2 已冻结：

```text
Dock / Resize
≠ navigation action
```

因此：

```text
Work View opens
→ camera stays where it is
→ only HUD relocates
```

随后：

```text
user clicks Pin / Focus / Locator
→ now camera fit uses the smaller safeRect
```

这是 LCOS 对所有 donor camera 行为的上位约束。

---

# 9. Minimap：TapNow 的行为不是“ReactFlow 默认 MiniMap”

TapNow 虽然底层使用 ReactFlow MiniMap，但它在外面重新做了交互层。

这是非常值得借的地方。

Exact size：

```text
width = 200px
height = 150px
```

背景：

```text
rgba(24,24,27,0.92)
```

node default：

```text
rgba(90,90,99,0.5)
```

当前 selected node：

```text
rgba(59,130,246,0.9)
```

selected stroke：

```text
rgba(59,130,246,0.6)
```

普通 node stroke：

```text
rgba(255,255,255,0.6)
```

node border radius：

```text
4px
```

---

# 10. Minimap 当前 Viewport 表达

TapNow 没用 ReactFlow 默认 mask 作为最终视觉。

它自己覆盖一层 viewport rectangle：

```text
border = 1.5px solid white
background = rgba(0,0,0,0.1)
box-shadow = 0 0 0 9999px rgba(0,0,0,0.22)
```

所以用户看到：

```text
整个 MiniMap 稍暗
只有当前 viewport 的矩形比较清楚
```

这是非常好的“低信息地图”。

---

# 11. Minimap 点击空白区域：直接移动 Camera

TapNow 行为：

如果 pointerdown 在当前 white viewport rectangle 外：

```text
minimap click
→ convert minimap coordinate to world
→ calculate viewport center
→ move camera
```

整个动作没有：

```text
确认
popover
menu
```

这与 V2 的：

> 语义唯一就直接做

完全一致。

---

# 12. Minimap 拖 current viewport：连续跟手移动

如果 pointerdown 位于 white viewport rectangle 内：

```text
capture pointer
↓
drag white viewport
↓
continuously update ReactFlow viewport x/y
```

zoom 保持原值。

也就是：

```text
拖小地图里的白框
= 搬主画布摄像机
```

这个 interaction 应直接保留。

---

# 13. TapNow Minimap Camera motion

TapNow 内部对 minimap camera x/y 使用 spring：

```text
stiffness = 120
damping = 18
mass = 1
```

对外部 viewport 更新做：

```text
requestAnimationFrame batching
```

click 跳转后：

```text
约 300ms 后解除内部 moving flag
```

### 施工含义

不能实现成：

```text
onclick → setViewport instant
```

否则视觉上会明显掉档。

---

# 14. TapNow Minimap launcher 很适合 V2 的“图形优先”

TapNow canvas control launcher：

```text
28 × 28
rounded-lg
```

默认 icon：

```text
20px
```

active / hover 替代 icon：

```text
16px
```

icon 之间：

```text
opacity crossfade 200ms
```

底部 hover/active material：

```text
background rgba(0,0,0,.40)
backdrop blur 56px
shadow:
0 4px 16px rgba(0,0,0,.16)
+
inset top highlight
```

注意：

这不是说 LCOS 必须拿 56px blur。

但是它说明：

> Minimap launcher 完全可以长期只是一颗没有文字的动态图形按钮。

Hover 才 Tooltip。

非常符合 V2。

---

# 15. TapNow Minimap 还会把 Pin / Selection 状态映射进去

TapNow minimap nodeColor：

优先级大致：

```text
selected node
→ blue

active Pin group member
→ group color

otherwise
→ muted gray
```

这很值得 LCOS 借。

因为它让：

```text
Pin
Selection
Minimap
```

成为同一个视觉语言，而不是三个系统各显示一套颜色。

---

# 16. Lovart Minimap：更适合贡献“外壳密度”，不是 camera mechanic

Lovart / tldraw 相关 CSS：

```text
.tlui-minimap
height = 96px
min-height = 96px
width = 100%
padding = space-3
padding-top = 0
```

说明它的 minimap 更像：

> navigation panel 里的低高度空间概览。

而不是 TapNow 那个独立 200×150 黑色浮图。

---

# 17. Lovart toolbar 的价值：极低 Chrome

tldraw/Lovart toolbar：

```text
tool button = 48×48
```

但实际 hover / active hit visual：

```text
inset 4px
→ 约 40×40
radius = 8px
```

也就是说：

> hit target 可以够大，视觉主体仍然很小。

这非常适合 LCOS V2：

```text
系统 Chrome 少
≠ 点击区域也变得很小
```

---

# 18. Minimap 第一轮 donor 裁决

当前最优组合不是二选一。

而是：

```text
ENGINE:
Huabu ReactFlow MiniMap / viewport truth

BEHAVIOR:
TapNow
- click blank → camera
- drag viewport → camera
- Pin/Selection color mapping
- spring camera
- exact viewport box

VISUAL SHELL:
TapNow vs Lovart 第二轮 A/B
```

目前我更倾向：

## Compact Rest

借 Lovart：

```text
更轻
更融进导航 shell
```

## Expanded Active

借 TapNow：

```text
200×150
dark world
white viewport
direct manipulation
```

即：

```text
Rest 更 Lovart
Active 更 TapNow
```

这比“整套选一家”更好。

---

# 19. Search ↔ Focus 动态图标：停止手写 opacity swap

上一版 HTML 用：

```text
search SVG opacity out
focus SVG opacity in
```

这只是 prototype。

正式施工没有理由继续这样。

因为现有 source pack 已有：

```text
Morphicons v1.7.1
MIT
```

---

# 20. Morphicons 为什么特别适合 T2

Morphicons 允许：

```tsx
<MorphIcon icon={knownTarget ? LocateIcon : SearchIcon} spring="snappy" />
```

不需要：

- 两个重叠 icon；
- AnimatePresence；
- 手工 rotation group；
- 自己算 path interpolation。

它支持：

```text
Uncontrolled:
icon prop change → automatic morph

Controlled:
from / to / progress
→ gesture-driven morph

Imperative:
ref.morphTo(...)
```

对 T2 特别重要的是：

> controlled progress。

因为 Locator / near-edge transition 将来可能需要：

```text
target inside
→ near edge
→ offscreen
```

由一个 `progress` 连续驱动 icon morphology。

---

# 21. Morphicons 的 spring presets

源码：

```text
smooth:
k = 170
c = 26
critically damped

snappy:
k = 420
c = 30
subtle overshoot

bouncy:
k = 300
c = 14
```

T2 导航 glyph：

默认优先：

```text
snappy
```

而不是 bouncy。

因为导航是工具反馈，不应该玩得像 loading animation。

---

# 22. Morphicons Reduced Motion

它支持：

```text
reducedMotion="user"
```

即：

```text
prefers-reduced-motion
→ morph degrade to instant swap
```

这比每个 T2 icon 自己写 motion-reduce CSS 更统一。

---

# 23. Amicro IconSwap：作为 Morphicons 的备用，不是竞争关系

Amicro `IconSwap`：

```tsx
AnimatePresence(mode="popLayout")
```

IconSwapItem：

```text
initial:
opacity 0
scale .25
blur 4px

animate:
opacity 1
scale 1
blur 0

exit:
opacity 0
scale .25
blur 4px

spring:
duration .3s
bounce 0
```

它也是 MIT。

### 何时用

如果两个图标：

- path topology 很不适合 morph；
- 一个不是 stroke icon；
- 需要更明显的 semantic replace；

则：

```text
Amicro IconSwap
```

很好。

---

# 24. Search ↔ Focus 第一轮 verdict

正式施工候选：

```text
Search icon
↔
Known-target Focus / Locate icon

Morphicons
spring="snappy"
reducedMotion="user"
```

而不是：

```text
两个 static icon 并排
```

也不是：

```text
两个模式按钮
```

这和 V2 的：

> 图形优先、状态与动画表达系统功能

完全一致。

---

# 25. Spatial：必须纠正错误期待

Spatial v4 真实源码/符号 Census 已经明确：

以下产品级能力不存在证据：

```text
Minimap
Locator
Color Pin
centeredSpatialIndex
EdgePin
Beacon
Focus
```

所以：

```text
Spatial ≠ LCOS Navigation Feature Supplier
```

以后不得再写：

```text
“Locator 参考 Spatial 的 Locator”
```

因为根本没有这个东西。

---

# 26. Spatial 真正对 T2 有价值的是什么

真实存在：

```text
CanvasTransitionView
CanvasTransitionCursor
CanvasTransitionSwiper
CanvasTransitionMediaView
CanvasTransitionImageView
CanvasTransitionNotesView
CanvasTransitionVideoView
CanvasTransitionWebClipView
presentedScale
itemScaleWhenPresented
itemCanvasFrame
ZoomRasterGate
ZoomLevel
```

它最重要的产品体验是：

> 同一个空间对象从原位置自然进入“呈现态”，而不是打开一个与原对象断裂的新窗口。

---

# 27. Spatial 最适合贡献 FOCUS 中间态

最新 V2 专业工具生命周期：

```text
canvas lightweight
→ Focus
→ Docked
→ Floating
→ Immersive
→ Restore
```

Spatial 可以贡献：

```text
Canvas item original frame
↓
scale / translate
↓
presented state
```

关闭：

```text
presented state
↓
回原 frame
```

所以 Assembly / Context Atlas / deep preview 的：

```text
Canvas → FOCUS
FOCUS → Canvas
```

最值得采用 Spatial motion language。

---

# 28. Spatial 视觉帧显示出的几个关键手感

录屏帧可以观察到：

## 28.1 极少永久 Chrome

内容本身占主要画面。

## 28.2 对象有明确“被拿近”感觉

不是：

```text
点击节点
→ modal fade in
```

而是：

```text
那个节点本身
→ 放大
→ 接管工作区域
```

## 28.3 背景其它内容主动退后

通过：

- scale；
- opacity；
- spatial distance；

让当前对象成为主角。

## 28.4 退出仍有空间连续性

用户知道：

> 我不是离开这个 Canvas 去另一个页面，我只是把同一个东西拿近看了。

---

# 29. T2 对 FOCUS 的第一轮 motion verdict

上一版 HTML：

```text
central card scale(.92 → 1)
```

不够。

下一版应该改成 FLIP-like：

```text
1. 获取 Canvas object screen rect
2. Focus work body 初始视觉 frame = object rect
3. 同一个 identity body
   translate + scale
   → target Focus rect
4. underlying canvas stays put
5. restore 反向回原 frame
```

T2 不应让 Focus 像普通 Dialog。

---

# 30. Spatial motion 参数：区分“源证据”和“已有分析建议”

Spatial binary/source 确认：

```text
presentedScale
itemScaleWhenPresented
CanvasTransition*
```

但是：

```text
180–240ms
response .25 / damping .8
```

这些来自此前对录屏/行为的分析建议，不是可以直接声称为源码 constant。

所以正式施工卡必须标：

```text
VISUAL_CALIBRATION
```

而不是：

```text
SOURCE_EXACT
```

避免把推测冒充源码。

---

# 31. Locator：目前不能假装 donor 已经闭合

产品语义已经冻结：

```text
target in viewport
→ no redundant edge pointer

target leaves viewport
→ directional cue

click
→ direct camera locate
→ no popup

arrival
→ target clearly identified
```

但当前 donor evidence：

## TapNow

已经确认：

- Pin locate；
- fitView；
- minimap camera；
- highlighted nodes。

没有从现有 bundle 里闭合到：

```text
canvas offscreen locator
```

## Spatial

明确没有产品级 Locator。

## Lovart

当前也没有可靠证据证明一套可直接拿的 edge locator。

因此：

> Locator 目前必须保持 `VISUAL_DONOR_OPEN`。

---

# 32. Locator 现在能冻结什么

即使视觉 donor 未闭合，也能冻结：

## Geometry

```text
Huabu world bounds
→ project into active safeRect
```

## Click

```text
zero-confirmation
```

## Camera

优先继承 TapNow locate 感：

```text
≈500ms
bounded zoom
padding-aware
```

再由 LCOS safeRect 修正。

## Glyph implementation primitive

候选：

```text
Morphicons controlled mode
```

如果最后决定：

```text
local indicator
→ edge arrow
```

可通过 progress 驱动 morph。

但 exact glyph shape 暂不锁。

---

# 33. Arrival：暂时不要做成 Toast

无论最后 donor 是哪一个：

禁止：

```text
“已定位到 xxx”
```

Toast。

应当在目标 body 本身完成：

```text
brief rim
field pulse
subtle outline settle
```

Spatial 的“同一对象连续呈现”比 Toast 更符合产品。

Pin active outline 也可贡献一部分视觉语言。

---

# 34. V2 “非必要不显示字”对 T2 donor 选择的直接影响

从现在开始 donor 评估必须加一项：

```text
Does this interaction need persistent text to be understandable?
```

如果需要：

```text
降级
```

T2 主导航默认应靠：

- icon；
- shape；
- color；
- location；
- direction；
- morph；
- hover；
- short tooltip；

完成。

---

# 35. 第一轮 Donor 状态矩阵

| System | State | Donor | Evidence | Verdict |
|---|---|---|---|---|
| Pin | Rest trigger | TapNow | 26px stage / 18px icon / 6px dots | TAKE |
| Pin | Hover trigger | TapNow | -1px/-1px, -5deg, 200ms | TAKE |
| Pin | Membership change | TapNow | .88→1.06→1, 320ms | TAKE |
| Pin | Local dots | TapNow | 18 single / 14 multi / -10 overlap | TAKE |
| Pin | Group filter | TapNow | desaturate/dim | TAKE |
| Pin | Node active group | TapNow | 3px border + 22px glow | TAKE with LCOS material tuning |
| Pin | Member locate | TapNow | fitView 500ms / p1 / .5–2 | TAKE behavior |
| Search | default glyph | TBD icon family | V2 | OPEN exact shape |
| Search→Focus | glyph motion | Morphicons | MIT / controlled+spring | DIRECT_USE candidate |
| Focus | occurrence presentation | LCOS freeze | product semantic | donor pass still needed |
| Locator | edge glyph | none closed | no donor proof | OPEN |
| Locator | camera | TapNow feel + Huabu | 500ms fit | TAKE behavior |
| Minimap | engine | Huabu | current ReactFlow owner | KEEP |
| Minimap | expanded behavior | TapNow | 200×150 + click/drag | TAKE |
| Minimap | shell density | Lovart | 96px low navigation panel | TAKE visual reference |
| Minimap | launcher motion | TapNow | 28px + 200ms icon crossfade | TAKE / may replace with Morphicons |
| FOCUS | enter/restore | Spatial | CanvasTransition/presentedScale | TAKE interaction language |
| FOCUS | window lifecycle | shared LCOS | V2 | T2 consumes, not owns |
| Arrival | continuity | Spatial | presentation language | REFERENCE |
| Icon replacement | incompatible pair | Amicro | MIT IconSwap | DIRECT_USE fallback |

---

# 36. 第二轮仍需深挖的项目

不能现在就假装全部确定。

## 36.1 Search

还需找：

- TapNow search open placement；
- Lovart search chrome；
- result count / result cluster；
- focus handoff；
- result hover to canvas。

## 36.2 Focus Index

还需决定：

- occurrence visual morphology；
- 1 / 2 / 3 / 7 / 20 locations 如何排；
- current occurrence；
- cross-surface identity；
- overflow fan。

## 36.3 Locator

最重要 OPEN：

- exact resting/local form；
- exact edge form；
- near-edge transition；
- edge inset；
- label hover；
- cluster；
- target unavailable；
- archived target。

## 36.4 Railway

还需做：

- TapNow / Lovart workspace/project navigation；
- current state；
- hover preview；
- drag receive；
- dynamic icon；
- Receiver；
- child worksite emergence。

## 36.5 Dock collision

必须把：

```text
Pin
Focus
Search
Locator
Minimap
```

在：

```text
Docked right
Floating overlap
narrow viewport
```

分别跑一遍。

---

# 37. HTML v3 的明确修改项

下一版交互样机不得只是美化。

必须至少改：

## 37.1 FOCUS

```text
Canvas item rect
→ FLIP morph
→ Focus rect
```

参考 Spatial。

## 37.2 Search ↔ Focus icon

不再并排两个按钮。

demo 中至少表现为：

```text
same position
semantic morph
```

正式施工使用 Morphicons。

## 37.3 Pin

完全按 TapNow：

```text
26 stage
18 pin icon
6px dots
200ms
320ms bump
14/18 dots
-10 overlap
3px/22px group highlight
500ms locate
```

## 37.4 Minimap

TapNow active behavior：

```text
200×150
dark
white viewport
click blank
drag viewport
spring
Pin group color map
```

Rest shell 再试一版更 Lovart 的低 Chrome。

## 37.5 Locator

HTML 仍可做行为 proof。

但必须标：

```text
VISUAL FORM NOT FINAL
```

不能把样机里的 arrow 当施工冻结。

---

# 38. 当前最关键结论

现在终于能把这句话说得非常具体：

> TapNow 不是“给 LCOS 一个 Pin 灵感”，而是已经提供了 Pin 的 trigger、membership feedback、node-local stack、group filtering、member locating、minimap integration 和 camera rhythm 的一整组成熟 UX 答案。

> Lovart 当前最有价值的不是重写这些逻辑，而是给我们更克制的 canvas chrome、navigation panel 和工具 hit-area / visual-area 分离方法。

> Spatial 当前最有价值的不是导航功能，而是解决“同一个空间对象如何进入 FOCUS / professional view 仍然不丢空间连续性”。

> Morphicons / Amicro 则是把这些成熟产品里的动态图形体验合法地落到 Gen2，而不是让施工 Agent 手写一堆 SVG fade。

---

# 39. 对 source-level blueprint 的直接影响

后续施工卡不能再写：

```text
Add Pin animation.
```

而必须类似：

```text
UX_STATE:
PIN_TRIGGER_MEMBERSHIP_CHANGE

VISUAL_DONOR:
TapNow vendor-pkg-canvas-CI-o9b4X.js
RAe / MAe behavior

TARGET:
LCOS generic Action Arc Pin affordance

MOTION:
0.88 → 1.06 @58% → 1
320ms
cubic-bezier(0.2,0.85,0.2,1)

REDUCED_MOTION:
instant / no transform

ENGINEERING:
do not copy proprietary bundle source
reimplement through LCOS component + legal motion primitive
```

或者：

```text
UX_STATE:
SEARCH_TO_FOCUS_GLYPH

ENGINEERING_DONOR:
Morphicons v1.7.1
MIT

API:
<MorphIcon
  icon={knownTarget ? FocusIcon : SearchIcon}
  spring="snappy"
  reducedMotion="user"
/>

OWNER:
external navigation state
MorphIcon owns no semantic state
```

到这个粒度才叫“可以施工”。

