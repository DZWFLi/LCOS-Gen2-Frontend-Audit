# LCOS Gen2 · T2 对《最终产品冻结 V2》的职责重切与施工解释
## Viewport / Navigation / Screen-space HUD / Railway / Minimap / Locator / Safe Rect

日期：2026-09-05  
上位输入：`LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905.md`

> 本文不是新的产品冻结。
> 本文只负责把 2026-09-05 的最终产品冻结，翻译成 T2 这一条线程后续应该怎么做。
> 产品语义以最终冻结为准；具体 UI、动效、图形、比例、donor、OSS 和实现方案，仍由 T2 根据 TapNow / Lovart / Spatial / Huabu / permissive OSS 独立深挖并选最优解。

---

# 0. 先钉死：这份 V2 不是“设计方向说明书”

T2 后续不能把 V2 当成：

```text
Pin 就必须长这样
Minimap 就必须长这样
Railway 就必须长这样
Locator 就必须长这样
Work View 就必须固定 46vw
```

V2 真正冻结的是：

```text
这些东西为什么存在
它们解决什么用户问题
用户动作语义是什么
什么绝不能再发生
谁不能偷偷创建第二份真相
主画布什么时候不能动
通用组件必须怎么复用
```

所以 T2 正确工作方式是：

```text
V2 冻结产品心智
↓
T2 回 Library 恢复相关用户原话
↓
T2 拆 TapNow / Lovart / Spatial 最成熟呈现
↓
Huabu / permissive OSS 找最合适实现轮子
↓
决定最终 GUI / UX
↓
再写 exact-file / JSX / CSS / motion 施工卡
```

不能：

```text
V2 写了“Minimap”
↓
随便做一个 Minimap
```

---

# 1. T2 重新确认后的职责边界

T2 以后集中负责：

## A. 项目级空间导航壳

- Railway / Rail 的用户工作现场导航
- Surface / worksite 切换呈现
- Current location / active worksite feedback
- Rail target 的 cross-surface receiving feedback
- Receiver 在导航壳里的呈现接口
- Rail 和主画布、Work View 之间的空间关系

T2 不负责：

- Context 内部内容组织
- Workflow 内部内容组织
- Assembly 内部业务结构
- Glyth Conversation 深度内容

---

## B. Search / Focus / Pin / Locator / Minimap 这一整套导航语言

T2 负责把：

```text
不知道在哪
→ Search

对象已经知道
→ Focus / Where

想长期留下空间索引
→ Pin

目标跑出屏幕
→ Locator

想看整个现场大概方位
→ Minimap
```

做成一套连续、直觉、低 Chrome 的空间导航体验。

它们可以共享视觉家族、动态图标、HUD 位置和 transition grammar。

但语义不能合并。

---

## C. Camera navigation 的“用户可感知规则”

T2 负责：

- 点击目标导航是否直接执行
- 如何 fly / fit
- 如何处理多目标 bounds
- 到达时如何反馈
- safeRect-aware focus
- Work View 打开后如何把目标框在真正可用区域
- Locator → Camera → Arrival 的连续体验

T2 不拥有：

- world coordinate truth
- camera canonical runtime
- node geometry truth

这些继续由 Huabu / spatial runtime 负责。

T2 只定义：

> 用户点下去以后，镜头应该怎么“接住”目标。

---

## D. Screen-space HUD

T2 负责：

- Search HUD
- Focus Location Index
- Pin Index
- Locator
- Minimap launcher / shell
- arrival feedback
- navigation tool glyph
- HUD priority / collision / avoidance
- active spatial viewport / safe rect 下的重排

这些 UI 都必须服从 V2：

> 图形优先，文字按需出现。

---

## E. 主画布与大 Work View 之间的空间契约

这里需要重新收边。

T2 不再把自己理解成：

> “所有 Work View window lifecycle 的完整 owner。”

最终冻结明确：

所有大工作界面应该复用统一：

```text
Float
Dock
Undock
Resize
Move
Horizontal / Vertical composition
Close
Restore
```

这个统一 Window / Work View lifecycle 是跨系统公共能力。

T2 真正负责的是：

```text
当这些 Work View 出现以后
主画布和导航 HUD 应该怎么办
```

即：

- Canvas world 不自动移动
- Camera 不自动移动
- Node 不自动重排
- occupied region / safe rect 被更新
- Locator / Minimap / Focus / Search / Pin / transient control 避让
- 空间不足时低优先级 UI 收紧 / 换边 / 折叠 / 隐藏
- 用户显式导航时 Camera 才重新 fit remaining spatial viewport

所以：

> Window 本体不是 T2 独占；Screen-space response 是 T2 核心职责。

---

# 2. V2 对 T2 的硬约束

以下后续 donor 不能改。

## 2.1 图形优先

Search / Focus / Pin / Minimap / Locator / Receiver：

默认不应该变成文字按钮。

优先：

```text
glyph
shape
color
direction
motion
state
```

Hover / keyboard focus / explicit expand：

才出现短标签。

所以后续评 donor 时：

```text
如果一个 donor 靠常驻文字才能解释自己
→ 即便实现成熟，也不适合作为 T2 主视觉 donor
```

## 2.2 直觉动作直接执行

如果目标已经明确：

```text
点击 Locator
→ 直接去

拖到 Railway Context A
→ 就是在 Context A 使用

点击某个 Focus occurrence
→ 直接去那个 occurrence
```

不能因为某 OSS 默认有 Modal 就照搬。

## 2.3 多选不自动弹 Composer

T2 的 Selection / navigation 行为必须保持中性。

多选以后：

```text
只是保持 Selection
```

不能因为导航壳觉得“用户可能想 AI”就自动开 Composer。

## 2.4 主画布永远稳定

任何：

```text
Work View 打开
Dock
Resize
Float
Undock
```

都不能自动改变：

```text
Camera
Canvas world
Node positions
```

只改变：

```text
screen-space safe region
```

这是 T2 后续 camera / locator / minimap 设计的最高约束之一。

## 2.5 通用 Work View / Window 不能各系统重做

T2 如果需要：

```text
Search expanded view
Archive view
Assembly dock
Conversation dock
Context professional view
Workflow deep view
```

不能给它们各造：

```text
SearchDock
AssemblyDock
ContextDock
...
```

T2 只消费公共 window lifecycle，并负责 HUD adaptation。

---

# 3. Railway 在 V2 下应该怎么重新理解

Railway 不是：

```text
文件树
页面导航
模式导航
Sidebar 管理器
```

更接近：

> **项目真实工作现场的空间入口。**

它至少承接：

- Main
- Context
- Workflow
- 长期 worksite / 子画布入口
- Receiver 的当前承接状态
- cross-surface receiving target

但是 V2 没有冻结：

- Railway 必须 64px
- 必须竖着
- icon 必须圆角矩形
- hover preview 必须哪种形态
- Collection 是否以同级 permanent item 展示
- 子画布入口什么时候显式出现

这些仍然要：

```text
回用户原话
+
看 TapNow / Lovart / Spatial
+
看实际信息密度
```

再决定。

---

# 4. Search / Focus 的硬语义与开放视觉

## 冻结

Search：

> 不知道东西在哪 / 叫什么。

Focus：

> 已经知道对象，想知道它出现在哪里。

二者不能重新合并成一个 “searchMode”。

## 开放

以下都还要深挖：

- Search glyph 最优形态
- Search → Focus 是否使用 Morph icon
- top-center 还是其它 screen-space layout
- 搜索结果 constellation / strip / fan
- Focus occurrence glyph
- 结果 hover 如何回画布
- active occurrence 的视觉
- 多 occurrence overflow

TapNow / Lovart / Spatial 谁在某个状态做得最好：

> 就拿谁的答案。

不要求整套系统只认一个 donor。

---

# 5. Pin 的硬语义与开放视觉

## 冻结

Pin：

- 是长期 user-authored spatial index relationship
- 不是 Focus
- 不是 Selection
- 不是收藏模式
- node-local 有可见身份
- global navigation 可以利用它
- click member 最终应该能空间定位

## 开放

仍需继续挖：

- TapNow color-pin group 的 exact 动效
- 节点多个 pin 的 stack / spread
- global pin index 是 TapNow 方案更好，还是 Lovart 有更轻的呈现
- pin chooser 用 compact pill 还是其它更成熟结构
- pin member list / mini popover 的 density
- pin → locate 的 exact camera feel
- pin group filtered highlight 的 glow / outline / dimming

原则：

> 不是“像 TapNow”。
>
> 而是逐状态对比 TapNow / Lovart / Spatial，谁最好就拿谁。

---

# 6. Locator / Camera 的硬语义与开放视觉

## 冻结

目标离屏：

- 用户应该还能知道方向
- 点击导航是零确认 direct spatial action
- 不弹 Modal / Popover
- 显式导航可以移动 Camera
- 最后必须把目标接进 active usable spatial area
- 到达要让用户知道“就是它”

## 开放

继续深挖：

- Locator 是否是 arrow / wedge / edge bead / morphing cursor
- inside → edge → offscreen 的变形方式
- pointer shape 是否跟 TapNow 一致
- Camera easing
- Camera duration
- padding
- small target / huge target 的 zoom limits
- multiple target union fit
- arrival feedback
- locator disappear timing

TapNow 当前已经是强参考。

Spatial 更值得挖：

- 连续空间过渡
- 物体接管 / presentedScale
- zoom/presentation continuity
- edge / directional interaction 手感

Lovart 可补：

- 低 Chrome
- tldraw 式 navigation feedback
- animation rhythm

---

# 7. Minimap 的硬语义与开放视觉

## 冻结

Minimap：

> 是大范围空间方位辅助。

不是：

- Project Search
- Focus replacement
- Pin replacement
- 主导航中心

并且：

- world/viewport mechanics 必须继续吃 Huabu
- 不允许 second coordinate engine

## 开放

以下都可以直接借成熟产品最优答案：

- 是否默认只显示 launcher
- 展开方式
- exact dimensions
- dark / light material
- viewport box
- click navigation
- drag viewport
- node density rendering
- hover reveal
- Dock 后换边 / 收缩
- close transition

TapNow 的 `200×150 + dark map + white viewport + click/drag camera` 已经是一个非常强的行为 donor。

Lovart / tldraw 的 Minimap：

更值得比较：

- chrome 更少
- material 更克制
- canvas integration 更自然

最终不要求 “TapNow 全抄”。

---

# 8. Assembly / 专业工作工具的中间态，对 T2 到底意味着什么

V2 已经把专业工作工具统一成：

```text
画布轻量形态
→ Focus
→ Docked
→ Floating
→ Immersive / Dedicated
→ Restore
```

T2 不负责决定：

- Assembly 里面放什么
- Atlas 里面放什么
- Workflow 深度视图里面放什么

T2 负责确保：

## Focus

仍有空间归属感。

不能一点击就像跳进另一个网站。

## Docked

占 screen-space。

但：

```text
Camera 不自动搬
```

## Floating

不能遮死关键 HUD。

## Immersive

导航 shell 可以按优先级收敛。

## Restore

回去时：

```text
仍然是同一个对象
```

不能像打开新页面再返回。

---

# 9. Archive 对 T2 的影响

Archive 本体不属于 T2 主业务。

但 T2 需要对它承担导航层兼容：

- Archived object 仍可 Search
- Archived object 仍可 Focus 到语义位置/来源
- Restore 后新活跃 spatial projection 不恢复旧 x/y
- Archive / Restore 入口属于 More / management，不进入高频 Action Arc
- archived object 不应让 Locator 指向一个已经不存在的旧 Main spatial position
- 如果 navigation target 已失效，必须呈现 honest unresolved / restore affordance，而不是飞向幽灵坐标

---

# 10. T2 的 Donor 使用方式重新冻结

以后不是：

```text
TapNow = Pin 系统
Lovart = Minimap 系统
Spatial = Camera 系统
```

这种粗暴一一对应。

而是：

```text
按用户状态拆件
```

例如 Pin：

```text
Pin trigger
→ TapNow 可能最好

Pin chooser
→ TapNow / Lovart 对比

Pin node-local stack
→ TapNow

Pin global index
→ TapNow / Lovart / LCOS existing freeze 对比

Pin click camera
→ TapNow mechanic feel + Huabu implementation

Arrival
→ Spatial / Lovart motion 可能更好
```

Minimap 同理。

Search 同理。

Locator 同理。

最终是：

> **每个微交互状态都拿最好的成熟答案，不要求“整套抄一家”。**

---

# 11. T2 后续 donor 深挖要回答的真正问题

以后不是：

```text
这个 donor 有 Minimap 吗？
```

而是：

```text
它 resting state 怎么长？
hover 怎么变？
active 怎么变？
click 后 camera 怎么动？
drag 怎么跟手？
目标到达后怎么收尾？
Dock 占空间以后怎么重排？
小屏幕怎么办？
screen-space icon 在 zoom 中是否稳定？
```

每个系统都要按：

```text
Idle
Hover
Pressed
Active
Transition
Complete
Failure
Recovery
```

逐状态拆。

---

# 12. T2 下一阶段工作顺序

## Round A · 重新回 Library

只读 T2 相关用户原话：

- Railway
- Search
- Focus
- Pin
- Locator
- Minimap
- Camera
- Work View safe rect
- dynamic glyph
- cross-surface drop
- Receiver shell

建立：

```text
EARLY
→ CORRECTED
→ FINAL
```

## Round B · donor micro-interaction census

TapNow / Lovart / Spatial：

不是泛看视频。

逐项记录：

```text
geometry
icon
motion
visibility
hover
click
drag
camera
arrival
dock collision
```

## Round C · supplier implementation census

对于每个最终 UX：

优先找：

```text
Huabu existing mechanic
→ permissive OSS primitive
→ existing LCOS primitive
```

不是自己写。

## Round D · source-level blueprint

只有到这里才写：

```text
target file
owner
props
JSX
CSS
token
motion
safeRect
LOD
acceptance
```

---

# 13. T2 当前最重要的一句重新定义

T2 不是：

> “负责做左侧导航和小地图。”

T2 真正负责的是：

> **让用户在任何空间工作状态下，都能非常轻地知道：我在哪、目标在哪、怎么直接过去、怎么换现场、怎么留下路标，而且当大工作视图出现时，这套导航不会失灵，也不会逼着主画布自己搬家。**

视觉答案：

> 去 TapNow / Lovart / Spatial 里拿最成熟的。

实现答案：

> 去 Huabu / permissive OSS 里拿最成熟的。

LCOS 自己只保留：

> 产品语义、身份、owner、safe-rect contract 和最薄 glue。
