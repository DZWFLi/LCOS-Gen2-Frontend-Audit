# LCOS Gen2 · T2 Patched Navigation Cards
## Workspace / Child Canvas / Railway / SurfaceDock / Minimap / Search / Focus / Locate / Arrival

日期：2026-09-05  
状态：阶段 A 修卡；不施工

---

# 0. Patch 标签

```text
UNCHANGED
PATCH_UX
PATCH_OWNER
PATCH_MUTATION
SUPERSEDED
WAIT_CROSS_THREAD
```

每张卡必须回指 UX 场景，并明确不允许新增第二 owner。

---

# Card T2-01 · Railway Product Body

**UX_SCENE_REF**  
`T2-A-RAIL-IDLE / T2-A-RAIL-HOVER / T2-C-DROP-RAIL / T2-D-RECEIVER`

**CURRENT_STATUS**  
`PATCH_UX + PATCH_OWNER`

**历史证据**  
Gen1 `WorkspaceRailVNext` 已有 true spatial preview、truthful fallback、+N、Hover Preview、reorder、direct semantic drop。

**PATCH**

保留 Railway 产品概念与已验证 interaction，但重组 Gen2 ontology：

```text
Surface = Glyph
Long-term Worksite = true spatial preview
Receiver = Glyth identity
```

REST 低 Chrome；Hover = Peek；Drag = Receive Map；Manage = More/right-click。

**OWNER**

- Surface identity：`surfacePort` / Core product truth；
- spatial preview geometry：Huabu；
- Receiver truth：Core Receiver；
- durable order exact contract：`WAIT_CROSS_THREAD`。

**DO_NOT_BUILD**

`RailwayStore / NavigationManager / second project hierarchy`。

**ACCEPTANCE**

- Railway 不变 Explorer；
- LayerPanel 不被复制；
- Work View 打开后 Railway 仍存在；
- Drop destination 唯一时直接 commit，无 chooser。

---

# Card T2-02 · Old Flat Railway Kinds

**CURRENT_STATUS**  
`SUPERSEDED`

旧：

```text
scene | collection | context | workflow
```

平级。

新：

```text
Main / Context / Workflow = 一级 Surface
materialized long-term worksite = persistent destination
Collection / Scope / temporary Context range ≠ automatic Rail item
```

旧 ontology 禁止继续作为 Gen2 Railway 产品定义。

---

# Card T2-03 · `/view-rail-order` Durable Contract

**CURRENT_STATUS**  
`WAIT_CROSS_THREAD + PATCH_OWNER`

**已确认**

当前 Core 已有 durable order / CAS / restart / dedupe 能力，值得 KEEP。

**冲突**

当前 item ontology 仍旧是 `scene|collection|context|workflow`。

**T2 结论**

机制可复用，但不能宣称现接口就是最终 Gen2 Railway contract。

**需要**

T6 + Coordinator 定义：

- long-term worksite rail identity；
- migration；
- old kinds compatibility。

---

# Card T2-04 · SurfaceDock Bottom-Center Priority

**UX_SCENE_REF**  
`T2-B-SURFACE-SWITCH`

**CURRENT_STATUS**  
`PATCH_UX / KEEP`

Gen1 `SurfaceDock.tsx` 原源码明确让 dock 空间给三视图与现场 pill，缩放走滚轮/触控板。

Gen2：

```text
bottom-center primary chrome
→ Main / Context / Workflow
```

具体视觉现代化，图形优先，Hover 才短标签。

**DO_NOT_BUILD**

不要为了 Huabu 现有 `NodeToolbar position="bottom-center"` 把三视图永久挤走。

---

# Card T2-05 · Huabu Canvas Toolbar Presentation

**CURRENT_STATUS**  
`PATCH_UX`

**重要**

只修改 presentation priority，不修改 Select / Pan / Lasso / Frame / Note / Text / Sketch 等 mechanics owner。

当前规划：

```text
persistent primary toolbar
→ secondary/contextual tool entry
```

逐能力继续分：

- hand gesture / shortcut；
- selection-contextual；
- compact secondary tools；
- content creation via direct input / composer / drop。

**DO_NOT_BUILD**

不能为了少 Chrome 删除 underlying capability。

---

# Card T2-06 · Spatial Navigator / Minimap Cluster

**UX_SCENE_REF**  
`T2-K-MINIMAP / T2-M-SAFE-HUD`

**CURRENT_STATUS**  
`PATCH_UX / KEEP / MODERNIZE`

Gen1 `CanvasMiniMap` 已把：

```text
Minimap
Zoom - / +
Live zoom
Reset 100%
Grid Snap
Fit Content
Camera rect
click/drag camera
safe inset
arrival beacon
```

放在一个 cluster。

Gen2 最终方向：

```text
ENGINE = Huabu viewport/world
EXPANDED INTERACTION = TapNow high-fidelity donor
REST SHELL = Lovart/tldraw low chrome
HISTORICAL PRODUCT STRUCTURE = Gen1 MiniMap cluster
```

可把 Huabu Zoom / Fit / Lock 等 current viewport controls 收入该 cluster；exact Lock/Grid placement 仍需 tool-owner/UX 再核。

**ACCEPTANCE**

- 默认仅轻 launcher；
- 展开后 map 可 direct manipulate；
- Dock 后基于 active safeRect；
- 无 second coordinate engine。

---

# Card T2-07 · Collection Navigation

**CURRENT_STATUS**  
`SUPERSEDED`（旧 child-scene 理解）

**CURRENT_TRUTH**

Collection 原地 collapsed ↔ expanded。

T2 仅参与：

```text
Search
Focus
Locate
```

禁止：

```text
Collection click → child canvas
Collection → Back stack
Collection auto Rail item
```

除非用户显式 materialize 出真正 long-term worksite；其 materialization owner 不归 T2。

---

# Card T2-08 · Scope Navigation Container

**CURRENT_STATUS**  
`SUPERSEDED`

旧 `Scope.parentScopeId / CanvasScope` 不能作为 Gen2 child-worksite hierarchy。

Scope 当前是：

> 这次只处理这些。

T2 不为普通 Scope 建：

- permanent Railway item；
- Back stack；
- independent camera；
- child canvas。

---

# Card T2-09 · Long-term Worksite / Child Canvas Canonical Identity

**CURRENT_STATUS**  
`WAIT_CROSS_THREAD`

**T2 可冻结的 UX**

```text
Enter = active worksite changes
Return/Back = navigation context reverses
Railway can expose long-lived destination
Child Canvas has independent spatial scene
```

**T2 不可冻结**

- exact Core entity/schema；
- 是否继承/迁移 old Workspace；
- membership table；
- back-stack persistence model。

**需要**

T6 + Coordinator。

---

# Card T2-10 · Old Workspace State Runtime

**CURRENT_STATUS**  
`WAIT_CROSS_THREAD / LEGACY_COMPAT?`

当前 Core 仍有 Workspace state/membership routes，但 current web-gen2 未发现可靠 typed consumer。

Huabu-first 已明确禁止：

```text
old workspace viewport/frameBounds
→ overwrite Huabu spatial truth
```

所以 T2 不接旧 viewport restore。

T6 需判断旧 state/membership API：

```text
CURRENT
LEGACY_COMPAT
migration substrate
retire later
```

---

# Card T2-11 · Enter Worksite

**NEW_SCENE_REF**  
`T2-W1-ENTER-WORKSITE`

**CURRENT_STATUS**  
`PATCH_UX`

Frame：

```text
A user chooses Railway long-term worksite / child portal
B destination identity pressed
C active worksite changes
D destination Surface/canvas becomes active
E initial viewport is resolved by current Gen2 spatial contract
F Railway active identity updates
G subtle Arrival feedback
```

**禁止**

- 把 Enter 实现成纯 `fitBounds`；
- 复活 old Workspace viewport overwrite；
- 中间 chooser（destination 已明确时）。

---

# Card T2-12 · Locate Target

**UX_SCENE_REF**  
`T2-I-LOCATOR-CLICK / T2-I-LOCATOR-FIT`

**CURRENT_STATUS**  
`UNCHANGED + evidence strengthened`

Gen1 已有 `locateWorkspace()` 只改 Camera 的历史差异。

Gen2：

```text
target canonical/projection
→ Huabu bounds
→ active safeRect
→ fit
→ Arrival
```

TapNow donor：

```text
padding 1
minZoom .5
maxZoom 2
duration 500ms
```

最终 production 需 distance-aware / safeRect-aware tuning，但不弹 popup。

---

# Card T2-13 · Search

**UX_SCENE_REF**  
`T2-E-SEARCH-OPEN / T2-E-SEARCH-RESULT / T2-E-SEARCH-FOCUS`

**CURRENT_STATUS**  
`UNCHANGED`

Search = 用户不知道对象在哪 / 叫什么。

Truth：Core Project Search。

Presentation 可借 TapNow keyboard navigation / direct activation。

禁止把 Huabu current-canvas search taxonomy 当 Project Search truth。

---

# Card T2-14 · Focus / Where

**UX_SCENE_REF**  
`T2-F-FOCUS-OPEN / T2-F-FOCUS-FAN`

**CURRENT_STATUS**  
`UNCHANGED / donor shape still open`

Focus = known entity → occurrences。

可以跨：

- Surface；
- long-term worksite；
- projection/location refs。

点击 occurrence：

```text
必要时 switch Surface/worksite
→ Locate
→ Arrival
```

Focus 不等于 Search mode。

---

# Card T2-15 · Search ↔ Focus Glyph

**CURRENT_STATUS**  
`PATCH_UX`

同一 screen-space family，语义不同。

正式 implementation candidate：

```text
Morphicons MIT
spring="snappy"
reducedMotion="user"
```

HTML 的 opacity SVG swap 只作为 prototype，不得成为 final implementation。

---

# Card T2-16 · Pin Locate

**UX_SCENE_REF**  
`T2-H-PIN-* / T2-J-ARRIVAL`

**CURRENT_STATUS**  
`UNCHANGED`

Pin 是 durable navigation relationship，不是 Focus/Search。

TapNow Pin trigger/local stack/filter/member-locate 当前作为主要 high-fidelity donor。

Camera owner Huabu；Core Pin truth 不变。

---

# Card T2-17 · Locator

**UX_SCENE_REF**  
`T2-I-LOCATOR-MORPH / CLICK / FIT`

**CURRENT_STATUS**  
`UNCHANGED BEHAVIOR / WAIT_VISUAL_DONOR`

Frozen behavior：

```text
inside target-local cue
→ near edge morph
→ offscreen directional cue
→ click direct camera travel
→ arrival
```

禁止 modal / confirmation。

目前没有证据足以把 Spatial / Lovart 某一造型宣称为 exact Locator donor。

HTML arrow = prototype placeholder only。

---

# Card T2-18 · Arrival

**UX_SCENE_REF**  
`T2-J-ARRIVAL`

**CURRENT_STATUS**  
`PATCH_UX`

Arrival 是 navigation completion feedback，不是独立 state owner。

优先：

```text
target rim / field pulse / subtle body highlight
```

禁止 Toast：

```text
“已定位到 xxx”
```

Arrival 要对 Locate 与 Enter 均可复用，但具体 worksite arrival identity 与 node arrival body 可以不同 visual body。

---

# Card T2-19 · Back / Return

**NEW_SCENE_REF**  
`T2-W2-BACK-WORKSITE`

**CURRENT_STATUS**  
`PATCH_OWNER + PATCH_UX`

Back 产品动作 KEEP。

旧：

```text
Scope.parentScopeId → leaveScope
```

SUPERSEDED。

新 UX：

```text
Enter child/long-term worksite
→ navigation context recorded
→ Back returns to previous parent/worksite context
→ no synthetic Scope container
```

Exact stack durability / persistence：`WAIT_CROSS_THREAD`。

---

# Card T2-20 · Work View Navigation Integration

**UX_SCENE_REF**  
`T2-M-SAFE-OPEN / HUD / FOCUS`

**CURRENT_STATUS**  
`PATCH_OWNER`

T4 owns Work View lifecycle。

T2 only consumes：

```text
occupiedRect
safeRect
open/close/resize events or public seam
```

Rules：

- open/resize ≠ Camera move；
- Railway remains；
- Spatial Navigator remains/repositions；
- Search/Focus/Pin top slot re-centers inside active safe region；
- explicit Locate/Focus uses safeRect-aware fit。

---

# Card T2-21 · Assembly Entry

**CURRENT_STATUS**  
`SUPERSEDED` old fake-node design / `PATCH_UX` correct trigger

Correct：

```text
Selection
→ Action Arc Assembly
→ same project-level Assembly Work View
→ presented FOCUS from trigger anchor
```

禁止：

- Main `AssemblyNode`；
- global top `Assembly mode` 作为普通 Surface navigation；
-复制 Assembly state。

---

# Card T2-22 · Railway Receive Map

**UX_SCENE_REF**  
`T2-C-DROP-RAIL / T2-C-DROP-NOMODAL`

**CURRENT_STATUS**  
`PATCH_UX`

Drag active：

```text
Rail REST
→ eligible destinations become explicit
→ ineligible destinations recede
→ hover Surface can reveal long-term worksite targets
→ destination unique = Drop commit
```

Huabu cross-space move mechanic 可 ADOPT；默认 chooser Modal REJECT。

Canonical membership/mutation 由目标 owner 决定，T2 不定义。

---

# Card T2-23 · Context / Workflow Temporary Region → Rail

**CURRENT_STATUS**  
`SUPERSEDED`

禁止：

```text
点 Context 时间块 → 自动 Rail item
形成 Scope → 自动 Rail item
创建 Collection → 自动 Rail item
```

只有用户明确 materialize 成 long-term worksite / child canvas 才进入 persistent Railway。

Materialization owner：T4/T6/Coordinator。

---

# Card T2-24 · Bottom Chrome Final Priority

**CURRENT_STATUS**  
`PATCH_UX`, final visual waits T5

当前证据支持：

```text
Top:
Search / Focus / Pin family

Left:
Railway

Bottom center:
Main / Context / Workflow SurfaceDock

Lower-left adjacent canvas:
Minimap / Spatial Navigator cluster

Selection-local:
Action Arc / Composer

Secondary:
Canvas editing tools
```

这是信息架构，不是最终美术尺寸。

**DO_NOT_BUILD**

不要让 Huabu donor 的默认 toolbar placement 反过来定义 LCOS 产品优先级。

---

# 25. Patch Summary

| 既有结论 | Patch |
|---|---|
| Gen1 Railway 整体退休 | SUPERSEDED：改为 KEEP/LIFT 可用资产 |
| old flat rail kinds 继续 | SUPERSEDED |
| `/view-rail-order` 已最终闭合 | WAIT_CROSS_THREAD |
| Collection = child scene | SUPERSEDED |
| Scope = nav container | SUPERSEDED |
| Enter = Locate | SUPERSEDED |
| Back = Scope parent | PATCH_OWNER / old runtime SUPERSEDED |
| T2 owns Work View lifecycle | PATCH_OWNER → T4 |
| Assembly as canvas node | SUPERSEDED |
| bottom-center belongs Huabu tools | PATCH_UX |
| SurfaceDock 三视图优先 | KEEP / MODERNIZE |
| Minimap 与 viewport controls 分散 | PATCH_UX → Spatial Navigator cluster |
| Pin / Search / Focus semantic split | UNCHANGED |
| Locator direct click | UNCHANGED |
| Railway Receive Map | PATCH_UX |

