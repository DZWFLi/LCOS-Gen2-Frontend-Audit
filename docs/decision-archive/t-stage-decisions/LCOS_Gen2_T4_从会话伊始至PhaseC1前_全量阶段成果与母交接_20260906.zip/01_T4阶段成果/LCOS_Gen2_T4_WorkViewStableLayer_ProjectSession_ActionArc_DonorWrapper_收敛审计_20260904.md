# LCOS Gen2 · T4 第四路
## WorkView Stable Presentation Layer × Project Session Owner × Action Arc / Viewport / Skill / Donor Wrapper 收敛审计

日期：2026-09-04  
源码锚点：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`  
Huabu vendor pin：`58339e269b784728d67730c70bfe7792cae2457d`  
Huabu upstream observed HEAD：`dc128fff2d37b5481ec305070a7e86d3de85f7d2`  
性质：`T4 INTERIM SOURCE-LEVEL CONVERGENCE / NOT FINAL CONSTRUCTION PLAN`

> 本文继续遵守六线程 V6 反惰性 SOP。它不是最终施工正本，也不授权直接写 patch。最终 T4 正本仍须在 Mandatory Read Completion、五轮审计、跨线程复核完成后锁定。

---

# 0. 本轮最重要的五个结论

## 0.1 WorkView actual body 不能直接条件渲染进 MainLayout.rightPanel

2026-09-04 最新冻结应拆成两层：

```text
Spatial Presentation:
SPATIAL ↔ FOCUS

Professional Work View Placement:
FLOATING ↔ DOCKED ↔ IMMERSIVE
```

并且：

```text
FLOATING → DOCKED
= same WorkViewSession
= same content owner
= same object identity
= rect morph
≠ unmount Floating + mount Docked
```

所以旧候选：

```text
LcosRightSurfaceHost
  if workView:
    <WorkViewBody />
  else:
    <PreviewWorkspacePanel />
```

会在 FLOATING / DOCKED 切换时换宿主、重挂 body，违反最新冻结。

最新结构改成：

```text
RootLayout page-area
└─ LcosProjectSessionProvider
   ├─ <Outlet />
   │   └─ CanvasPage
   │       └─ MainLayout
   │           └─ rightPanel
   │               ├─ PreviewWorkspacePanel
   │               └─ WorkViewDockSlot   # 只有占位/目标 rect
   │
   └─ WorkViewPresentationLayer
       └─ ONE stable WorkViewShell
           └─ ONE stable professional body
```

`WorkViewPresentationLayer` 才是 body 的稳定 mount owner。

`MainLayout.rightPanel` 只提供 Docked/Immersive 的布局机械、目标 rect 和 resize handle。

---

## 0.2 LCOS runtime 与 WorkView session 都是 project-session lifetime，不是 CanvasPage lifetime

当前 `useLcosCanvasProps.tsx` 已经明确写着：

```text
一个 project session 一个 createLcosRuntime()
canvas change
→ runtime.retarget({ canvasId })
→ seam identity remains stable
```

`createLcosHostRuntime.ts` 也把 `projectId` 与当前 `canvasId` 分开持有。

当前错误不是 runtime 模型，而是 React owner 挂太低：

```text
CenterArea
└─ useLcosCanvasProps()
```

MainLayout fullscreen 会卸载 CenterArea；CanvasPage 又是 route-scoped。

因此：

```text
CenterArea = TOO LOW
CanvasPage = enough only for fullscreen, STILL TOO LOW for cross-route Surface continuity
RootLayout page-area = current best lifetime anchor
```

---

## 0.3 Project identity 不能继续从 env 偷渡进新 Provider

当前 `CenterArea.tsx`：

```ts
const lcosProjectId =
  import.meta.env.PROJECT_ID
  ?? 'disposable-mvp-sample'
```

2026-09-03 Current Consumer Audit 已把它定性为：

```text
HOST_SESSION_WIRED
PRODUCT_PROJECT_OPEN_INCOMPLETE
```

所以新的 `LcosProjectSessionProvider` 不能自己读 `PROJECT_ID` 并把 interim 接线永久化成架构。

正确依赖：

```text
Project Identity Producer
    ↓ projectId
LcosProjectSessionProvider
    ↓ current Surface.canvasId
runtime.retarget()
```

Project Launcher / Project Open identity producer 属上游 Shell / Core Project 主线，不由 T4 自造。

---

## 0.4 MainLayout 不再是 NO MODIFY，但只允许极薄 controlled-width seam

当前 MainLayout：

```text
RIGHT_DEFAULT_WIDTH_PX = 420
rightWidthPx = local state
```

而 LCOS 冻结 Docked WorkView：

```text
default ≈ 45–50vw
resizable
```

如果 MainLayout 完全不改，要么 WorkView 被迫继承 420px，要么 WorkView 私存另一份 width 并绕过 MainLayout，后者会形成第二 width truth。

因此：

```text
MainLayout = MODIFY THINLY
```

增加 optional controlled right-width seam。MainLayout 继续拥有 pointer resize、clamp、slot layout、transition、fullscreen、collapse；WorkView session 只持有自己的 presentation width value。

---

## 0.5 Floating WorkView 第一刀不需要 react-rnd

当前 Huabu 已有：

```text
motion ^13.1.1
```

最新 Floating 硬需求是：

```text
drag
→ edge attraction
→ docking preview
→ release
→ rect morph into dock
```

并没有最新原文要求四边自由 resize。

因此供应顺序：

```text
Motion
→ Floating drag / rect transition

MainLayout
→ Dock resize

CanvasFloatingPopover
→ Action Arc / local anchored chrome

react-rnd
→ only fallback if future raw requirement proves Floating free-resize mandatory
```

---

# 1. FOCUS / FLOATING 最终语义

不能再用一个 enum 把两者混成同层状态。

```text
FOCUS
= world-space presentation / camera framing
= 仍属于 Spatial

FLOATING
= viewport-space professional WorkView placement
= same WorkViewSession as Docked/Immersive
```

于是：

```text
Focus may move Camera when explicitly invoked.
Open/resize/move WorkView must not move Camera.
```

从 Dock 拖回空间时：

```text
same sessionId
same target
same body
same unsaved local body state
```

---

# 2. Project / Surface / Runtime 正确物理关系

当前 `SurfaceRegistry` 已冻结：

```text
Main / Context / Workflow
= same project
= same Huabu runtime family
= distinct canvasId
= independent camera / selection / history / persistence
```

所以最终结构：

```text
Project Session
├─ ONE LCOS host runtime
│  └─ retarget(current Surface.canvasId)
├─ ONE WorkView session
└─ current Surface
   └─ one distinct Huabu canvasId
```

禁止：

```text
three runtimes
three ReactFlow roots
one canvas pretending to be three Surfaces
```

---

# 3. Runtime 现有实现 KEEP，React owner MOVE

## 3.1 KEEP

```text
apps/web-gen2/src/host/createLcosHostRuntime.ts
huabu/apps/web/src/lcos/lcosHost.ts
```

现有正确能力：

```text
create once per project session
retarget project/canvas
stable seam provider
rebuild host only on actual target/config change
dispose reconciler timer
```

不需要再写 RuntimeManager。

## 3.2 MOVE

当前：

```text
CenterArea
└─ useLcosCanvasProps(projectId)
```

目标：

```text
RootLayout page-area
└─ LcosProjectSessionProvider
   └─ owns one runtime
```

Canvas/Suface 只调用：

```text
retargetCanvas(canvasId)
```

---

# 4. RootLayout 是现成的正确生命周期 anchor

`App.tsx` 当前明确把 RootLayout 定义为 data-router never-unmounting root，而 CanvasPage 是 route-scoped。

页面区现有：

```tsx
<div className="relative min-h-0 flex-1">
  <Outlet />
</div>
```

建议：

```tsx
<div className="relative min-h-0 flex-1">
  <LcosProjectSessionProvider>
    <Outlet />
    <WorkViewPresentationLayer />
  </LcosProjectSessionProvider>
</div>
```

优势：

- 不盖 WindowChrome；
- 不随 CanvasPage / Surface route 卸载；
- GlobalModals 仍在更高 app shell；
- WorkView body 可稳定挂载；
- 不需要先改成复杂 nested router。

---

# 5. Provider 只拥有 project-session presentation/runtime state

候选：

```ts
interface LcosProjectSessionValue {
  readonly projectId: string | null
  readonly canvasId: string | null
  readonly hostExtension?: CanvasHostExtension
  readonly workView: WorkViewSession | null

  activateProject(input: { projectId: string; canvasId?: string }): void
  retargetCanvas(canvasId: string): void

  openWorkView(request: OpenWorkViewRequest): void
  closeWorkView(): void
  setWorkViewBasePlacement(kind: 'floating' | 'docked'): void
  setWorkViewDockWidthPx(width: number): void
}
```

禁止进入 Provider：

```text
ProjectGraph
Artifact body
Run truth
Skill package truth
Warehouse cache
Context snapshot history
Surface camera
Surface selection
Canvas geometry
```

它是 session owner，不是新的 Core。

---

# 6. Project identity 是硬 cross-thread dependency

当前 `PROJECT_ID` env 只能当 migration bridge。

T4 final production wiring 需要上游提供：

```text
Project Launcher / Project Open
→ canonical projectId
→ ProjectSessionProvider.activateProject(projectId)
```

T4 不新增：

```text
ProjectManager
ProjectRouter
ProjectStore
```

如果协调者允许先保留 env bridge，也必须标 `INTERIM`，不能成为 provider API 的 truth source。

---

# 7. WorkViewSession 最小模型 v3

```ts
type WorkViewBasePlacement = 'floating' | 'docked'

interface WorkViewSession {
  readonly sessionId: string
  readonly projectId: string
  readonly target: WorkViewTarget
  readonly projection: WorkViewProjection

  readonly origin: {
    readonly surface: SurfaceKeyName
    readonly canvasId: string
    readonly nodeId?: string
  }

  readonly basePlacement: WorkViewBasePlacement
  readonly dockWidthPx?: number
  readonly floatingRect?: ScreenRect
  readonly sourceScreenRect?: ScreenRect
}
```

不存：

```text
camera
selection
artifact body
run events truth
skill content truth
generic rendererState: unknown
```

---

# 8. IMMERSIVE 不复制 boolean

现有 `panelStore` 已有：

```text
isPreviewFullscreen
setPreviewFullscreen
togglePreviewFullscreen
```

WorkView active 时：

```text
isImmersive = panelStore.isPreviewFullscreen
```

所以 session 只保存：

```text
basePlacement = floating | docked
```

退出 fullscreen：

```text
base=floating → floating
base=docked   → docked
```

避免 `workView.isImmersive` 与 `panelStore.isPreviewFullscreen` 双 truth。

---

# 9. WorkView 不存 Camera

恢复只存 identity：

```text
origin.surface
origin.canvasId
origin.nodeId?
```

关闭 WorkView：

```text
retarget/navigate origin surface if needed
→ existing canvas identity restores its own camera
→ optional explicit Focus/Locator to origin node
```

WorkView 不复制 viewport。

---

# 10. WorkView target 复用 canonical IDs

禁止创造不存在的：

```text
WorkflowId
ContextVersionId
AssemblyWorkspaceId
SkillBindingId
```

Workflow 当前 domain 是：

```text
Scope.kind === 'workflow'
scopeId
```

Context 同理使用 Scope / ContextSnapshot 等现有 identity。

候选 target：

```ts
type WorkViewTarget =
  | { kind: 'entity'; ref: CoreEntityRefLoose }
  | { kind: 'scope'; scopeId: string; scopeKind: 'context' | 'workflow' | 'collection' }
  | { kind: 'run'; runId: string }
  | { kind: 'skill'; skillId: string; version?: string }
  | { kind: 'assembly'; target: AssemblyTargetRefV1 }
  | { kind: 'project-assembly'; projectId: string }
```

最终可继续收窄，绝不为了 UI 方便扩成比 canonical contract 更宽的第二 domain。

---

# 11. Target 与 Projection 必须分开

同一个 Context target：

```text
Structure
Evolution
Relationship
Provenance
```

同一个 Skill target：

```text
Outline
Mind Map
```

所以：

```text
target identity != current professional body
```

`projection` 是 presentation choice，不是新 entity。

---

# 12. Stable WorkViewPresentationLayer

建议新增：

```text
huabu/apps/web/src/lcos/workview/WorkViewPresentationLayer.tsx
```

职责：

```text
read one WorkViewSession
resolve current body
keep body mounted across placement changes
measure page-area bounds
observe DockSlot rect
own Floating drag / rect morph
```

不负责：

```text
Core truth
right resize mechanics
fullscreen truth
camera
```

---

# 13. WorkViewDockSlot

建议新增：

```text
huabu/apps/web/src/lcos/workview/WorkViewDockSlot.tsx
```

它不是 body。

只做：

```text
inert right-slot occupant
DOMRect measurement
publish dockTargetRect
```

这样：

```text
WorkView body always in stable layer
MainLayout only creates desired geometry
```

---

# 14. LcosRightSurfaceHost 最新职责

如果保留：

```text
right-slot mux only
```

候选：

```tsx
if WorkView needs right/fullscreen destination:
  return <WorkViewDockSlot />
else:
  return <PreviewWorkspacePanel />
```

它不渲染 WorkViewBody。

---

# 15. MainLayout controlled width seam

当前：

```ts
const [rightWidthPx, setRightWidthPx] = useState(420)
```

建议：

```ts
interface MainLayoutProps {
  ...
  rightPanelWidthPx?: number
  onRightPanelWidthChange?: (widthPx: number) => void
}
```

内部：

```text
uncontrolled Preview
→ existing local 420px

controlled WorkView Dock
→ width from session
→ pointer resize uses existing clamp
→ emits onRightPanelWidthChange
```

不改 Camera。

---

# 16. 为什么 WorkView dockWidth 不塞 panelStore

`panelStore.isRightCollapsed` 是 generic right panel preference。

`WorkView dockWidthPx` 是 project-session professional presentation state。

如果塞 panelStore，会变成 app-global right width preference，语义错误。

所以：

```text
MainLayout = mechanical width owner
WorkViewSession = WorkView-specific controlled value
```

---

# 17. 默认 Dock 宽度

最新冻结：

```text
~45–50vw
```

建议 first open 以 page-area 当前尺寸计算约 48%，再经过 MainLayout existing constraints。

不把 420px 作为 WorkView 默认。

跨 app restart 是否记忆 width 暂不进入第一阶段，除非上游 Project UI persistence freeze明确要求。

---

# 18. Current MainLayout Camera path 是安全的

当前 right resize 没有 `setViewport()`。

因此旧 WorkRail：

```text
panel changes → move Camera
```

不是 current MainLayout mechanics。

验收仍要证明：

```text
open / resize / dock / undock / immersive
→ viewport transform unchanged
```

但不预先写 Camera patch。

---

# 19. occupiedRect 仍交 T1，不造 safeRegion2

T4 可产生：

```text
DockSlot DOMRect
Floating WorkView DOMRect
```

T1 负责把它们接到 current：

```text
active spatial viewport
Focus fit
HUD
Pin
Minimap
edge navigation
```

当前 c2ff 未找到历史同名 `activeSpatialViewport / safeInsets / spatialOverlayEnvironment`，所以 T4 不能自建新 owner。

---

# 20. Action Arc current owner 与 physical slot

当前：

```text
apps/web-gen2/src/interaction/overlayArbitration.ts
```

已经有：

```text
action-arc
work-view
composer
```

但：

```text
LcosHostOverlay.tsx
→ actionArcOpen:false
→ workViewOpen:false
```

即：

```text
SEMANTIC POLICY EXISTS
PRODUCTION STATE CONSUMER MISSING
```

物理挂点：

```text
NodeWrapper.overlayContent
```

因此：

```text
T3/T5 → Action Arc visual consumer
T4    → openWorkView(target, projection)
```

T4 不改 NodeWrapper / NodeFloatingToolbar。

---

# 21. CanvasFloatingPopover 的正确定位

当前组件已成熟解决：

```text
flow-space → screen-space
portal
flip/shift
canvas boundary
ResizeObserver
modal arbitration
surface attention
```

适合：

```text
Action Arc
Compact Composer
local toolbar
```

不适合直接当：

```text
free draggable WorkView shell
```

因为它是 anchored popover。

---

# 22. Floating WorkView 复用 Motion

Huabu 已有 Motion。

建议：

```text
motion.div
useDragControls / drag handle
dragMomentum=false
```

行为：

```text
drag floating shell
→ update presentation rect
→ near right edge show docking destination
→ release
   ├─ dock threshold met → basePlacement=docked
   └─ otherwise → retain floating rect
```

同一 React body 不变。

---

# 23. WorkView motion discipline

参考冻结：

```text
SELECT ~80–120ms
FOCUS ~180–260ms
OPEN WORK ~220–280ms
```

主变化：

```text
position
scale
rect
```

opacity 仅辅助。

禁止：

```text
heavy spring overshoot
old body fade out + new body fade in
```

Restore 优先 reverse morph。

---

# 24. React key 纪律

WorkView body key 只基于：

```text
sessionId + canonical target + projection
```

不得包含：

```text
placement
dock width
fullscreen
surface
canvasId
```

否则 Placement 变化会偷偷 remount。

---

# 25. Body local state 归 body

不建：

```ts
rendererState: unknown
```

各 body 自己持有真正的 local draft：

```text
Skill Builder → markdown/map draft
Assembly → filter/current source
Context → selected checkpoints/nodes
Run Review → mostly canonical read
```

Placement 变化因为 body 不卸载，自然连续。

---

# 26. Context Structure / react-arborist 修正

当前候选：

```text
react-arborist 3.16.0
```

第一阶段：

```text
disableDrag=true
disableDrop=true
```

但这不代表 react-dnd backend 一定不会初始化。历史 issue 已出现“disabled drag/drop 仍遇到 two HTML5 backends”。

当前 Huabu 没有 react-dnd，只用 dnd-kit，所以风险可控。

纪律：

```text
one active Arborist body
inactive tree unmount
if multiple Arborist retained later → shared dndManager
```

禁止因此退回自造 tree engine。

---

# 27. Context Evolution / vis-timeline

候选：

```text
vis-timeline 8.5.4
```

第一阶段：

```text
editable=false
```

canonical mutations：

```text
ContextSnapshot create
compare
branch
```

不允许拖 timeline item 改历史。

wrapper：

```text
contextEvolutionProjection.ts
ContextEvolutionBody.tsx
local CSS import/override
instance.destroy()
```

---

# 28. Context Relationship / Cytoscape

候选：

```text
Cytoscape 3.34.2
```

Truth：

```text
CoreRelationClient
```

第一阶段建议：

```text
autoungrabify(true)
```

避免 Relationship Lens 变成第二空间编辑器。

关键 runtime：

```text
ResizeObserver(container)
→ cy.resize()
```

因为 WorkView dock resize / morph 并不保证 window resize。

unmount：

```text
cy.destroy()
```

---

# 29. Mind Elixir stable pin

当前 npm `latest` 指向 prerelease：

```text
6.0.0-next.4
```

稳定 5.x 当前：

```text
5.15.1
```

T4 推荐：

```text
mind-elixir@5.15.1
```

不要 `latest`。

---

# 30. Mind Elixir sealed interaction island

Skill Mind Map 是可编辑 instrument，wrapper 必须显式处理：

```text
editable
draggable
keypress
handleWheel
selectionContainer
contextMenu
toolBar
```

浏览器 proof：

```text
wheel inside mindmap != Canvas zoom
drag mindmap node != Canvas node drag
keyboard edit != Canvas shortcut
context menu != Canvas context action
Escape first resolves donor-local editor/menu
```

cleanup 用正式：

```text
destroy()
```

---

# 31. react-virtuoso 已经在 Huabu

当前：

```text
react-virtuoso ^4.18.7
```

无需新增依赖。

直接用于：

```text
Assembly source list
Run events/logs
Provenance
large Skill catalog
```

---

# 32. Skill → Assembly current truth 与最新产品 gap

当前 c2ff：

```text
AssemblyApplyService
skill → unsupported
```

历史 8/30 diff 曾尝试：

```text
skill → PresentationEntityRef → presentation membership
```

但历史 diff 不能覆盖 current source。

最新产品总账又明确要求：

```text
same Skill
→ Workflow Step
→ Composer
→ Glyth
→ ordinary capability target
same skillId/version
no package copy
```

所以 current unsupported 是：

```text
REAL PRODUCT GAP
```

不是 future nice-to-have。

---

# 33. T4 对 Skill gap 的边界

T4 可完成：

```text
Assembly Skills catalog
CoreSkillClient
Skill SourceRef drag intent
```

但 canonical usage binding 未落地前：

```text
NO fake success
NO local-only binding
NO frontend SkillBinding model
```

T6/Core 必须裁四类 target 的真实 persisted semantics。

---

# 34. Typed Clients 继续 small-client 模式

新增：

```text
CoreAssemblyClient
CoreRunClient
CoreContextClient
CoreSkillClient
CoreWorkflowClient
```

不塞进：

```text
Gen2Host
```

Provider 可以共享 transport/config，但 body 仍消费 typed client，而不是 arbitrary HttpClient request。

Workflow multipart gap 继续成立：HttpClient 需极薄 raw/FormData seam。

---

# 35. ExactFile 动作表 v4

## MODIFY · HIGH CONFIDENCE

```text
huabu/apps/web/src/App.tsx
```

- RootLayout page-area 挂 ProjectSessionProvider；
- 挂 stable WorkViewPresentationLayer。

```text
huabu/apps/web/src/pages/CanvasPage/CenterArea.tsx
```

- 删除 `PROJECT_ID` + `useLcosCanvasProps` owner；
- 消费 stable hostExtension。

```text
huabu/apps/web/src/pages/CanvasPage/CanvasPage.tsx
```

- 当前 canvas ready → session retarget；
- right panel 使用 mux/slot；
- 不拥有 WorkView body。

```text
huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
```

- optional controlled right width；
- resize callback；
- 保留现有 fullscreen/collapse/resize mechanics。

```text
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
```

- `workViewOpen` 接真实 session；
- `actionArcOpen` producer 由 T3/T5 对接。

```text
apps/web-gen2/src/backend/client.ts
apps/web-gen2/src/index.ts
apps/web-gen2/test/core-clients.test.ts
```

- multipart/raw body；
- small client exports；
- exact route tests。

---

## ADD · HIGH CONFIDENCE

```text
huabu/apps/web/src/lcos/session/LcosProjectSessionProvider.tsx
huabu/apps/web/src/lcos/workview/workViewModel.ts
huabu/apps/web/src/lcos/workview/WorkViewPresentationLayer.tsx
huabu/apps/web/src/lcos/workview/WorkViewDockSlot.tsx
huabu/apps/web/src/lcos/LcosRightSurfaceHost.tsx
```

注意：

```text
LcosRightSurfaceHost = right-slot mux only
```

---

## ADD · TYPED CLIENTS

```text
apps/web-gen2/src/backend/assembly.ts
apps/web-gen2/src/backend/runs.ts
apps/web-gen2/src/backend/context.ts
apps/web-gen2/src/backend/skills.ts
apps/web-gen2/src/backend/workflow.ts
```

---

## ADD · PROFESSIONAL BODY CANDIDATES

```text
apps/web-gen2/src/presentation/contextStructureProjection.ts
apps/web-gen2/src/presentation/contextEvolutionProjection.ts
apps/web-gen2/src/presentation/contextRelationshipProjection.ts
apps/web-gen2/src/presentation/skillBuilderProjection.ts

huabu/apps/web/src/lcos/context/ContextWorkViewBody.tsx
huabu/apps/web/src/lcos/context/ContextStructureBody.tsx
huabu/apps/web/src/lcos/context/ContextEvolutionBody.tsx
huabu/apps/web/src/lcos/context/ContextRelationshipBody.tsx
huabu/apps/web/src/lcos/context/ContextProvenanceBody.tsx

huabu/apps/web/src/lcos/skill/SkillBuilderWorkViewBody.tsx
huabu/apps/web/src/lcos/skill/SkillOutlineBody.tsx
huabu/apps/web/src/lcos/skill/SkillMindMapBody.tsx

huabu/apps/web/src/lcos/run/RunReviewWorkViewBody.tsx
huabu/apps/web/src/lcos/assembly/AssemblyWorkViewBody.tsx
```

CSS 文件只在 donor 确实需要时新增，不为了目录对称凑数。

---

# 36. RETIRE / SUPERSEDE 旧规划项

最终正本不应继续：

```text
global WorkView Zustand
WorkViewDock.tsx geometry owner
WorkViewImmersive.tsx fullscreen owner
WorkViewFocusLayer.tsx
WorkViewRendererRegistry mega registry
safeRegion.ts new truth
WorkView camera restore
ExpandedNodePanel as WorkView host
PreviewWorkspace store as WorkView owner
LcosRightSurfaceHost directly owning WorkView body
CanvasPage as final project-session lifetime owner
MainLayout = NO MODIFY
CanvasFloatingPopover as free WorkView window
react-rnd as default first dependency
```

---

# 37. KEEP / ADOPT

```text
createLcosHostRuntime
runtime.retarget
stable host seam
ProjectionBinding
SurfaceRegistry
MainLayout resize mechanics
MainLayout fullscreen mechanics
panelStore fullscreen/collapse
canvasStore camera restore
CanvasFloatingPopover for local overlays
NodeWrapper overlayContent
overlayArbitration
Motion
react-virtuoso
Core ContextSnapshot
Core RunReview
Core Assembly
Core SkillPackage
```

---

# 38. Browser proof matrix

## Project Session

```text
open project
→ runtime created once

main → context → workflow
→ same project runtime
→ canvasId retarget
→ no second seam

project change
→ old runtime dispose
→ new runtime
```

## Immersive

```text
Docked WorkView
→ Immersive
→ CenterArea may unmount
→ project runtime remains
→ WorkView body remains
→ ProjectionBinding/reference continuity
→ exit immersive returns same base placement
```

## Floating → Docked

```text
open floating
edit local draft
drag to right edge
see docking target
release
same React body identity
draft unchanged
right width becomes WorkView width
camera unchanged
```

## Docked → Floating

```text
drag out
DockSlot releases
PreviewWorkspace resumes previous state
same WorkView body remains
camera unchanged
```

## Surface switch

```text
WorkView open
Main → Context → Workflow
sessionId unchanged
target unchanged
runtime canvas retarget
surface cameras remain independent
```

## Arborist

```text
single active backend
Canvas dnd-kit unaffected
no HTML5 backend conflict
```

## Cytoscape

```text
dock resize/morph
→ ResizeObserver
→ cy.resize()
```

## Mind Elixir

```text
5.15.1 stable
wheel/drag/keyboard isolated
destroy on projection unmount
```

---

# 39. Cross-thread dependency matrix

## T4 → T1

Need current exact owner for：

```text
occupiedRect aggregation
active spatial viewport
Focus fit
HUD/Pin/Minimap/edge navigation
```

T4 提供：

```text
DockSlot rect
Floating WorkView rect
```

不自己 aggregate。

## T4 → T3/T5

T4 提供：

```text
openWorkView()
workViewOpen
```

T3/T5 提供：

```text
Action Arc visual consumer
NodeWrapper overlayContent adoption
Open action
```

## T4 → T6 / Shell

Need：

```text
product Project identity producer
Project Launcher → projectId
SurfaceRegistry real consumer
Skill usage binding semantics
```

---

# 40. 为什么还不能宣布 FINAL

仍有：

```text
Mandatory File Library Completion Table 未正式闭合
16 ZIP exact entries 最终 Census 仍需逐项 FULL_READ 记账
T1 current activeSpatialViewport owner 未锁
T6 Skill canonical usage binding 未锁
Project identity product producer 仍 RED-01
```

因此：

```text
T4 SOURCE-LEVEL PREPLAN = STRONGLY CONVERGED
T4 FINAL CONSTRUCTION PLAN = NOT YET AUTHORIZED
```

---

# 41. 当前最小架构图

```text
Core Project Truth
        │
        ├──── small typed clients ───────────┐
        │                                    │
Project Identity Producer                    │
        │ projectId                          │
        ▼                                    │
LcosProjectSessionProvider                   │
        │                                    │
        ├─ ONE LcosHostRuntime               │
        │    └─ retarget(surface.canvasId)   │
        │                                    │
        ├─ ONE WorkViewSession               │
        │    ├─ canonical target             │
        │    ├─ projection                   │
        │    ├─ basePlacement                │
        │    └─ dock/floating presentation   │
        │                                    │
        ├─ Outlet                            │
        │   └─ CanvasPage                    │
        │       └─ MainLayout                │
        │           └─ right slot            │
        │              ├─ PreviewWorkspace   │
        │              └─ WorkViewDockSlot   │
        │                                    │
        └─ WorkViewPresentationLayer         │
             └─ stable WorkView body ◄───────┘
```

Spatial truth：Huabu。  
Domain truth：Local Core。  
WorkView：project UI presentation/session only。

---

# 42. 本轮最终裁决

第四路现在不再建议“做一个 WorkView 框架”。

而是：

```text
把已经正确存在的 project runtime owner
提到正确生命周期；

把 WorkView body 稳定挂一次；

让 MainLayout 继续只做 dock geometry；

用已经安装的 Motion 做 Floating/rect morph；

把专业 donor 做成 replaceable body；

所有 canonical mutation 继续回 Core。
```

这才是 Gen2 的模块化复用：不是多一层抽象，而是每个成熟模块只负责它已经很擅长的那一小块。

---

# 43. 下一轮继续项

```text
1. ProjectSessionProvider ↔ Project Identity 主线 exact handoff
2. SurfaceRegistry real consumer / route transition wiring
3. MainLayout controlled-width compatibility tests exact list
4. WorkView DockSlot rect / Motion transition API spike-level plan
5. Assembly Source Bay category/target adapter exact table
6. Skill usage binding cross-T6 verdict
7. T1 occupiedRect consumer exact file
8. Mandatory Read Completion Table refresh
9. Final five-round audit ledger consolidation
```

---

# 44. T1 occupiedRect 交界已从“未知”升级为“有成熟旧实现可 LIFT”

File Library 已恢复完整 A25 pure geometry donor：

```text
apps/web/src/features/spatial/activeSpatialViewport.ts
apps/web/src/features/spatial/useObservedActiveSpatialViewport.ts
```

它们来自 Gen1/旧前端施工链，不是 c2ff 当前 Gen2 production owner，因此分类必须是：

```text
GEN1 / PRIOR-FRONTEND DONOR
LIFT PURE BEHAVIOR
NOT CURRENT GEN2 OWNER
```

但它已经解决了 T4 不应该重做的核心问题。

Canonical chain：

```text
physical viewport
+ static shell insets
+ persistent edge occupants
→ resolveActiveSpatialViewport()
→ ActiveSpatialViewportProvider
→ consumer-local projections
```

纯 resolver：

- 无 Camera input；
- 无 Camera setter；
- 无 WorkView component name；
- deterministic；
- 输出 active rect / insets / top-center / edge bounds。

这正是 T1 应迁入 Gen2 的成熟 donor，而不是 T4 再建 `safeRegion.ts`。

---

# 45. WorkView occupiedRect exact DOM contract 已恢复

旧实现已经冻结 generic attribute：

```html
data-spatial-viewport-occupant="left|right|top|bottom"
```

observer 只查询：

```text
[data-spatial-viewport-occupant]
```

不允许：

```text
querySelector('.work-view')
querySelector('[data-work-view]')
querySelector('[data-testid="work-rail"]')
```

因此 T4 Docked WorkView 的 exact admission 应是：

```tsx
<div
  data-spatial-viewport-occupant="right"
  ...
/>
```

最自然的发布位置：

```text
WorkViewDockSlot
```

因为 DockSlot 的实际 DOM rect 就是持久占据的右边区域。

---

# 46. Floating WorkView 不应缩 active spatial viewport

A25 pure owner 已有重要规则：

```text
persistent edge occupant
→ may shrink active spatial viewport

floating center rectangle
→ ignored for active viewport shrink
→ may still be overlay collision obstacle
```

所以：

```text
Docked WorkView
→ data-spatial-viewport-occupant="right"

Floating WorkView
→ DO NOT publish persistent edge occupant
```

Floating 只进入 overlay collision/attention 体系。

这解决了一个潜在错误：不能因为一个浮动窗靠近画布中央，就把整个 Canvas safe center 永久推到另一边。

---

# 47. T1/T4 Exact handoff 更新

T4：

```text
WorkViewDockSlot
→ publish data-spatial-viewport-occupant="right"
→ DOM rect follows MainLayout controlled width
```

T1：

```text
LIFT prior activeSpatialViewport.ts
LIFT useObservedActiveSpatialViewport.ts behavior
ADAPT to Gen2/Huabu current page-area + Surface roots
migrate current Focus/HUD/Minimap/edge consumers
```

T4 不负责：

```text
ActiveSpatialViewportProvider
Focus fitting
Minimap projection
edgeScrollDelta
HUD top-center arbitration
```

---

# 48. 旧 A25 browser proof 可直接成为 Gen2 验收 donor

旧验收已有一个非常有价值的 fixture：

```text
beforeCamera = cameraSnapshot()
add fixed 360px right occupant:
  data-spatial-viewport-occupant="right"
expect centered spatial index anchor moves left
expect cameraSnapshot unchanged
```

Gen2 WorkView browser test 不必重新发明验收思想。

应迁成：

```text
open real Docked WorkView
resize to e.g. 360px / 48vw
→ active safe anchor changes
→ explicit Focus uses safe center
→ Camera does not change merely because dock opened/resized
```

这属于：

```text
LIFT TEST INTENT
```

不是复制旧 UI 壳。

---

# 49. T1 blocker 状态更新

此前：

```text
activeSpatialViewport exact current owner = UNRESOLVED
```

现在更精确：

```text
Gen2 current production owner = MISSING / NOT MIGRATED UNDER CURRENT TREE
Prior mature pure owner = FOUND_FULL / REUSABLE DONOR
Generic occupancy contract = FOUND_FULL
```

因此最终 Construction Matrix 应写：

```text
T1 migration required
not T4 invention required
```

这已经不再阻止 T4 定义 WorkView DockSlot contract，只阻止“宣称整条 safe-region production chain 已完成”。
