# LCOS Gen2 · T3 第三路正式施工规划
## 05_Acceptance_Recovery_CrossReview_Plan
### Local Object Interaction / Action Arc / Compact Composer / Reference / Voice

> 日期：2026-09-04  
> 目的：定义什么才算 T3 真正完成，以及失败、切换、取消、跨线程情况下怎样不破坏 canonical truth。  
> 原则：**验收真实用户路径，不验收“代码有组件”；恢复归 owner，不让 UI reset 冒充 rollback。**

---

# 0. Done Definition

T3 完成必须同时满足：

```text
A. Gesture causality
B. Selection / Reference / Relation separation
C. Action Arc local + minimal
D. Compact Composer target-local
E. Draft continuity
F. Reference Pick
G. Right-click management
H. Voice editable / explicit send
I. Run canonical client
J. Semantic Drop concrete destination
K. Glyth semantics not crossed
L. WorkView/takeover/safe rect interoperability
M. Donor replaceability
N. Browser visual quality
```

任何一项缺失：

```text
不标 Done
```

---

# 1. Acceptance Levels

## L0 Type/Unit

验证 pure semantics、state、adapter。

## L1 Component

React interaction、focus、popover、button。

## L2 Canvas Integration

真实 Huabu pointer + ReactFlow。

## L3 Browser E2E

Chromium/目标桌面浏览器真实手势。

## L4 Cross-thread integration

T1/T2/T4/T6 state/contract。

## L5 Visual/manual measurement

不是“看着行”，而是记录实际位置、遮挡、focus、motion、safe rect。

不新增永久 visual golden gate。

---

# 2. Pointer Acceptance

## P-01 First click

Given：

```text
unselected content node
```

When：

```text
single stable left click
```

Then：

```text
Huabu Selection includes node
Arc hidden
Composer hidden
Reference unchanged
Core unchanged
```

---

# 3. Selected re-click

Given：

```text
node already selected
```

When：

```text
same node stable click
```

Then：

```text
local affordance appears
```

And：

```text
Selection unchanged
Core unchanged
```

## Failure

若第一 click也开 Arc：

recognizer读取 selection timing错误。

检查：

```text
wasSelectedAtDown
```

而不是 pointerup当前 selected。

---

# 4. Re-click drag cancellation

Given：

already selected。

When：

```text
pointerdown
move > shared drag threshold
pointerup
```

Then：

```text
Huabu drag
no Arc reveal
```

同时：

```text
node位置按 Huabu更新
```

不能因为 T3 observer阻止 drag。

---

# 5. Threshold cross-check

至少测试：

```text
mouse
pen policy if enabled
touch remains native/no T3 claim
```

Reference与selected-reclick必须用同一 Huabu threshold source。

不测试 literal 4px。

---

# 6. Pointer ownership introspection

PointerRouter unit test：

在 selected-reclick observer active 时：

```text
ownerOf(pointerId)
```

仍是原 Huabu owner或 null。

observer不抢 ownership。

---

# 7. Functional controls

点击 node内部：

```text
button
input
textarea
contenteditable
link
```

不得触发 selected-reclick Arc。

---

# 8. Editing phase

Given：

NodeWrapper phase=editing。

Then：

```text
generic Arc suppressed
generic Composer suppressed
```

编辑器自己专属 AI action除外，但必须是 editor owner。

---

# 9. Multi selection

Given：

Shift selected A/B。

Then：

```text
Huabu MultiSelectToolbar正常
single-target Arc hidden
single-target Composer hidden
Reference不自动变[A,B]
```

---

# 10. Reference modifier

Ctrl/Cmd click bound node：

```text
toggle ordered Reference
Selection unchanged
```

Shift click：

```text
Selection
Reference unchanged
```

Ctrl/Cmd+Shift：

按 frozen grammar Shift优先或当前 pointerIntent定义精确测试。

不允许两个都 mutate。

---

# 11. Reference identity fail-close

Given：

native Huabu node没有 ProjectionBinding。

Ctrl/Cmd click：

```text
Reference unchanged
```

不生成：

```text
note:<nodeId>
```

---

# 12. Reference order

Pick：

```text
B
C
A
```

Run payload：

```text
B,C,A
```

删除 C：

```text
B,A
```

重新加 C：

```text
B,A,C
```

不能 Set排序。

---

# 13. Explicit Reference Pick

流程：

```text
Open Composer(A)
click Add Reference
mode=composer-pick
click B
click C
Esc
```

Then：

```text
Composer仍 target A
refs B,C
Selection原状
pick mode idle
```

---

# 14. Reference Pick drag

Pick mode active。

在 B body上 pointerdown并拖超过 threshold：

根据最终 grammar：

应取消 pick，不在 pointerup添加。

不得因为 pick mode抢 drag。

如果 frozen产品明确 Pick mode禁止 drag，则需要更晚权威；当前默认沿现有 Reference slop纪律。

---

# 15. Reference Pick unbound

unbound native node：

```text
pass/fail-close
```

UI最好不给 eligible feedback。

---

# 16. Action Arc content

普通 content target：

```text
3–5 actions max
```

低频管理操作不占 Arc。

若 resolver返回 >5：

unit test fail。

---

# 17. Action Arc position

Browser测：

```text
target center
target top edge
bottom edge
left/right edge
zoom min
zoom max
```

Arc：

- 跟 target；
- 不被 canvas overflow裁；
- 不盖相邻 WorkView/panel；
- 通过 FloatingUI flip/shift；
- screen-space button可点。

---

# 18. Arc while dragging

开始 drag：

```text
Arc hidden/suppressed
```

结束后：

不自动重新弹，除非产品定义。

推荐用户需再次 stable click。

避免拖完对象工具突然冒出来。

---

# 19. Arc takeover

node body takeover/collapse：

Arc anchor应：

```text
takeover mark
```

不是 invisible original bbox。

---

# 20. Arc action dispatch

每个 action：

```text
descriptor
→ correct owner
```

例如：

```text
Add Reference
→ ComposerDraft/referenceController

Relation
→ Core Relation

Pin
→ T2/Core Pin owner

Assembly
→ T4

Open
→ Huabu/T4 target open
```

不允许一个 action callback直接改多个 truth，除非正式 Core transaction定义。

---

# 21. More / context menu

Arc More：

可打开同 management menu。

右键：

直接 context menu。

两者 action list来自同 resolver管理集。

---

# 22. Context menu native editor

右键 textarea/contenteditable：

```text
LCOS menu不出现
```

浏览器/编辑器 native menu保持。

---

# 23. Context menu node

右键 content node：

- point正确；
- action适配；
- Escape关闭；
- outside pointer关闭；
- 打开时 Arc不并存；
- 关闭不改 Selection。

---

# 24. Context menu blank

如果 latest product不定义 blank menu：

```text
no LCOS menu
```

仍 suppress native canvas browser menu按 Huabu policy。

若后续 T2定义 blank commands，由对应 authority注入。

T3不自行塞 Create/Zoom菜单。

---

# 25. Double-click stock content

Expandable native content：

```text
Huabu Preview behavior保持
```

T3不拦。

---

# 26. Double-click LCOS species

只有实现 activation seam后测试。

Given Glyth-specific target：

```text
host returns handled
```

Then stock Preview不重复触发。

Given普通 node：

```text
native
```

stock继续。

---

# 27. Composer reveal

打开 Compose action：

```text
mode=Composer(target)
```

Composer anchor target。

不 fixed screen bottom。

---

# 28. Composer no autofocus

Pointer-based reveal：

```text
activeElement不变
```

用户点击 textarea后才 focus。

Keyboard explicit Compose若最终支持：

可另测 autofocus。

---

# 29. Composer textarea

必须：

- IME中文输入；
- Shift+Enter换行；
- Enter submit；
- max lines；
- overflow scroll；
- selection/cursor不触发 canvas。

---

# 30. Composer draft body replacement

Unit：

mount body A：

```text
prompt hello
refs A,B
```

unmount。

mount body B读取同 store：

```text
hello
A,B
```

证明 draft不属于 UI body。

---

# 31. Composer target switch

这里必须按产品语义明确。

推荐安全测试：

若当前 draft非空，点击另 target不应静默把同一 prompt target换掉。

具体是：

```text
retain old draft?
prompt confirm?
new draft?
```

最新原文若无明确，需要单独裁决。

当前标：

```text
OPEN_MICRO_POLICY
```

施工 owner必须让这个 policy可实现，不能把 target写死在 component props无生命周期。

---

# 32. Composer target deleted

target projection delete：

- local affordance关闭；
- draft如何处理取决于 Core target是否仍存在。

至少不能继续 submit一个不可解析 target。

Reference删除规则沿现有。

---

# 33. WorkView continuity

Given：

```text
target A
prompt hello
refs B,C
```

Open WorkView：

```text
Composer body suppressed
```

Close：

```text
prompt/refs/target still same
```

---

# 34. Project switch

Project change：

current runtime dispose/recreate。

T3 transient state必须 reset：

```text
local affordance closed
Reference index reset
Composer draft reset or explicit migration
voice recording disposed
drop canceled
```

不能把 Project A nodeId带到 Project B。

---

# 35. Canvas retarget within session

useLcosCanvasProps retarget后：

ProjectionBinding resync。

需要测试 Composer target若当前 target在新 canvas无 projection：

- target state如何关闭/保留 Core ref。

默认 presentation关闭更安全。

draft canonical target若是 CoreEntityRef可保留需产品确认。

---

# 36. Voice permission denied

Mock：

```text
getUserMedia → NotAllowedError
```

Then：

```text
local error
voiceStatus idle
prompt intact
refs intact
target intact
```

Tracks none。

---

# 37. Voice no microphone

`NotFoundError`

同上。

---

# 38. Voice recording lifecycle

Start：

```text
one active MediaStream
one AudioContext
rAF running
```

Cancel/unmount：

```text
tracks stopped
AudioContext closed
rAF canceled
```

Memory leak test。

---

# 39. Voice MIME

模拟：

```text
webm opus supported
only webm
only mp4
none preferred
```

Blob content type合理。

不硬假定 Chrome唯一格式。

---

# 40. Voice transcription request

FormData：

```text
audio file
optional hints
```

Network inspector/test：

请求头不能手写：

```text
multipart/form-data
```

缺 boundary。

浏览器应设置 boundary。

---

# 41. Voice transcription success

Core返回：

```text
text
```

Then：

```text
voiceStatus idle
text enters editable prompt
no run created
```

---

# 42. Voice + existing prompt

这是 open micro policy。

在正式裁决前单测只保证：

```text
不会静默清掉既有文字
```

哪怕临时选择 append，也必须显式实现并后续可改。

---

# 43. Voice transcription fail

502/503：

```text
prompt intact
refs intact
target intact
error local
```

是否保留 audio Blob用于 Retry：

若未实现，不显示“Retry transcription”假按钮。

---

# 44. Voice abort

Composer close/project switch：

Abort request。

recorder resources清理。

不自动 restart。

---

# 45. Run payload

Mock Core捕获：

```text
instruction
outputIntent
target...
orderedReferences
receiverRef
skill/provider
```

必须全部来自明确 owner。

---

# 46. Run Reference mapping fail-close

如果 Composer ref无法映射到正式 Run `orderedReferences` union：

```text
submit blocked/local error
```

不丢那一项后继续悄悄发。

Current Core route里已有 server flatMap过滤风险，前端更应在 client前 fail-close，避免用户明明加了 Reference但后端静默忽略。

---

# 47. Run accepted

POST 201后：

按最终产品 policy清/roll draft。

至少：

```text
不在 response前 clear
```

---

# 48. Run 409

Then：

```text
draft remains
submitStatus failed
```

Retry由用户显式。

---

# 49. Run abort/network

同样不清 draft。

不能创建 UI fake run id。

---

# 50. Run dispatch/recover/sync

如果 T3 Composer只 create不负责后续 dispatch：

明确 owner交 T6。

如果按 Core current flow需要 immediate dispatch：

使用正式 client。

不建第二 state machine。

---

# 51. Receiver binding

Run前读取 active receiver。

如果 required但无 receiver：

UI明确提示/禁用。

不拿 last-open chat猜。

---

# 52. Receiver switch

若 Composer内允许选择 receiver：

setActiveReceiver通过 Core route。

UI selection不是单独 permanent truth。

---

# 53. Semantic Drop no payload

Recognizer observe pointer：

```text
state idle
```

完全 inert。

---

# 54. Semantic Drop acquisition

只有 source明确提供 payload：

```text
acquireDrop(payload)
```

之后 machine tracking。

recognizer不 invent payload。

---

# 55. Native external blank drop

File拖到空 canvas：

```text
Huabu native add node
```

Semantic Drop不双写。

---

# 56. Concrete semantic target

拖到 Glyth body：

```text
target resolver finds Glyth body
preview exact outcome
```

不是 left/bottom。

---

# 57. Dwell

Near edge：

仅用于 transient reveal/navigation需要时。

测试：

- 快速掠过；
- 420ms附近；
- cancel distance；
- hysteresis。

数值最终可 browser tuning。

不要把 dwell当最终 semantic intent。

---

# 58. Drop preview

Preview必须：

```text
pointer-events none
```

不会截 pointer。

文案与真实 commit一致。

---

# 59. Drop cancel pointerup outside

tracking/dwell/preview但无 valid target：

```text
idle
0 mutation
```

---

# 60. Drop Escape

active：

```text
idle
0 mutation
```

---

# 61. Drop source unmount

拖拽 source消失/route switch：

必须 cancel。

测试 teardown cleanup。

---

# 62. Drop commit once

pointerup valid target：

只有一个 commit invocation。

防 duplicate event。

现 Huabu native drop有 dedupe；LCOS semantic path也要确保 pointer router/HTML5 drop不会双触发。

不默认加数据库 unique gate，先通过 event ownership消重。

---

# 63. Drop committing network ambiguity

如果 Core返回不确定：

不能：

```text
reset idle + success UI
```

必须查询正式 mutation/transaction state或 fail/recover。

具体取决于 T6 Core API。

---

# 64. Glyth semantics

Drop body：

```text
conversation context mapping
```

Relation port：

```text
relation
```

Ctrl Reference：

```text
temporary run input
```

测试三者互不写对方 store/API。

---

# 65. Glyth body hit

Halo视觉存在时：

点击/Drop halo空白不能当 body hit。

真实 DOM/hit target必须 body。

---

# 66. Takeover mark

Collapse后：

- click identity same；
- Arc anchor mark；
- Composer anchor mark；
- Reference click能解析 same binding；
- no phantom original bbox hit。

---

# 67. Safe rect / occupied rect

WorkView dock打开：

Arc/Composer不盖 WorkView。

Floating primitive的 boundary/safe rect由 T2/T4提供。

T3验收只验证消费结果。

---

# 68. Window resize

Arc/Composer跟随：

```text
ResizeObserver/FloatingUI
```

不漂。

---

# 69. Zoom/pan

target在 camera移动后：

floating跟随。

不持久化 screen position。

---

# 70. Attention tracking

Mouse移到 portalled Arc/Composer：

canvas attention不丢。

`FLOATING_CHROME_PROPS`必须生效。

---

# 71. Visual LOD

低 zoom：

target takeover/LOD变化时：

screen control仍可读。

不随 world zoom缩小。

---

# 72. Action Arc visual acceptance

不是以 donor pixel identical为验收。

检查：

- local；
- 3–5；
- compact；
- icon清晰；
- hover；
- active；
- selected；
- no chrome clutter；
- motion因果；
- LCOS identity。

---

# 73. Composer visual acceptance

- target-local；
- compact；
- refs inline；
- 2–4 lines；
- tool row轻；
- 不像右侧 ChatPanel；
- 不像 modal；
- 不抢节点主体。

---

# 74. Right-click visual acceptance

- desktop menu density；
- shortcut alignment；
- destructive item分层；
- no giant cards；
- nested submenu only when needed。

---

# 75. Voice visual acceptance

- Mic不抢主视觉；
- Recording明显但克制；
- Transcribing状态清晰；
- error local；
- Waveform不做娱乐性大动画。

---

# 76. Motion acceptance

Arc：

```text
~160ms initial
```

Composer：

```text
~180ms initial
```

Donor手感目标：
low overshoot。

Browser review根据视觉可调整。

Reduced motion：

无多余 scale animation。

---

# 77. Performance acceptance

Canvas idle：

新增 T3不能给每个 node注册 listener。

Expected：

```text
one host recognizer instance
one active Arc max
one active Composer max
```

---

# 78. Render subscription acceptance

LocalAffordance store selector只让：

```text
HostOverlay / active body
```

重渲。

不要所有 nodes订阅整个 ComposerDraft。

Reference badge若 per-node订阅，使用细粒度 selector。

---

# 79. Memory acceptance

Project switch：

- runtime disposed；
- reference click suppressor disposed；
- recorder disposed；
- AbortControllers canceled；
- transient stores reset；
- drop reset。

---

# 80. Recovery hierarchy

## R0 transient UI

Arc/Menu/Composer visible body：

```text
close/reopen
```

## R1 unsubmitted draft

ComposerDraft store。

## R2 network request

Abort/retry client。

## R3 canonical Core mutation

Core runtime/recovery。

UI不越级实现 R3。

---

# 81. Composer crash recovery

若 body React error导致 unmount：

draft store仍在。

重新 mount可恢复。

不要求 localStorage持久化。

---

# 82. Browser reload

当前 T3没有证据要求 unsubmitted draft跨 full reload恢复。

所以不新增 persistence。

如果未来要求，再单独审计。

---

# 83. Voice crash recovery

录音中组件崩：

dispose media tracks。

不持久化音频。

---

# 84. Run recovery

Core已经有：

```text
recover
sync
events
```

T3不复制。

---

# 85. Drop recovery

Pre-commit：

cancel即可。

Post-commit：

依 Core transaction。

---

# 86. Cross-review · T1

T1必须提供/确认：

```text
takeover mark geometry owner
LOD anchor behavior
spatial hit compatibility
```

T3验收：

Arc/Composer不自行复制 geometry。

---

# 87. Cross-review · T2

需要确认：

```text
safe rect
occupied rect
Pin / Focus action owner
global shortcut ownership
```

T3不实现第二份。

---

# 88. Cross-review · T4

需要确认：

```text
WorkView open state
Assembly action
Skill target
Context/Workflow surface target descriptor
Glyth open/work action
```

如果接口未定：

T3只留 callback/typed adapter点。

---

# 89. Cross-review · T5

T5校验：

```text
ActionArc visual body
Composer visual hierarchy
Reference satellite
Voice state
icon family
```

T5不得改：

```text
Selection/Reference semantics
```

---

# 90. Cross-review · T6

必须核：

```text
Run types
Receiver types
Voice response
Glyth durable context mutation
Relation action
Semantic Drop commit/recovery
```

T3 client使用现有 contracts。

---

# 91. Cross-thread conflict protocol

发现：

```text
T4认为 Assembly action local state
T6认为 Core canonical
```

T3不选边猜。

上报 coordinator：

```text
REPORT_CONFLICT
```

带：
- exact files；
- exact contract；
- failure scenario。

---

# 92. Test execution order

```text
1 Typecheck
2 unit
3 Huabu component
4 web-gen2 integration
5 Playwright focused
6 full relevant suite
7 manual browser
8 cross-thread smoke
```

前置检查不能代替真实 browser执行。

---

# 93. No “tests green = visual done”

Unit全绿仍必须测：

```text
Arc位置
Composer遮挡
hover
focus
motion
WorkView
LOD
```

反过来视觉漂亮也不能代替 Reference/Run payload tests。

---

# 94. Browser evidence capture

每个关键路径记录：

```text
scenario
viewport size
zoom
state
observed
expected
```

可截图/录屏。

不强制建立 permanent golden image baseline。

---

# 95. Accessibility review

- keyboard reachable；
- focus visible；
- aria labels；
- menu semantics；
- voice controls；
- reduced motion；
- color contrast。

---

# 96. Destructive actions

Right-click Delete/Remove Projection：

必须清楚区分。

UI label不能两个都叫“Delete”。

Mutation owner测试。

---

# 97. Projection delete + Reference

沿 current frozen：

projection delete：

pending draft Reference移除。

Core entity未删除。

测试：

```text
entity仍可通过其它 projection存在
```

---

# 98. Relation action failure

Core Relation失败：

Arc/Menu关闭策略可独立。

但 UI不能先画永久 relation edge再回滚猜。

继续走 existing relation projection。

---

# 99. Pin/Assembly action cross owner

T3只 dispatch。

测试通过 mock callback证明：

```text
correct target
```

真实 canonical测试在 T2/T4。

---

# 100. Error presentation

局部 action失败：

优先 local error/inline feedback。

不要全系统 toast作为唯一。

但是否统一 Toast由 Huabu/T5现有 pattern决定。

---

# 101. Offline behavior

当前没有 offline-first T3需求。

Network unavailable：

- Composer draft保留；
- Voice transcription不可用；
- Run不可用；
- local Selection/Reference仍可编辑。

不新增离线队列。

---

# 102. Race · rapid target clicks

快速：

```text
A selected
A re-click Arc
click B
```

Expected：

```text
Arc A closes
B selects
no stale A action
```

---

# 103. Race · target deleted while menu open

Close menu。

Action click后target invalid：

fail-close。

---

# 104. Race · WorkView opens during Voice

WorkView suppression是否允许 recording继续？

这是 product micro policy。

安全默认：

```text
visible Composer被 suppress
recording should stop/cancel
```

因为隐藏录音违反用户可见性预期。

需 T4/Voice freeze复核。

标：

```text
OPEN_CROSS_POLICY
```

---

# 105. Race · project switch while Run submitting

Abort client request if possible。

若 server已创建：

Core Run存在。

UI重新加载/同步应通过 Core list/events恢复，不造 phantom rollback。

---

# 106. Race · Reference binding refresh

Reconcile更新 node→entity index。

已有 draft refs按 Core identity，不按 node id。

因此 order不应因 node id变化重排。

若 projection删除规则触发，按正式 lifecycle处理。

---

# 107. Race · Semantic Drop target moves

Preview target node被移动：

target identity仍 same。

Preview anchor应刷新。

如果 target被删：

cancel。

---

# 108. Failure blast radius acceptance

主动 fault injection：

## Arc CSS失效

Selection/Composer/Run仍可工作。

## Recorder throw

Text Composer工作。

## Context menu render fail

Arc/Selection工作。

## WorkView state unavailable

fail-close local overlay，不能 camera corruption。

---

# 109. Donor replaceability test

可以用 test stub替代：

```text
ActionArcBody
AudioRecorder
```

semantics测试不变。

这是模块化验收。

---

# 110. Retirement acceptance

删除 `LcosComposerShell` 后：

搜索：

```text
data-lcos-composer旧 selector
old fixed bottom styles
debug reference label
```

不得残留 production consumer。

---

# 111. Drop hardcode retirement

搜索：

```text
surface:left-dock
surface:bottom-dock
左侧导航坞
底部停靠区
```

最终 production T3无残留。

若其它历史测试/fixture保留，明确标 legacy test。

---

# 112. Old slop retirement

搜索：

```text
SLOP_PX = 4
```

Reference路径不再有独立 literal。

---

# 113. No second owner audit

完成后 grep/review：

```text
document.addEventListener pointer/click/contextmenu in LCOS T3
new Selection state
new relation arrays
new Run IDs
```

都应无新增。

---

# 114. Final code review checklist

Reviewer逐项：

```text
[ ] pointer owner single
[ ] Selection single
[ ] Reference ordered
[ ] Relation Core
[ ] Arc <=5
[ ] Composer target-local
[ ] no autofocus
[ ] draft survives suppression
[ ] contextmenu no global listener
[ ] Voice no auto-send
[ ] Run formal Core
[ ] Drop concrete target
[ ] WorkView safe
[ ] donor provenance
[ ] retirement done
```

---

# 115. Acceptance sign-off structure

每个 card结束提交：

```text
Done:
Evidence:
Tests:
Browser:
Recovery:
Retired:
Cross-thread:
Open:
```

不能只写：

```text
tests pass
```

---

# 116. Blocker categories

施工中只允许以下 blocker：

```text
MISSING_CANONICAL_CONTRACT
LATEST_PRODUCT_AMBIGUITY
UPSTREAM_BREAKING_DELTA
CROSS_THREAD_OWNER_CONFLICT
BROWSER_MECHANIC_FAILURE
```

不允许：

```text
“实现比较复杂，所以先做一个临时第二 store”
```

---

# 117. Open items currently known

```text
O1 Voice transcript与已有 prompt exact merge policy
O2 LCOS species double-click具体 override清单
O3 T4 concrete Surface/Assembly drop target descriptors
O4 WorkView exact selector/occupied rect interface
O5 Glyth durable context exact T6 mutation client
O6 WorkView opens while active voice recording policy
```

这些不阻塞：

```text
Arc
draft
Reference Pick
Run client
Voice recorder/client
contextmenu base
```

---

# 118. P0 acceptance batch

对应 C03-01~04：

- threshold；
- affordance owner；
- observer；
- action resolver。

完成标准：

```text
无视觉 Arc也能 unit证明正确 intent
```

---

# 119. P1 acceptance batch

Arc/contextmenu。

完成：

```text
Browser local controls
no gesture regression
```

---

# 120. P2 acceptance batch

Composer/Reference。

完成：

```text
draft continuity
Reference grammar
focus
```

---

# 121. P3 acceptance batch

Run/Receiver/Voice。

完成：

```text
real Core mock/integration
```

---

# 122. P4 acceptance batch

Semantic Drop/Glyth/WorkView。

完成：

```text
cross-thread real target
```

---

# 123. Regression suite

至少不回归：

```text
Huabu node drag
resize
lasso
multi select
text edit
native drop
connection
Preview double-click
toolbar
panel attention
```

T3不能只跑 lcos小测试。

---

# 124. Performance regression

重点：

```text
canvas node count
selected re-click observer
Reference badge
floating follow
```

不新增 per-node global effects。

---

# 125. Chromium/Edge

用户实际开发环境Edge。

Playwright chromium应覆盖主交互。

如果 Electron/Huabu desktop也为正式目标，加 desktop smoke。

---

# 126. Final recovery statement

T3最重要的 recovery原则：

> **Transient UI可以丢，未提交 draft不该因 UI suppression丢，canonical Core truth只能由 Core恢复。**

这三层必须清清楚楚。

---

# 127. Final cross-review statement

任何线程若要求 T3：

```text
复制 Selection
自己算 camera
自己存 Run
自己造 WorkView
```

都应拒绝并回 owner。

---

# Appendix A · Acceptance trace table

| Feature | Unit | Integration | Browser | Recovery | Cross |
|---|---|---|---|---|---|
| Re-click | yes | pointer router | yes | close | Huabu |
| Arc | resolver | overlay | yes | transient | T5 |
| Context menu | seam | Canvas | yes | transient | Huabu |
| Composer | draft | overlay | yes | draft | T4 |
| Reference | controller | recognizer | yes | ordered | Core binding |
| Voice | adapter | HTTP | yes | draft | T6 |
| Run | payload | HTTP | yes | Core | T6 |
| Drop | reducer | target | yes | Core | T4/T6 |
| Glyth | semantic | hit/commit | yes | Core | T4/T6 |

---

# Appendix B · Manual visual script

1. 1440×900 main canvas；
2. node放中央；
3. click/reclick；
4.观察 Arc；
5. target移至四边；
6. zoom 50/100/200；
7. Composer；
8.输入4行；
9. refs 1/3/8；
10. WorkView dock；
11. close；
12. right click；
13. Voice；
14. takeover；
15. Semantic Drop。

记录所有遮挡/跳动。

---

# Appendix C · Recovery fault injection

```text
throw recorder.start
HTTP 503 voice
HTTP 409 run
Abort run
delete target during Arc
unmount WorkView during Composer
project switch during voice
pointercancel during drop
Core drop commit failure
```

每个都必须有明确 expected state。

---

# Appendix D · Cross-thread handoff checklist

T1：
```text
[ ] anchor helper
[ ] takeover identity
```

T2：
```text
[ ] safe/occupied rect
[ ] Pin/Focus callbacks
```

T4：
```text
[ ] WorkView state
[ ] Assembly
[ ] Skill
[ ] surface target
```

T5：
```text
[ ] visual tokens
[ ] iconography
```

T6：
```text
[ ] Run types
[ ] Receiver
[ ] Voice
[ ] Glyth context mutation
[ ] drop transaction/recovery
```

---

# Appendix E · Why no extra release gate

T3多数变化是：

```text
reversible UI/presentation
```

现有：

```text
Git
TypeScript
tests
browser execution
```

足够。

不可逆/跨系统 mutation仍由 Local Core contract/transaction保障。

所以本册没有再创造：

```text
T3 release approval gate
hash freeze
visual golden requirement
```

---

# Appendix F · Final close criteria

必须全部：

```text
01–05 docs current
tests green
browser path green
cross-thread blockers closed/explicit
legacy shell retired
legacy drop destination retired
no second owner
donor provenance retained
```

之后 T3才可提交给 coordinator标：

```text
PLAN_READY_FOR_CONSTRUCTION
```


---

# Appendix G · Destructive Mutation Recovery Matrix

## Remove Projection

Owner：

```text
Huabu projection / LCOS binding path
```

Acceptance：

- only current projection removed；
- Core entity remains unless explicit Delete Entity；
- pending Reference follows frozen projection-delete rule；
- other projections remain；
- menu closes。

Failure：

```text
projection mutation refused
```

UI保持 target，不伪装成功。

---

## Delete Entity

只有 resolver明确提供时。

必须区别：

```text
Delete entity
vs
Remove from canvas
```

如果 Core route/contract没有明确 entity delete：

T3不得展示 Delete Entity。

普通按钮颜色/确认弹窗不能替代 canonical delete contract。

---

## Relation mutation

关系删除/建立：

- 交 Core；
- projected edge follows reconciliation；
- UI不直接先删/画 edge作为 truth。

---

## Conversation Context Mapping

Glyth body drop：

- durable context mutation；
- 如果 Core commit失败，preview/feedback回到可理解失败；
- 不回退成 Reference；
- 不写 Relation。

---

# Appendix H · Session Lifecycle Matrix

## Same node / same canvas

local affordance可切：

```text
arc → composer → menu → closed
```

draft留。

## Different node / same canvas

Selection切换后：

旧 Arc/Menu关闭。

Composer draft target switch按 open micro policy处理，不能静默 rebind。

## Same project / different canvas

ProjectionBinding resync。

Presentation target若不存在则关闭。

## Different project

全部 T3 transient/draft reset，除非未来明确跨项目 draft功能。

## Window blur

Arc/menu可按产品关闭。

Voice recording应考虑 stop/cancel，不能隐身继续。

Drop active应 cancel。

---

# Appendix I · Cross-thread Conflict Examples

## Example 1

T4说 WorkView打开后 Composer继续 visible overlay。

T3最新 freeze/overlay arbitration说 WorkView专业容器 exclusive。

处理：

```text
REPORT_CONFLICT
```

不让 T3自己选 z-index。

## Example 2

T6给 Run API不接受 orderedReferences某 entity type。

T3：

```text
resolver/submit fail-close
```

不能偷偷过滤。

## Example 3

T2 Pin action希望直接写 UI store，但 Core Pin identity另有 owner。

回 T2/Core owner，不在 action dispatch双写。

## Example 4

T5想把 Arc button做 20px实际 hit。

T3 accessibility验收要求扩大 hit region。

视觉可20px，交互区域保持可用。

---

# Appendix J · Completion Evidence Package

每批施工最终保留：

```text
git diff
test command/output
browser scenario notes
screenshots/recording where useful
upstream provenance
open conflict list
retired-source search
```

这些是交接 evidence。

不要求生成新的 checksum manifest。

---

# Appendix K · Final No-Silent-Fallback Rule

下列失败必须显式：

```text
Reference unmappable
Run target invalid
Receiver missing
Voice unavailable
Semantic Drop target unsupported
Glyth Core mutation unavailable
```

不允许 fallback成：

```text
普通 Selection
native edge
generic note
default receiver
自动忽略 Reference
```

因为这类“贴心 fallback”会制造第二 truth，比报错危险得多。
