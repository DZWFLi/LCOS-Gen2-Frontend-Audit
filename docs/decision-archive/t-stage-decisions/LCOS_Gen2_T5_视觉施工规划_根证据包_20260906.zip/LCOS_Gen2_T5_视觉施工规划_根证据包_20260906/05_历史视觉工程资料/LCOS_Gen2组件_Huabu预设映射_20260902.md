# LCOS Gen2 组件 → Huabu 成熟预设 映射审计（2026-09-02）

> **方向纠正（重要）**：不是"改造 Gen1"，而是**吸取 Gen1 的教训**——Gen1 在呈现层自己搓了一堆
> 歪七扭八的组件（比例/缩放边界/排版/造型全错）。Gen2 的正确做法是：**LCOS 对应的每个组件，
> 直接落成 Huabu 基座上已有的成熟预设**；尺寸/比例/造型/材质这些"LCOS 风格"留到后续在 token 层调回。
>
> 证据：Huabu `apps/web/src/components/Common/*`（在盘实测）+ `apps/web/src/index.css`（设计 token 全表）
> + `Common/{Button,Modal,Popover,Select}.tsx` props 契约（已读）。
>
> **一句话**：Gen2 上 LCOS 的按钮/输入/浮层/选择/开关/页签/提示/队列/状态图，**几乎全部能映射到
> Huabu `Common/*` 现成件**；必须自绘的只剩 Glyth 造型 + drop 五阶段语义 + 各 projection 布局纯函数。
> 不需要再引 base-ui/mind-elixir 这些外部库——Huabu 自家 Common 就已覆盖，且视觉 token 已统一。

---

## 0. Huabu 底盘（在盘实测）

### 0.1 设计 token（`index.css`，已收敛成体系）
```css
/* 文本层级 */ --fg-default / --fg-muted / --fg-subtle / --fg-inverse
/* 背景 */     --bg-default / --bg-surface / --bg-hover / --bg-inverse
/* 边框 */     --edge-default
/* 状态 */     --info(--bg,--bg-hover) / --success / --warning / --danger（各含 -bg/-bg-hover 变体）
/* AI */       --ai / --ai-light / --ai-bg
专用：--canvas-grid、--question-*、--skeleton-*、--shimmer-*；Tailwind4 `@theme inline` 转成 `--color-*`
```
→ LCOS 不需要自建色板/材质，**直接用这套 token**；LCOS 身份 accent 后续在 token 层补一个即可。

### 0.2 Common/* 现成件（全部在盘，可用）
`Button · Input · TextInput · Popover · Modal · Select · SplitSelect · DropdownMenu · Toggle ·
TabGroup · Tooltip · Toast · ColorPicker · RangeSlider · EmptyState · Loading · ThinkingIndicator ·
AgentIcon · AgentAvatarMark · BuiltInAgentAvatar · NodeRef · CommandBlock · PathInput ·
FloatingToolbar · CanvasFloatingPopover · DragToCanvasHandleButton · cn`

---

## 一、LCOS 通用控件 → Huabu Common（最直接的一批）

| gen2 要做的 LCOS 组件 | Huabu 现成预设 | 证据（props） | 留待调回 LCOS 风格 |
|---|---|---|---|
| 任意按钮（primary/secondary/ghost/destructive） | **`Button`** `variant(solid\|outline\|ghost)` × `tone(neutral\|info\|success\|warning\|danger)` × `shape(default\|pill)` × `size(sm\|md\|lg)` + `iconOnly` + `shortcutBadge` | 已读 Button.tsx | accent 蓝 tone 后叠 |
| 图标按钮 / 胶囊按钮 | `Button` + `shape="pill"` + `iconOnly` | 同上 | 有机形状 |
| 文本输入 / 浮层标签 | **`TextInput` / `Input`** | 已在盘 | focus ring 色 |
| 下拉选择（含分组/disabled/底槽） | **`Select`** `options[{value,label,icon,description,sectionLabel,disabled}]` + `footerSlot` + `align` | 已读 Select.tsx | — |
| 分屏选择（多列值） | **`SplitSelect`** | 已在盘 | — |
| 下拉菜单 | **`DropdownMenu`** | 已在盘 | — |
| 开关（含"选中画勾/收藏/点赞"态） | **`Toggle`** | 已在盘 | 形态 |
| 页签（Surface 切换指示器） | **`TabGroup`** | 已在盘 | layoutId 指示条（Amicro 可选）|
| 浮层（光标定位/边缘钳制/Esc 关闭） | **`Popover`** `position/anchor/offset/viewportMargin/boundary` + clamp + Esc | 已读 Popover.tsx | 材质（ios26 liquidGlass 后叠）|
| 模态（title/desc/footer/backdrop/Esc） | **`Modal`** `isOpen/title/description/footer/initialFocusRef/closeOnBackdrop/closeOnEscape` | 已读 Modal.tsx | — |
| 工具提示 | **`Tooltip`** | 已在盘 | — |
| 轻提示（toast） | **`Toast`** | 已在盘 | — |
| 颜色选择（Color Pin 授权） | **`ColorPicker`** | 已在盘 | — |
| 范围滑条 | **`RangeSlider`** | 已在盘 | — |
| 空态（EmptyState） | **`EmptyState`** | 已在盘 | — |
| 加载中 / 思考流 | **`Loading` / `ThinkingIndicator`** | 已在盘 | — |
| 浮动工具条 | **`FloatingToolbar`** | 已在盘 | — |
| 画布浮动浮层 | **`CanvasFloatingPopover`** | 已在盘 | — |

> **结论**：老库 `ui/` 那套 `LcosButton/LcosTextField/LcosPopover/LcosTooltip/LcosToaster/ConfirmDialog` 的
> **每一个在 gen2 都有 Huabu Common 现成件**。直接 import，不用自己写 class，比例/字号/圆角/材质全默认。

---

## 二、LCOS 画布/节点相关 → Huabu 已有能力（Gen1 用来自研的，Gen2 白送）

| gen2 LCOS 能力 | Huabu 已有 | 备 |
|---|---|---|
| 画布物理（pan/zoom/select/drag/resize/connect） | ReactFlow（`@xyflow/react`）宿主 | Gen1 自研 SpatialCanvas 重灾区，Gen2 白送 |
| 小地图 | ReactFlow minimap | Gen1 `CanvasMiniMap`(10K) 白送 |
| 语义缩放边界（LOD） | `config/semanticZoom.ts`（screen-space threshold + 10px hysteresis + representative-size）| Gen1 `spatialLod/glythSemanticLod` 迁逻辑 |
| 节点接管（question/note 优雅降级） | `useNodeTakeover` / `config/nodeTakeover.ts` | 三种 stage |
| 节点物种形态 | `nodeTypes`（note/text/image/pdf/video/audio/frame/web/sketch）| Gen1 `CanvasNodeVisual`(47K) 语义迁 |
| 富文本编辑 | `@milkdown` | Gen1 `InlineNoteEditor`(20K) 换 |
| 文本自适应 | `useTextAutoSize` / textMeasure | Gen1 同类自研 |
| PDF / 视频 / 图像预览 | `react-pdf` + 节点 | Gen1 `PdfViewer`(10K) 换 |
| 工作区/面板/坞 | `SidebarPanel / Header / MainLayout / WorkspaceLayout` | Gen1 `WorkspaceRailVNext`(37K)/`SurfaceDock` 白送 |

---

## 三、必须自绘的（Gen2 上 LCOS 独有的，成熟件没有）

| LCOS 独有 | 自绘范围 | 用什么 | 为何必须自绘 |
|---|---|---|---|
| **Glyth 造型 + presence** | 深石墨身体 + 双浅眼 + 状态 accent；Near/Mid/Far 语义 LOD | **一小段 SVG + motion**（lcospresets.snappy）| 无任何预设库表达 LCOS 身份形态；不引 three/GL |
| **drop 五阶段语义** | 状态机 + 命中判定 + 触觉 | **纯逻辑**（dropPhases/useSemanticDropFeedback 迁）+ `motion` / Amicro cursor | 语义是 LCOS 灵魂，壳可叠预设 |
| **空间近场摆位** | 世界坐标近场 resolver | 纯函数 | @floating-ui 只能管屏幕浮层，管不了世界空间 |
| **各 projection 布局** | mindMap / context strands / relationship / outline 布局 | **纯函数**（mindMapLayout 等迁，不依赖引擎）| 布局数学与框架无关 |
| **上下文/工作流/Skill/Assembly 仪器** | 接收 projection 的只读呈现 | react-arborist / mind-elixir / Cytoscape / vis-timeline **只作仪器** | 但它们是"器官"非轮子，语义留 Core |

---

## 四、执行顺序（先换预设，再回 LCOS 风格）

```
① 通用控件：→ Huabu Common/*（Button/Input/Select/Modal/Popover/Toggle/TabGroup/Tooltip/Toast/ColorPicker/RangeSlider/EmptyState/Loading）
   —— 这一步把 Gen1 "歪七扭八的比例/字号/造型"全卸掉，长度尺寸全默认。
② 画布/节点：→ ReactFlow + semanticZoom + nodeTakeover + nodeTypes（白送）
③ 仪器：→ Huabu virtuoso/panels + 只读 graph/timeline 库
④ LCOS 独有自绘：Glyth(SVG+motion) + drop 语义(纯逻辑) + 布局(纯函数)
⑤ 最后统一调回 LCOS 风格：在 Huabu token 层补 --lcos-accent、Liquid Glass 材质、去卡片化 —— 只改 token，不改组件。
```

> 红线：**通用控件绝不再自写 class**（Gen1 `ui-primitives.css` 正是病灶）；**逻辑/语义保留在纯函数**
> （drop 状态机、布局数学、投影 resolver），呈现全交给 Huabu Common + token。这样 Gen2 就不重蹈 Gen1 覆辙。

---

*关联：LCOS_Gen1呈现层替换审计、ui-primitives.css 病灶、Huabu Common 源码（在盘）、Gen1重构差异分析（§2-§4 Huabu 白送项）。*
