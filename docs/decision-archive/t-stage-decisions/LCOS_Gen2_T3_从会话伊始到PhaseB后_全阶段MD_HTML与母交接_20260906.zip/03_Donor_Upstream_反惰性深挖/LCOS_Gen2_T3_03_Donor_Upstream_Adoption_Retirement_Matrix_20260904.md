# LCOS Gen2 · T3 第三路正式施工规划
## 03_Donor_Upstream_Adoption_Retirement_Matrix
### Local Object Interaction / Action Arc / Compact Composer / Reference / Voice

> 日期：2026-09-04  
> 基线：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`  
> Huabu vendored pin：`58339e269b784728d67730c70bfe7792cae2457d`  
> Huabu upstream observed：`dc128fff2d37b5481ec305070a7e86d3de85f7d2`  
> 文档性质：T3 五册正式交付中的第 03 册。  
> 本册回答：**哪些成熟东西直接用，哪些只包，哪些只 lift primitive，哪些只做高保真设计 donor，哪些必须拒绝和退役。**

---

# 0. 总裁决

T3 donor 采用必须同时维护两条独立轨：

```text
Track A · Engineering
DIRECT_USE / WRAP / LIFT / REFERENCE / REJECT

Track B · Visual / UX
HIGH_FIDELITY_DONOR / PARTIAL_DONOR / STYLE_REFERENCE / REJECT
```

不能再出现：

```text
Lovart = reference only
TapNow = reference only
```

这种模糊句子。

因为：

```text
proprietary code 不能复制
```

不等于：

```text
它已经做成熟的 layout / hover / spacing / reveal / motion
也必须重新设计一遍
```

T3 最终采用原则：

```text
成熟产品
→ 回答应该长什么样、什么时候出现、怎么动

成熟 OSS / Huabu
→ 回答具体怎么实现

LCOS
→ 只保留 target / Reference / Relation / Run / Receiver 等 canonical semantics
```

---

# 1. Supplier Priority

按 V6 与双轨裁决，T3 supplier 优先级：

```text
1. Huabu current mechanic
2. Huabu upstream newer mechanic
3. permissive OSS exact upstream
4. proprietary bundle wheel provenance
5. proprietary UI/UX high-fidelity measurement
6. self-build thin glue
```

Self-build 不是默认第五种 donor。

Self-build 是：

```text
前五项确实没有
+
LCOS 又有独有 semantics
```

之后才出现的最后选项。

---

# 2. 模块化目标

Gen2 模块化不等于：

```text
把一个大文件拆成 12 个小文件
```

T3 正确结构：

```text
canonical owner
↓
thin semantic adapter
↓
mature mechanic
↓
replaceable presentation body
```

例如 Action Arc：

```text
LCOS target/action semantics
↓
pure action resolver
↓
Huabu target anchor + floating mechanics
↓
Orbit radial geometry
↓
LCOS visual body
```

换 donor：

```text
只换 body / geometry
```

不能动：

```text
Selection
pointer
ProjectionBinding
Core
```

---

# 3. Donor Matrix 总览

| Feature | Donor | Engineering | Visual | Final |
|---|---|---|---|---|
| pointer routing | Huabu | DIRECT_USE | — | PROTECT |
| selection | Huabu | DIRECT_USE | — | PROTECT |
| node anchor | Huabu NodeFloatingToolbar | DIRECT_USE/WRAP | STYLE TUNE | PROTECT |
| floating placement | Huabu CanvasFloatingPopover | DIRECT_USE | STYLE TUNE | PROTECT |
| context menu mechanics | Huabu Popover/DropdownMenu | DIRECT_USE | STYLE TUNE | PROTECT |
| textarea/input mechanics | Huabu ChatInput | WRAP | PARTIAL | ADOPT MECHANICS |
| draft/body split | Huabu upstream ThreadChatInput | ADOPT PATTERN | — | STRONG |
| Action Arc radial geometry | zumerlab/orbit | LIFT | PARTIAL | STRONG |
| Action Arc UX | TapNow/Lovart/Spatial | REFERENCE | HIGH_FIDELITY | STRONG |
| Reference local satellite | Lovart | REFERENCE | HIGH_FIDELITY | STRONG |
| Reference Pick | Lovart | REFERENCE | HIGH_FIDELITY | STRONG |
| Voice recorder | CopilotKit | LIFT | TUNE | STRONG |
| whole CopilotKit input | CopilotKit | REJECT | STYLE_REFERENCE | REJECT BODY |
| LibTV product code | LibTV bundle | REJECT/WHEEL_PROVENANCE | PARTIAL | NO COPY |
| LibTV skills | libtv-labs | DIRECT_USE allowed | — | LOW T3 fit |
| TapNow product code | TapNow bundle | REJECT/REFERENCE | HIGH_FIDELITY | NO COPY |
| Lovart product code | Lovart bundle | REJECT/REFERENCE | HIGH_FIDELITY | NO COPY |
| Spatial runtime | Spatial bundle | REJECT/BEHAVIOR | HIGH_FIDELITY | NO OWNER |
| Semantic Drop machine | LCOS existing | DIRECT_USE | — | PROTECT |
| Run backend | LCOS Core | DIRECT_USE | — | PROTECT |
| Voice backend | LCOS Core | DIRECT_USE | — | PROTECT |
| Receiver backend | LCOS Core | DIRECT_USE | — | PROTECT |

---

# 4. Huabu · Pointer Router

## Feature

所有 canvas pointer lifecycle。

## Engineering

```text
DIRECT_USE
```

## Visual

N/A。

## Why

当前 Huabu 已经：

```text
stock recognizers
+ hostExtension recognizers
```

同一个 router。

T3 Reference 已证明可通过这个 seam工作。

## Borrow

全部 mechanics。

## Do not borrow

不是 donor问题，直接继续使用。

## Canonical owner

Huabu。

## Replacement boundary

无。

## Max blast radius

pointer router changes会影响全 canvas，因此 T3禁止无必要修改。

---

# 5. Huabu · CanvasFloatingPopover

## Feature

target-local Action Arc / Compact Composer placement。

## Engineering

```text
DIRECT_USE
```

## Visual

```text
STYLE_TUNE
```

## Existing mechanic

已经：

```text
flow rect
→ virtual reference
→ browser page rect

Floating UI:
offset
flip
shift
autoUpdate

boundary:
canvas DOM node

ResizeObserver:
panel/canvas resize
```

## Why it is superior to self-build

若 T3 自己再写：

```text
target x/y
zoom
viewport transform
window resize
panel safe edge
```

必然制造第二 geometry truth。

## Borrow

100% positioning mechanic。

## Change

仅：

```text
T3 body
preferred side
offset
visual class
未来 safe/occupied rect boundary inputs
```

## Do not change

viewport truth。

## Replacement boundary

Body only。

---

# 6. Huabu · NodeFloatingToolbar

## Feature

live target anchor。

## Engineering

```text
DIRECT_USE / WRAP
```

## Current strengths

- internal absolute position；
- live width/height；
- explicit style size优先于 measured；
- auto-sized fallback；
- takeover mark；
- modifier hold suppression；
- CanvasFloatingPopover。

## T3 use

不要 copy component。

提取/复用它已经定义的：

```text
anchor resolution pattern
```

如果 Action Arc/Composer需要同样 anchor：

优先让现有 common anchor能力可被多个 consumer复用。

但：

> 不为了“代码复用”预先抽一个抽象层。

只有两个以上真实 consumer重复相同 20+ 行 geometry逻辑时才抽。

---

# 7. Huabu · Popover

## Feature

screen-space context menu / small transient menus。

## Engineering

```text
DIRECT_USE
```

## Existing

- screen position；
- viewport/boundary clamp；
- portal；
- outside dismiss；
- Escape；
- nested portal safety；
- ResizeObserver。

## T3 use

Right-click菜单。

## Not for

target-relative node Arc placement。

那一类用 CanvasFloatingPopover。

---

# 8. Huabu · DropdownMenu

## Feature

Right-click / More。

## Engineering

```text
DIRECT_USE
```

## Existing

- controlled/uncontrolled；
- item；
- shortcut；
- submenu；
- hover；
- keyboard；
- outside/Escape。

## T3 glue

只给：

```text
action descriptors
```

不要让 Menu知道 species。

---

# 9. Huabu · ChatInput

## Feature

Compact Composer generic input mechanics。

## Engineering

```text
WRAP / EXTRACT_GENERIC_MECHANICS
```

不是：

```text
DIRECT_USE WHOLE
```

## Why not direct whole

它当前依赖：

```text
useChatSession
useChatStore
thread pending attachments
selectionAttachment
agent/session state
```

若直接放进 LCOS Composer：

```text
LCOS Run draft
```

会被绑定到：

```text
Huabu Chat thread truth
```

形成第二 semantics。

## What to reuse

```text
controlled textarea
IME-safe keydown
auto-grow
send/stop button mechanics
attachment drop/paste mechanics
slash typeahead body if LCOS later needs
focus-visible behavior
```

## What not to reuse

```text
thread ownership
chat history ownership
agent mode semantics
Huabu attachment semantic mapping
```

## Replacement boundary

generic input body。

---

# 10. Huabu upstream · ThreadChatInput

## Feature

Draft owner / body split。

## Engineering

```text
ADOPT_PATTERN
```

如果 upstream同步后进入 vendored：

```text
ADOPT upstream
```

## Why important

它把：

```text
thread draft
```

放在 store owner，

把：

```text
ChatInput
```

变成 controlled body。

这与 T3正式 Composer需要的：

```text
ComposerDraft owner
→ CompactComposerBody
```

完全同构。

## T3 lesson

不要复制 ThreadChatInput。

学习它的责任拆法：

```text
owner outside
body inside
```

---

# 11. Orbit · exact provenance

## Repo

```text
zumerlab/orbit
```

## Exact version/commit

```text
1.4.12
9b8906713a9e8d5fb48e04df824401c65acf6a16
```

## License

```text
MIT
```

## Exact relevant source

```text
src/scss/_radial-layout.scss
src/scss/_satellite.scss
src/scss/_arc.scss
src/orbit.scss
```

## Engineering

```text
LIFT
```

或经构建验证后：

```text
DIRECT_STYLE_USE
```

## Visual

```text
PARTIAL_DONOR
```

它不是 LCOS视觉答案，只是成熟 radial mechanic。

---

# 12. Orbit · what exactly to lift

`_radial-layout.scss` 的核心职责：

```text
按 child count
→ 计算 --o-angle
→ 给每个 satellite child index
```

`_satellite.scss`：

```text
angle
radius
ellipse
sin/cos
→ transform
```

同时：

```text
satellite pointer-events: all
```

这表明：

> Orbit 可以只负责几何，完全不需要成为 pointer owner。

## Recommended implementation

T3 ActionArcBody：

```text
React renders actions
Huabu owns click/pointer
LCOS owns action state
Orbit-derived CSS owns radial translate
```

## Do not import

```text
global color theme
demo visual identity
web-component lifecycle
unneeded progress/capsule/gravity modules
```

## Why LIFT instead of package-wide import

T3只需要几百行以下的 radial primitive。

若整 package import引入：

```text
global selectors
theme variables
unused shapes
```

替换半径会变大。

MIT允许 copy/lift，但必须保留许可要求。

---

# 13. Orbit · failure blast radius

理想：

```text
ActionArcBody
+
ActionArc radial CSS module
```

Orbit升级失败：

```text
Arc layout退化
```

不应影响：

```text
pointer
Selection
Composer
Run
Core
```

如果升级 Orbit 能让 Selection挂掉：

说明边界做错。

---

# 14. CopilotKit · provenance

## Repo

```text
CopilotKit/CopilotKit
```

## Observed main

```text
3472104d06eb53ae9d23541d8b60ff81c0c7684a
```

## License

```text
MIT
```

## Relevant exact files

```text
packages/react-core/src/v2/components/chat/CopilotChatAudioRecorder.tsx
packages/react-core/src/v2/components/chat/CopilotChatInput.tsx
```

---

# 15. CopilotChatAudioRecorder

## Engineering

```text
LIFT
```

## Visual

```text
TUNE_TO_LCOS
```

## Mature mechanics

```text
navigator.mediaDevices.getUserMedia
MediaRecorder
audio/webm;codecs=opus fallback
audio/webm fallback
audio/mp4 fallback
stream cleanup
AudioContext cleanup
requestAnimationFrame cleanup
idle/recording/processing
waveform
permission error
no mic error
recording error
imperative start/stop/dispose
```

## Why T3 should not rewrite

这些是标准浏览器录音坑。

自写只会重新经历：

```text
Safari/Chrome MIME差异
权限失败
track leak
AudioContext leak
unmount recording leak
```

对 LCOS没有产品差异价值。

---

# 16. Copilot recorder adaptation

## Keep

```text
recorder lifecycle
cleanup
MIME negotiation
waveform sampling
imperative API
```

## Change

```text
class names
LCOS token
visual geometry
error copy
integration adapter
```

## Product-state adapter

Donor：

```text
idle
recording
processing
```

LCOS：

```text
idle
recording
transcribing
editable
```

不要把 donor `processing` 直接当 LCOS `transcribing`。

因为：

```text
recorder stop processing
```

与：

```text
Core network transcription
```

是两个不同阶段。

---

# 17. Whole CopilotChatInput

## Engineering

```text
REJECT
```

## Visual

```text
STYLE_REFERENCE
```

## Why reject

Whole input会带：

- CopilotKit config provider；
- tool menu semantics；
- chat action semantics；
- branded styling namespace；
- input modes；
- provider assumptions。

而 Huabu自己已有成熟 ChatInput。

引入整颗是：

```text
第二套 Composer stack
```

不是复用。

---

# 18. LibTV product bundle

## Engineering

```text
WHEEL_PROVENANCE_ONLY
```

## Visual

```text
PARTIAL_DONOR
```

## T3 value

从指定 bundle chunk找到：

```text
CopilotKit
MediaRecorder
Radix/Floating traces
Slate
ReactFlow
```

真正价值是：

```text
“这个成熟产品没有自己手搓所有东西”
```

因此 LCOS也不该。

## Do not copy

```text
bundle JS
minified component
CSS extraction
brand visual assets
```

---

# 19. LibTV Skills

## Engineering

许可证允许时：

```text
DIRECT_USE_ALLOWED
```

## T3 fit

当前低。

已见能力偏：

```text
session
project
file
result
```

更适合 T4/T6。

## Decision

```text
DO NOT FORCE ADOPTION
```

MIT不是“必须用”的理由。

---

# 20. Lovart · Add to Reference

## Engineering

```text
PROPRIETARY_REFERENCE_ONLY
```

## Visual

```text
HIGH_FIDELITY_DONOR
```

## High-fidelity design answer

观察到的成熟 pattern：

```text
local satellite attached to content
rest hidden / near-hidden
hover/focus reveal
small square/circle trigger
icon compact
popover immediately local
Add to Reference明确可读
```

## LCOS translation target

建议施工规格区间：

```text
visual trigger: ~24px
icon: ~16px
local offset: 4–6px
reveal opacity: 120–180ms
```

这些是实现 target，不是复制 proprietary CSS。

## Mechanics source

```text
Huabu Popover/Button
```

不是 Lovart JS。

---

# 21. Lovart · Select From Canvas

## Engineering

```text
PROPRIETARY_REFERENCE_ONLY
```

## Visual

```text
HIGH_FIDELITY_DONOR
```

## Key product insight

Reference source selection可以：

```text
Upload
Paste
Select From Canvas
```

而 canvas pick：

```text
temporary mode
```

不是大 modal。

这与 LCOS冻结：

```text
Composer stays
Reference Pick · Esc
click eligible objects
```

吻合。

## LCOS implementation

```text
existing Reference controller
+
temporary presentation intent
+
same pointer router
```

---

# 22. Lovart · Composer

## Engineering

```text
PROPRIETARY_REFERENCE_ONLY
```

## Visual

```text
HIGH_FIDELITY_DONOR
```

## Borrow

- compact density；
- references inline；
- progressive reveal；
- target-local feel；
- transient tools；
- input/control spacing；
- reference thumbnail/chip hierarchy。

## Do not borrow

- proprietary component；
- CSS literal；
- brand icon；
- complete trade dress。

---

# 23. TapNow · local interaction

## Engineering

```text
PROPRIETARY_REFERENCE_ONLY
```

## Architecture

```text
RESPONSIBILITY_DONOR
```

## Visual

```text
HIGH_FIDELITY_DONOR
```

## Value

bundle中可以看到不同责任被分开：

```text
selection toolbar policy
context menu policy
attachment state
context node refs
quoted text
voice recording
voice stop
uploading
streaming
thinking
tool activity
run recovery
```

## LCOS lesson

不要做：

```text
LocalInteractionStore = everything
```

正确：

```text
pointer mechanics
presentation affordance
draft
Run
Voice recorder
Core runtime
```

各自有生命周期。

---

# 24. TapNow · Right click / transient control

Visual borrow：

- compact context menu；
- local geometry；
- low chrome；
- progressive disclosure；
- hover density；
- action hierarchy。

Engineering：

```text
Huabu Popover/DropdownMenu
```

因此：

```text
TapNow design answer
+
Huabu code
```

---

# 25. TapNow · Voice responsibility split

TapNow的启发不是拿其 code。

是确认：

```text
pendingVoiceInput
isVoiceRecording
pendingVoiceStop
```

与：

```text
streamingMessage
run activity
```

不是一坨。

LCOS进一步简化：

```text
recorder transient
transcription request
Composer draft text
Run state
```

四层。

---

# 26. Spatial v4

## Engineering

```text
BEHAVIOR_REFERENCE
```

## Visual/Motion

```text
HIGH_FIDELITY_INTERACTION_DONOR
```

## Relevant feel

- full-screen immersive；
- low chrome；
- local menu；
- in-place edit；
- direct manipulation；
- no unnecessary bounce；
- local causal feedback。

## Timing calibration

当前研究可用范围：

```text
small local reveal ~200ms
direct manipulation transition ~220–260ms
```

正式第 04 册需要按具体组件拆成更精确 token，不直接全局写一个 220ms。

---

# 27. Spatial · what not to adopt

不采用：

```text
第二 gesture owner
第二 animator
第二 zoom store
第二 viewport
```

Spatial负责“手感是什么”。

Huabu负责“gesture怎么发生”。

---

# 28. High Fidelity ≠ Pixel Copy

允许：

```text
geometry
spacing
density
radius
shadow hierarchy
hover timing
selected treatment
progressive disclosure
panel reveal
motion direction
visibility policy
```

不允许直接拿 proprietary：

```text
source JS
source CSS
SVG path
logo
font files
illustration
mascot
brand icon
```

---

# 29. Action Arc · 最终 donor composition

```text
Product semantics:
LCOS action resolver

Gesture:
Huabu pointer router

Anchor:
Huabu NodeFloatingToolbar / CanvasFloatingPopover

Radial geometry:
Orbit MIT

Visual hierarchy:
TapNow / Lovart

Motion feel:
Spatial v4

Icons:
LCOS/Huabu existing family

Core action:
existing LCOS owner
```

这是完整 donor 链。

没有任何一层需要：

```text
“自己从 div 开始设计一个 radial menu”
```

---

# 30. Compact Composer · donor composition

```text
Target:
ProjectionBinding / LCOS

Draft:
LCOS ComposerDraft

Reference:
referenceController

Input mechanics:
Huabu ChatInput generic primitives

Draft/body pattern:
Huabu upstream ThreadChatInput

Reference UX:
Lovart

Transient density:
Lovart/TapNow

Floating:
Huabu CanvasFloatingPopover

Voice recorder:
CopilotKit MIT

Voice backend:
Local Core

Run:
Local Core

Motion:
Spatial v4 calibration
```

Whole CopilotKit/Huabu Chat thread owner都不进来。

---

# 31. Right click · donor composition

```text
Event:
Huabu Canvas

Target:
Huabu hit / node id

Semantics:
LCOS pure action resolver management set

Placement:
Huabu Popover

Rows:
Huabu DropdownMenuItem

Visual density:
TapNow/Lovart high-fidelity

Motion:
Huabu + Spatial calibration
```

---

# 32. Reference Pick · donor composition

```text
Reference semantics:
LCOS existing

Gesture:
Huabu host recognizer

UI state:
LCOS temporary pick intent

Design:
Lovart Select From Canvas

Local satellite:
Lovart AddToReference

Popover:
Huabu

Feedback:
LCOS reference badge
```

---

# 33. Voice · donor composition

```text
Recorder primitive:
CopilotKit MIT

Presentation:
LCOS Compact Composer

Transcription:
Local Core

Transport:
web-gen2 thin FormData client

Transcript:
same Composer draft

Run:
explicit later submit
```

---

# 34. Semantic Drop · donor position

Semantic Drop当前不是找新的 third-party library。

它已有 LCOS pure machine + Huabu hit mechanics。

Donor主要用于：

```text
feedback quality
destination visual treatment
hover/dwell motion
```

而不是：

```text
drop state owner
```

TapNow/Spatial可做 visual/interaction donor。

---

# 35. Donor Retirement Matrix

## RETIRE `LcosComposerShell`

替代后删除/停止生产。

## RETIRE hardcoded `surface:left-dock / bottom-dock`

保留 pure Drop FSM。

## RETIRE duplicate 4px Reference slop

统一 Huabu threshold policy。

## REJECT new ActionCapabilityRegistry

用 pure resolver。

## REJECT whole CopilotKit Composer

只 lift recorder。

## REJECT bundle copy

LibTV/Lovart/TapNow只做 provenance/design。

## REJECT second radial interaction owner

Orbit只做 geometry。

---

# 36. OSS Copy / Lift Rules

每个实际 lift必须在第 04 册写：

```text
UPSTREAM:
repo
commit
file

LICENSE:
...

KEEP:
...

CHANGE:
...

DO NOT COPY:
...

LOCAL DESTINATION:
...

UPGRADE CHECK:
...
```

不是：

```text
“用了 Orbit”
```

就结束。

---

# 37. Orbit final Copy/Lift candidate

## UPSTREAM

```text
zumerlab/orbit
9b8906713a9e8d5fb48e04df824401c65acf6a16
```

## Relevant

```text
src/scss/_radial-layout.scss
src/scss/_satellite.scss
```

## KEEP

- angle distribution math；
- CSS custom property geometry；
- satellite transform formula。

## CHANGE

- selector namespace；
- LCOS token；
- button size；
- interaction class；
- TypeScript/React rendering。

## DO NOT COPY

- color themes；
- demos；
- unrelated shapes；
- global package visual identity。

---

# 38. Copilot recorder final Lift candidate

## UPSTREAM

```text
CopilotKit/CopilotKit
3472104d06eb53ae9d23541d8b60ff81c0c7684a
```

## FILE

```text
packages/react-core/src/v2/components/chat/CopilotChatAudioRecorder.tsx
```

## KEEP

- MediaRecorder setup；
- supported MIME resolution；
- cleanup；
- waveform sampling；
- recorder ref API；
- error classes concept。

## CHANGE

- Tailwind namespace；
- LCOS styles；
- product-state adapter；
- error surface；
- tests aligned LCOS browsers。

## DO NOT COPY

- whole ChatInput；
- providers；
- chat semantics。

---

# 39. Huabu upstream adoption matrix

T3必须检查 vendored pin 与 current upstream。

## ThreadChatInput

upstream exists，vendored pin absent。

Decision：

```text
ADOPT upstream direction
```

但同步策略由主协调/整体 Huabu sync决定。

不应：

```text
手工复制一份再起新名字
```

如果近期不做 full upstream sync，也应在 LCOS seam以同样 controlled-body pattern实现，而不是复制 upstream private ownership。

---

# 40. Huabu ChatInput upstream delta

upstream近 19 commits触及 ChatInput / performance tests。

第 04 册施工前需要：

```text
compare exact current upstream ChatInput
vs vendored ChatInput
```

理由：

我们要抽/包 generic input mechanics。

不能基于已经过时的 vendored body设计 wrapper，然后 upstream一同步又冲突。

---

# 41. Proprietary Design Measurement Protocol

正式测量不要求拿 proprietary source。

可以通过可观察 UI记录：

```text
default size
hover size
gap
offset
radius
opacity
transition duration
easing
visibility state
selected state
pressed state
density
```

记录成 LCOS implementation spec。

必须写来源：

```text
Donor:
screen/state
observed behavior
```

不能伪装成 vendor CSS原值。

---

# 42. Action Arc High-Fidelity target

当前 T3建议区间：

```text
action count:
3–5

satellite visual:
28–32px

hit region:
32–36px

icon:
14–16px

target gap:
8–12px

reveal:
120–180ms

motion:
opacity + small scale
low/no overshoot
```

这些要在第 04 册结合 T5 token最终冻结。

Orbit负责 angle/radius，不负责这些视觉 token。

---

# 43. Reference satellite High-Fidelity target

Lovart-derived：

```text
rest:
hidden / very low salience

hover/focus-within:
reveal

button:
~24px

icon:
~16px

offset:
4–6px

motion:
120–180ms opacity
```

点击：

```text
direct toggle or tiny menu
```

由 target policy决定。

反馈：

```text
badge/chip
```

不 toast。

---

# 44. Compact Composer High-Fidelity target

```text
local target anchor
no big sidebar
no big modal
```

Layout：

```text
reference strip/chips
prompt
compact tool row
send/run
```

Height：

```text
idle 1–2 lines
max 3–4
then internal scroll
```

Interaction：

```text
reveal no autofocus
reference pick keeps composer in place
voice inside composer
```

Visual donor：

```text
Lovart/TapNow
```

Mechanics：

```text
Huabu
```

---

# 45. Voice visual target

Recorder body不是“音频编辑器”。

只要：

```text
mic state
small waveform/activity
cancel
finish
transcribing
```

避免大独立 panel。

Copilot waveform可以保留 mechanic，但视觉应 LCOS化。

---

# 46. Design Token Boundary

第 04 册必须给具体 token，而不是内联 donor颜色。

候选 namespace例如：

```text
--lcos-local-bg
--lcos-local-border
--lcos-local-shadow
--lcos-local-radius
--lcos-local-action-size
--lcos-local-gap
--lcos-composer-max-width
--lcos-composer-max-lines
--lcos-motion-fast
--lcos-motion-local
```

是否新建这些 exact token，要先复用现有 Huabu token。

原则：

```text
已有 token够用
→ 不新增
```

---

# 47. Donor Replacement Tests

Action Arc：

```text
用一个简单 linear debug body替换 Orbit body
→ action semantics仍工作
```

若不行，说明语义耦进 visual。

Voice：

```text
用 fake recorder替换 Copilot recorder
→ transcription adapter可测
```

Composer：

```text
换 body
→ draft/reference/target仍存在
```

右键：

```text
换 menu styling
→ action policy不变
```

---

# 48. License Discipline

Permissive OSS lift：

- pin exact version/commit；
- 保留 required notice；
- 记录 source path；
- 不偷偷混 proprietary bundle code。

proprietary：

```text
只记录 observable design / architecture evidence
```

不复制代码。

---

# 49. Donor-specific Reject Reasons

## Whole CopilotKit
第二 chat/composer semantics。

## Whole Orbit package visual system
过大 blast radius，无必要。

## LibTV bundle
proprietary + provenance only。

## TapNow bundle
proprietary。

## Lovart bundle
proprietary。

## Spatial runtime
会制造第二 gesture/viewport owner。

## new homegrown radial menu
已有 Orbit。

## new homegrown recorder
已有 CopilotKit。

## new homegrown popover
已有 Huabu。

## new homegrown menu
已有 Huabu。

---

# 50. Donor-to-File Preliminary Mapping

最终 exact file在第 04 册冻结。

当前映射：

```text
Action Arc
→ Huabu Lcos composition area
→ CanvasFloatingPopover
→ LCOS body + Orbit geometry

Composer
→ replace LcosComposerShell
→ controlled body
→ ComposerDraft owner

Voice
→ web-gen2/huabu boundary adapter
→ Copilot recorder primitive
→ backend voice client

Right click
→ Canvas host seam
→ Popover/DropdownMenu

Reference
→ existing referenceController
→ Composer draft integration
→ Reference Pick presentation
```

---

# 51. Maximum Failure Blast Radius

## Action Arc donor failure

允许影响：

```text
radial layout / Arc appearance
```

不允许影响：

```text
Selection
pointer
target identity
```

## Composer donor failure

允许：

```text
input body render
```

不允许：

```text
draft disappear
Reference mutate incorrectly
Run wrong receiver
```

## Recorder failure

允许：

```text
voice input unavailable
```

不允许：

```text
text composer unavailable
draft cleared
```

---

# 52. Cross-thread Donor Handoff

## T1

Spatial/takeover visual anchor info。

## T2

safe rect/floating boundary。

## T4

Skill/WorkView visual donor adoption。

## T5

正式 visual body/LCOS token。

## T6

Run/Receiver/Voice client与 Core contract。

---

# 53. Engineering Status Definitions

## DIRECT_USE

现成机制直接消费，不 fork。

## WRAP

保留内部实现，只加 LCOS adapter。

## LIFT

从 permissive OSS 拿一段独立 primitive，记录 provenance。

## REFERENCE

只做行为/架构参考。

## REJECT

即使可用，也因 owner/架构不适配拒绝。

---

# 54. Visual Status Definitions

## HIGH_FIDELITY_DONOR

允许认真测量并复现成熟 interaction/layout solution。

## PARTIAL_DONOR

只拿局部。

## STYLE_REFERENCE

只参考气质，不作为 exact spec。

## REJECT

与 LCOS语义/身份不合。

---

# 55. T3 final donor architecture

```text
                         ┌─────────────────────┐
                         │ Local Core          │
                         │ Run/Receiver/Voice  │
                         └──────────┬──────────┘
                                    │
                         ┌──────────▼──────────┐
                         │ LCOS semantics      │
                         │ Target/Reference    │
                         │ Action resolver     │
                         └──────────┬──────────┘
                                    │
              ┌─────────────────────▼────────────────────┐
              │ Huabu mechanics                          │
              │ pointer / selection / geometry / popover │
              └─────────────────────┬────────────────────┘
                                    │
             ┌──────────────────────▼───────────────────────┐
             │ Replaceable bodies                           │
             │ Orbit Arc / Huabu input / Copilot Recorder   │
             └──────────────────────┬───────────────────────┘
                                    │
             ┌──────────────────────▼───────────────────────┐
             │ High-fidelity visual policy                  │
             │ Lovart / TapNow / Spatial → LCOS tokens      │
             └──────────────────────────────────────────────┘
```

---

# 56. Retirement Order

不能先删旧壳再接新 owner。

建议：

```text
1. ComposerDraft owner
2. controlled new Composer body
3. Reference draft migration
4. target-local placement
5. Voice/Run wiring
6. browser acceptance
7. retire LcosComposerShell

Drop:
1. real target resolver
2. commit adapter
3. preview body
4. acceptance
5. retire left/bottom hardcode
```

---

# 57. No-New-Wheel Proof

T3完成后，施工者应能回答：

```text
为什么没新 PointerRouter？
Huabu已有。

为什么没新 Popover？
Huabu已有。

为什么没新 ContextMenu library？
Huabu已有。

为什么没新 Recorder？
CopilotKit MIT已有。

为什么没新 radial geometry？
Orbit MIT已有。

为什么没新 Run API？
Core已有。

为什么没新 Voice API？
Core已有。

为什么没复制 Lovart？
它是 visual donor，不是 code donor。

为什么没复制 LibTV bundle？
只用于 wheel provenance。
```

---

# 58. Current Adoption Decisions

```text
ADOPT:
Huabu pointer
Huabu floating
Huabu popover/menu
Huabu interaction phase
LCOS referenceController
Core Run/Receiver/Voice

WRAP:
Huabu ChatInput generic mechanics
Huabu upstream draft/body pattern

LIFT:
Orbit radial geometry
CopilotKit AudioRecorder

HIGH_FIDELITY:
Lovart
TapNow
Spatial

REFERENCE/WHEEL PROVENANCE:
LibTV

RETIRE:
LcosComposerShell
Phase-A hardcoded Drop destination

REJECT:
second pointer
second selection
whole CopilotKit composer
whole proprietary code
homegrown radial
homegrown recorder
new context menu framework
```

---

# 59. Entry to Source-Level Construction Plan

第 03 册已给出足够 donor authority，下一册不得再写：

```text
“可考虑使用 Orbit”
“参考 Lovart”
“可以复用 Huabu”
```

第 04 册必须直接变成：

```text
TARGET_FILE
EXISTING_OWNER
DONOR_FILE
PROPS
JSX
CSS/TOKEN
STATE
MOTION
COPY/LIFT RULE
RETIREMENT
TEST
```

---

# 60. Coordinator Summary

T3 donor 深挖后的核心结果不是“找到了更多东西要加”。

而是：

> **把原本需要自研的范围进一步砍小。**

真正需要 LCOS 写的只剩：

```text
semantic resolver
controlled draft adapter
host callback
typed Core clients
thin body composition
LCOS token styling
```

其余通用难题都有现成成熟 owner / wheel。

这是 V6 反惰性策略在 T3 的最终价值。


---

# Appendix A · Donor 逐能力施工字段模板实例

## A01 Action Arc

```text
Donor:
Orbit + Lovart + TapNow + Spatial

Feature:
Action Arc

ENGINEERING_STATUS:
Orbit = LIFT
Huabu Floating = DIRECT_USE

VISUAL_STATUS:
Lovart/TapNow = HIGH_FIDELITY
Spatial = HIGH_FIDELITY_MOTION

Borrow:
- radial geometry
- compact local density
- hover/reveal hierarchy
- low overshoot motion

Do not borrow:
- proprietary code
- Orbit global theme
- second pointer owner

Canonical owner:
LCOS target/action semantics

Implementation source:
Huabu + Orbit MIT primitive

Replacement boundary:
ActionArcBody

Maximum failure blast radius:
local action presentation
```

## A02 Composer

```text
Donor:
Huabu + Lovart + TapNow

ENGINEERING:
Huabu input mechanics WRAP

VISUAL:
Lovart/TapNow HIGH_FIDELITY

Canonical:
LCOS Composer draft

Replacement:
CompactComposerBody
```

## A03 Voice

```text
Donor:
CopilotKit

ENGINEERING:
LIFT AudioRecorder

VISUAL:
TUNE

Canonical:
Composer draft + Core transcription

Blast:
voice modality only
```

---

# Appendix B · Anti-Copy Review

每次 donor implementation review 检查：

```text
是否包含 proprietary minified source？
有 → reject。

是否 exact OSS upstream？
无 → 继续 provenance。

license 是否明确？
无 → 不 direct use。

是否把 donor store一起带入？
是 → 检查是否第二 truth。

是否能把 donor body删掉而 semantics仍可运行？
不能 → coupling过深。

是否 source plan只写“参考”？
是 → 继续拆 implementation spec。
```

---

# Appendix C · Visual Measurement Table Skeleton

正式浏览器/截图测量填：

| Feature | State | Width | Height | Radius | Gap | Opacity | Duration | Easing | Notes |
|---|---|---:|---:|---:|---:|---:|---:|---|---|
| Arc satellite | rest | TBD | TBD | TBD | TBD | TBD | — | — | |
| Arc satellite | reveal | TBD | TBD | TBD | TBD | 1 | TBD | TBD | |
| Reference satellite | rest | ~24 | ~24 | TBD | — | low | — | — | donor observation |
| Reference satellite | hover | ~24 | ~24 | TBD | 4–6 | 1 | 120–180 | TBD | |
| Composer | idle | TBD | 1–2 lines | TBD | TBD | 1 | TBD | TBD | |
| Composer | expanded | TBD | 3–4 lines | TBD | TBD | 1 | TBD | TBD | |
| Voice | recording | TBD | TBD | TBD | TBD | 1 | TBD | TBD | |

数值未观测到的必须写 TBD，不能模型脑补精确 donor值。

---

# Appendix D · Upstream Pin Ledger

```text
Huabu vendored:
58339e269b784728d67730c70bfe7792cae2457d

Huabu observed:
dc128fff2d37b5481ec305070a7e86d3de85f7d2

Orbit:
9b8906713a9e8d5fb48e04df824401c65acf6a16
MIT

CopilotKit observed:
3472104d06eb53ae9d23541d8b60ff81c0c7684a
MIT
```

这些是 planning evidence pin。

是否把依赖写入 package lock，由第 04 册最终 construction decision决定。

---

# Appendix E · Why not import one giant design system

看起来最省事的方案：

```text
import whole donor design system
```

实际会引入：

```text
new tokens
new button
new popover
new menu
new focus policy
new portal
new theme
new z-index
```

而 Huabu已经有这一整层。

因此 T3只采用“缺失 primitive”。

这也是为什么：

```text
Orbit radial = yes
Orbit whole style system = no

Copilot recorder = yes
Copilot whole chat input = no
```

---

# Appendix F · Maintenance / Upgrade Rule

以后 donor升级：

## Orbit

只 compare：

```text
radial layout
satellite geometry
```

不需要追所有 themes。

## CopilotKit

只 compare recorder file及必要依赖。

## Huabu

因为是 construction host核心：

```text
持续 compare upstream
```

尤其 ChatInput/ThreadChatInput/Floating。

## Proprietary donor

视觉升级不是 package upgrade。

仅在需要重新校准 UI时重新观察。

---

# Appendix G · Accessibility

High-fidelity不能以牺牲 accessibility换“像 donor”。

Arc action：

```text
button semantic
aria-label
focus-visible
keyboard reachability
```

Context menu：

继续 Huabu menu keyboard。

Composer：

textarea / tool buttons标准 focus。

Voice：

record/cancel/finish有明确 aria state。

如果 donor视觉 hit target过小：

LCOS允许保留视觉 24px，同时把实际 hit region扩到 32–36px。

这是合理 product fit 修改。

---

# Appendix H · Interaction LOD

T3 donor body必须能响应：

```text
screen-space LOD
takeover
WorkView safe rect
```

而不改变 semantics。

Action Arc在极低 LOD：
可能不 reveal，或 anchor takeover mark。

Composer：
只有明确 target可交互时出现。

Reference badge：
可按 LOD降细节，但 Reference truth不消失。

---

# Appendix I · Visual identity protection

高保真借的是：

```text
解法
```

不是：

```text
Lovart品牌
TapNow品牌
Spatial品牌
```

最终必须用：

```text
LCOS icon family
LCOS token
LCOS typography
LCOS color semantics
```

所以“高保真”与“产品身份独立”并不矛盾。

---

# Appendix J · Final Donor Review Checklist

每个施工 card必须有：

```text
Donor
Feature
ENGINEERING_STATUS
VISUAL_STATUS
Borrow
Do not borrow
Canonical owner
Implementation source
Replacement boundary
Maximum failure blast radius
Exact source
License
Version/commit
Acceptance
Retirement
```

缺任意一项，不允许写“donor已经审计完成”。
