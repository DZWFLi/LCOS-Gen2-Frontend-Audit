# LCOS Gen2 · T4 第四路
## 模块化职责与 Donor 映射
### 吸收 Spatial 新资料 + Context Atlas Astra 冻结补丁 · 2026-09-05

> 目的：把第四路“到底管什么、哪些直接复用 donor、哪些不能越界”重新拆成可施工模块。
>
> 上位 authority：
> - `LCOS_Gen2_最终产品冻结_无损分发稿_V2_20260905`
> - `LCOS_Context_Atlas_Astra空间质感_收敛冻结补丁_20260905`
>
> 新增 donor 证据：
> - `Spatial_画布形态与动效收敛包_含帧图_20260905`
> - `GPT6Astra地图形态拆解_含帧图_20260905`

---

# 0. 一句话

第四路不再按“功能名”堆任务，而按九个模块施工：

```text
M0 Project Session
M1 Professional Workbench / Unified Work View
M2 Assembly
M3 Context Atlas Entry + Detail Lifecycle
M4 Context Professional Instruments
M5 Workflow Deep Work
M6 Skill Builder + Run Review
M7 Spatial/Workbench Boundary
M8 Archive Work View
M9 Shared Donor Adapter Layer
```

每个模块都必须遵守：

```text
Product semantics
→ canonical owner
→ mature donor primitive
→ thin adapter
→ acceptance test
```

禁止：

```text
先写 UI
→ 再找数据
→ 再补语义
```

---

# M0 · Project Session

## 用户感知

用户打开一个 LCOS Project 后：

- 系统知道“我现在就在这个 Project”；
- Main / Context / Workflow 都属于它；
- 切 Surface 不等于重新开 Project；
- Workbench 里的专业窗口不会因为切 Surface 全丢。

## T4 管什么

- Active Project Session 生命周期；
- canonical `projectId` 从 Launcher 进入；
- one Project Session → one Workbench manager；
- one runtime object；
- one SurfaceRegistry。

## 已有

Core 已有：

```text
Project Catalog
GET /projects
POST /projects
Project Summary
Visual Profile
```

web-gen2 已有 `CoreProjectClient`。

## 不造

```text
第二 Project store
projectId = workspaceId
projectId = canvasId
env PROJECT_ID 做正式 owner
```

---

# M1 · Professional Workbench / Unified Work View

## 用户感知

任何大工作界面统一遵守：

```text
Float
Dock
Undock
Resize
Move
Horizontal / Vertical composition
Close
Restore
Immersive
```

并且可以同时存在多个：

```text
Conversation Preview
Assembly
Context Detail
Evolution
Workflow Deep View
Skill Builder
Run Review
Archive
Web/PDF/HTML
```

## T4 管什么

- 多专业窗口的 screen-space topology；
- stable panel identity；
- panel close/restore；
- Protected Canvas；
- Workbench 与 ProjectSession 生命周期；
- 不让位置变化导致 body 重建/数据复制。

## Engineering donor

当前第一候选：

```text
Dockview Core/React
```

职责：

```text
panel/group
split
float
dock/undock
resize
layout
stable renderer
```

## Spatial 给什么

Spatial 新包最值得直接吸收的是“感觉与行为词典”：

```text
focus 时周围让路
原位 morph
present / restore
drag 时邻居聚散
Stack / scatter / pull-out / settle
低 chrome
低 overshoot
```

特别是：

```text
打开 ≈250ms 内
原位 frame → presented frame
背景退避
关闭为可倒带的反向转场
```

这些不是新的窗口 manager，而是 Workbench/Preview 的 motion grammar。

## 不造

```text
MainLayout 自制 IDE manager
第二 overlay manager
第二 animation store
每个工具自己一套窗口
```

---

# M2 · Assembly

## 用户感知

从任何当前现场打开项目共同的 Assembly：

```text
Project materials
Capture
Sources
Skills
```

找东西、预览、拖出来，直接作用到当前 target。

## T4 管什么

- Source Bay UX；
- source adapters；
- Preview；
- Masonry / list / search；
- drag source → canonical AssemblyApply；
- target context；
- dedicated / docked / quick 三种呈现深度。

## Lovart 最适合给什么

```text
material browser
Masonry / waterfall
thumbnail hierarchy
source grouping
dense-but-readable asset browsing
```

视觉/交互借鉴，不复制 proprietary business model。

## 当前 Core 已有

```text
Warehouse
Capture staging
Resource source
Skill Catalog
AssemblyApply
```

## 唯一明显红项

```text
Skill usage-binding canonical mutation
```

必须 Core/T6 定义。

T4 禁止假成功。

---

# M3 · Context Atlas Entry + Detail Lifecycle

## 最新产品心智

Context Atlas：

> 一张有轻微高度和纵深的项目 Context 地图。

不是：

> 3D 信息城市。

点 / 线 / 面：

```text
面 = Atlas
线 = Evolution / Wave
点 = Context Spatial Canvas
```

## T4 管什么

T4 不是 Atlas renderer 主 owner。

T4 主要负责：

```text
Atlas 作为大工作态如何进入
点击 region 后的临时详情
临时详情 → Evolution
临时详情 → Context Spatial Canvas
临时详情 → Work View
这些状态如何和 Workbench 共存
```

## T1 / Spatial owner 负责更多

```text
region geometry
轻2.5D
world/screen projection
LOD
Pin / Locator presenter
Focus framing
camera mechanics
```

## Astra 给什么

只参考：

```text
轻 2.5D massing
克制 AO / contact shadow
低信息密度
world geometry
+ screen-readable Pin / Label
```

不参考：

```text
城市隐喻
道路
3D Relation
3D 时间地层
自由 Orbit
人物车辆
复杂 PBR
```

---

# M4 · Context Professional Instruments

## 用户感知

Atlas 负责总览。

真正需要深读时进入更合适的专业视图：

```text
Evolution / Wave
Relationship
Provenance / Source
Detail inspection
```

## 最新冻结

Evolution / Wave：

```text
继续 2D 优先
```

因为：

```text
顺序
range
compare
trim
branch
revision
before/after
```

二维阅读更舒服。

## T4 管什么

- 这些专业 body 如何进入统一 Workbench；
- target/session；
- body state continuity；
- 与 Atlas 的来回；
- 与 Assembly / Preview 并存。

## 不做

```text
把 Wave 叠进 2.5D Atlas
把 Relationship 做成 Atlas 默认道路
把 Provenance 做成 3D 地层
```

---

# M5 · Workflow Deep Work

## 用户感知

Workflow Surface 本身仍是一级自由工作现场。

专业深查只在需要时打开：

```text
某一工作轮次
某个结果
Review
logs
tool calls
provider
retry
```

## T4 管什么

- Workflow deep body；
- 打开/关闭/定位；
- 与 Run Review；
- 与 Assembly；
- 与 Skill；
- 与 Project Workbench 共存。

## 不做

```text
第二 Workflow DAG engine
把资料 drop 自动变成 Step
把 runtime truth 存 UI
```

---

# M6 · Skill Builder + Run Review

## Skill Builder

用户编辑的是：

```text
Skill Artifact
```

不是 Harness Run。

T4 管：

```text
Skill Builder professional body
版本/结构/子Skill的专业 UI
Work View lifecycle
Assembly entry
```

LibTV / Skill donor：

- 优先复用已有 skill 结构/展示/组织 primitive；
- provider/runtime 仍由 T6。

## Run Review

T4 管：

```text
Run结果怎么看
Review怎么开
Artifact Return怎么呈现
Accept/Reject/Retry入口怎么在当前工作现场出现
```

不管 Run engine 本身。

---

# M7 · Spatial / Workbench Boundary

这是第四路非常关键的边界模块。

## Workbench 打开时

允许：

```text
Canvas visible rect 变小
HUD避让
Pin避让
Locator避让
Composer避让
Action Arc避让
```

禁止：

```text
camera 自动移动
fitView
setViewport
node 自动重排
```

只有用户显式：

```text
Focus
```

才允许 camera framing。

## T4 输出

通用 occupancy：

```text
occupied rect
safe rect input
floating collision rect
```

## T1 消费

```text
activeSpatialViewport
Pin / Locator
Minimap
Focus framing
edge HUD
```

T1 不应依赖 Dockview API。

---

# M8 · Archive Work View

## 用户感知

```text
按归档日期
Masonry
单选
多选
Restore
Restore All
```

## T4 管什么

- Archive professional body；
- Masonry browsing；
- selection；
- restore affordance；
- Workbench lifecycle。

## Lovart donor

Masonry / asset browsing 非常适配。

## 仍缺

current Core 还没确认正式 Archive canonical lifecycle owner。

因此：

```text
UX READY
CORE TRUTH OPEN
```

T4 不用 hidden array/localStorage 冒充。

---

# M9 · Shared Donor Adapter Layer

这一层是“模块化”的关键。

目的不是造一个超级框架。

而是让 donor 随时可替换。

## 只允许很薄的 adapter

例如：

```text
WorkbenchLayoutAdapter
AssemblySourceAdapter
ContextEvolutionProjection
SkillBuilderProjection
ActiveSpatialOccupancyAdapter
```

## donor failure blast radius

换 Dockview：

```text
只换 Workbench layout adapter
```

换 Lovart 风格：

```text
只换 presentation/body composition
```

换 Spatial motion recipe：

```text
只换 motion tokens/transition wrapper
```

不能波及：

```text
Core truth
SurfaceRegistry
ProjectionBinding
Run truth
Skill truth
AssemblyApply
Huabu Camera
```

---

# 1. Spatial 新包对第四路最有价值的五件事

## 1. 原位 morph

Spatial 明确存在 item canvas frame → presented frame 的 transition family。

LCOS 可以把它变成统一 grammar：

```text
node / preview
→ professional view
```

不是 pop modal。

---

## 2. Focus 不是目标变大，而是周围让路

Spatial 的重点不是“放大”，而是：

```text
背景轻退
目标留在原位逻辑上成长
```

对 LCOS：

```text
Focus preview
temporary detail
open Work View
```

都值得复用这种感觉。

---

## 3. Drag 后邻居让位 / settle

这对：

```text
Assembly落位
Context整理
Workflow材料整理
Stack/scatter
```

都非常适合。

但最终 geometry/layout solver 仍归 Huabu。

T4 只消费/触发动效，不造第二 layout truth。

---

## 4. Stack / Folder 分开

Spatial 证据明确：

```text
Folder = 独立嵌套画布
Stack = 临时组织
```

这个区分和 LCOS 很有价值：

```text
Collection / long-lived group
≠ transient visual stack
```

不能因为长得都像一摞卡就合并语义。

---

## 5. 高级感来自留白和层级，不是功能密度

实读帧里：

```text
51%留白
73%留白
84%留白
```

都存在。

对 LCOS 专业工作区的启发：

```text
不要为了“显示信息完整”把每个 Work View 塞满
```

这与最新 Context Atlas 的“总览优先、专业信息按需进入”完全一致。

---

# 2. Context Atlas 新补丁对第四路最大的五个影响

## 1

Atlas 不再被理解为“Context 全功能工作台”。

它只是总览。

## 2

Evolution / Relationship / Provenance 不再默认作为 Atlas 上常驻层。

它们是专业 lens / Work View。

## 3

Atlas 点击 region：

```text
先临时详情
```

而不是：

```text
立即创建长期子Canvas
```

这个“临时详情 lifecycle”归 T4 重点处理。

## 4

Work View 打开/resize：

```text
不动主 Camera
```

继续硬冻结。

## 5

Glyth / Pin / Label：

```text
world anchored
screen readable
```

但视觉 presenter更多归 Spatial/T1；T4只保证临时详情/Work View不把它们挡死。

---

# 3. Donor 不按项目整包收，而按 mechanic 收

正确：

```text
Spatial
→ focus / morph / stack / settle / drag reflow / low chrome

Lovart
→ material browsing / masonry / source hierarchy

TapNow
→ marker / Pin / fixed-screen label / HUD / hit priority

Astra
→ Context Atlas 2.5D visual language only

Dockview
→ multi professional window mechanics

Huabu
→ sole spatial physics
```

Leap / LibTV / 其他 donor：

继续按各自已有源码证据做 mechanic census。

禁止：

```text
“这个功能像 Lovart”
→ 整套照搬 Lovart

“这个页面像 Spatial”
→ 整套照搬 Spatial
```

---

# 4. 第四路最终模块化验收

每个模块必须单独回答：

```text
1. 用户在做什么？
2. canonical truth是谁？
3. T4只拥有哪一层？
4. donor primitive是什么？
5. adapter在哪？
6. 哪些文件允许改？
7. 哪些文件明确不碰？
8. donor挂了最大影响范围？
9. browser acceptance怎么验？
10. 是否产生第二套 truth/store/camera/layout？
```

第10项只要答案是“是”，默认退回。

---

# 5. 当前最值得继续深挖的顺序

```text
P1 Workbench prototype
- Dockview + Protected Canvas
- stable body
- Float/Dock/Undock
- no camera mutation

P2 Context temporary detail lifecycle
- Atlas region click
- detail
- Evolution
- Context Canvas
- Back/Restore

P3 Assembly Source Bay
- Lovart visual donor
- existing canonical adapters

P4 Context professional bodies
- Evolution 2D
- Relationship
- Provenance

P5 Skill Builder / Run Review

P6 Archive
- waiting Core archive truth
```

---

# 6. 最终口令

第四路以后不再说：

> “我要做 Work View、Assembly、Context、Workflow、Skill。”

而要说：

> **“我要把九个独立模块接成一个稳定的专业工作系统，每个模块只拥有自己该拥有的层，底下真实数据和空间事实都继续归现有 owner。”**

这样才能既模块化，又不会为了模块化再造九套框架。
