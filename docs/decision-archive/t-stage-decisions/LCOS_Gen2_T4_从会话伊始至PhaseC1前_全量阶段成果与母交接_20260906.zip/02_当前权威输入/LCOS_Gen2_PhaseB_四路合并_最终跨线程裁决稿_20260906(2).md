# LCOS Gen2 · Phase B 四路合并 · 最终跨线程裁决稿
## 基于 T1 / T2 / T4 / T6 阶段 A 对账，回填 T3 交互冻结，并为 T5 最终视觉方案提供稳定输入
日期：2026-09-06
状态：`COORDINATOR PHASE-B DECISION`

> 本稿不是 production code 施工稿。
> 本稿把 T1（空间）、T2（导航）、T4（专业工作）、T6（Core/Truth）阶段 A 结果合并成唯一产品/owner 答案。
> 从本稿开始，已裁决产品语义不再由专项线程重新解释；T1/T2/T3/T4/T6 可以进入源码级施工方案；T5 可以开始最终视觉方案。

# 0. 总判断

四路现在已经能拼成一套清楚的分层：

- T1 = 空间结果、几何、布局、HUD、Huabu mechanics
- T2 = 进入、返回、定位、Railway、Surface switch、Arrival
- T3 = 手势、Composer、Reference、Arc、Semantic Drop 的用户语言
- T4 = Context / Workflow / Assembly / Skill / Professional Window 的工作方式
- T5 = 最终视觉形态、动效、密度、LOD、Donor 高保真采用
- T6 = canonical identity、membership、mapping、projection、archive、recovery

共同结论：

> 不能再用 Scope / Workspace / Presentation / Frame 中任何一个旧实现，把 Collection、Context、Workflow、Worksite、Work View、Colony 一次性包掉。

# 1. D01 · Scope 不再拥有自己的长期 canonical identity

Scope 当前只表示：

> “这一次只处理谁。”

它可以是 current target set、selection-derived range、temporary work boundary、Agent/Run 当前使用范围。

它不再是 Collection、Workspace、Worksite、child canvas、ownership boundary、permanent navigation destination。

T4 之前的关键问题“Scope Save / Commit 到底保存成什么”，现在正式关闭：

> **不保存成 durable Scope。**

如果用户想把当前范围长期留下，必须明确转成真实产品对象：

- 想长期把这些算一组 → Collection
- 想把这段工作正式留下 → Workflow
- 想开另一张以后还能回来的桌子 → Worksite
- 只是本轮 Agent / Run 使用 → Scope 结束后消失，执行历史照常保留

因此不需要 DurableScope / ScopeContainerEngine / ContextScopeDB / WorkflowScopeDB。

旧 ScopeKind / CanvasScope / scopeId / parentScopeId / camera/layout 只按字段逐项兼容迁移，不再整体作为产品 owner。

# 2. D02 · Collection 正式拆成三层

## 2.1 Collection identity / nesting

Collection 本身是 canonical project object。Collection 可以包含 Collection。

Collection → Collection 才属于 structural cycle / depth guard。

## 2.2 Entity → Collection membership

普通项目对象加入 Collection：

> 是 durable、many-to-many canonical membership。

不是 ownership transfer。

对象仍属于 Project；同一对象可属于多个 Collection；Archive 不删除这个 membership；删除 projection 也不删除 membership。

## 2.3 Collection presentation

Collection collapsed ↔ expanded、Frame、fan-out、Grid、Stack、Masonry、member placement 全部属于 Presentation / Huabu spatial layer，不属于 canonical membership。

## 2.4 Core 约束

T6 必须提供一个独立于 Presentation / ProjectionBinding 的 canonical membership transaction。

但本稿不提前冻结“一定新建某张表”。T6 源码施工方案必须先判断现有 Relation / membership infrastructure 能否无损承接；只有现有 owner 无法满足 many-to-many、Archive survival、batch atomicity、Undo、idempotency、delete cascade 时，才新增专用持久化。

# 3. D03 · Collection Drop：左拖与右拖都可以加入，但空间结果不同

## 左拖进眼前可见的 Collection

左拖对象身体 → visible Collection host → Add Collection membership → 当前 projection 留在 drop 位置 → Huabu 可做 host reflow。

不回弹。

## 右拖到 Collection

右拖最终定义得更精确：

> “不搬当前对象，只把同一个对象的语义使用权 / 归属关系给目标。”

这是 transport semantics，不代表目标关系一定 temporary。

因此：

Right-drag ghost → Collection → Add Collection membership → 当前 source projection 从头到尾不动。

Collection 的 target-natural semantic 只有 membership，所以不需要 chooser。

Relation handle → Collection 始终是 Project Relation，严格分开。

T3 后续不要再把 Right-drag 写成“temporary borrow”，而要写成：

> source spatial placement 不动；目标按自己的唯一 natural semantic 建立关系。生命周期由目标语义决定。

# 4. D04 · Visible Host / Remote Target 正式二分

Visible Host，例如 expanded Collection、Gallery、Grid、Stack、Masonry、当前 Surface 中真实空间 host：

- 左拖成功 → 当前 projection 留在目标位置。

Remote Target / Portal，例如 Glyth、Railway 远端 destination、Child Worksite portal、另一个未打开 Worksite：

- 左拖成功 → canonical semantic / mapping / target projection 更新；source 当前 projection 留在 source scene。
- 右拖 → source 从头到尾不移动。

Relation handle：

- 只建立 Project Relation，不改变空间位置。

# 5. D05 · Context 顶层 Atlas 不建立人工 membership truth

Context 的本质：

> 这个项目到现在知道了什么。

默认 Atlas 的按时间、按事情、来源、演进、关系，都是对整个 Project canonical truth 的派生理解。

因此：

> **顶层 Context Surface 不维护一份“哪些对象属于 Context”的 canonical membership 列表。**

否则 Context 会退化成人工文件夹。

时间块 / 事情块默认都是 derived view；点击进入 temporary detail，仍不创建 durable membership。

只有用户明确“把这一块长期留下”时，才产生真实持久化，并明确变成 Collection、Workflow、Long-term Worksite，或现有 canonical Context artifact。不能偷偷创建 Context Scope。

Agent 事情地图仍是派生视图；拖/合并/拆开只是修正 Agent 分组理解，只有明确“固定”后才写长期 truth。

# 6. D06 · Workflow 拥有 durable composition，但不等于 canvas

Workflow 是用户明确从真实现场抽出来的一段长期独立工作。

因此正式 Workflow identity 必须有 durable working composition，至少能引用输入材料、Conversation/Glyth、Result、关键一轮动作、Review、Skill usage 等正式采用的对象。

Workflow 的“包含谁”必须与“这些东西现在摆哪里”分开。

接受：

semantic composition ≠ Presentation layout ≠ ProjectionBinding。

但内部 contract 名称不必现在就叫 SurfaceCompositionV1，源码方案优先复用现有 typed relation / membership substrate。

Workflow identity 可以存在而不自动拥有 child canvas。只有用户真的选择“单独开桌长期做”，才 materialize Worksite。

# 7. D07 · Worksite 保留产品心智，瘦身 Workspace，不另造平行世界

Long-term Worksite 是正式产品概念：

> 一份以后还能回来继续的长期工作现场。

Core 应保存 identity、projectId、name/intent、stable canvasId、durable working-set refs、home/origin Surface 或 parent worksite ref、lifecycle、timestamps。

Huabu 保存 camera、node geometry、layout、spatial history、frame/body geometry。

优先沿用 / 迁移旧 Workspace identity，逐步瘦身成新的 Worksite contract。

禁止“旧 Workspace 留着 + 再新建一套 Worksite system”，也禁止把旧 Workspace interface 原样复活。

# 8. D08 · Worksite materialization 只由明确用户动作触发

禁止内容数量、停留时间、首次点击、创建 Collection 等隐式规则自动创建 Worksite。

唯一规则：

> 用户明确表达“这件事我要单独长期开桌继续”。

Agent 可以建议；用户明确采用后才创建。

# 9. D09 · Back stack session-only；Worksite 本身 durable

- Worksite identity = durable
- 当前 active Worksite = project session 可恢复
- Back stack = session navigation state

重启后可恢复最近 active Worksite，但不要求恢复完整历史 Back stack。Railway 负责重新去其它长期现场。

不复活 Scope.parentScopeId / scopePath 作为导航真相。

# 10. D10 · Conversation Child Canvas = Worksite 的明确案例

Glyth 双击进入 same Conversation deep work。

- Conversation child canvas = nested Worksite。T6 管 identity/persistence，T2 管 Enter/Back/Arrival，T1 管 spatial，T4 管与其它专业区域组合。
- Conversation Preview = Professional Window。
- Assembly = Project-shared Professional Window，target = current Conversation。

三者共享 Conversation identity，但绝不使用同一 state owner。

# 11. D11 · Colony 当前版本采用 derive-only contour

T1 与 T6 已经追回 R3-A exact history。

当前真正需要保留：

- create
- explicit add
- sticky membership
- peel
- rescope
- dissolve
- organic field

Colony 当前定义：

> 当前 Surface / Worksite 中一片长期可恢复的空间组织。

membership 可以持久，但属于 Surface-local Presentation semantic，不是 Project canonical domain membership。

当前 milestone：

> contour 只从 Huabu 当前 member geometry 派生。

Core 不再写 contour points。

Rescope 表示用户重新圈定 membership，不表示用户永久编辑 contour 曲线形状。

authored soft contour 当前不做。不提前加 schema、binding、authored contour object、mode。未来真实使用证明必要再单独评估。

Peel 的 threshold / settle / neck / tether / feedback 由 T1 负责；T6 只接受最终 membership change；T5 最终决定 morphology。

# 12. D12 · 同一 canonical entity，同一 canvas 当前只允许一份真实 projection

T6 提出的 same-canvas multi-instance 是真实 contract 风险，但当前没有足够产品需求。

所以：

same entity + same canvas + same spatial kind = one authoritative projection。

跨不同 canvas 可以有不同 projection。

如果用户真的需要同一张桌面出现第二次，当前使用 proxy、Reference、derived preview、mirror body，而不是新增第二份 authoritative ProjectionBinding。

当前 composite key 不需要为了假设性需求加入 instanceId。

# 13. D13 · Archive lifecycle 与事件顺序

Archive 是 canonical lifecycle，不是 T1 hide，也不是第二仓库。

## Archive

用户 Archive
→ Core 标记 archived / archivedAt
→ membership / relation / history 保留
→ ProjectEvent: archived
→ active Main projection eligibility = false
→ Reconciler / Projection layer 移除 Main active projection
→ T1 不保存旧 x/y

## Archived state

对象仍然 Searchable、Referenceable、Agent-readable，Context/Workflow 可引用，但 read-only。

## Restore

Core Restore
→ archived state clear
→ ProjectEvent: restored(batch)
→ active Main projection eligibility = true
→ Projection/Reconcile 建立当前 projection
→ T1 用 Huabu fresh layout

不读取 archive 前旧 x/y。

## Archived Search / Focus

T2 显示 Archived 状态 / archive date，可打开 Archive viewer；不自动 Restore，也不定位幽灵坐标。

Restore 必须是明确动作。

# 14. D14 · Work View occupied/safe rect contract

T4 必须对外只提供一套公共 screen-space occupancy seam。

语义建议：

ProfessionalWindowEnvironment {
  occupiedRects
  safeRect / safeInsets
  activeRegions
}

名字可以复用已有环境，不要求新建 Store。

T1/T2 消费：

- HUD
- Pin
- Locator
- Minimap
- Arc
- Composer
- edge drop band
- explicit Focus framing

禁止 DOM query 多套 panel、hardcoded right panel width、persisted safeRect。

# 15. D15 · Work View 打开/resize 的 Camera policy

最终：

> LCOS Work View / Professional Window 导致的 host resize，不允许自动改变 Camera。

T1 发现 Huabu 当前通用 resize 有 camera compensation。

当前先做：

> LCOS host-level policy override。

不要直接把这个行为改成 Huabu 全球默认。

后续若 upstream 也证明应统一，再单独提交 Huabu 改动。

# 16. D16 · SurfaceDock 与 Railway 两者都保留，但权重不同

SurfaceDock 底部中心：

> Main / Context / Workflow 的一级快速切换器。

这是 primary surface switch。

Railway 左侧：

> Project navigation skeleton。

承担 long-term Worksite、Receiver、cross-surface drop、current location、preview/Peek、Arrival destination。

Railway 可以显示 Main / Context / Workflow 作为结构根节点并允许激活，但不与 SurfaceDock 竞争同等视觉权重的第二套三视图按钮。

一句话：

SurfaceDock = primary quick switch
Railway = structural navigation / destination map

# 17. D17 · Railway durable order：保留机制，换 ontology

当前 `/view-rail-order` 的 durable ordering、CAS、restart、dedupe 可继续复用。

旧 `scene / collection / context / workflow` 平级 kind 废弃。

Gen2 ontology：

- Surface root
- Long-term Worksite
- Receiver / Conversation identity
- compatibility legacy item（迁移期）

Collection / Scope / temporary Context block 不自动进入 Rail。

T6 源码方案负责最小兼容迁移，不新造 RailwayStore。

# 18. D18 · ContextSnapshot branch：旧组合 mutation 退休

当前：

checkpoint → create collection scope → clone/new ArtifactView → x/y

不再作为 Gen2 产品 mutation。

以后 branch/fork 若仍有产品需求，必须拆开：

历史 fork / snapshot ≠ Collection membership ≠ spatial placement ≠ Worksite materialization。

没有明确用户动作时，不创建 Collection / Worksite。

T6 在 source plan 处理 legacy read/migration；T4 Context UI 不依赖旧副作用。

# 19. D19 · Workflow extraction 的 canonical result

用户：

选一批真实材料 → 整理为 Workflow

正式采用后：

1. 创建/复用 canonical Workflow identity；
2. 保存 durable typed working composition；
3. 不 clone 原实体；
4. 在 Workflow Surface 建立 projection；
5. 当前 Main/Context source projection 不删除；
6. 如用户进一步选择“单独开桌长期做”，再 materialize Worksite；
7. Agent proposal 未采用，不写 canonical Workflow。

T4 owns UX/proposal；T6 owns canonical transaction；T1 owns placement；T3 owns gesture。

# 20. D20 · Skill 使用不是 membership，也不是复制

Skill canonical package继续唯一。

Composer 中 Skill selection：

> per-run / current composer input。

不自动形成 durable Project binding。

Workflow / Glyth 中，用户明确“这段工作以后就用这个 Skill”：

> durable typed capability-use relation。

至少引用 skillId、version / compatible version、target ref。

不复制 Skill package。

具体优先复用现有 Relation / Skill contracts。T6 源码方案不得因为缺口直接新建 frontend SkillBindingStore。

# 21. D21 · Assembly 的 scope compatibility 只保留迁移，不保留产品

Assembly 继续是 Project-shared Source Bay + Target。

Target 使用 typed canonical target ref。

当前 context/workflow/collection → scope endpoint 只允许 LEGACY_COMPAT。

T6 source plan 逐目标迁移到真实 target command。

Assembly 自己不拥有 membership、relation、Skill binding、Collection containment，只路由 canonical services。

# 22. D22 · T1 Stage A 现在可以关闭，但第二份不是正式施工稿

T1 新补的 Historical Semantic Reconciliation 与 CrossThread Questions 已达到 Stage A。

`T1_Patched_Construction_Cards` 内容有价值，但按 T1 自己的性质澄清：

> 只能作为 candidate patch ledger / source-plan skeleton。

不能冒充已批准的 `04 / 05 / 99`。

本稿裁决回填后，T1 可以正式开始写 source-level `04`，无需继续产品考古。

# 23. D23 · T6 Stage A 关闭，Deep Dive 作为当前最高优先级证据

T6 2026-09-06 三稿已经纠正上一轮 owner 漂移。

但 `T6_Deep_Dive_Contract_Options_20260905` 进一步找到：

- R3-A exact provenance
- Collection membership owner gap
- Context/Workflow composition 层问题
- Workspace membership split
- same-canvas projection key 风险

因此 Deep Dive + 本 Phase B 裁决覆盖 T6 旧三稿中仍残留的 OPEN / 旧措辞。

需要回填：

- R3-A provenance still gap → CLOSED
- Right-drag→Collection → D03
- Colony contour → D11
- Context顶层 composition → D05
- Workflow composition → D06
- Worksite → D07
- multi-instance → D12

完成后 T6 可以进入 source-level plan。

# 24. T2 阶段 A 回填结果

T2 现在可以关闭：

- Long-term Worksite contract → D07
- Context/Workflow materialization → D08
- Back stack durability → D09
- Work View safeRect seam → D14 / D15
- Archived object Focus → D13
- SurfaceDock vs Railway → D16
- Rail ontology → D17

仍由 T2 source plan 自己完成：

- exact route / type
- current consumer
- migration
- browser acceptance

这些不再需要产品裁决。

# 25. T4 阶段 A 回填结果

T4 现在可以关闭：

- Scope Save/Commit → D01
- Context canonical membership → D05
- Workflow membership → D06 / D19
- Long-term Worksite identity → D07
- Context temporary detail materialization → D08
- Conversation child canvas → D10
- Collection containment owner → D02
- ContextSnapshot branch → D18
- Skill usage binding → D20
- Assembly scope compatibility → D21
- Archive lifecycle → D13
- Right-drag to T4 targets → D04 + target-natural semantic，T3 负责手势 presentation

T4 可以进入 source-level plan。

# 26. T3 现在只需要做一次 interaction contract 回填

T3 不再重新考古。

必须回填：

Right-drag
= source spatial placement 不动
= target 按唯一 natural semantic commit
= relation handle 永远另算 Relation

以及：

visible host left-drop
→ stay at target

remote target left-drop
→ source home

multi-select
→ no auto Composer

之后 T3 可以直接写最终 source-level interaction plan。

# 27. T5 现在可以开始最终视觉方案

T5 此时已经有足够稳定输入。

必须区分视觉：

- Collection
- Colony
- Scope highlight
- Worksite
- Child Canvas
- Professional Window
- Context temporary region
- Workflow action round
- Archive cold object
- Remote target
- Visible host

T5 不再等这些概念的产品定义。

它只负责：

- shape
- material
- density
- motion
- LOD
- icon/glyph
- hover
- label
- window proportion
- settle
- peel
- Arrival
- archive / restore appearance

并严格遵守：

> 能图形表达就不常驻文字，Hover / Focus 再显示字。

# 28. 后续源码施工方案统一顺序

## Phase C1 · T1/T2/T3/T4/T6 Source-level Plans

每一路必须写：

- exact current file
- current owner
- consumer
- donor / primitive
- new thin seam
- migration
- retirement
- test
- browser acceptance
- recovery / rollback
- blast radius

不能再做产品选择。

## Phase C2 · T5 Final Visual Plan

T5 在 C1 工程骨架出来后最终选择：

- body
- donor
- visual state
- motion
- LOD
- spacing
- typography
- icon
- density

## Phase C3 · Visual patch 回填 source plans

然后生成 FINAL SOURCE CONSTRUCTION PLAN，才进入 production coding。

# 29. 当前不再 OPEN 的产品问题

以下不再允许专项线程重新打开：

- Scope 是否 durable container
- Collection 是否 child canvas
- Context top-level 是否人工 membership container
- Workflow 是否 DAG
- Work View 是否 child canvas
- Workspace 是否原样复活
- Colony 是否 Collection
- Colony contour 是否继续 Core points
- Right-drag 是否必须 temporary relation
- Archive 是否第二仓库
- Work View resize 是否自动 move camera
- 同 canvas 是否默认多 projection
- SurfaceDock / Railway 谁是一级三视图主入口

除非 current source 明确证明技术不可行且没有薄适配方案，否则不重新讨论产品心智。

# 30. 最终一句话矩阵

Main
= 项目活跃桌面

Context
= 项目理解的派生地图

Workflow
= 一段被正式抽出来的长期工作

Collection
= 哪些东西长期算一组

Scope
= 这一次只处理谁

Colony
= 当前空间里哪些东西形成一片

Worksite
= 另一张以后还能回来继续的桌子

Work View
= 把某件事拿近、展开、深入操作的窗口

Glyth
= 一段持续 Conversation 的空间身份

Archive
= 东西还在项目里，但先从活跃桌面收起来

整个 Gen2 后续继续坚持：

> **点、拖、丢、拉、直接打字、说一句话。**
>
> **代码负责确定的东西，Agent 负责需要理解的东西。**
>
> **能少一步，就不多一步。**
