# LCOS Gen2 · UX 场景先行施工前置协议
## 先把“用户到底怎么用、画面到底怎么变化”讲透，再决定源码怎么施工

> 日期：2026-09-04  
> 用途：同步给 LCOS Gen2 各并行规划 / 审计 / 施工会话  
> 适用范围：所有涉及 GUI / UX / Spatial / Navigation / Composer / Work View / Assembly / Context / Workflow / Visual Components 的线程  
> 性质：跨线程新增前置施工纪律。若与更晚用户原话冲突，以更晚用户原话为准。

---

# 0. 为什么新增这条规则

当前 Gen2 已经建立了：

```text
审计优先
Huabu-first
Core truth 唯一
ProjectionBinding 唯一
Donor 双轨
OSS wheel-first
源码级 exact-file 施工
```

但还缺一个更上游的环节：

> **不能只让每个线程根据源码、OSS、donor 自己判断“最终应该长什么样”。**

因为如果产品体验没有先恢复清楚，哪怕工程上：

- owner 找对了；
- OSS 找对了；
- API 找对了；
- CSS 组件也找对了；

最后仍然可能做成：

```text
工程正确
+
用户流程错误
+
GUI 排布错误
+
交互节奏错误
```

也就是：

> **代码层已经很“对”，产品层仍然不好用。**

因此以后所有 GUI / UX 相关源码级施工，在进入 exact-file / JSX / CSS / donor adoption 之前，必须增加一个强制前置阶段：

```text
USER UX SCENE RECOVERY
```

中文可以理解为：

> **“用户实际操作场景复原”**

它不是高层 PRD，也不是一句“优化导航体验”。

它必须把用户真实使用时：

```text
看见什么
→ 鼠标在哪里
→ 点什么
→ 什么出现
→ 什么不出现
→ 画布怎么动
→ 控件怎么变
→ 用户下一步做什么
```

完整画面化。

---

# 1. 新的正确施工顺序

以后 GUI / UX 类施工统一使用下面这条链：

```text
用户原话 / 最新冻结
        ↓
UX 场景恢复
        ↓
GUI 空间排布恢复
        ↓
状态 / 转场 / 动效恢复
        ↓
交互动线冻结
        ↓
现有源码 Owner / Consumer 审计
        ↓
Huabu 能力审计
        ↓
Donor / OSS 审计
        ↓
决定 Adopt / Wrap / Lift / Retire
        ↓
Exact File
        ↓
Props / JSX / CSS / Token / Motion
        ↓
测试
        ↓
真浏览器
```

禁止倒过来：

```text
先看到一个 OSS 组件
→ 觉得能用
→ 硬把产品流程塞进组件
```

也禁止：

```text
先看当前代码怎么写
→ 在现有结构上继续补
→ 最后才发现用户根本不想这样操作
```

---

# 2. 先回答“用户看到什么”，再回答“代码在哪里”

每个线程必须先把自己负责的几个大系统写成：

```text
用户进入这个状态时，屏幕是什么样？
```

而不是先写：

```text
Store 在哪里？
Route 是什么？
Adapter 怎么接？
```

工程术语当然需要，但它必须排在 UX 场景之后。

用户侧的描述必须优先回答：

```text
用户此刻的目标是什么？
用户眼睛主要看哪里？
鼠标/手当前在哪？
当前 Selection 是什么？
屏幕上固定存在什么？
什么控件默认不出现？
用户执行动作后，第一帧变化是什么？
接下来 100~300ms 内发生什么？
Camera 是否移动？
目标对象是否移动？
是否打开 Work View？
是否出现 Popover？
是否需要第二次确认？
完成动作后用户在哪里？
用户下一步最自然的动作是什么？
```

---

# 3. 每个大系统都必须先做“UX Scene Sheet”

以后每个线程负责的每个主要系统，都必须先产出一份：

```text
UX Scene Sheet
```

最低字段：

```text
System:
User Goal:
Entry Condition:
Current Selection:
Current Surface:
Visual Focus:
Persistent UI:
Transient UI:
Hidden UI:
Primary Action:
Immediate Feedback:
Spatial Motion:
Camera Rule:
Object Motion:
Popup Rule:
Exit State:
Next Natural Action:
Failure State:
Recovery State:
User Original Evidence:
Final Frozen Interpretation:
```

---

# 4. UX Scene Sheet 不能只写一句话，要拆成连续画面

例如不能写：

```text
点击 Locator 后定位目标
```

必须写成：

```text
Frame A
目标仍在 viewport 内
→ Locator 不出现
→ 节点局部保持正常 Glyph

Frame B
目标逐渐离开 viewport
→ 同一视觉对象开始向 directional morphology 过渡
→ 不弹 Tooltip / Popover

Frame C
目标完全离开 viewport
→ 指路形 Locator 稳定出现
→ 方向指向真实目标方向

Frame D
用户点击 Locator
→ Locator 轻微 pressed feedback
→ 不弹窗
→ 不出现“确认前往”

Frame E
Camera 开始平滑移动
→ Locator 在极短时间内继续提供方向连续性

Frame F
目标进入 safeRect
→ Camera 按目标 bounds + optical padding 完成 fit

Frame G
Camera settle
→ 节点完整落在可操作区域
→ 极轻 arrival beacon
→ Locator dissolve

Frame H
用户可以立即继续操作目标节点
```

这才叫：

> **UX 场景恢复完成。**

---

# 5. GUI 排布也必须画面化

除了交互流程，每个线程还必须写清楚 GUI 空间关系。

至少回答：

```text
控件在 viewport 哪个区域？
离边缘多少？
和 Selection 的关系？
和 Work View 的关系？
和 Railway 的关系？
和 Minimap 的关系？
屏幕宽度变窄怎么办？
Work View 打开以后谁让谁？
Search / Focus / Pin 同时存在时谁占主位？
哪些东西 persistent？
哪些东西 hover 才出现？
哪些东西只在 Selection 时出现？
```

例如不能只写：

```text
Pin HUD 放顶部
```

而要写：

```text
无 Pin
→ 顶部中央不保留空壳

存在 Pin
→ 顶部中央出现 compact Pin Index
→ 默认只显示必要 identity / count

hover
→ 横向轻展开
→ label 才出现

Search active
→ Search presentation 获得 top-center dominant slot
→ Pin Index 收敛/让位，而不是两个控件叠加

Work View 占右侧
→ top-center placement 仍基于 active safeRect，而不是浏览器全宽
```

---

# 6. 必须回到 Library / 原话恢复，而不是靠线程自己“理解”

这条规则最重要的一部分：

> **UX Scene Sheet 的主要证据必须来自用户当时的原话、后续纠偏、最终冻结。**

不能只拿：

```text
审计总结
旧施工计划
助手自己的产品理解
当前代码表现
```

来代替用户原话。

每个系统都要优先搜索：

```text
用户首次提出
用户不满意当前方案
用户指出哪里不对
用户给出更具体例子
用户最后确认
```

然后整理：

```text
EARLY
→ CORRECTED
→ FINAL
```

---

# 7. 必须做“用户痛点 → 最终画面”转换

不能只记录：

```text
用户嫌侧边栏多
```

要转换成：

```text
用户痛点：
四边家具过多、重复侧栏、画布被挤压

最终画面约束：
- Canvas 是视觉主体
- 非必要 UI 不 permanent
- Railway 保留项目级必要导航
- Layer 只属于当前 Surface
- Minimap 不长期占据大面积
- object-local control transient
- Work View 打开时占边，但不触发 Camera 自动移动
```

再进一步转换为：

```text
施工影响：
- RETIRE duplicated sidebar
- DO NOT BUILD second global panel
- Minimap compact/transient
- HUD placement 使用 safeRect
```

这一链必须完整。

---

# 8. “用户语言层”和“开发语言层”必须同时存在

为了避免用户被工程术语淹没，所有关键施工文档都要保留两套表达。

## A. 用户语言

例如：

```text
用户点那个指路箭头以后，
不要弹任何东西，
镜头直接丝滑飞过去，
最后刚刚好把目标节点框住。
```

## B. 开发语言

转换为：

```text
Known target navigation is a zero-confirmation direct spatial action.

onPointerUp(locator)
→ resolve canonical target
→ obtain Huabu world bounds
→ compute active safeRect
→ derive optical fit bounds
→ animate camera
→ arrival feedback
→ dismiss locator

Forbidden:
modal
popover
confirmation
second search
fixed zoom
viewport-center-only alignment
```

两个版本都必须保留。

不能只留 B。

---

# 9. 新增“UX Freeze Gate”

以后 GUI / UX 相关系统进入源码施工之前，必须回答：

```text
这个系统用户实际怎么操作？
```

如果这个问题还只能用抽象术语回答，例如：

```text
通过导航组件访问空间对象
```

那么：

```text
UX FREEZE = FAIL
```

只有达到：

```text
任何一个不懂代码的人，
看完都能想象屏幕上发生什么
```

才算：

```text
UX FREEZE = PASS
```

---

# 10. UX Freeze 的最小验收

每个大系统至少必须具备：

```text
1. 用户目标
2. 入口
3. 默认画面
4. hover
5. click
6. drag（若适用）
7. active / selected
8. transition
9. completion
10. next action
11. Work View / viewport collision
12. failure / missing target
13. recovery
14. keyboard / shortcut（若适用）
15. 用户原话证据
```

---

# 11. UX 冻结之后，才能决定 OSS 到底该选哪个

Donor / OSS 审计必须变成：

```text
我们已经知道产品需要这个精确行为
↓
现在找哪个成熟轮子最接近
```

而不是：

```text
这个轮子看起来很酷
↓
我们来看看哪里能塞进去
```

例如：

```text
UX 已冻结：
Locator 要连续 morph
点击直接 camera travel
无 popup
fit safeRect

↓

再找：
哪个 icon morph primitive 合适
哪个 animation primitive 合适
Huabu 哪个 camera API 可直接用
哪个 OSS popover 根本不需要
```

这样 OSS 才是供应商，不是产品经理。

---

# 12. UX Scene Sheet 决定“抄什么”

前面已经冻结 Donor 双轨：

```text
成熟产品
→ 回答应该长什么样、怎么动

成熟 OSS
→ 回答怎么实现

LCOS
→ 保留语义和 owner
```

现在增加一层：

```text
用户原话 / Frozen UX Scene
→ 决定我们到底需要什么

成熟产品
→ 提供已验证的视觉 / 交互答案

成熟 OSS
→ 提供合法成熟实现

LCOS
→ 做最薄集成
```

最终顺序：

```text
USER INTENT
↓
UX SCENE
↓
GUI SCENE
↓
DONOR VISUAL
↓
OSS IMPLEMENTATION
↓
LCOS EXACT FILE
```

---

# 13. 不能让 donor 反向篡改用户动线

例如 Huabu upstream 提供：

```text
Move Selection
→ 打开 Modal
→ 选择 Space
→ Confirm
```

如果 LCOS Frozen UX 是：

```text
拖到 Railway 目标
→ 直接在那个现场使用
```

那么正确裁决是：

```text
Huabu Move Mechanic:
ADOPT

Huabu MoveSelectionModal:
UX REJECT
```

不能因为现成组件已经写好了，就把 LCOS 用户动线改成 Modal。

---

# 14. 不能让当前源码反向定义最终 GUI

当前代码只能回答：

```text
现在是什么
```

不能自动回答：

```text
最终应该是什么
```

例如：

```text
current code 有 sidebar
```

不代表：

```text
final UX 必须有 sidebar
```

必须先回到用户原话和冻结场景判断：

```text
这个 sidebar 到底应该：
KEEP
REDUCE
TRANSIENT
MERGE
RETIRE
```

---

# 15. 每个线程必须先列出自己的“几大系统”

每个线程不能直接钻文件。

先列：

```text
我主管的几个用户可感知系统是什么？
```

例如 T2：

```text
A. Railway
B. Project Search
C. Focus / Where
D. Color Pin / Pin HUD
E. Dynamic Locator
F. Minimap
G. Layer Panel
H. Surface switching
I. Cross-Surface Drop
J. Receiver entry / handoff
K. Work View safe-rect interaction
L. Navigation right-click / More
```

然后每一个先做 UX Scene Sheet。

---

# 16. 示例：T2 Dynamic Locator

## 用户语言

```text
用户正在画布里工作。

目标节点如果还在屏幕上，
就不需要额外导航 UI。

目标滑出屏幕后，
节点对应的导航视觉自然变成指路形。

用户点它，
不要弹窗，
镜头直接丝滑移动过去。

最后镜头刚刚好把目标节点完整框下来，
右侧如果开着 Work View，
也不能把节点框到 Work View 后面。

到达以后给一个很轻的提示，
用户立即继续操作节点。
```

## GUI Scene

```text
Inside viewport:
node-local glyph

Near edge:
morphing state

Outside:
directional locator

Pressed:
subtle scale response

Camera travel:
locator maintains continuity briefly

Arrival:
target node fully visible inside active safeRect

Settled:
light beacon
locator dissolves
```

## 开发语言

```text
Target owner:
Core / Selection / Focus

Geometry owner:
Huabu

Projection:
world bounds → active screen-space safeRect

Click:
zero-confirmation direct spatial action

Camera:
fit target bounds + optical padding

Forbidden:
modal
popover
second search
fixed zoom
duplicate camera state
LocatorStore
```

---

# 17. 示例：T2 Railway

## 用户语言

```text
Railway 是项目工作现场导航。

用户不用打开一个“管理空间”的大窗口。

Main / Context / Workflow / Collection
本身就是 Railway 里的可见现场。

用户可以点击切换。

更重要的是，
用户拖着当前 Selection 到另一个 Railway 现场，
那个现场本身就是 Receiver。

Drop 到哪，
就是要去哪里使用。

不能 Drop 完以后再弹一个窗口问：
你想放在哪？
```

## GUI Scene

```text
Idle:
compact rail

Hover:
target identity becomes readable

Drag start:
eligible Railway targets reveal receiving state

Drag over target:
target gets spatial receive highlight

Drop:
immediate semantic handoff / move

After drop:
destination preview / target state updates

No:
destination modal
mode chooser
second confirmation
```

## 开发语言

```text
Canonical rail order:
Core

Surface identity:
SurfacePort / Core

Physical drag:
Huabu

Move mechanic:
Huabu upstream move API

LCOS:
thin semantic target adapter

REJECT:
MoveSelectionModal as primary UX
```

---

# 18. 示例：Search → Focus

## 用户语言

```text
不知道东西叫什么、在哪：
用 Search。

已经找到对象：
不再继续搜。

点“在哪”以后，
告诉我它出现在哪些现场。

选其中一个，
直接带我过去。
```

## GUI Scene

```text
Cmd/Ctrl+F
→ Search

query
→ readable result identities

select result
→ entity becomes known

Focus / Where
→ occurrences

choose occurrence
→ camera / Surface navigation

arrival
→ highlight target
```

## 开发语言

```text
Search:
ProjectSearchService

Focus:
locationRefs / occurrence resolver

Navigation:
canonical target resolve

Camera:
Huabu

Forbidden:
SearchMode = Focus
second global search taxonomy
```

---

# 19. 新增施工文档结构

以后 `04_Source_Level_Construction_Plan.md` 不能直接从文件开始。

必须先有：

```text
PART 0 — UX Scene Freeze
```

推荐：

```text
0.1 System Map
0.2 User Goals
0.3 Scene-by-Scene UX
0.4 GUI Spatial Layout
0.5 State Matrix
0.6 Motion / Transition
0.7 Popup / Confirmation Rules
0.8 Cross-Surface Behavior
0.9 Work View / Safe Rect
0.10 Failure / Recovery
0.11 User Original Evidence
0.12 Frozen UX Verdict
```

然后才进入：

```text
PART 1 — Current Owner
PART 2 — Donor
PART 3 — Exact File
PART 4 — JSX
PART 5 — CSS
PART 6 — Tests
```

---

# 20. 每个 exact-file 施工条目必须回指 UX Scene

以后不能出现孤立的：

```text
修改 Locator.tsx
```

必须写：

```text
UX_SCENE:
T2-LOCATOR-SCENE-03~07

TARGET_FILE:
...

WHY:
实现“目标离屏 → 指路 → 点击直接 camera travel → safeRect fit → arrival”
```

这样施工 Agent 才知道：

> 这段代码为什么存在。

---

# 21. 新增“不得自行产品设计”规则

施工 Agent / Codex 的职责：

```text
实现已经冻结的 UX
```

不是：

```text
重新决定 UX
```

如果施工时发现：

```text
冻结 UX 无法由当前架构实现
```

必须返回：

```text
ARCHITECTURE CONFLICT
```

而不是私自：

```text
加一个弹窗
加一个模式按钮
加一个右侧栏
换一种流程
```

---

# 22. 新增“禁止抽象话术”

以下词如果没有具体场景，不算施工结论：

```text
提升效率
优化体验
增强导航
更直观
更高级
更现代
更丝滑
macOS 感
降低认知负担
更沉浸
更自然
```

必须改写成：

```text
用户做什么
→ 屏幕发生什么
→ 下一步是什么
```

---

# 23. 对其它六线程的同步要求

每个线程都要暂停一下“直接 exact-file 规划”，先回答：

```text
我主管的几大系统，
用户真实使用时到底是什么画面？
```

然后：

```text
逐系统
→ 回 Library 找原话
→ 找纠偏
→ 找最终冻结
→ 画 UX Scene
→ 画 GUI Scene
→ 再回代码
```

如果某个系统缺用户原话：

```text
MISSING USER INTENT
```

不允许线程自己补产品定义。

---

# 24. 对用户的交付格式也要改变

以后同步给用户时，不要先报：

```text
我们发现 Core route 是 xxx
store 是 xxx
adapter 是 xxx
```

先说：

```text
这个系统用户实际会这样用：
...
```

再补：

```text
所以工程上我们决定：
...
```

即：

```text
用户语言
→ 开发语言
```

而不是反过来。

---

# 25. 新的四层冻结模型

以后每个系统最终要有四层：

## L0 — USER INTENT

用户真正想干什么。

## L1 — UX SCENE

实际操作过程。

## L2 — GUI SCENE

屏幕长什么样、状态怎么变化。

## L3 — IMPLEMENTATION

Owner / Huabu / donor / OSS / file / JSX / CSS。

顺序不得反转。

---

# 26. 新的完成标准

一个系统不能因为：

```text
接口通了
组件写了
测试绿了
```

就叫 PRODUCT_COMPLETE。

必须同时满足：

```text
USER INTENT RECOVERED
UX SCENE FROZEN
GUI SCENE FROZEN
OWNER VERIFIED
DONOR VERIFIED
IMPLEMENTATION WIRED
BROWSER PROVEN
RECOVERY PROVEN
```

---

# 27. 最终统一开发表述

以后可以把这条纪律用开发语言概括成：

> **LCOS Gen2 的 GUI 施工采用 User-Intent-First / Scene-Driven Implementation。**
>
> 在任何 source-level implementation planning 之前，必须先恢复用户原始需求并建立可视化、逐状态、逐动作的 UX Scene Specification。
>
> UX Scene Specification 是 donor selection、OSS adoption、component architecture、state ownership、JSX/CSS implementation 的上游约束。
>
> 当前源码和外部 donor 只能作为 implementation supplier，不能反向定义产品用户流程。
>
> 每个 source-level construction item 必须可追溯到一个已冻结 UX Scene。

---

# 28. 给所有线程的一句话

> **先把“人怎么用”画清楚，再决定“代码怎么写”。**

不是：

```text
看完源码
→ 想一个合理 GUI
```

而是：

```text
找回用户原话
→ 把真实操作画面恢复清楚
→ 再审计源码
→ 再决定轮子
→ 最后下压到 exact JSX / CSS / token / motion
```

这才是 LCOS Gen2 后续源码级施工规划应有的精度。

否则哪怕每一行代码都写得很漂亮，
也可能只是把错误的产品体验实现得更加牢固。
