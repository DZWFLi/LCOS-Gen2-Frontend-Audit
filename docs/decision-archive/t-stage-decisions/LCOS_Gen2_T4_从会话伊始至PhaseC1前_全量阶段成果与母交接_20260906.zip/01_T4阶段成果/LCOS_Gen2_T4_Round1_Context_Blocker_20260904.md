# LCOS Gen2 · T4 第四路接管 / Round 1 Context Blocker
## Unified Work View / Assembly / Context / Workflow / Skill

日期：2026-09-04  
本轮时间锚点：2026-09-04 11:33 +08:00  
状态：`ROUND_1_CONTEXT_RECOVERY_BLOCKED_BY_9_RAW_ORIGINALS`

---

# 0. 结论

第四路已经按《LCOS_Gen2_六线程_ExactFile_反惰性规划引导包_V2_20260904》锁定为：

> **T4 · Unified Work View / Assembly / Context / Workflow / Skill**

当前 **不进入源码级施工规划正文**。

不是因为 `Gen2开发(5).zip` 的 T4 审计材料缺失，也不是因为当前 GitHub 无法核验，而是因为 T4 的 `MANDATORY_EXACT_READ_LIST` 中，仍有 **9 份 File Library raw original** 在本会话无法取得 exact-file 全文。

当前只能找到它们的：

- 索引；
- SHA256；
- 旧审计引用；
- patch 内嵌副本；
- 历史 `FOUND_FULL` 记录；
- 或二手摘要。

按照当前 SOP，这些都不能替代：

```text
exact filename
+ current-session full raw read
```

因此保持停工，不从摘要/旧计划自行补写产品语义。

---

# 1. AUDIT START LEDGER

```text
Thread:
T4 · Work View / Assembly / Context / Workflow / Skill

Current time:
2026-09-04 11:33 +08:00

LCOS repo:
DZWFLi/LCOS_Gen2

LCOS current main HEAD:
c2ff890a867922a1256572199458438572eb0a8c

Vendored Huabu pin:
58339e269b784728d67730c70bfe7792cae2457d

Huabu upstream repo:
microsoft/Huabu

Huabu upstream current main HEAD:
dc128fff2d37b5481ec305070a7e86d3de85f7d2

pin → upstream:
ahead_by = 19
behind_by = 0

Planning status:
AUDIT ONLY

Construction plan permission:
LOCKED

Commitment:
No source-level construction plan before at least five distinct audit rounds are completed.
No production patch in this planning thread.
```

---

# 2. T4 Scope 冻结

第四路负责：

- `WorkViewTarget`
- `FLOATING / DOCKED / IMMERSIVE / RESTORE`
- `occupiedRect / safeRect`
- Assembly / Source Bay
- Assembly categories
- Glyth Assembly target
- Context:
  - Structure
  - Versions / Evolution
  - Relationship
  - Source / Provenance
- Workflow Action Path
- Skill Artifact / Skill Builder
- Harness Run / Result / Review professional representation
- Work View 与 Composer / Assembly / Surface 的关系
- Cross-Surface Work View continuity

第四路禁止自行改变：

- Core truth
- Huabu spatial truth
- Selection / Reference / Relation 分离
- Main / Context / Workflow Surface semantics
- Work View lifecycle
- Assembly = project-level shared source/warehouse/workspace
- Skill ≠ Harness Run
- Search / Focus / Pin mental model

跨线程冲突只记录 `REPORT_CONFLICT`，不自行改母本。

---

# 3. T4 Mandatory File Library Completion Census

总数：

```text
Shared File Library:          10
T4-specific File Library:     14
TOTAL:                        24
```

当前 exact raw object 状态：

```text
EXACT RAW LOCATED:            15
MISSING RAW CURRENT SESSION:   9
```

> `EXACT RAW LOCATED` 只表示当前能拿到 exact file object。
> 在正式 Round 1 completion table 中，仍需逐份完成全文读取后才能升级为 `FOUND_FULL / FULL_READ=YES`。

---

# 4. 当前缺失的 9 份 raw original

## 4.1 Shared mandatory originals · 缺 3

### M1
`LCOS_v015_原文到后续施工计划_差分审计_20260831.md`

当前仅有：
- SHA/index；
- 历史审计引用；
- 旧 Census 的读取记录。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

### M2
`LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md`

当前仅有：
- SHA/index；
- 历史审计引用；
- 旧 Census 的读取记录。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

### M3
`LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md`

当前仅有：
- SHA/index；
- 历史 `FOUND_FULL + GITHUB_VERIFIED` 记录；
- 二手引用。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

# 4.2 T4-specific mandatory originals · 缺 6

### M4
`LCOS_三大视图组件体系筛选表_v01_20260821.md`

历史恢复账已经明确记录：

```text
Still unresolved
No exact source recovered
```

当前仍未找到 exact raw。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

### M5
`LCOS_v0.15_R3D_SkillArtifact_SkillBuilder_CrossSurface_Freeze_20260830.md`

当前可找到：
- SHA；
- recovery ledger；
- patch 中嵌入的完整新增内容。

但 T4 V2 要求的是 File Library exact filename raw full read，不能用 patch 代替。

状态：

`RAW_CONTENT_RECOVERABLE_FROM_PATCH_BUT_EXACT_FILE_MISSING`

仍视作 blocker。

---

### M6
`LCOS_v015_Context_Workflow_Component_CameraFocus_审判与收敛_20260831.md`

当前只定位到：
- index；
- SHA；
- 旧 Census `FOUND_FULL` 记录；
- 后续计划引用。

未取得本会话 exact raw object。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

### M7
`LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md`

当前只定位到：
- SHA；
- Video donor index；
- 后续施工计划引用。

第二路独立复核也遇到同一 raw-original 缺口。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

### M8
`LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md`

当前只定位到：
- Video donor index；
- 后续施工计划引用。

第二路独立复核也遇到同一 raw-original 缺口。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

### M9
`LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md`

已按 exact filename 做 File Library recovery，未取得 exact raw object。

当前包内有视觉/GUI图片，但不能用图片或历史摘要冒充这份提示词原文。

状态：

`MISSING_RAW_IN_CURRENT_SESSION`

---

# 5. 当前已定位的 15 份 File Library exact raw

## Shared

1. `LCOS_20260821至20260902_全功能最新冻结总账_白话UX与Gen2施工映射.md`
2. `LCOS_v015_MANDATORY_PRECONSTRUCTION_CONTEXT_20260831.md`
3. `LCOS_v015_CONSTRUCTION_CONTEXT_INDEX_20260831.md`
4. `LCOS_v015_Frontend_Gen2_Huabu_First_重建总纲_20260901.md`
5. `LCOS_Gen2_Context_Recovery_可见对话原文_20260903.md`
6. `LCOS_Gen2_重构进度审计澄清_Context_Recovery_Census_20260903.md`
7. `LCOS_Gen2_详细施工方案_SOP_审计优先版_20260903.md`

## T4-specific

8. `LCOS_0.1_三大独立视图组件化详细施工总稿_v03_对话选择与承接全链补齐_20260821.md`
9. `LCOS_v0.15_UX冻结_同一套物理三个语义现场与Assembly_20260829.md`
10. `LCOS_v0.15_UX冻结_Assembly同步空间与PointerCursor交互语言_20260829.md`
11. `LCOS_v015_SURFACE_COMPONENT_GUI_GRAMMAR_FREEZE_20260831.md`
12. `LCOS_v015_CENTERED_SPATIAL_INDEX_SEARCH_ASSEMBLY_FREEZE_20260831.md`
13. `LCOS_v015_UNIFIED_COMPACT_COMPOSER_PROMPT_REFERENCE_VOICE_GUI_FREEZE_20260831.md`
14. `LCOS_v015_UNIFIED_WORK_VIEW_DOCKED_IMMERSIVE_PREVIEW_ASSEMBLY_FREEZE_CANDIDATE_20260901.md`
15. `LCOS_v015_LATEST_L0_WORKVIEW_HUD_DIRECT_MANIPULATION_ADDENDUM_20260901.md`

这些文件目前只记为：

`EXACT_RAW_LOCATED`

收到缺失 9 份以后，再按 V2 completion table 逐份做完整 `FULL_READ`，不拿当前 search snippets 冒充全文。

---

# 6. Gen2 ZIP 状态

`Gen2开发(5).zip` 中，T4 guide 明确点名的 Shared + T4-specific 审计/历史施工 entry 均已定位。

包括：

## Shared entries
- `LCOS_Gen2_审计轮次总索引_20260902.md`
- `LCOS_Gen2_GUI实现SOP_20260902.md`
- `LCOS_Gen2_三方转化审计_LCOS自己那套怎么用现成轮子搭_20260902.md`
- `LCOS_Gen2_Gen1_vs_Huabu_画布接口源码级全功能映射审计_20260903.md`
- `LCOS_Gen2_全功能Huabu源码级融合与重构阶段计划_20260902.md`
- GLM 总索引
- 审计优先 SOP
- Context Recovery 原文

## T4 entries
- `LCOS_v015_PHASE_BC_MATURE_DONOR_CENSUS_PRE_FREEZE_20260901.md`
- `LCOS_Gen2_摸牌四_PhaseBC_DonorCensus对照_20260902.md`
- `MD3_工作台与现场编排层_源码对应审计_20260903.md`
- `MD4_Agent运行与服务层_源码对应审计_20260903.md`
- Phase C Surfaces/Instruments/Composer 历史施工正本
- B06e/C06e WorkViewIntermediateState
- C04g GlythAssemblyTarget
- C05b SkillAssemblyMatrix

状态：

```text
PATH_FOUND = YES
FULL_READ = PENDING
```

因为当前先遵守 raw-original blocker，不提前把历史施工稿当 current plan。

---

# 7. Current GitHub 动态事实

已重新核：

```text
DZWFLi/LCOS_Gen2 main
= c2ff890a867922a1256572199458438572eb0a8c
```

当前 `HUABU_UPSTREAM.md`：

```text
vendored Huabu pin
= 58339e269b784728d67730c70bfe7792cae2457d
```

Huabu upstream：

```text
microsoft/Huabu main
= dc128fff2d37b5481ec305070a7e86d3de85f7d2
```

比较结果：

```text
upstream ahead_by = 19
behind_by = 0
```

本轮已经看到与 T4 可能直接相关的 upstream delta：

- Cross-Space Move UI / service / schema；
- `MoveSelectionModal`;
- `space-move-plan`;
- `space-move.service`;
- `packages/shared/src/types/api/space-move.ts`;
- Preview Workspace architecture 文档变化；
- storage/Space ownership 一组同步调整。

这些现在只记：

`UPSTREAM_DELTA_CANDIDATE`

不提前写 `ADOPT`。

Round 4 必须逐项做 touched-path/current-consumer/adoption 判断。

---

# 8. T4 donor 状态

当前三个上传包中没有发现以下 T4 专业 donor 的独立源码目录：

- `react-arborist`
- `vis-timeline`
- `Cytoscape.js`
- `ELK / elkjs`
- `react-resizable-panels`
- `re-resizable`
- `cmdk`
- `dnd-kit`
- `Mind Elixir / Markmap` 等历史候选

但这 **目前不构成 Round 1 blocker**：

T4 V2 SOP 已要求 Round 4 动态核 current upstream / license / maintenance，因此这些公共 donor 可以在缺失产品原文补齐后直接从官方上游重新核。

如果协调会话要求使用某个**固定版本 / 本地修改版 / 已审定 snapshot**作为 donor authority，则需额外提供那份 pinned source package；否则不需要为了“资料齐全感”重复上传公共仓库。

当前真正 blocking input 仍是上面的 **9 份产品 raw original**。

---

# 9. 已冻结但尚未用于写计划的 T4 法条

当前只记录，不扩写设计：

```text
Work View lifecycle:
SPATIAL
→ FOCUS
→ FLOATING
→ DOCKED
→ IMMERSIVE
→ RESTORE
```

硬边界：

- project-global single owner
- same target/session continuity
- cross-Surface continuity
- opening/resizing does NOT move Camera
- exposes occupiedRect/safeRect
- HUD/navigation adapt
- PreviewWorkspace mechanics may be adopted
- PreviewWorkspace does NOT become LCOS canonical Work View owner

Assembly：

- project-level shared source/warehouse/workspace
- not fourth Surface
- not Surface Component catalog
- same Assembly from Main / Context / Workflow
- current object/field can be target
- Glyth durable feed != current Run Reference

Context：

- one Context Surface
- four specialist instruments:
  1. Structure
  2. Versions/Evolution
  3. Relationship
  4. Source/Provenance
- no four independent apps
- no second Evolution truth

Workflow：

- not automation DAG builder
- Action/intent/execution records are the truth
- Run/ExecutionItem/Result/Review remain execution truth

Skill：

- Skill = first-class Artifact
- Skill Builder = edit projection
- Harness Run = execute
- no Skill-specific Binding
- no per-Surface Skill package copy

---

# 10. 收到缺失原文后的继续顺序

收到 9 份 exact raw original 后，第四路继续：

## Round 1
完成 24 份 File Library + 16 份 ZIP + current GitHub + upstream + donor 的正式 Source Ledger / FULL_READ completion table。

## Round 2
追至少两条真实 production 用户路径：

```text
对象 → Work View → Run/Review → Restore
对象/Glyth → Assembly → durable mutation → reload
```

输出 Current Consumer / Owner / Runtime Trace。

## Round 3
恢复至少 5 条：

```text
用户反复强调
→ 旧实现为何失败
→ 后续纠偏
→ FINAL truth
```

覆盖 Work View / Assembly / Context / Workflow / Skill。

## Round 4
执行：

```text
vendored Huabu pin
↔ latest microsoft/Huabu
↔ Huabu sibling primitives
↔ external donor current source/license
↔ Gen1 behavior asset
```

形成 Supplier / Adoption / Retirement Matrix。

## Round 5
做 Cross-Boundary / Recovery / Contradiction Audit：

- T1 occupiedRect/HUD
- T2 Railway/Navigation
- T3 Action Arc/Composer/Drop
- T5 visual body
- T6 Core/Realtime/Migration

至少提出 10 个 second-truth / duplicate-owner 反证问题。

证据不足则自动 Round 6+。

---

# 11. 最终强制交付仍保持锁定

五轮以上审计完成后才允许产出：

1. `01_Evidence_Census_Authority_Recovery.md` ≥30KB
2. `02_Current_Source_Consumer_Owner_Audit.md` ≥30KB
3. `03_Donor_Upstream_Adoption_Retirement_Matrix.md` ≥30KB
4. `04_Source_Level_Construction_Plan.md` ≥30KB
5. `05_Acceptance_Recovery_CrossReview_Plan.md` ≥30KB
6. `99_COORDINATOR_HANDOFF.md`

当前一份都不提前伪造。

---

# 12. 需要用户补充的最小材料

请直接提供以下 9 份 exact raw original，单独 `.md` 或一个 ZIP 都可以：

```text
1. LCOS_v015_原文到后续施工计划_差分审计_20260831.md
2. LCOS_v015_最新UX_GUI_理想与现实代码对照_P0用户原话优先_20260901.md
3. LCOS_Gen2_Huabu_SpatialTruth_裁决补丁_20260901.md
4. LCOS_三大视图组件体系筛选表_v01_20260821.md
5. LCOS_v0.15_R3D_SkillArtifact_SkillBuilder_CrossSurface_Freeze_20260830.md
6. LCOS_v015_Context_Workflow_Component_CameraFocus_审判与收敛_20260831.md
7. LCOS_v015_Lovart_Trae_TapNow_交互与动效拆解_20260830.md
8. LCOS_v015_CodexDesktop_局部锚点_PersistentPanel_交互拆解_20260831.md
9. LCOS_FigmaMake_定向校正施工提示词_v1_20260901.md
```

如果其中某份已经改名，只需提供 **exact current replacement + 原文件的 supersession/rename 依据**。

---

# 13. STOP

当前停止点：

```text
T4 ROUND 1
= CONTEXT RECOVERY
= BLOCKED BY 9 RAW ORIGINALS
```

不输出施工 patch。  
不提前设计新的 WorkView framework。  
不把 PreviewWorkspace 改名当答案。  
不把 Context 拆成四个 app。  
不把 Workflow 做成 DAG builder。  
不把 Skill 与 Harness Run 合并。  
不拿旧施工正本补缺。
