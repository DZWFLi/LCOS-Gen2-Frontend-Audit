# LCOS Gen2 · T2 UX Scene Freeze v0.1
## Railway / Search / Focus / Pin / Locator / Minimap / Layer / Cross-Surface Drop / Receiver / Work View

> 日期：2026-09-04  
> 线程：T2 · Viewport / Chrome / Railway / Minimap / Navigation  
> 状态：UX SCENE RECOVERY / PRE-SOURCE-CONSTRUCTION  
> 用途：在 Exact File / JSX / CSS / donor adoption 前冻结“用户实际看到什么、怎么操作、屏幕怎么变”  
> 重要：本文不是 patch，不宣称当前 Gen2 已经完成这些 GUI。

---

# 0. 这份文件解决什么问题

T2 之前已经完成了大量：

- Core owner census；
- Huabu mechanic census；
- donor / OSS census；
- Search / Focus / Pin / Marker 语义拆分；
- Railway / Receiver / Minimap 边界审计。

但这些仍然可能让施工者陷入一个坏习惯：

```text
知道 owner 在哪
+
知道 donor 有什么
+
知道 OSS 能怎么写
↓
自己脑补最终 GUI
```

T2 后续不允许这样做。

本文件把 T2 主管范围内的用户可感知系统先恢复成一组明确 UX Scene。

之后所有：

```text
ADOPT
WRAP
LIFT
RETIRE
Exact File
JSX
CSS
Token
Motion
```

都必须回指本文 Scene，而不能脱离用户体验自己发展。

---

# 1. T2 用户可感知系统地图

T2 主管的主要系统暂冻结为：

```text
T2-A  Railway / Workspace Rail
T2-B  Surface Switching
T2-C  Cross-Surface Drop
T2-D  Active Receiver in Railway
T2-E  Project Search
T2-F  Focus / Where
T2-G  Centered Spatial Index
T2-H  Color Pin / Pin HUD
T2-I  Dynamic Map Locator / Edge Cursor
T2-J  Arrival Beacon
T2-K  Minimap
T2-L  Layer Panel / Current Surface Search & Filter
T2-M  Active Spatial Viewport / Work View Safe Rect
T2-N  Navigation Right-click / More boundary
```

这些系统不是十四套产品。

它们最终构成的是一套空间导航语言：

```text
不知道对象是什么/在哪
→ Search

已经知道对象
→ Focus / Where

想长期保存位置线索
→ Pin

目标离开当前视区
→ Locator

点击目标导航
→ Camera travel

到达
→ Beacon

想切工作现场
→ Railway

拖对象去另一个现场使用
→ Cross-Surface Drop

想看整体空间方位
→ Minimap

只想看当前 Surface 内的层级
→ Layer Panel
```

---

# 2. 统一屏幕空间原则

所有 T2 系统必须遵守以下画面原则。

## 2.1 Canvas 是主体

默认状态不允许出现：

```text
左边一整套项目树
右边一整套详情栏
顶部一整排筛选器
底部一整排模式按钮
角落永久大 Minimap
节点旁永久动作按钮
```

默认应该是：

```text
Canvas / content = body

必要导航 = compact shell
局部操作 = transient satellites
```

---

## 2.2 Top Center 不是浏览器物理中心

任何顶部居中 HUD：

- Search；
- Focus；
- Color Pin；
- Centered Spatial Index；

都必须基于：

```text
activeSpatialViewport
```

而不是：

```text
window.innerWidth / 2
```

Work View / Rail / persistent occupied UI 改变可用区域后：

```text
HUD 重新排布
Camera 不自动搬家
```

---

## 2.3 Screen-space UI 不拥有 world truth

以下对象：

```text
Railway
Centered Spatial Index
Locator
Beacon
Pin HUD
Minimap chrome
```

可以显示世界状态，但不能重新拥有：

```text
camera
node position
surface truth
selection truth
project truth
```

---

# 3. T2-A · Railway / Workspace Rail

## 3.1 用户语言

Railway 是：

> 我现在在哪个工作现场，以及我接下来想去哪个工作现场。

不是：

> 文件夹树。

不是：

> 右侧工作面板。

不是：

> 项目设置页。

它保留：

```text
Main
Context
Workflow
长期 Workspace / worksite
Collection / saved project views（按最新稳定身份）
Active Receiver
member / conversation preview
cross-Surface drop target
```

---

## 3.2 Idle Scene

### Frame A · 正常工作

用户正在 Main / Context / Workflow 任一 Surface。

Railway：

```text
固定在左侧
但视觉重量很低

当前现场
→ 有明确 active state

其它现场
→ 主要显示 species / preview identity
→ 文本不必永远全部展开
```

它必须让用户一眼知道：

```text
当前是 Main / Context / Workflow / 哪个工作现场
```

但不能像传统 IDE Explorer 一样抢占主体。

---

## 3.3 Hover Scene

### Frame B · Hover 一个 Context

Hover 时才增加：

```text
名称
轻量 member preview
必要 identity hint
```

如果是不同类型：

```text
Collection
→ stack/group preview

Context
→ signal/evolution preview

Workflow
→ small path/node preview
```

不能只是：

```text
同一个白色矩形
换三种颜色
```

---

## 3.4 Click Scene

### Frame C · 点击另一个现场

用户点击 Railway 项。

行为：

```text
click
→ 切换 Surface/worksite
→ 加载对应独立 canvasId / camera / selection / layout
```

用户不应该看到：

```text
Loading mode...
Choose view...
Are you sure?
```

切换就是直接导航。

---

## 3.5 Current Surface Return

### Frame D · 回到 Main

如果用户此前在 Main 有：

```text
camera A
selection A
layout A
```

切 Context 后又切回来：

```text
Main 恢复自己的现场状态
```

不能把 Context camera/selection 带回来。

---

## 3.6 GUI 排布冻结

Railway 必须：

```text
left
viewport-fixed
compact
independent from right Work View
```

右侧 Unified Work View 打开时：

```text
Railway 不消失
不被 Work View 替代
不与 Work View 重叠
```

旧右 `WorkRail` 与这个 Railway 完全不是一件事。

---

## 3.7 禁止

```text
❌ Project folder tree mental model
❌ Main > Contexts > Workflows 层级目录作为主心智
❌ Railway 被 Work View 替换
❌ RailwayStore 成为第二 Surface truth
❌ 固定宽大侧栏
❌ 永久显示大量文字
```

---

# 4. T2-B · Surface Switching

## 4.1 用户语言

Main / Context / Workflow 是：

```text
同一个 Project
三个不同工作现场
```

不是：

```text
一个 Canvas 的三个 mode
```

---

## 4.2 Scene

### Frame A

用户在 Main。

### Frame B

点击 Context。

### Frame C

Context 进入。

用户感受到：

```text
环境连续
物理规则一致
但是工作语义不同
```

也就是：

```text
pan/zoom/selection/drop/orbit
肌肉记忆相同

关系、工具、内容强调
不同
```

---

## 4.3 禁止

```text
❌ 切 Surface 后 camera/selection 共用
❌ 三 Surface 各写一套 pointer grammar
❌ 顶部“模式切换”按钮把同一 canvas 改模式
```

---

# 5. T2-C · Cross-Surface Drop

这是 Railway 最重要的用户价值之一。

## 5.1 用户语言

> 拖到哪里，就是去哪里使用。

不是：

```text
拖到目标
→ 打开选择框
→ 再选“放入上下文”
→ 再确认目标
```

---

## 5.2 Scene

### Frame A · 用户选中对象

Canvas 上一个或多个对象被选中。

### Frame B · 开始拖向 Railway

Railway 普通状态开始退后。

可接收目标：

```text
Context
Workflow
其它 eligible worksite
Receiver target
```

出现轻量 receptive state。

### Frame C · Drag Over Context

目标 Context：

```text
变为明确 receptive
显示目标身份
必要时显示极短 semantic hint
```

例如：

```text
放到 Context A
```

但不是菜单。

### Frame D · Release

松手即表达：

```text
我就是要在 Context A 使用这些对象
```

直接进入既有 semantic/admission 流程。

### Frame E · Commit feedback

成功：

```text
目标 rail item / preview 有轻反馈
```

源对象是否继续保留在源现场：

由 LCOS canonical 语义决定。

不能简单理解成：

```text
move node = delete source object
```

---

## 5.3 Huabu upstream 的正确使用

如果 Huabu 已有：

```text
MoveSelection API / atomic mechanics
```

则：

```text
ADOPT mechanic
```

如果 Huabu 默认 GUI 是：

```text
MoveSelectionModal
→ choose destination
→ confirm
```

则：

```text
REJECT as LCOS primary UX
```

因为用户已经通过拖拽明确给出 destination。

---

## 5.4 禁止

```text
❌ generic “What do you want to do?” modal
❌ destination chooser after destination already known
❌ drag 到 Railway 后只做 hover preview 不 commit
❌ native browser text/plain DnD 代替 spatial pointer
```

---

# 6. T2-D · Active Receiver in Railway

## 6.1 用户语言

Receiver 是：

> 当前项目正在承接哪段真实 Conversation / Agent 工作上下文。

它不是一个新的 Surface。

---

## 6.2 Idle Scene

Railway 中 Receiver：

```text
始终可见
但低噪音
```

用户可以知道：

```text
当前 Active Receiver 是谁
```

不需要打开一个 Agent Settings。

---

## 6.3 Switch Scene

用户切另一个 Receiver：

```text
click / select
→ active receiver changes
```

如果涉及 handoff：

```text
当前 surface
当前 selection
必要现场信息
```

被带入 canonical handoff。

不是前端复制上下文对象。

---

## 6.4 Work View coexistence

Work View 打开时：

```text
Receiver 仍然在 Railway
```

不能因为右边有 Agent tab / Work View 就把 Receiver 身份藏掉。

---

## 6.5 禁止

```text
❌ RailwayReceiverStore
❌ ComposerReceiverStore
❌ Railway 上一份，Composer 再一份
❌ provider picker 冒充 Receiver
```

---

# 7. T2-E · Project Search

## 7.1 用户语言

Search 回答：

> 我不知道具体叫什么，或者不知道它在哪，我想找一个项目里的东西。

---

## 7.2 Activation Scene

### Frame A

用户按：

```text
Cmd/Ctrl + F
```

### Frame B

activeSpatialViewport 顶部中央出现：

```text
compact Search input
```

不是：

```text
modal backdrop
大 Search page
右侧 Search panel
```

Canvas 仍在背景中保持空间感。

---

## 7.3 Typing Scene

### Frame C

输入关键词。

用户不看到：

```text
FTS
Vector
Semantic
OCR
Database
```

这些实现层完全隐藏。

---

## 7.4 Result Scene

### Frame D

top hits 形成：

```text
center-balanced labeled constellation
```

例如：

```text
[▣ Moodboard]
[◈ Workflow A]
[◇ Brief V2]
```

结果必须可辨认：

```text
对象是什么
为什么匹配
大概在哪
```

不能所有结果变成无文字小圆点。

---

## 7.5 Hover Scene

Hover 某个结果：

如果当前 Surface 有可见 occurrence：

```text
空间中对应对象轻 highlight
```

如果 offscreen：

```text
Locator 可接管方向反馈
```

---

## 7.6 Activate Scene

点击结果：

如果有直接 occurrence：

```text
Focus/Fly-to
```

如果对象类型应该打开：

```text
先 spatial locate / object activation
```

但 Search 不自动：

```text
建立 Pin
建立 Relation
打开大 Work View
```

---

## 7.7 Search → Focus

搜索已经确定对象后：

```text
用户点“在哪”
```

Search：

```text
yield top slot
```

Focus：

```text
接管 top slot
显示 occurrence
```

用户心智从：

```text
找什么
```

切成：

```text
它在哪
```

---

## 7.8 Keyboard

至少：

```text
Cmd/Ctrl+F → Search
Arrow Up/Down → result
Enter → activate
Esc → layered dismiss
```

---

# 8. T2-F · Focus / Where

## 8.1 用户语言

Focus 回答：

> 这个对象我已经知道了。它在哪些现场出现？

---

## 8.2 Entry Scene

用户：

```text
Selection 已存在
按 F
```

顶部 Search 不出现。

而是：

```text
Focus Location Index
```

---

## 8.3 Single occurrence

只有一个位置：

```text
top-center 一个 occurrence marker
```

当前 occurrence：

```text
直接高亮当前空间 body
```

不需要大列表说：

```text
1 result
Main Canvas
```

---

## 8.4 Multiple occurrences

例如对象存在：

```text
Main
Context A
Workflow B
```

顶部：

```text
◉   ◉   ◉
```

hover：

```text
Main
Context A
Workflow B
```

文字是按需出现，不必永久占位。

---

## 8.5 Many occurrences

超过主要数量：

```text
◉ ◉ ◉ ◉ ◉ +4
```

点击 `+4`：

```text
在同一 top index 家族下
展开 compact fan
```

不是：

```text
打开右侧大列表
```

---

## 8.6 Activate occurrence

点击 occurrence：

```text
known target
→ canonical navigation resolve
→ Surface switch if required
→ camera travel
→ arrival
```

不弹确认。

---

## 8.7 Esc

```text
fan open
→ Esc 先关 fan

Focus active
→ 再 Esc 关 Focus
```

---

## 8.8 禁止

```text
❌ Focus 搜索框
❌ Focus 持久化成 Pin
❌ Focus large permanent list
❌ Focus 和 Search 共用 state
```

---

# 9. T2-G · Centered Spatial Index

它是 presentation family，不是第四个导航真相。

## 9.1 Idle arbitration

```text
Search active
> Focus active
> Color Pin
> none
```

Assembly 在自己的 workspace 使用自己的 category index。

---

## 9.2 Layout Scene

1 item：

```text
        ●
```

2 items：

```text
      ●   ●
```

3+：

```text
浅弧 / constellation
```

核心：

```text
总视觉重心始终围绕 activeSpatialViewport top center
```

不能：

```text
从左边一颗颗往右长
```

---

## 9.3 Add / Remove motion

当数量变化：

```text
其它 item 轻 slide/rebalance
```

不是：

```text
旧全部 fade out
新全部 fade in
```

目标是空间连续性。

---

# 10. T2-H · Color Pin / Pin HUD

## 10.1 用户语言

Pin 是：

> 我主动留下一个以后还想回来用的空间索引关系。

不是：

```text
收藏
选中
Focus
状态标签
```

---

## 10.2 Authoring Scene

### Frame A

对象已选中。

### Frame B

Action Arc / Orbit 中出现：

```text
Pin
```

### Frame C

点击 Pin：

```text
对象附近打开 compact transient color chooser
```

没有永久 Pin toolbar。

### Frame D

选一个已有颜色或创建真实用户颜色。

canonical membership 写入。

---

## 10.3 Node-local Scene

对象存在 Pin：

```text
节点 body 上方
显示小 Color Pin dots
```

它：

```text
persistent
```

但不是：

```text
右上角 Action Arc anchor
```

也不是 Map Locator 形态。

---

## 10.4 Global Pin Index

只有真实存在 membership 的颜色才出现。

没有 Pin：

```text
top-center 什么也没有
```

不能显示：

```text
红橙黄绿蓝紫
```

等着用户填。

---

## 10.5 Click one color

点击 Blue：

```text
所有 Blue members
→ temporary outline/highlight
```

一个 member：

```text
可直接 Focus/Fly-to
```

多个 member：

```text
compact members popover
```

popover 中只要：

```text
glyph
title
必要 location hint
```

不能膨胀成 Inspector。

---

## 10.6 Hover

Hover color：

```text
name
count
```

例如：

```text
蓝 · 竞品 · 4
```

默认 Canvas 仍主要显示颜色本身。

---

# 11. T2-I · Dynamic Map Locator / Edge Cursor

这是用户刚刚进一步精确冻结的系统。

## 11.1 用户语言

目标还在屏幕里：

```text
不要额外弄一支大箭头。
```

目标离开屏幕：

```text
原来的空间导航视觉自然变成指路形。
```

点击：

```text
别弹任何东西。
镜头直接丝滑带我过去。
```

---

## 11.2 Inside Scene

### Frame A

目标在 activeSpatialViewport 内。

```text
Locator = hidden / node-local navigation identity only
```

---

## 11.3 Near-edge Scene

### Frame B

目标逐渐接近 safe edge。

同一视觉家族：

```text
开始 morph
```

避免：

```text
display:none
→ 突然 mount 一个完全不相关 arrow
```

---

## 11.4 Offscreen Scene

### Frame C

目标完全 offscreen。

Locator：

```text
贴 active safe edge
方向轴 / pointed tip 指向真实 world target
```

不是贴：

```text
被 Work View 遮住的 browser physical edge
```

---

## 11.5 Click Scene

### Frame D

pointerdown：

```text
轻 pressed response
```

pointerup：

```text
直接导航
```

禁止：

```text
modal
popover
confirmation
menu
```

---

## 11.6 Camera Travel Scene

### Frame E

camera 平滑运动。

Locator 短暂保留方向连续性。

随着 target 进入：

```text
Locator 向 arrival morphology 收敛
```

---

## 11.7 Final Fit Scene

### Frame F

不是：

```text
target center = browser center
fixed zoom
```

而是：

```text
target real bounds
+ optical padding
+ activeSpatialViewport
→ fit
```

结果：

```text
目标完整可见
大小自然
可立即继续操作
不被 Dock / Rail / Composer 遮挡
```

---

## 11.8 Multi target

多目标：

```text
union bounds
→ fit union
```

---

## 11.9 禁止

```text
❌ LocatorStore
❌ Locator 自己存 world coordinate truth
❌ Locator 自己维护 camera
❌ 点击先弹信息卡
❌ fixed zoom
❌ physical viewport center
```

---

# 12. T2-J · Arrival Beacon

## 12.1 用户语言

用户不应该在飞过去后还要找：

> 到底是哪一个？

到达必须有极轻的一次：

```text
“就是它”
```

---

## 12.2 Scene

Camera travel 结束：

```text
Locator dissolve
```

目标 body：

```text
pulse / field 轻增强 1–2 次
```

然后：

```text
恢复安静
```

---

## 12.3 Beacon 来源

只允许真实 navigation：

```text
Focus
Search → Focus
Rail locate
Agent locate
Assembly Return
cross-Surface navigation
```

普通 hover 不产生 Beacon。

---

## 12.4 禁止

```text
❌ toast “已定位到 xxx”
❌ 大型 modal
❌ 长时间闪烁
❌ 永久高亮
```

---

# 13. T2-K · Minimap

## 13.1 用户语言

Minimap 是：

> 我想看整个大现场的大致方位和视口位置。

不是：

> 正常找具体对象的第一工具。

具体找目标：

```text
Search / Focus / Locator
```

优先。

---

## 13.2 Default Scene

后期冻结已经否定早期“大固定地图”作为默认主视觉。

最终倾向：

```text
compact / low-presence
```

具体尺寸和展开形态：

```text
需在 donor visual pass 后冻结
```

不能直接拿早期 `176×112` 当最终。

---

## 13.3 Expand Scene

需要看大局时：

```text
hover / explicit activate
→ minimap 轻展开
```

真实世界映射继续用 Huabu / ReactFlow。

---

## 13.4 Click Scene

点击 Minimap：

```text
camera navigation
```

目标中心基于：

```text
active usable viewport
```

不是物理 browser center。

---

## 13.5 Work View Scene

Work View 打开：

```text
Minimap 重新找 safe corner
```

不被 Dock 覆盖。

---

## 13.6 禁止

```text
❌ 第二套 world→mini coordinate engine
❌ Toolcase minimap world model 接管 LCOS
❌ permanent huge map by default
❌ minimap click 改 Surface membership
```

---

# 14. T2-L · Layer Panel / Current Surface Search & Filter

## 14.1 用户语言

Layer Panel 回答：

> 我现在这个现场里面有什么，以及当前画布层级怎么组织。

不是：

> 整个项目去哪。

---

## 14.2 Scene

当前 Surface 内：

```text
hierarchy
type filter
canvas-local query
```

可以共存。

但它们不升级成：

```text
Project Search
Railway
Focus
```

---

## 14.3 Search distinction

Huabu Canvas Search：

```text
当前 canvas 内找 node
```

LCOS Project Search：

```text
跨 Project object / content / occurrences
```

可以共享：

```text
input primitive
keyboard mechanics
```

不能共享 canonical result truth。

---

## 14.4 禁止

```text
❌ Layer Panel 变项目导航树
❌ Project Search 塞进 Layer filter
❌ Railway 和 Layer 合并成一个 Explorer
```

---

# 15. T2-M · Active Spatial Viewport / Work View Safe Rect

## 15.1 用户语言

打开右侧 Work View：

> 我只是打开一个工作视图，不是让整个世界突然自己平移。

---

## 15.2 Open Scene

### Frame A

Canvas 原 camera 稳定。

### Frame B

Work View 从右侧进入。

```text
Camera 不自动变
```

但是：

```text
HUD
Locator
Pin Index
Focus Index
Search
Minimap
edge gesture
```

立即把右边区域视作 occupied。

---

## 15.3 Resize Scene

用户拖 Work View 宽度。

内容跟手。

Canvas camera：

```text
不每个像素自动纠正
```

HUD：

```text
按新的 safeRect 重排
```

---

## 15.4 Explicit Focus after Dock

用户这时点击 Locator / Focus：

```text
camera 可以移动
```

因为这是显式 navigation。

最终 target：

```text
fit 在剩余 spatial area
```

不是 Dock 后面。

---

## 15.5 Edge gesture

Work View 区域内：

```text
Work View owns pointer
```

Canvas edge auto-pan / locator edge：

```text
只认 active spatial edge
```

---

# 16. T2-N · Navigation Right-click / More Boundary

## 16.1 用户语言

高频导航动作：

```text
直接点
直接拖
Action Arc
快捷键
```

低频管理：

```text
Right-click / More
```

---

## 16.2 允许进入 Right-click

例如：

```text
rename
duplicate
remove
delete
organize
management
```

---

## 16.3 不应该藏进去

```text
Focus
Search
Assembly direct entry
Pin direct authoring（高频对象局部）
Railway navigation
```

这些应该有更直接入口。

---

# 17. T2 几个系统之间的完整用户旅程

## Journey 1 · “我不知道那个文件在哪”

```text
Cmd/Ctrl+F
→ top-center Search
→ 输入“冰箱创意”
→ 显示 5–7 个 readable results
→ hover 一个结果
→ 当前画布有 occurrence 就轻 highlight
→ 点击
→ Focus/Fly-to
→ offscreen 时出现 Locator
→ camera travel
→ safeRect fit
→ arrival beacon
→ 继续操作
```

没有：

```text
Search modal
engine mode
结果详情页
确认导航
```

---

## Journey 2 · “我知道这个对象，想看它在哪些地方”

```text
select object
→ F
→ Focus index
→ Main / Context A / Workflow B 三个 occurrence
→ hover 看 identity
→ click Workflow B
→ switch surface
→ locator / travel
→ target fit
→ arrival
```

---

## Journey 3 · “这个以后我还要经常回来”

```text
select object
→ Action Arc
→ Pin
→ compact color chooser
→ Blue
→ node 上方出现 blue dot
→ top Pin Index 出现 Blue
```

以后：

```text
click Blue
→ members highlight
→ multiple → compact members popover
→ click member
→ Focus/Fly-to
```

---

## Journey 4 · “把这个东西拿去 Context 用”

```text
select / drag object
→ Railway Context A receptive
→ drop
→ semantic commit
→ Context preview updates
```

没有：

```text
选择目标 Modal
选择操作 Modal
确认一次
```

---

## Journey 5 · “右侧正开着 Work View，我还要定位一个节点”

```text
Work View docked right
→ target behind / outside active safe area
→ Locator attaches to active right edge（Dock 左边）
→ click
→ camera fit target into remaining Canvas
→ target not hidden behind Work View
→ arrival
```

---

# 18. EARLY → CORRECTED → FINAL 纠偏账（T2 第一版）

## 18.1 Search / Focus

EARLY：

```text
Search 和 Focus 曾共用一个 navigator
```

CORRECTED：

```text
Ctrl/Cmd+F = Search
F = Focus
```

FINAL：

```text
Search = 不知道什么/在哪
Focus = 已知对象的 occurrences
Search 可 handoff Focus
state 永不合并
```

---

## 18.2 Minimap

EARLY：

```text
固定左下 176×112
作为常驻控制区
```

CORRECTED：

```text
Beacon / Focus 是具体导航第一反馈
Minimap 地位下降
```

FINAL：

```text
Minimap = 大现场方位
compact / safe-rect aware
Huabu world mechanics
具体 chrome 等 donor pass 冻结
```

---

## 18.3 Railway

EARLY：

```text
传统 Left Rail / workspace sidebar
```

CORRECTED：

```text
Project View Rail
saved views 平级
```

FINAL：

```text
一级 worksite navigation
member preview
Receiver
cross-Surface drop
不被 Unified Work View 替代
```

---

## 18.4 Cross-Surface Drop

EARLY：

```text
drop shelf / 感应区
→ 再选动作
```

CORRECTED：

```text
direct project-view target
```

FINAL：

```text
Drop 到哪
= 就在那里使用
目标本身表达 intent
只有真实歧义/危险才询问
```

---

## 18.5 Pin

EARLY：

```text
binary Pin / marker
```

CORRECTED：

```text
Color Pin
```

FINAL：

```text
many-to-many user-authored spatial index relationship
node-local dots
top-center only real colors
member navigation → Focus
```

---

## 18.6 Work View geometry

EARLY：

```text
Dock 打开后帮用户自动 recenter camera
```

CORRECTED：

```text
persistent UI 影响 safe region
```

FINAL：

```text
open/resize ≠ camera command
HUD reflow
explicit Focus 才移动 camera
```

---

# 19. 当前实现状态映射

以下不是最终施工卡，只用于避免把 Frozen UX 误说成 Done。

| System | Product UX | Core Truth | Huabu Mechanic | Gen2 GUI |
|---|---|---|---|---|
| Railway | FROZEN | rail order AVAILABLE | shell/DnD AVAILABLE | MISSING / TO WIRE |
| Surface Switch | FROZEN | surface identity AVAILABLE | canvas identity/runtime AVAILABLE | production host incomplete |
| Cross-Surface Drop | FROZEN | semantic Core paths vary | move mechanic upstream AVAILABLE | primary Railway UX MISSING |
| Receiver | FROZEN | AVAILABLE | presentation only | thin consumer missing |
| Project Search | FROZEN | AVAILABLE | input/chrome reuse possible | client exists, final GUI host missing |
| Focus | FROZEN | occurrence/location truth available | camera/focus mechanics | final Gen2 consumer missing |
| Color Pin | FROZEN | AVAILABLE | presentation only | Gen2 final consumer missing |
| Locator | FROZEN | target resolution AVAILABLE | geometry/camera | exact dynamic morph consumer missing |
| Beacon | FROZEN | transient presentation | motion | final consumer missing |
| Minimap | FROZEN | no extra truth | Huabu ReactFlow MiniMap | chrome/policy to wire |
| Layer Panel | FROZEN boundary | Huabu canvas local state | mature current mechanics | LCOS integration needed |
| Safe Rect | FROZEN | presentation session state | geometry seam | production integration incomplete |

---

# 20. 对 donor / OSS 的直接约束

从现在开始 T2 donor 不能自由选择。

必须匹配 Scene。

## 20.1 Locator

需要 donor 能回答：

```text
inside → edge → offscreen morph
direction morphology
pressed
travel continuity
arrival
```

不能只因为某 OSS 有一个漂亮 arrow icon 就采纳。

---

## 20.2 Railway

需要 donor 能回答：

```text
compact worksite identity
preview
active state
DnD receptive
receiver badge
low persistent chrome
```

不能直接拿一个 macOS Dock 就说完成 Railway。

---

## 20.3 Minimap

需要 donor 回答：

```text
compact resting
expand/reveal
safe corner
minimal chrome
```

mechanics 已经由 Huabu 决定。

---

## 20.4 Search / Focus / Pin

需要 donor 回答：

```text
top-center cluster
center rebalancing
hover identity
compact overflow fan
transient transitions
```

不能采用左侧长列表 donor 破坏冻结 GUI。

---

# 21. 后续 Exact Source-Level 施工必须回指这些 Scene

示例：

```text
T2-I-LOCATOR-FRAME-C~F
→ exact file
→ screen projection adapter
→ icon/morph body
→ click handler
→ Huabu camera fit
→ safeRect
→ arrival
```

再例如：

```text
T2-C-CROSS-DROP-FRAME-B~E
→ Railway target body
→ Huabu DnD sensor
→ destination adapter
→ Core semantic commit
→ target preview feedback
```

---

# 22. T2 UX FREEZE 目前的开放项

不是语义开放，而是视觉参数待 donor pass：

```text
1. Railway exact collapsed width
2. Railway icon/preview exact geometry
3. Minimap exact compact size
4. Minimap hover/activate expansion size
5. Locator exact SVG morphology
6. Locator morph duration/easing
7. Beacon exact pulse amplitude/duration
8. Centered Index exact item size/gap/arc
9. Color Pin palette material/shadow
10. Search result pill exact typography/density
```

这些参数后续必须通过：

```text
TapNow / Lovart / LibTV / Spatial
+
permissive OSS supplier
+
LCOS visual baseline
```

确定。

这里不允许施工 Agent 自己“看着舒服调一下”。

---

# 23. T2 UX FREEZE 目前不开放的事项

以下已经是硬语义，不得 donor 改写：

```text
Search ≠ Focus
Pin ≠ Focus
Railway ≠ Layer Panel
Railway ≠ Work View
Minimap ≠ Project Search
Locator click = no popup
Work View open = no auto camera move
explicit Focus = safeRect-aware fit
Drop 到 Railway target = destination already expressed
Receiver = Core canonical
Color Pin = many-to-many persistent relationship
Huabu = world/camera/viewport mechanic owner
```

---

# 24. 下一步施工前置动作

T2 接下来不立即写 final `04_Source_Level_Construction_Plan`。

正确顺序：

```text
1. 对上述每个 Scene 回溯 exact user-original evidence
2. donor visual pass
3. 把视觉开放参数冻结
4. current consumer trace
5. exact file target
6. props / JSX / CSS / token / motion
7. acceptance
```

最终每一张施工卡至少要做到：

```text
用户画面已经确定
+
视觉 donor 已确定
+
mechanic owner 已确定
+
canonical truth 已确定
+
可直接抄的 OSS file 已确定
+
CSS/token/motion 已确定
```

然后施工 Agent 才有资格落代码。

---

# 25. 一句话

T2 的导航最终不是：

```text
一堆导航组件
```

而是：

> **用户在项目空间里永远知道自己在哪、目标在哪、怎么直接过去、怎么留下锚点、怎么换工作现场，而且这些动作不靠弹窗、模式选择和大侧栏来解释。**

更短：

```text
看见
→ 指向
→ 直接过去
→ 刚好接住
→ 继续工作
```

这才是后续所有源码施工的上游真相。

---

# 26. Scene ID 与原始证据回指表

后续施工卡必须至少引用一个 Scene ID。

| Scene ID | 系统 | 核心用户画面 | 主要原始/冻结证据 |
|---|---|---|---|
| T2-A-RAIL-IDLE | Railway | 左侧低噪音 worksite switcher，当前现场明确 | `LCOS_20260821至20260902_全功能最新冻结总账_白话UX与Gen2施工映射.md` F-009 |
| T2-A-RAIL-HOVER | Railway | hover 才增强名称/member preview | 08-12 Project View Rail + 09-02 总账 |
| T2-B-SURFACE-SWITCH | Surface | Main/Context/Workflow 同物理、独立现场 | `LCOS_v0.15_UX冻结_同一套物理三个语义现场与Assembly_20260829.md` |
| T2-C-DROP-RAIL | Cross-Surface Drop | drag over target → receptive → release commit | 08-13 Direct Manipulation handoff；08-29 PointerCursor freeze |
| T2-C-DROP-NOMODAL | Cross-Surface Drop | destination 已由 drop 表达，不再 chooser | 08-29 “即拖即用”；09-02 总账 |
| T2-D-RECEIVER | Receiver | Railway 中可见当前 Receiver，handoff 不复制真相 | 08-31 Navigation/Receiver freeze；current Core Receiver |
| T2-E-SEARCH-OPEN | Search | Cmd/Ctrl+F → top-center compact input | 08-29 Search freeze；08-31 Centered Index freeze |
| T2-E-SEARCH-RESULT | Search | readable 5–7 result constellation | `LCOS_v015_CENTERED_SPATIAL_INDEX_SEARCH_ASSEMBLY_FREEZE_20260831.md` |
| T2-E-SEARCH-FOCUS | Search | 已知对象后 Search yield → Focus | 同上 + A25-5 |
| T2-F-FOCUS-OPEN | Focus | F → occurrence markers，无搜索框 | 08-29 Search/Focus split；A25-4 |
| T2-F-FOCUS-FAN | Focus | many occurrences → compact +N fan | A25-4 Focus Location Index |
| T2-G-TOP-ARBITER | Index | Search > Focus > Pin > none | 08-31 Centered Spatial Index freeze |
| T2-H-PIN-AUTHOR | Pin | selected → Arc → Pin → transient chooser | A25-7 Color Pin authoring |
| T2-H-PIN-LOCAL | Pin | node body 上方 persistent dots | 08-31 Centered Index freeze + A25-7 |
| T2-H-PIN-GLOBAL | Pin | top-center only live colors | 08-31 Centered Index freeze |
| T2-I-LOCATOR-MORPH | Locator | inside → edge → directional morphology | 08-26 Spatial Beacon；08-31 Map Locator freeze；2026-09-04 用户补充 |
| T2-I-LOCATOR-CLICK | Locator | click = zero-confirmation camera travel | 08-31 Map Locator freeze；2026-09-04 用户补充 |
| T2-I-LOCATOR-FIT | Locator | target bounds + safeRect → optical fit | 09-01 L0 Work View safe region；2026-09-04 用户补充 |
| T2-J-ARRIVAL | Beacon | settle → 1–2 次轻 pulse → quiet | 08-26 Spatial Beacon |
| T2-K-MINIMAP | Minimap | 大局方位辅助，不抢具体导航 | 08-26 Beacon/Minimap 分工；09-01 A25 safe geometry |
| T2-L-LAYER | Layer | current Surface hierarchy/filter/query only | current Huabu Layer/Search consumer + Search freeze |
| T2-M-SAFE-OPEN | Work View | open/resize 不自动 move camera | 09-01 Latest L0 |
| T2-M-SAFE-HUD | Work View | HUD/Locator/Minimap 围绕 activeSpatialViewport 重排 | 09-01 Latest L0 |
| T2-M-SAFE-FOCUS | Work View | explicit Focus 才 camera fit remaining area | 09-01 Latest L0 |
| T2-N-MORE | Right-click | management only，高频导航不藏入 More | 09-01 Latest L0 |

---

# 27. 后续施工卡强制回指格式

每张 source-level construction card 使用：

```text
UX_SCENE_IDS:
- T2-I-LOCATOR-MORPH
- T2-I-LOCATOR-CLICK
- T2-I-LOCATOR-FIT

USER_VISIBLE_ACCEPTANCE:
1. target in viewport → no redundant edge locator
2. target offscreen → locator attaches active safe edge
3. click → no modal/popover
4. camera travels continuously
5. target settles fully inside safeRect
6. arrival feedback is transient
```

然后才允许写：

```text
TARGET_FILES
OWNER
DONOR
COPY_FROM
PROPS
JSX_STRUCTURE
CSS_TOKENS
MOTION
TESTS
```

如果施工卡无法回指 UX Scene：

```text
SOURCE CONSTRUCTION = BLOCKED
```

---

# 28. 对 T2 donor visual pass 的测量清单

下一阶段不是再泛泛“看 TapNow / Lovart”。

需要对照 Scene 逐项量：

## Railway

```text
collapsed width
active item footprint
icon/body size
preview reveal method
hover label timing
drag receptive state
target highlight radius/material
Receiver indicator density
item reorder motion
```

## Centered Index

```text
item diameter / pill height
1–7 item layouts
center rebalance curve
horizontal/vertical gap
hover scale
active marker treatment
+N fan geometry
label reveal timing
```

## Locator

```text
inside morphology
near-edge intermediate morphology
offscreen pointed form
edge inset
rotation/orientation method
pressed scale
travel persistence duration
arrival transition
```

## Pin

```text
local dot diameter
dot gap
node-body offset
top-index diameter
hover label
members popover width
single→direct navigation threshold
```

## Minimap

```text
resting footprint
expanded footprint
corner inset
border/radius
background opacity
viewport box material
reveal/close timing
drag/click affordance
```

## Search

```text
input width/height
result pill height
glyph-title gap
5–7 result constellation
overflow +N
keyboard active treatment
loading/error morphology
```

这些数值一旦 donor pass 冻结：

```text
不再留给施工 Agent 自己调审美。
```

---

# 29. T2 Scene Freeze Completion 标准

只有同时满足：

```text
USER ORIGINAL RECOVERED
LATEST OVERRIDE APPLIED
UX SCENE VISUALIZED
GUI SPATIAL LAYOUT FROZEN
INTERACTION TRANSITION FROZEN
NO-POPUP / CONFIRMATION RULE FROZEN
SAFE-RECT BEHAVIOR FROZEN
DONOR MEASUREMENT COMPLETE
```

某个 T2 系统才允许从：

```text
UX_SCENE_RECOVERY
```

升级为：

```text
UX_FREEZE_PASS
```

随后才进入：

```text
SOURCE_LEVEL_BLUEPRINT
```
