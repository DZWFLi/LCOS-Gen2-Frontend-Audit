# LCOS Gen2 · T4 第四路
## V2 最终冻结后的统一多工作区窗口 · Dockview Donor 裁决与架构纠偏

日期：2026-09-05  
源码锚点：`DZWFLi/LCOS_Gen2@c2ff890a867922a1256572199458438572eb0a8c`

状态：
```text
SOURCE-LEVEL PREPLAN / DONOR VERDICT
NOT FINAL CONSTRUCTION PLAN
NO PRODUCTION PATCH AUTHORIZED
```

## 0. 核心纠偏

9 月 5 日 V2 冻结明确：Conversation 子画布、Conversation 深度预览、Assembly 可以同时存在；除主画布外的大工作界面统一支持 Float / Dock / Undock / Resize / Move / 横纵组合 / 独立关闭 / Restore。

因此旧的：
```text
ONE WORKVIEW INVARIANT
one active professional body
one activeTarget represents whole professional layer
```
全部标记：
```text
SUPERSEDED
```

保留的正确部分只有：**某个具体工作区实例在 Float / Dock / Undock / Resize 时，不应因为 placement 改变而复制 canonical object 或无意义重建 body。**

新的第四路核心对象应理解为：

> Professional Workbench：一个管理多个专业工作区 screen-space 拓扑的窗口系统。

它只拥有：
- 当前打开哪些专业工作区；
- split/group/tab；
- floating / docked；
- rect/size；
- visible/closed；
- maximize/restore；
- UI presentation layout。

它不拥有：
- Artifact / Conversation / Context / Workflow / Skill / Run / Assembly truth；
- Canvas camera；
- Canvas nodes；
- Project membership；
- Relation；
- Archive canonical truth。

---

## 1. current Huabu 能继续直接吃什么

### MainLayout

成熟能力：
- left/right collapse；
- left/right resize；
- right-panel motion；
- Preview fullscreen；
- Canvas restore choreography。

但结构本质仍是：
```text
LEFT | CANVAS | ONE RIGHT PANEL
```
它不是通用 dock manager。V2 后禁止继续把它扩成 rightPanel2 / bottomPanel / floatingPanels / splitGroups。

### PreviewWorkspace

current 已经有：
- tabs；
- 最多两组；
- 水平 split；
- tab group 间拖动；
- keyboard splitter；
- split ratio；
- scroll memory；
- dnd-kit。

裁决：
```text
KEEP:
PreviewWorkspace 作为 Preview 专属 body / mini-workspace

DO NOT:
把 previewWorkspaceStore 升格成 project-global Workbench truth
```

---

## 2. 主 Donor 候选比较

| 能力 | Dockview | FlexLayout | React Mosaic | Allotment | Huabu+Motion 自拼 |
|---|---|---|---|---|---|
| 多工作区 | YES | YES | YES | split only | 需自写 |
| 横纵 split | YES | YES | YES | YES | 需扩 |
| tabs/groups | YES | YES | 新版有 | NO | Preview仅局部 |
| Float | YES core | 当前主线偏 tabset/popout | 非主强项 | NO | Motion |
| Dock/Undock | YES | YES | 部分 | NO | 自写 |
| resize | YES | YES | YES | YES | 组合 |
| serialization | YES | JSON | tree | sizes | 自写 |
| stable moved panel | YES | YES | 需验证 | N/A | 自己负责 |
| React 19 | official 16.8–19 | 需谨慎 | 新版补齐 | 已补 peer | YES |
| DnD 风险 | zero runtime dep，可拦截 | 中 | react-dnd multi-backend | low | dnd-kit |
| MIT | core/react YES | YES | YES | YES | existing |
| 工程增量 | 小/中 | 中 | 中+冲突 | 大 | 最大 |

### React Mosaic
因 `react-dnd` / multi-backend 与 Huabu 现有 dnd-kit 叠加风险，降为 REJECT_FOR_GEN2_WORKBENCH。

### Allotment
只解决 split pane，不解决 Float/Dock/Undock/group topology，降为 splitter reference。

### FlexLayout
成熟 tabset/dock/JSON model 很强，但 2026 仍有 internal floating tabs 相关开放工作，作为 SECOND_CHOICE。

### Huabu PreviewWorkspace + Motion 自拼
最终会自己实现 arbitrary split tree、floating groups、drag-to-dock、undock、serialization、collision、keyboard 等，已跨过“薄增量”边界，REJECT_AS_PRIMARY。

---

## 3. 第一推荐：Dockview React / Core

截至本轮检索，current docs 为 v8.2.0。

免费 MIT core/react 已提供：
- Panels / Groups / Tabs；
- resizable grid；
- group split；
- panel/group move；
- Floating Groups；
- Edge Groups；
- Maximize/Restore；
- `toJSON/fromJSON`；
- React binding。

许可：
```text
dockview-core   MIT
dockview        MIT
dockview-react  MIT
dockview-enterprise proprietary
```

LCOS 只考虑 MIT core/react。

Enterprise 的 Smart Guides、DnD Compass、Layout History、auto edge groups 等增强不能偷写成免费 core 能力。第一版也不依赖它们。

---

## 4. Dockview 为什么贴 V2

### 同一 panel Dock → Float
`addFloatingGroup()` 接受 existing panel/group，不要求重建另一个 FloatingPanel。

### 同一 panel 在 group 间移动
`panel.api.moveTo()` / group move 可移动 existing panel，不销毁后创建。

### Stable body
专业 panel 可使用：
```ts
renderer: 'always'
```
保持 DOM/React state。

对于 heavy body，不可见时仍应暂停 animation/polling/video/expensive observers，避免后台烧资源。

### Immersive
Docked group 可以 maximize/restore。Floating group不能直接 maximize，因此 Floating → Immersive 的候选语义是：
```text
move same panel/group back to grid
→ maximize same group
```
这条必须经过 prototype 身份连续性验证后才能进入 final plan。

---

## 5. 最关键接法：Protected Canvas Panel

Dockview 不应该把 Canvas 当普通工作窗。

建议：
```text
MainLayout
├─ existing Left Navigation / Header
└─ ProfessionalWorkbenchStage
   └─ DockviewReact
      ├─ ProtectedCanvasPanel
      ├─ Assembly
      ├─ Conversation Preview
      ├─ Context professional views
      ├─ Workflow deep views
      ├─ Skill Builder
      ├─ Run Review
      ├─ Archive
      └─ Web/PDF/HTML deep views
```

Protected Canvas 配置候选：
```text
panel id = lcos:spatial-canvas
renderer = always
group header = hidden
group locked = true
```

`locked=true` 正好允许：
- 其他 group 从 Canvas 四周 split；
- 但不能把工作 panel drop 进 Canvas group 成为 tab。

Canvas 还必须通过 LCOS guard 禁止：
- close；
- float；
- popout；
- 被拖走；
- 成为普通 tab；
- 被 persisted layout 删除。

panel id 不应包含当前 `canvasId`。Main→Context→Workflow 应保持同一 Canvas host，LCOS runtime `retarget(newCanvasId)`。

---

## 6. “Canvas 稳定”到底怎么验

Docked 工作区打开后，Canvas DOM 可见宽高变化是合法的。

禁止的是：
```text
setViewport()
fitView()
camera x/y/zoom mutation
node layout mutation
自动平移 world
```

浏览器验收：
```text
snapshot Huabu viewport transform
→ open Docked Assembly
→ resize
→ split Run Review
→ float/redock
→ close
→ viewport transform unchanged
```

只有用户主动 Pan / Zoom / Focus 才能改 Camera。

---

## 7. T1 safe-region 继续保持通用协议

T1 不应该知道 Dockview。

T4 把 docked professional regions 转成 generic edge occupancy：
```html
data-spatial-viewport-occupant="right|left|top|bottom"
```

T1 继续只消费 generic occupied DOM rect。

Floating region：
```text
不缩 activeSpatialViewport
```
只参与 overlay collision。

未来即便 Dockview 换掉，T1 不用改。

---

## 8. MainLayout 的新裁决

旧计划中“继续给 MainLayout 加 controlled rightWidth”只适合单右栏时代。

V2 后建议：

```text
MainLayout
KEEP:
- left navigation/header column
- left collapse/resize
- shell sizing

RETIRE after Workbench adoption:
- professional rightPanel ownership
- Preview fullscreen ownership
- right-panel-specific width/motion as global professional mechanic
```

最终 center：

```text
MainLayout
└─ ProfessionalWorkbenchStage
```

不要把 MainLayout 继续改造成第二 Dockview。

---

## 9. PreviewWorkspace 怎么迁

不要重写 Preview 当前成熟 body。

```text
PreviewWorkspacePanel
→ WorkbenchPanelHost(kind='preview-workspace')
```

它内部仍可保留：
- 两组 preview；
- tabs；
- open-to-side；
- scroll memory。

Dockview 负责“Preview 这个专业区域和 Assembly/Run Review 之间怎么排列”；PreviewWorkspace 负责“Preview 自己里面怎么看多个预览”。

这是两级不同职责，不冲突。

---

## 10. Workbench semantic descriptor 必须很薄

候选 UI type：

```ts
type ProfessionalRegionKind =
  | 'conversation-preview'
  | 'assembly'
  | 'context'
  | 'workflow'
  | 'skill-builder'
  | 'run-review'
  | 'archive'
  | 'web'
  | 'pdf'
  | 'html'
```

它是 renderer/body taxonomy，不是 Domain taxonomy。

```ts
interface ProfessionalRegionDescriptor {
  regionId: string
  projectId: string
  kind: ProfessionalRegionKind
  target: CanonicalTargetRef
}
```

不能塞 canonical content。

`regionId` 表示 Workbench presentation instance identity。

例如同一个 Conversation 可以同时有：

```text
Conversation subcanvas
Conversation Preview region
Assembly region(target = that Conversation)
```

三种 presentation，canonical Conversation仍只有一个。

---

## 11. Close / Restore 不能碰 canonical entity

Dockview panel `close()` 只允许映射为：

```text
关闭专业工作区 presentation
```

绝不能映射为：
- Delete Artifact；
- Delete Context；
- Delete Workflow；
- Delete Skill。

最新冻结中的 Restore 需要区分：
1. 当前 Workbench session 重新打开某个专业区域；
2. app restart 是否还原所有窗口拓扑。

第 2 点产品冻结没有写死 exact persistence scope，所以 T4 不擅自把 floating rect / split tree 写进 Core Project Truth。

Dockview `toJSON/fromJSON` 若使用，也只能是 UI presentation persistence，并且必须 sanitize Protected Canvas。

---

## 12. DnD 防串台

Huabu 当前依赖：
```text
@dnd-kit/core
@dnd-kit/sortable
```

Dockview没有引入 react-dnd runtime dependency，并暴露：
```text
onWillDragPanel
onWillDragGroup
onWillDrop
onWillShowOverlay
onUnhandledDragOver
```

官方也明确提供 third-party DnD 协同入口。

必须验收：

```text
拖 panel header
→ Workbench layout move

拖 Artifact body
→ LCOS Semantic Drop
→ Workbench docking overlay不出现

右拖 Artifact
→ LCOS proxy semantics

拖 Relation handle
→ canonical Relation

拖 Skill body
→ LCOS target semantic drop
```

不能因为整个画面有 Dockview 就把一切拖动都解释成“搬窗口”。

---

## 13. Visual donor 与 Engineering donor 分开

ENGINEERING：
```text
Huabu
+ Dockview MIT
+ LCOS thin adapters
```

VISUAL / INTERACTION：
```text
Spatial:
- low-chrome spatial work
- layered workspace feeling
- movement / spatial continuity

TapNow:
- transient controls
- compact hover labels
- direct manipulation
- low mode/chrome density

Lovart:
- content-first panel hierarchy
- masonry / waterfall
- Source Bay / material browser density
- persistent workspace visual hierarchy
```

Dockview不是视觉答案，它只是“窗户怎么活”的成熟 wheel。

---

## 14. Archive · V2 新增的 T4 专业 body

V2 冻结：
```text
Archive
→ 按归档日期
→ Masonry / Waterfall
→ 单选 Restore
→ 多选 Restore
→ Restore All per day
```

视觉首选 donor：
```text
Lovart masonry / material browsing
```

工程上 Huabu 已有：
```text
react-virtuoso
```
可用于长列表/虚拟化，不新增另一套虚拟列表依赖。

Archive body应该是内容优先浏览，不做后台表格。

---

## 15. Archive 当前 Core gap

本轮对 current repo 检索：
```text
archive
archivedAt
```
没有找到现成 Archive contract/owner。

因此当前只能判：

```text
PRODUCT:
FROZEN

T4 ARCHIVE UX:
CAN PLAN

CORE ARCHIVE TRUTH:
NOT FOUND / NEED T6-CORE CENSUS
```

禁止：
```text
local hidden array
localStorage archived nodes
借 hiddenViewIds 冒充 Archive
```

Canonical Archive最低应支持：
- original identity；
- archived state；
- archivedAt；
- archive/restore mutation；
- read-only guard；
- Search/Assembly/Reference 可发现；
- Relation/Collection/Context/Workflow 引用保留；
- Restore 不恢复 old Main x/y。

按“归档日期”分组是确定规则，不应让 Agent 猜。

---

## 16. Glyth 深度工作现场

V2 正式允许：
```text
Conversation subcanvas
+ Conversation Preview
+ Assembly
```
同时存在。

工程默认拓扑候选可为：
```text
Canvas | Preview
       | Assembly
```
或：
```text
Canvas | Preview | Assembly
```

具体默认横纵与比例仍交给 T4/T5 继续从 Spatial / TapNow / Lovart 的实际 donor 中测，不在产品冻结里硬编答案。

关键不变：
```text
same Conversation
same session
three presentation regions
no cloned Conversation truth
```

---

## 17. Context / Workflow 在 Workbench 中的位置

### Context
Context Atlas / 时间演进 / Relationship / Provenance 是查看同一 Context 的专业工具，不等于创建第二 Context。它们可以作为专业 region 与 Assembly/Preview 并存。

不要再机械设计“四个长期 tab”。最新 V2 用户心智是：
```text
Context
├─ 默认时间地图
└─ Agent 派生事情地图

面 → 全局
线 → 演进
点 → 具体工作
```
专业 instrument 是实现这些体验的手段，不反过来成为产品一级心智。

### Workflow
Workflow本身继续是一级自由 Surface，不是放进 Workbench 的 DAG 编辑器。

Workbench里的 Workflow deep regions用于：
- 某轮工作深查；
- 某结果；
- Review；
- logs/tool calls/provider/retry 等三级信息。

主 Workflow Surface仍以真实材料、关键动作、结果为主角。

---

## 18. ProjectSession × Workbench × Surface

更新后的结构：

```text
ProjectSession
├─ ONE LCOS runtime
│  └─ retarget(current Surface.canvasId)
├─ ONE ProfessionalWorkbench manager
│  ├─ Protected Canvas host
│  └─ N professional regions
└─ Surface
   ├─ Main canvasId
   ├─ Context canvasId
   └─ Workflow canvasId
```

注意：

```text
ONE Workbench manager
≠ ONE WorkView
```

Surface切换：
```text
Protected Canvas host stays
runtime.retarget(newCanvasId)
professional regions stay unless target invalid
```

Project切换：
```text
dispose Project A runtime/workbench session
create Project B session
```

不能串项目。

---

## 19. Overlay arbitration 的新输入

旧的：
```text
workViewOpen: boolean
```
已经不足以完整表达 V2。

但也不能把 Dockview API塞进 overlay arbitration。

Overlay只消费 derived facts：
```text
hasProfessionalRegions
activeProfessionalRegion
occupiedRects / activeSpatialViewport
floatingCollisionRects
```

由 Workbench adapter转换。

Action Arc / Composer / Locator / Minimap只看通用 screen-space facts。

---

## 20. ExactFile 候选

### dependency
```text
huabu/apps/web/package.json
+ dockview-react
```
真正施工时重新 pin 当日稳定版本，禁止写 `latest`。

### ADD candidates
```text
huabu/apps/web/src/lcos/workbench/ProfessionalWorkbenchStage.tsx
huabu/apps/web/src/lcos/workbench/workbenchModel.ts
huabu/apps/web/src/lcos/workbench/workbenchRegistry.ts
huabu/apps/web/src/lcos/workbench/WorkbenchPanelHost.tsx
huabu/apps/web/src/lcos/workbench/ProtectedCanvasPanel.tsx
huabu/apps/web/src/lcos/workbench/workbenchDndPolicy.ts
huabu/apps/web/src/lcos/workbench/workbenchLayoutPersistence.ts
```

名字仍需 prototype 后 final lock。

### MODIFY
```text
huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
huabu/apps/web/src/pages/CanvasPage/CanvasPage.tsx
huabu/apps/web/src/components/Panels/PreviewWorkspace/PreviewWorkspacePanel.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
```

`App.tsx / ProjectSessionProvider` 的上提方向继续保留，不因多 WorkView 纠偏而改变。

---

## 21. SUPERSEDED ledger

```text
One WorkView Invariant                         SUPERSEDED
global single activeTarget WorkView           SUPERSEDED
MainLayout.rightPanel as sole work destination SUPERSEDED
one professional body mounted at a time        SUPERSEDED
basePlacement alone models whole work layer    SUPERSEDED
WorkViewDockSlot as the only docking model     SUPERSEDED
```

仍然 KEEP：
```text
stable individual body across placement changes
no duplicate canonical truth
Camera not owned by work window system
ProjectSession above Surface
generic safe-region contract
```

---

## 22. Dockview prototype gate

当前裁决：
```text
Dockview React/Core
ENGINEERING_STATUS:
STRONG ADOPT CANDIDATE / PROTOTYPE REQUIRED
```

Final construction plan前必须证明：

### P1 Protected Canvas
```text
Canvas renderer='always'
header hidden
locked group
open/resize/float/redock work panels
Canvas React instance unchanged
```

### P2 Camera
```text
camera transform snapshot
dock / resize / float / redock
unchanged
```

### P3 semantic DnD
```text
dnd-kit Artifact drag
not captured as Workbench layout DnD
```

### P4 panel identity
```text
Assembly local filter/input state
Dock → Float → Dock
unchanged
```

### P5 multi-panel
```text
Conversation Preview
+ Assembly
+ Run Review
simultaneous
horizontal/vertical recompose
```

### P6 Surface switch
```text
Main → Context → Workflow
Protected host remains
runtime retargets
work regions remain
```

### P7 close/restore
```text
close presentation
reopen target
no canonical duplication
```

---

## 23. Replacement boundary / failure blast radius

如果 Dockview未来不合适，只替换：
```text
ProfessionalWorkbenchStage
layout adapter
panel host
presentation persistence
```

不得波及：
```text
Core
ProjectSession runtime
CanvasStore
SurfaceRegistry
AssemblyApply
Context truth
Workflow truth
Skill truth
Run truth
```

这才是 donor-first 的正确模块化，而不是把某个 library 变成新的系统真相。

---

## 24. 本轮一句话裁决

> **用 Dockview 解决“窗户怎么活”，用 Huabu 解决“空间怎么活”，用 Core 解决“对象怎么活”，用 TapNow / Lovart / Spatial 决定“这些东西怎么长得像成熟产品”。**

V2 的多窗口冻结不要求 LCOS 自己发明一个 IDE layout engine。恰恰相反，它把“应该吃成熟 wheel”的理由变得更强了。
