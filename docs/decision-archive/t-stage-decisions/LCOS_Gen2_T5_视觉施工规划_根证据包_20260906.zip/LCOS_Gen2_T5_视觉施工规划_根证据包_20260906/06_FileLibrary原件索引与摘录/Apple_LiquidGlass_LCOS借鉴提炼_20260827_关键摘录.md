# Apple Liquid Glass · LCOS 借鉴提炼关键摘录
> 来源原件：`Apple_LiquidGlass_LCOS借鉴提炼_20260827.md`（File Library）
> 本文件是可确认关键条款摘录，不是完整原件。

核心定位：macOS / iOS Liquid Glass 作为 LCOS 桌面 chrome、toolbar、popover、sidebar、material、motion 的规格参考。

许可边界：
> “抄规格，不碰素材”。

关键原则：
- Liquid Glass 用于浮在内容之上的导航/控件层，不用于内容本体大面积背景，不做“玻璃叠玻璃”。
- 材质应统一为有限梯度，不允许各面板自己发明 blur / opacity / shadow。
- 颜色应通过少量语义 token + alpha 层级收敛，而不是几十个灰值。
- radius、shadow、motion 都应成为有限阶梯，不再各业务组件随手写值。
- Apple/macOS 质感不是把所有东西都透明化，而是极少数 chrome 的克制材质 + 干净层级 + 精确 motion。
- 原件提出了 Liquid Glass material 梯度、label/fill 层级、radius 阶梯、duration/easing 家族，可作为 T5 token 候选证据，但最终数值仍需结合 current Huabu/T5 visual smoke。
