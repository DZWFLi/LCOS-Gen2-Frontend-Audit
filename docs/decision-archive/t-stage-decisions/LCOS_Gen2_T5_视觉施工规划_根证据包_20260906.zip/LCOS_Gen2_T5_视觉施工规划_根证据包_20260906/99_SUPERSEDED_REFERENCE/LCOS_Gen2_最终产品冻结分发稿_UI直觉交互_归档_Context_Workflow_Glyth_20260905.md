# LCOS Gen2 · 最终产品冻结分发稿
## UI 直觉交互 / 归档 / Context / Workflow / Glyth / 通用窗口
日期：2026-09-05

> 性质：面向 T1–T6 后续施工规划的跨线程产品冻结输入。
> 本稿冻结“用户看到什么、怎么操作、什么情况下产生什么结果”。
> 后续线程不得因为实现方便、donor 差异或局部视觉偏好反向修改这些产品语义。
> 视觉细节、尺寸、比例、动效、材质、窗口初始占比可由 T5 / 对应 UI 线程继续打磨，但不得改变这里的用户心智。

---

# 0. 总口令

LCOS 的产品目标不是增加功能入口，而是减少操作步骤。

优先级：

```text
直觉直接操作
>
轻量即时反馈
>
必要时临时提示
>
最后才是显式选择
```

用户应该尽量只需要：

```text
点
拖
丢
拉
直接打字
说一句自然语言
```

复杂结构、SQL、JSON、Markdown、Context 整理、Workflow 提炼、API 调用等由本地 Agent / 外部 Agent / Skill / API 处理。

---

# 1. UI 呈现标准：非必要不显示字

这条作为所有 T1–T6 UI 施工的硬标准。

## 1.1 控件图形优先

凡是可以明确通过以下方式表达的：

- 图标
- Glyph
- 形状
- 颜色
- 状态
- 动画
- 位置
- 大小
- 方向

默认不常驻文字。

例如：

- Pin
- Focus
- Search entry
- Minimap
- Receiver
- Run state
- Action Arc
- Close / Dock / Float
- Relation handle
- Reference
- Archive / Restore
- Context 时间视图 / 事情视图切换

优先图形表达。

## 1.2 文字按需出现

鼠标 Hover、键盘 Focus、选中或明确展开时：

```text
图形
→ 显示短标签 / Tooltip
```

不要默认堆：

```text
按钮文字
模式名称
说明文字
状态长句
```

## 1.3 这条规则只限制系统 Chrome

项目真实内容本身该有文字就有文字。

例如：

- Artifact 标题
- Conversation 内容
- Context 内容
- Workflow 结果
- 文档正文

不因为“少字”原则强行隐藏。

少的是：

> 系统解释自己在干什么的字。

不是项目内容。

---

# 2. 不设流程卡

任何操作只要从当前场景看起来是自然且语义唯一的，就直接允许。

禁止为了“系统严谨”强迫用户：

```text
先点模式
→ 再选类型
→ 再选目标
→ 再确认
→ 才执行
```

如果用户直接拖就能表达，就拖。

如果用户直接点就能输入，就输入。

如果用户直接双击就能进入，就进入。

如果用户直接把东西给 Agent 就能表达，就不要再开配置页。

---

# 3. 唯一例外：真的存在语义歧义

“不设流程卡”不等于让系统乱猜。

如果一个动作存在两个同样合理的不同含义：

> 用不同的直觉手势拆开。

例如：

```text
Artifact 身体拖到 Collection
= 加入集合

Relation handle 拉到 Collection
= 建立项目关系
```

不弹大 Chooser。

最多：

- 短 Tooltip
- 轻量状态提示
- 一次瞬时确认

不要引入完整向导。

---

# 4. 通用组件优先，禁止为每个视图客制一套

Context / Workflow / Glyth / Assembly 等所有地方优先复用：

- 同一个 Composer
- 同一个 Reference 机制
- 同一个 Action Arc
- 同一个右键菜单基础
- 同一个 Drag / Drop 语法
- 同一个 Work View
- 同一个 Tooltip / Popover
- 同一个 Selection
- 同一个 Voice Input

不要出现：

```text
ContextComposer
WorkflowComposer
GlythComposer
AtlasComposer
```

各自重新设计。

---

# 5. 某个通用能力在当前场景不支持时

不要重新做一个阉割版组件。

仍然使用通用组件。

例如 Context Atlas 某个派生区域不能作为 Reference：

用户操作 Reference 时：

```text
轻提示：
“这个视图不能直接作为 Reference”
```

即可。

如果可以引用其底层真实对象，则直接引导/解析到底层真实对象。

原则：

> 不因一个局部例外制造一套新轮子。

---

# 6. 所有文字输入统一为直接输入

凡是普通文字输入：

```text
点进去
→ 光标闪
→ 直接打字
```

不要：

```text
点一下
→ 弹 Modal
→ 选字段
→ 再输入
```

普通输入统一：

- inline caret
- direct typing
- Enter / blur 完成
- Esc 取消当前编辑

适用于：

- 改名
- Prompt
- 简短备注
- Agent 指令
- Search
- Collection / Workflow / Context 标签

复杂数据结构不让用户手写。

---

# 7. SQL / JSON / MD / Context 结构不做默认主交互

LCOS 不把用户变成数据库工程师。

例如用户想得到 SQL：

```text
把相关数据对象给本地 Agent
+
直接说目标
```

Agent：

```text
整理字段
生成 SQL
执行 / 调 API
返回结果
```

Context 同理。

用户：

```text
选这些材料
→ “这些属于同一件事，帮我整理”
```

Agent 可以返回：

- Markdown
- JSON
- 摘要
- 结构化 Context
- 关系建议

Workflow 也不要求用户手工编 DSL / DAG / API node。

---

# 8. Main 会不断变大，因此正式引入“归档”语义

随着项目长期使用：

Main 真实对象数量会持续增加。

不能无限把所有历史对象保持为活跃空间对象。

因此冻结：

> 项目对象可以进入 Archive / 归档状态。

归档不是删除。

也不是移到第二个项目仓库。

---

# 9. 归档后保留什么

归档对象继续保留：

- canonical identity
- 内容
- 历史版本
- provenance / 来源
- semantic Relation
- Collection membership
- Conversation / Run / Result 等真实语义关系
- Search / Focus 可发现性
- Context / Workflow 中的引用能力

也就是说：

> 库里登记的对象数量不变。

它仍然属于项目。

---

# 10. 归档后丢弃什么

归档后不再保留它在 Main 的“活跃空间现场”。

包括：

- 当前 x / y
- 当前画布排列
- 对特定 camera 的空间锚定
- viewport 相对位置
- 当前视觉群落位置
- 仅服务于该 Main projection 的局部布局信息

简单说：

> 归档保存“它是什么、和谁有关”，不保存“当时在桌面哪儿摆着”。

这是归档能够真正减轻长期 Main 负担的关键。

---

# 11. 归档后的编辑权限

归档对象进入：

> **只读冷状态。**

可以：

- Search
- 查看
- Focus / 定位到归档记录
- Reference
- 给 Agent 使用
- 被 Context 引用
- 被 Workflow 引用
- 被 Assembly 找到
- 参与历史 / provenance 查看

不能：

- 直接修改原对象内容
- 在原 Main 空间位置继续编辑
- 直接改变其旧空间排布

如果用户想修改原对象：

```text
Restore / 恢复
```

先恢复为活跃对象。

---

# 12. Context / Workflow 对归档对象的规则

如果某个 Context / Workflow 引用了已归档对象：

```text
仍然能看
仍然能引用
仍然能给 Agent
```

但：

> 不能直接从 Context / Workflow 修改这个归档源对象。

需要改原对象：

```text
Restore
→ 回到活跃状态
→ 再编辑
```

这样所有地方的只读逻辑一致。

---

# 13. 归档对象重新恢复时

Restore 不创建新 canonical object。

恢复的是同一个对象。

但因为旧 Main 空间锚定已经释放：

> 不恢复旧 x/y 布局。

对象重新出现时：

```text
进入一个整齐、机械、可预期的默认排列
```

例如：

- Grid
- Strip
- Stack
- Masonry

具体默认 donor / layout 由 T1/T5 决定。

用户之后：

- 自己拖
- 让本地 Agent 整理
- 使用自动 Arrange

都可以。

---

# 14. 归档不是 Assembly

不要再造第二仓库。

Assembly 仍然是：

> 项目共享来源 / 装配工作区。

Archive 是：

> Project object 的生命周期 / presentation 状态。

两者不能混。

---

# 15. Archive 也不是 Delete

冻结产品语言：

```text
Remove
= 从当前视图 / membership / mapping 拿掉
→ 直接执行 + Undo

Archive
= 保留项目真相，但退出活跃 Main 空间
→ 可恢复

Delete
= 真正删除 canonical entity / file
→ 明确确认
```

三个动作必须区分。

---

# 16. Context 默认地图：时间

Context Atlas 默认按时间切块。

支持用户调节颗粒度：

- 小时
- 天
- 周
- 更长区间

项目越久，用户可以越粗看。

区域表达：

> 某个时间段累积了多少内容 / 工作 /变化。

具体面积、密度、材质、动态图形由 T5 决定。

---

# 17. 点击 Context 时间块

冻结：

```text
点击一个时间块
→ 先进入临时查看
```

不是立即创建长期工作区。

临时查看里可以：

- 看
- Search
- Focus
- Reference
- 给 Agent
- 看来源
- 看演进

如果用户发现：

> “这一块值得重新拿出来长期做”

再显式：

- Restore 一些对象
- 拖出对象
- 形成 Collection
- 整理为 Workflow
- 建立长期工作区

---

# 18. Context 第二种地图：Agent 按事情组织

Agent 可根据长期项目历史识别：

- 一件事情从开始到结束
- 跨多天持续的一条工作
- 中途暂停
- 完成
- 复盘

形成“事情地图”。

这是同一批 Context 的第二种 view。

默认不改变项目结构。

---

# 19. 事情地图的人工修正

如果 Agent 分错：

用户直接：

- 拖动
- 合并
- 拆开
- 重新归到另一块

这些是地图底层编辑手势。

然后用户可以：

```text
点中这个区域
→ 通用 Composer
→ “这两块其实是一件事”
→ 发给 Agent
```

Agent 重新理解。

---

# 20. 事情地图继续复用通用 Composer

不做 `ContextMapComposer`。

就是普通 Composer。

如果当前 Atlas region 本身不能直接 Reference：

- Reference UI 仍然保留；
- 用户尝试时给轻提示；
- 能解析到底层对象则使用真实对象。

不要客制一套特殊输入系统。

---

# 21. Workflow 最小显示粒度正式冻结

Workflow 中最小的“动作单位”不是 tool call，也不是内部 API step。

冻结为：

> **一次用户可感知的工作轮次。**

最典型就是：

```text
用户 / 上一环节给出一次指令或输入
→ Agent / API / Skill 执行
→ 返回一个可感知结果
```

这一轮就是 Workflow 可以显示的最小动作粒度。

无论内部：

- 调了多少工具
- 改了多少次
- 重试了多少回

默认都不继续拆小。

---

# 22. Workflow 中的一轮如何显示

默认只显示：

- 这轮做了什么
- 谁接的
- 返回了什么

例如：

```text
[修改脚本]
→ script_v3.md
```

或者：

```text
[整理 Context]
→ context_summary.md
```

Hover / 选中：

- 输入
- Skill
- Agent
- 状态

深度查看才显示：

- Tool calls
- logs
- provider
- retry
- intermediate state

---

# 23. Workflow 不是执行日志

即使 Workflow 的最小动作单位是一轮 Agent 工作：

> Workflow 仍然首先是工作现场。

真实材料、结果、关键判断仍然是主要视觉对象。

“动作轮次”只是把：

```text
输入
→ 做了什么
→ 结果
```

串起来。

不把整个 Workflow 重新做成聊天记录或 Run Timeline。

---

# 24. Workflow / Context 中继续坚持“图形优先，字按需出现”

尤其这两个 View：

默认不堆：

- Step 1
- Step 2
- Status Running
- Agent GPT
- Source X
- Type Y

优先用：

- identity glyph
- source silhouette
- result preview
- motion
- position
- relation
- state color / shape

Hover / Focus 再显示短文字。

---

# 25. Glyth 深度工作状态：能力冻结，布局不冻结

双击 Glyth：

→ 进入同一 Conversation 的深度工作状态。

可以同时存在：

- Conversation 子画布
- Glyth / Conversation 深度预览
- Assembly

三者：

- 可拖动
- 可缩放/拉伸
- 可 Dock
- 可 Undock
- 可竖排
- 可横排
- 可自由态
- 可轻固定
- 可取消固定
- 可独立关闭

共享同一 Conversation identity。

---

# 26. 除主画布以外，大工作界面都应具备自由窗口能力

这条推广到：

- Conversation 预览
- Assembly
- Skill Builder
- Context 专业视图
- Workflow 深度视图
- Run / Review
- Web / PDF / HTML 深度查看

它们不一定默认全部浮动。

但应该具备统一的窗口能力：

```text
Float
Dock
Undock
Resize
Move
Horizontal / Vertical composition
Close independently
Restore
```

具体默认布局由 T4/T5 决定。

---

# 27. 主画布永远是稳定底盘

无论开多少自由窗口：

- Canvas world 不自动移动；
- Camera 不自动重排；
- Project object 不因为窗口打开改变位置。

变化只发生在 screen-space UI：

- HUD
- Arc
- Composer
- Minimap launcher
- Locator
- transient controls

它们避开被窗口占据的区域。

---

# 28. 所有项目对象默认可拖

所有有项目身份的对象默认都应支持 drag。

可以：

- 拖出
- 拖入
- 给目标
- 进 Collection
- 进 Workflow
- 给 Glyth
- 给 Assembly
- 给 Composer Reference
- 拖到 Rail

这是 LCOS 的统一操作语言。

---

# 29. 统一拖动语义

```text
左拖到空白
= 搬

左拖身体碰目标
= 给 / 加入 / 使用

右拖
= 借过去用，原对象不动

Relation handle
= 连
```

如果“给”的语义不是 Move：

→ source 回原位。

如果是 Move / Reparent / Place：

→ source 留下。

---

# 30. 多选不自动弹 Composer

多选可能只是：

- 整理
- 搬
- 对齐
- 成组
- 集体 Drop

因此：

```text
多选
→ 只保持 Selection
```

用户主动点 AI / Composer 才出现。

Drag / Right-drag / Move 同样不自动打开 Composer。

---

# 31. 这轮对 Collection / Scope / 长期工作区的继续冻结

## Collection

> 这些东西长期算一组。

保留 Project identity，同时增加 membership。

## Scope

> 这次工作只处理这些。

是当前工作范围。

## 长期工作区 / 子画布

> 这件事我要单独开桌长期干。

只有用户明确决定才建立。

三者不得再混。

---

# 32. 代码和 Agent 的最终分工

固定代码负责确定性：

- identity
- persistence
- relation
- membership
- archive
- projection
- drag/drop
- navigation
- window lifecycle
- run/result
- undo/recovery

Agent 负责语义判断：

- 哪些属于同一件事
- Context 怎么整理
- Workflow 怎么提炼
- Skill 怎么生成
- SQL / JSON / MD 怎么做
- API 怎么调用
- 历史怎么归类
- 结果怎么总结

一句话：

> **代码负责确定的东西，Agent 负责需要理解的东西。**

---

# 33. 后续六路施工必须遵守的 UI 检查表

任何新 UI 在进入施工前必须回答：

1. 能不能不用常驻文字？
2. 能不能 Hover / Focus 才显示标签？
3. 能不能直接拖，不开向导？
4. 能不能直接点进去输入？
5. 能不能复用通用 Composer / Arc / Work View？
6. 如果不支持某能力，能不能只做轻提示而不是客制新组件？
7. 是否偷偷增加了步骤？
8. 是否因为实现方便制造 Mode？
9. 是否让用户手工做 Agent 本可完成的语义整理？
10. 是否破坏主画布稳定性？
11. 是否给归档对象错误地保留旧空间真相？
12. 是否为某个 View 新造第二套轮子？

只要答案有问题：

> 施工卡退回修改。

---

# 34. 最终冻结句

## UI

> 能用图形表达就不用常驻文字；需要解释时 Hover / Focus 再显示。

## 操作

> 只要用户直觉上觉得“应该能这样做”，且语义唯一，就直接允许，不加流程卡。

## 组件

> 复用通用轮子，局部不支持就给轻提示，不为一个 View 重造一套。

## Archive

> 保留项目真相，释放活跃空间位置，进入只读冷状态；恢复后同一对象以整齐新布局重新出现。

## Context

> 默认按时间看，也可让 Agent 按事情看；时间块先临时查看，用户决定是否重新拿出来长期工作。

## Workflow

> 最小动作粒度是一轮对用户可感知的工作：一次输入/指令到一次结果返回。

## Glyth / Work View

> 深度工作区域可以自由拖、拉伸、Dock/Undock、横竖组合、独立关闭；主画布始终不被自动搬动。

## 总目标

> **点、拖、丢、直接打字、说一句话。**
> 能少一步就不多一步。
