# LCOS Gen2 · T2 C1
# Coordinator Engineering Dependency Handoff

日期：2026-09-06  
状态：`NO PRODUCT OPEN · ENGINEERING EXPORT DEPENDENCIES ONLY`

> Phase B 已经关闭 T2 的产品级跨线程 OPEN。
> 本文件不请求重新裁决任何产品语义。
>
> 这里只列：T2 正式 source plan 需要 T3/T4/T6 回填的 exact engineering exports。

---

# 1. T2 当前 C1 状态

```text
S01–S12 Engineering Seam    COMPLETE
Consolidated source plan    COMPLETE
T5 engineering input        COMPLETE
Production coding           LOCKED pending cross-owner exact exports + T5 final body
```

---

# 2. DEP-T6-01 · Slim Worksite contract

## Phase B already decided

Long-term Worksite：
- durable；
- stable；
- explicit materialization；
- old Workspace identity优先迁移/瘦身；
- Huabu owns camera/geometry；
- Back session-only。

## T2 needs exact exports

请 T6 回：

```text
exact contract file
exact Worksite type name
stable canvasId field
surface/home ref
lifecycle field
working-set refs
active Worksite read
rename action
archive action
materialize action
read-by-id action
```

## T2 consumers

```text
S02 Railway
S03 Enter/Back
S04 Search locations
S05 Focus occurrences
```

## Forbidden fallback

T2不会用：

```text
old Workspace.viewport
Scope.parentScopeId
preferredSurface
localStorage active Workspace
```

替代。

---

# 3. DEP-T6-02 · Rail ontology migration

## Current exact debt

`packages/contracts/src/index.ts`

```text
ProjectViewRailKindV0 =
scene|collection|context|workflow
```

`apps/local-core/src/routes/projects.ts`

GET still filters through：

```text
getWorkspaces
getScopes
```

## Phase B already decided

normal new ontology：

```text
Surface root
Worksite
Receiver/Conversation
legacy
```

## T2 needs

- exact migrated type；
- legacy read behavior；
- new-write allowed kinds；
- legacy Collection/Scope ref migration outcome；
- `remove from rail` 是否 presentation action 与 Archive 分离的 exact contract。

T2保留现有 order/CAS/restart/dedupe mechanism。

---

# 4. DEP-T6-03 · Navigation occurrence compatibility

T2 S05建议沿：

```text
NavigationMarkerService
```

增加 full occurrences read projection，
而不是 frontend扫描 graph。

请 T6/Core cross-review：

```text
Worksite-facing occurrence ref
Archive availability
Conversation Worksite ref
legacy workspace/scope compatibility
```

重点：

Search current `locationRefs` 只返回前 5，
Focus 必须支持完整 7/12/20+ occurrence。

---

# 5. DEP-T4-01 · Public Work View occupancy seam

## Phase B already decided

T4 对外暴露：

```text
occupiedRects
safeRect/safeInsets
activeRegions
```

Work View open/resize：

```text
Camera must not auto move
```

## Current source audit

LCOS Gen2 current HEAD 未找到这套 public export。

## T2 needs exact export

请 T4 回：

```text
exact source file
hook/store/selectors name
snapshot type
coordinate system
viewportRect
safeRect
occupiedRects
activeRegions
revision/change subscription
fullscreen/immersive canvas-active semantics
```

## T2 consumers

```text
Navigation HUD
Locator
Spatial Navigator
explicit camera framing
```

## T2 will NOT do

```text
query DOM Work View
hardcode right width
persist safeRect
```

---

# 6. DEP-T3-01 · Railway typed DropDestination

## Current source

```text
apps/web-gen2/src/interaction/semanticDropMachine.ts
huabu/apps/web/src/lcos/lcosDropState.ts
huabu/apps/web/src/lcos/lcosRecognizers.ts
```

Phase A current destination只有 generic：

```text
surface:left-dock
surface:bottom-dock
```

## T2 needs T3 exact extension

能够表达：

```text
Surface destination
Worksite destination
Receiver destination
```

要求：

- target identity typed；
- target can advertise eligibility；
- Railway only presents/hit-tests；
- semantic action still T3/T6 owner；
- no chooser modal。

---

# 7. DEP-T3/T6-02 · Drop transaction result

T2 Receive Map need only presentation result。

请提供 exact commit outcome，至少能让 T2知道：

```text
pending
success
recoverable failure
permanent failure
```

并能区分实际空间结果：

```text
source stays
source moves/removes
target projection created/reused/none
```

T2 不自行推断。

---

# 8. DEP-HUABU-01 · Upstream physical move selective sync

当前 vendored：

```text
58339e2
```

audited upstream：

```text
a3c411e
24 commits ahead
```

high-value new files：

```text
packages/shared/src/types/api/space-move.ts
apps/server/src/modules/canvas/space-move-plan.ts
apps/server/src/modules/canvas/space-move.service.ts
apps/server/src/modules/canvas/canvas.route.ts
apps/server/src/modules/canvas/write-coordinator.ts
apps/web/src/api/canvas.ts
```

T2 recommendation：

```text
selectively adopt engineering mechanic
reject MoveSelectionModal primary UX
```

Only use when semantic transaction requires actual cross-canvas physical move。

---

# 9. No Coordinator re-decision requested

以下都已经关闭，不请求复议：

```text
Worksite semantics
materialization timing
Back durability
SurfaceDock vs Railway
Rail ontology
Archive Focus
safeRect product rule
Work View camera rule
Receiver identity ownership
```

---

# 10. Technical blockers

截至本 C1：

```text
NONE requiring coordinator arbitration
```

已发现的冲突都有 thin path：

```text
Huabu Cmd+F
→ hotkey arbitration

Search locations cap
→ navigation occurrences read

Huabu resize camera compensation
→ host viewportPolicy

Rail generic left-dock drop
→ typed destination extension

no Pin/Receiver frontend client
→ typed thin clients

vendored Huabu lacks move primitive
→ selective upstream adoption
```

---

# 11. Handoff completion gate

T2 等待的不是“讨论结论”，而是 exact engineering exports。

当 T3/T4/T6 回：

```text
exact file
exact type/function
read/write path
version/CAS/event semantics
```

T2 即可直接回填 consolidated plan，
不重新进入产品考古。
