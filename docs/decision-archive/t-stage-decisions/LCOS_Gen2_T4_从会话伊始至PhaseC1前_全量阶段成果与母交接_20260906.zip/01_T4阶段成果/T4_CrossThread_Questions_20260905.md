# LCOS Gen2 · T4
# Cross-Thread Questions I Must Not Decide

日期：2026-09-05  
线程：T4  
状态：`PHASE-A CROSS-THREAD HANDOFF`

> 这些不是“没做完的借口”。
>
> 它们是本轮语义考古完成后，T4 已经走到 owner 边界、再往前一步就会替别人造 truth 的问题。
>
> 每项统一格式：
>
> ```text
> 问题
> 为什么不属于 T4
> T4 已确认局部事实
> 需要谁回答
> T4 明确不会做的假设
> ```

---

# Q1 · Scope 的 Save / Commit 到底保存成什么 canonical truth？

## 问题

最新产品已经把 Scope 重新定义为：

> “这次只处理谁。”

但当用户希望把这次工作范围长期保留下来时：

```text
Save / Commit
```

最终得到的是什么？

可能涉及：

```text
durable Scope identity
Collection
Workflow
Long-term Worksite
saved target set
其它现有 contract
```

T4 不决定。

## 为什么不属于 T4

这是 canonical persistence / membership / migration。

属于：

```text
T6 + Coordinator
```

## T4 已确认的局部事实

- 2026-08-29 历史用户原话曾明确：“Scope就是长期的”“Scope 是容器”；
- 2026-09-05 V2 已覆盖这一旧定义；
- current Scope 不应默认是 container / child canvas / Workspace；
- old `ScopeKind/CanvasScope` 同时混有 collection/context/workflow/workbench/camera/layout；
- 因此不能复活旧 Scope umbrella。

## T4 明确不会做的假设

不会新增：

```text
ContextScopeDB
WorkflowScopeDB
ScopeContainerEngine
```

不会默认：

```text
Save Scope = create child canvas
Save Scope = create Collection
```

---

# Q2 · Context / Workflow 的 canonical membership 各自最终是什么？

## 问题

一个 canonical Artifact / Note / Conversation / Skill 等：

```text
“在 Context 里”
“在 Workflow 里”
```

最终分别保存什么：

```text
membership
mapping
reference
presentation
```

？

## 为什么不属于 T4

这是 Domain Truth。

属于：

```text
T6
```

Coordinator负责与 T1/T3 交互语义拼合。

## T4 已确认的局部事实

- Main / Context / Workflow 是三个一级 Surface；
- Context/Workflow membership不能等于 Collection containment；
- current source仍大量通过 `scope` / presentation membership兼容；
- current AssemblyApply把 context/workflow/collection relation endpoint映到 `'scope'`；
- current Workflow import/export仍吃 `scopeId`；
- 这些只能作为 migration evidence。

## T4 明确不会做的假设

不会：

```text
Context = ScopeKind.context
Workflow = ScopeKind.workflow
```

不会在 UI 建第二份 member arrays 冒充 canonical truth。

---

# Q3 · Long-term Worksite / Child Canvas 的 canonical identity 最终由什么承接？

## 问题

用户明确要：

```text
另一张以后还能回来继续的桌子
独立 camera
独立 layout
独立 history
长期 continuity
```

时，Gen2 最终创建/复用哪种 canonical identity？

历史候选：

```text
Workspace
Scene
Worksite
canvas binding
组合 contract
```

## 为什么不属于 T4

T4只定义：

> 专业工作何时“值得”进入长期 worksite。

真正 identity/persistence：

```text
T6
```

进入/返回/navigation：

```text
T2
```

spatial mechanics：

```text
T1/Huabu
```

## T4 已确认的局部事实

- historical Workspace/Current Scene明确承载长期现场意图；
- old Workspace混有 scopeId/camera/frameBounds/preferredSurface，不能整接口照搬；
- V2明确 Work View ≠ child canvas；
- Glyth Conversation child canvas 是当前最明确的 nested worksite 案例。

## T4 明确不会做的假设

不会新增：

```text
WorkspaceRuntimeV2
WorkViewCanvasOwner
ChildCanvasStore
```

也不会宣布：

```text
child canvas == old Workspace interface
```

---

# Q4 · Context temporary detail 何时升级为 long-term worksite？

## 问题

V2明确：

```text
Atlas region click
→ temporary detail
```

不自动 child canvas。

用户后续做什么动作才算：

```text
“我要长期单独开桌继续”
```

最终 navigation/materialization gesture 需要统一。

## 为什么不属于 T4

T4可以定义 professional-detail UX。

但：

```text
entry gesture
navigation stack
Arrival/back
materialize worksite mutation
```

横跨 T2/T6。

## T4 已确认的局部事实

产品门槛是：

```text
独立 view
独立 layout
独立 history
长期回来继续
```

但 exact interaction尚不应由 T4单独拍板。

## 需要谁回答

```text
T2 + T6 + Coordinator
```

T3负责最终手势 grammar 对齐。

## T4 明确不会做的假设

不会：

```text
double click every Context region
→ automatically create canvas
```

不会根据内容数量自动 materialize。

---

# Q5 · Conversation child canvas 的 canonical owner / navigation 是什么？

## 问题

Glyth double-click后：

```text
Conversation child canvas
Conversation Preview
Assembly
```

可同时存在。

Conversation child canvas作为真实 nested spatial worksite：

```text
identity
canvasId
membership
parent
restore
back/arrival
```

由谁承接？

## 为什么不属于 T4

T4只拥有：

```text
Preview + Assembly professional region lifecycle
multi-region composition
```

child canvas本身横跨：

```text
T1 spatial
T2 navigation
T6 identity/persistence
```

## T4 已确认的局部事实

三个区域属于同一 Conversation identity，但不是同一 presentation 类型。

## T4 明确不会做的假设

不会把 Conversation child canvas实现成：

```text
Dockview panel
Work View tab
temporary Scope
```

---

# Q6 · Collection canonical containment 当前唯一 owner 是什么？

## 问题

T4的 Assembly/Context/Workflow可能消费 Collection，但不拥有 Collection。

current source里仍可见：

```text
scope(kind='collection')
```

以及 aggregate source mapping。

最终 Collection canonical membership owner / relation ref类型是什么？

## 为什么不属于 T4

明确属于：

```text
T6
```

T1只管 expanded Collection 的 geometry/layout。

## T4 已确认的局部事实

- Collection ≠ Scope；
- Collection ≠ Colony；
- Collection ≠ child canvas；
- current `ContextSnapshot.branch()` 新建 `scope(kind='collection')` 是 migration debt；
- Assembly current mapping把 collection当scope兼容 endpoint。

## T4 明确不会做的假设

不会让：

```text
Assembly
ContextSnapshot
Workflow
```

继续依赖 `scope(kind=collection)` 作为最终产品 owner。

---

# Q7 · ContextSnapshot branch 的新 canonical语义是什么？

## 问题

current：

```text
Checkpoint
→ branch()
→ create collection scope
→ create new ArtifactViews
→ generated x/y
```

最新产品下应该拆成：

```text
history branch
containment?
projection?
optional worksite?
```

哪几层？

## 为什么不属于 T4

Checkpoint/branch mutation属于：

```text
T6
```

空间 placement属于：

```text
T1/Huabu
```

T4只消费 resulting Context history/professional view。

## T4 已确认的局部事实

```text
Checkpoint snapshot/compare
= KEEP

branch current combined mutation
= LEGACY_COMPAT
```

## T4 明确不会做的假设

不会在 Context UI 直接复制 View 或生成 x/y。

---

# Q8 · Workflow extraction 的 canonical mutation是什么？

## 问题

V2：

```text
选中一批真实材料
→ 整理为 Workflow
```

用户采用后成为正式 Workflow。

这一步创建：

```text
Workflow identity
membership
relations
initial projection
```

各是什么 canonical channel？

## 为什么不属于 T4

T4拥有 extraction UX / proposal / professional view。

Domain write：

```text
T6
```

gesture：

```text
T3
```

placement：

```text
T1
```

## T4 已确认的局部事实

Workflow：

```text
不是 DAG
不是自动化 builder
不是 Run log
```

最小动作是一轮用户可感知工作。

## T4 明确不会做的假设

不会：

```text
selected nodes → local WorkflowStore
```

也不会直接用 old `scopeId` 当 Workflow identity。

---

# Q9 · Skill usage-binding canonical model

## 问题

latest product需要：

```text
Skill → Workflow
Skill → Composer
Skill → Glyth
Skill → capability target
```

引用：

```text
skillId/version
```

不复制 package。

current `AssemblyApplyService`：

```text
skill → unsupported
```

所以 canonical write 需要什么 contract？

## 为什么不属于 T4

这是：

```text
T6/Core
```

T4只做 Builder和使用入口 presentation。

## T4 已确认的局部事实

SkillPackageService本体成熟：

```text
CRUD
version
composition
subskills
provenance
```

Builder无需第二份 Skill truth。

## T4 明确不会做的假设

不会新增：

```text
frontend SkillBindingStore
Skill copy
Skill package duplicate
fake apply success
```

---

# Q10 · Assembly context/workflow/collection 的 scope compatibility 何时退休？

## 问题

current：

```text
AssemblySourceRef context/workflow/collection
```

在 Relation endpoint mapper中仍变：

```text
scope
```

什么时候、用什么新的 canonical endpoint替换？

## 为什么不属于 T4

T4只拥有：

```text
Assembly Source Bay UX
thin apply adapter
```

relation/entity taxonomy属于：

```text
T6
```

## T4 已确认的局部事实

AssemblyApply整体架构正确：

> 不拥有新 mutation，只路由既有 canonical services。

所以正确修法不是重写 Assembly。

## T4 明确不会做的假设

不会建立：

```text
AssemblyMembershipDB
AssemblyScopeBridge
```

---

# Q11 · Archive canonical lifecycle

## 问题

V2要求：

```text
Archive
Restore
archivedAt
read-only cold state
keep relation/membership/provenance
release Main spatial placement
```

current source尚未发现完整 canonical Archive owner。

## 为什么不属于 T4

T4负责：

```text
Archive professional body
Masonry
single/multi/day restore UI
```

生命周期 truth属于：

```text
T6
```

fresh projection layout属于：

```text
T1/Huabu
```

## T4 已确认的局部事实

Archive不是：

```text
Delete
Assembly
hidden
```

## T4 明确不会做的假设

不会使用：

```text
localStorage archivedIds
hiddenViewIds
ArchiveWarehouse
```

冒充 canonical Archive。

---

# Q12 · Scope persistent visualization 是否需要独立 body？

## 问题

Scope作为“这次只处理谁”时，是否应该有：

```text
field
highlight
range indicator
```

哪些 presentation mechanic由 T1/T5承担？

## 为什么不属于 T4 单独决定

T4只定义：

```text
Scope不是长期容器
```

具体 geometry/body：

```text
T1
```

视觉：

```text
T5
```

local gesture：

```text
T3
```

## T4 已确认的局部事实

明确不要：

```text
persistent empty dashed container card
```

## T4 明确不会做的假设

不会给 Scope自己建立 spatial engine或长期 frame truth。

---

# Q13 · ProjectSession 与 navigation route 的最终交界

## 问题

T4需要稳定：

```text
ProjectSession
SurfaceRegistry
Professional regions
```

但 deep-link / route怎样表达：

```text
projectId
surfaceKey
child worksite
```

？

## 为什么不属于 T4

产品导航 owner：

```text
T2
```

T4只消费 active project/surface。

## T4 已确认的局部事实

current：

```text
/canvas/:canvasId
```

不足以单独恢复完整 LCOS Product Session。

## T4 明确不会做的假设

不会自行冻结：

```text
/projects/:id/main
```

等 URL。

---

# Q14 · SurfaceRegistry 的真实 product consumer 由谁触发？

## 问题

已有：

```text
SurfaceRegistry.current(surfaceKey)
→ canvasId
```

但 production consumer未闭合。

是：

```text
Navigation
ProjectSession
CanvasPage
```

谁触发 active Surface切换？

## 为什么不属于 T4 单独决定

T4需保持 professional window/session continuity。

但 Surface navigation intent属于：

```text
T2
```

Huabu load mechanics属于：

```text
T1/current shell
```

## T4 已确认的局部事实

T4可以提供：

```text
onSurfaceReady(projectId, surface, canvasId)
```

式 lifecycle seam。

## T4 明确不会做的假设

不会新建：

```text
SurfaceManagerV2
```

---

# Q15 · old WorkbenchService 的兼容/退休计划

## 问题

current Core `WorkbenchService`：

```text
temporary Scope + ViewRefs + merge
```

已经不等于 V2 Work View / professional window system。

它的现有 route/consumer是否还有必须保留的迁移用途？

## 为什么不属于 T4 单独决定

T4可以宣布：

```text
它不是新的 product owner
```

但删除/迁移 service需要：

```text
T6
```

consumer cleanup可能涉及 T2/T3。

## T4 已确认的局部事实

新的 professional window manager不得调用它来创建 window session。

## T4 明确不会做的假设

不会：

```text
rename old WorkbenchService → New Workbench
```

然后继续用。

---

# Q16 · Right-drag / Give 到 T4 targets 的 exact canonical mutation

## 问题

对于：

```text
Assembly
Workflow
Context detail
Skill target
Conversation
```

body drop / right-drag 的 exact mutation依赖目标类型。

T4不能只看“它是专业工作区”就统一。

## 为什么不属于 T4

gesture grammar：

```text
T3
```

canonical mutation：

```text
T6
```

physical placement：

```text
T1
```

## T4 已确认的局部事实

T4必须为每个专业 target暴露：

```text
capability/admission
target canonical ref
supported semantic action
```

而不是自己解释 pointer gesture。

## T4 明确不会做的假设

不会把：

```text
Right-drag
```

变成 universal membership。

---

# Q17 · T5 最终视觉复核前，T4需要输出什么稳定 contract？

## 问题

T5 phase C需要知道：

```text
哪些是 worksite
哪些是 professional region
哪些是 Scope field
哪些是 Atlas region
哪些是 child canvas
```

T4应给出什么 visual-state contract，既不越过 T5，又不让概念被画混？

## 为什么不属于 T4 完全决定

T4定义 semantic presentation categories。

T5定义：

```text
shape
material
motion
density
proportion
```

## T4 已确认的局部事实

至少必须输出不可混淆标签：

```text
SURFACE
PROFESSIONAL_REGION
TEMPORARY_DETAIL
SCOPE_HIGHLIGHT
NESTED_WORKSITE
```

## 需要谁回答

```text
T4 + T5 after Coordinator Phase B
```

---

# Q18 · Gen1 原仓库 direct source 仍未解析

## 问题

本轮已恢复：

```text
LCOS_前端源码合并版.md
```

含297文件源码快照。

但 GitHub connector未能解析出原 Gen1 repo / historical commit。

是否还存在可提供的：

```text
Gen1 repo URL
bundle
commit ref
```

可供最终 source census做 direct verification？

## 为什么这是 Cross-thread / Evidence 问题

不是产品定义。

但影响：

```text
GITHUB_VERIFIED
```

能否对 Gen1旧行为打勾。

## T4 已确认的局部事实

当前足以证明旧 `CanvasScope` / Workspace / temporary-workbench mechanics存在。

但严格状态必须写：

```text
GEN1_SOURCE_SNAPSHOT_FOUND
DIRECT_ORIGINAL_REPO_NOT_RESOLVED
```

## T4 明确不会做的假设

不会把源码快照说成：

```text
已直接核原 Gen1 GitHub HEAD
```

---

# Final Handoff

T4 当前可以独立关闭：

```text
Work View != Child Worksite
Context/Workflow = first-class Surfaces
Atlas/Workflow detail/Skill Builder = Instruments
Assembly = Project-shared source/assembly shell
Skill Builder != Harness Run
old long-lived/container Scope = superseded
old WorkbenchService != new professional window owner
```

T4 必须等待：

```text
Scope Save/Commit truth
Context/Workflow membership
Collection migration
Long-term Worksite identity/navigation
Skill usage binding
Archive lifecycle
Assembly scope endpoint migration
Workflow extraction mutation
```

这批问题不闭合前：

```text
T4 FINAL CONSTRUCTION PLAN
= BLOCKED BY DESIGN
```

这不是停工。

T4仍可继续：

```text
donor census
source audit
prototype isolated window mechanics
professional body adapter design
browser acceptance design
```

但不能落 production domain assumptions。
