# LCOS Gen2 · GLM 施工正本 Phase D
## Centered Spatial Navigation / Pin & Glyph / Glance / Material & Motion / Release E2E

> Phase D 不是“最后美化”。它把导航、状态可见性、材料、动效、可访问性和全功能验收收成一个可长期替换的视觉/交互 owner；仍不增加新 domain semantics。

---

# 0. 权威来源

| Source ID | 来源 | 强制结果 |
|---|---|---|
| U-NAV | 用户强调导航系统、拼图标、三大视图、节点右上角角标、Glance 动效 | 全部进入统一状态/视觉语法，不散落组件私有实现。 |
| U-HUABU | Huabu 文本节点、右侧插入图表、agent tabs 原生丝滑应作为范式 | 保留 Huabu shell/interaction；LCOS只补不可替代语义层。 |
| U-NONEW | 绝对不增加新语义；相同对象合并 | Pin/Focus/Search/Glance/Badge是不同状态，不建新entity；图标variant不建新对象类型。 |
| F-NAV | `LCOS_v015_CENTERED_SPATIAL_INDEX...md` top slot/quantity layout/Color Pin/Focus/Search/Assembly/arbitration | centered index完整行为。 |
| F-DYNAMIC | `LCOS_v015_前端最终收敛四阶段_DynamicGlyph_PinVisualSystem_20260831.md` | DynamicGlyph与Pin visual system。 |
| F-THREE | 三Surface硬规则 | 导航不变成top canvas tabs；当前surface能力过滤。 |
| F-MATERIAL | ios26 design-system材料与legibility资料 | invisible shell、shape adaptive border、spring presets、反模式。 |
| F-AMICRO | Amicro/AnimatedMetricCard/mono-charts/css animations inventory | 只取克制、可替换的单色图表/微交互。 |
| F-REACTBITS | ReactBits完整清单与推荐 | 只采用无three/ogl、低侵入点缀。 |
| F-DONOR | donor重编排、三方代码审计、GUI SOP | Huabu先、成熟轮子次、LCOS只写语义；每项trace。 |
| F-SMOKE | Phase A Human Product Smoke Runbook | machine/app/human/voice/zoom/DPI/occupied region/layering验收。 |

---

# 1. 状态语义表：不得互相冒充

| 状态 | owner | 持久性 | GUI表达 | 不等于 |
|---|---|---|---|---|
| Selection | Huabu canvas session | surface session | outline/handles | Reference/Pin |
| Reference | Composer/Run draft→Core Run | draft/run | numbered badge/strip | Selection/Relation |
| Relation | Core + projection | project | edge/port | visual proximity |
| Focus | presentation/camera | transient/restore | dim surroundings/camera | Work View/Selection |
| Pin | project navigation preference | project/user preference | color pin/index slot | entity/relation |
| Search result | query session | transient | result emphasis/locator | Pin |
| Glance | derived activity cue | transient | restrained motion | run status truth |
| Badge | derived highest-priority status | transient/canonical input | single corner mark | multiple mini cards |
| Surface | project worksite identity | project | navigation location | top tab |
| Work View | project work container | project session | floating/docked/immersive | right preview tab |

Pin 可以指向 existing entity/view/workspace/surface；它保存一个 reference + color/order，不复制目标。Glance 从 canonical state/event 派生，动画结束不改变 truth。

---

# 2. 目标目录

```text
apps/web-gen2/src/
  navigation/
    CenteredSpatialIndex.tsx
    navigationState.ts
    navigationLayout.ts
    navigationArbitration.ts
    SurfaceLocation.tsx
    SearchMode.tsx
    AssemblyMode.tsx
    FocusMode.tsx
    pins/
      pinModel.ts
      pinRepository.ts
      ColorPin.tsx
      PinRail.tsx
      PinLocator.tsx
  glyph/
    DynamicGlyph.tsx
    glyphModel.ts
    glyphRegistry.ts
    glyphParts.tsx
    GlythBadge.tsx
    glanceState.ts
  ui/
    tokens/
      color.css
      typography.css
      spacing.css
      material.css
      motion.ts
      hitTargets.ts
      zLayers.ts
    primitives/
      MagneticButton.tsx
      GlowButton.tsx
      Spotlight.tsx
      TiltSurface.tsx
      MonoMetric.tsx
    materials/
      InvisibleShell.tsx
      LegibilityBackdrop.tsx
  accessibility/
    reducedMotion.ts
    focusVisible.ts
    announcements.ts
  e2e/
    human-product/
    cross-surface/
    restart/
```

primitives 不 import Core domain；glyph/navigation adapters 才把 entity/status 映射为视觉。

---

# 3. D00 — Token owner 与依赖边界

## 现状问题

旧 LCOS、Huabu、donor各带颜色、radius、shadow、spring、hit size。直接复制会产生“每个功能像不同应用”。先建立 token owner，再接组件。

## Token 层级

1. Huabu base tokens：字体、canvas background、已有node/selection。
2. LCOS semantic tokens：project/intent/status/pin/glyph，不覆盖 base机械。
3. component tokens：只引用前两层，不定义新品牌色。
4. donor adapter：把 donor CSS变量映射到LCOS tokens，不把donor theme带进来。

## CSS 预设

```css
:root {
  --lcos-hit-min: 36px;
  --lcos-hit-preferred: 40px;
  --lcos-radius-xs: 8px;
  --lcos-radius-sm: 12px;
  --lcos-radius-md: 16px;
  --lcos-fg-primary: var(--huabu-fg-primary);
  --lcos-fg-secondary: color-mix(in srgb, var(--lcos-fg-primary) 64%, transparent);
  --lcos-outline-rest: transparent;
  --lcos-outline-hover: color-mix(in srgb, var(--lcos-fg-primary) 12%, transparent);
  --lcos-outline-selected: color-mix(in srgb, var(--lcos-accent) 58%, transparent);
  --lcos-material-thin-opacity: .03;
  --lcos-material-thin-blur: 100px;
}
```

100px blur来自ios26 donor，不表示处处使用。仅浮动导航/Composer/Work View chrome在背景复杂且legibility需要时启用；普通node默认透明，低性能/reduced transparency切纯色半透明。

## Motion 预设

```ts
export const lcosMotion = {
  duration: { instant: 0, micro: 0.09, short: 0.16, medium: 0.24, long: 0.38 },
  ease: { standard: [0.2, 0, 0, 1], exit: [0.4, 0, 1, 1] },
  spring: {
    snappy: { type: 'spring', stiffness: 520, damping: 38, mass: 0.72 },
    gentle: { type: 'spring', stiffness: 280, damping: 34, mass: 0.9 },
    bouncy: { type: 'spring', stiffness: 420, damping: 24, mass: 0.78 },
    stiff: { type: 'spring', stiffness: 650, damping: 48, mass: 0.65 },
  },
} as const
```

最终数值以motion 13实际API与真机校准。bouncy不得用于camera/text layout/serious review，只可极少用于成功确认；默认snappy/gentle。

---

# 4. D01 — Centered Spatial Index：一个变形导航，不是多套条

## 产品结构

中心空间索引占据统一top/center slot，在以下模式间形态变化：

```ts
export type SpatialIndexMode =
  | 'location'
  | 'pins'
  | 'search'
  | 'assembly'
  | 'focus'
  | 'command'
```

不是同时显示location bar + pin rail + search box + assembly shelf。`navigationArbitration` 保证一个dominant mode；临时badge/shortcut hints可附着。

## 默认 location

显示project + current surface/workspace path，足以回答“我在哪”。不显示三个固定Canvas tabs。点击/快捷键展开surface/worksite switcher；切换走SurfaceRegistry。

## 数量布局

- 0 pins：slot只显示location/search cue。
- 1–4：中心紧凑单排。
- 5–9：压缩spacing/可水平游标。
- >9：显示最近/固定前N + overflow，进入pins mode虚拟列表；不能无限横排。

## Mode transition

同一shell内shape/layoutId连续变形，键盘焦点保持；search/assembly关闭恢复location，不留下第二overlay。动效150–240ms gentle；resize/zoom不影响screen-space大小。

## 代码骨架

```tsx
export function CenteredSpatialIndex() {
  const state = useNavigationState()
  const mode = resolveDominantMode(state)
  return (
    <InvisibleShell data-mode={mode} role={roleForMode(mode)}>
      <AnimatePresence mode="popLayout" initial={false}>
        {renderMode(mode, state)}
      </AnimatePresence>
    </InvisibleShell>
  )
}
```

具体可不用`AnimatePresence`若Huabu已有motion primitive；关键是单owner/单slot。

## 键盘

- Mod+K：command/search（若grok palette已有，复用）。
- Mod+1..9：按当前可见pin order定位，不用于切top tabs。
- Esc：逐层退出search/assembly/focus，再回location。
- arrows/Enter：列表导航；屏幕阅读器有active descendant。

---

# 5. D02 — Pin model 与 Color Pin

## Model

```ts
export interface ProjectPin {
  readonly id: string
  readonly projectId: string
  readonly target: PinTarget
  readonly color: PinColorToken
  readonly label?: string
  readonly order: number
}

export type PinTarget =
  | { kind: 'entity'; ref: CoreEntityRef; preferredSurface?: SurfaceKey }
  | { kind: 'surface'; surface: SurfaceKey }
  | { kind: 'workspace'; workspaceId: string }
  | { kind: 'view'; viewId: string }
```

Pin identity可由Core现有view/project preference承载；若无endpoint，先使用明确的project preference store并列为Core缺口，不把Pin当artifact。Geometry不保存；定位时查binding，找不到则project/repair再locate。

## Color

颜色帮助空间记忆，不编码domain type/status。固定8–10个对比度合格token；用户同target可一个pin，不为不同surface重复除非需求明确。color在dark/light/high contrast均有可辨outline/shape。

## 交互

- Pin：右键/Action Arc能力；不常驻每node图钉按钮。
- 点击：locate intent，保留周边。
- 双击/Enter：read/focus，按target能力。
- 拖动pin：只重排order；拖到canvas默认不移动target，可作为locate preview。
- stale target：显示中性缺失态，可repair/remove，不崩溃。

## Pin/Focus/Search

Search result可临时locate，不自动pin；Pin click可focus但pin仍存在；Focus退出不unpin；Selection target不自动pin。

---

# 6. D03 — DynamicGlyph 与 Glyth

## 目标

一个glyph系统表达对象身份、能力和状态变化，但不让每个feature画自己的icon。动态是同一identity的局部形态变化，不是新语义。

## Model

```ts
export interface GlyphModel {
  readonly identity: GlyphIdentity
  readonly state?: GlyphState
  readonly emphasis?: 'quiet' | 'normal' | 'active'
  readonly badge?: GlythBadge
}

export type GlyphIdentity =
  | 'artifact-text' | 'artifact-image' | 'artifact-audio' | 'artifact-video'
  | 'conversation' | 'skill' | 'run' | 'workflow' | 'context' | 'assembly'
```

这些identity映射现有canonical object/species；不因`selected/running/pinned`新增identity。

## 组合

```text
base silhouette
  + optional semantic notch/port
  + state stroke/fill
  + one priority badge
  + optional glance motion
```

图标应使用共享SVG path/component；mono variants来自Amicro时提取path和viewBox，重包成LCOS primitive，不复制36个带业务名字组件。所有glyph支持16/20/24/32/48px，stroke在屏幕空间清晰。

## Glyth

Conversation/agent用Glyth而非普通chat bubble。Glyth可基于agent identity产生稳定形态/seed，但seed不是安全身份。状态角标位于右上但只显示最高优先级；tooltip/label提供文本。

## Badge arbitration

优先级：error > needs-review > recording/transcribing > running > complete-recent > pinned cue > none。Pin本身优先在导航表达，节点角标只有用户需要找回pin时短暂显示，避免角标爆炸。

---

# 7. D04 — Glance 动效状态机

## 定义

Glance 是让用户“余光知道发生了什么”的短促、低干扰motion grammar。它不循环炫技，不替代status文字，不触发domain mutation。

## 事件

```ts
export type GlanceEvent =
  | { kind: 'activity-started'; ref: CoreEntityRef }
  | { kind: 'activity-progress'; ref: CoreEntityRef; progress?: number }
  | { kind: 'needs-attention'; ref: CoreEntityRef }
  | { kind: 'completed'; ref: CoreEntityRef }
  | { kind: 'failed'; ref: CoreEntityRef }
  | { kind: 'located'; ref: CoreEntityRef }
```

## Motion map

| 事件 | 视觉 | 时长/循环 | reduced motion |
|---|---|---|---|
| started | glyph轻呼吸一次，badge进入 | 240–380ms，不无限loop | badge直接出现 |
| progress unknown | 低频边缘相位，最多3次后静态running | 1.2s×3 | 静态running |
| progress known | 小环/线性进度 | 随truth更新，不弹跳 | 数值/静态环 |
| attention | 单次偏移/亮度强调 | 180ms，可在10s后最多再一次 | outline+文本 |
| complete | check draw/收束 | 240ms一次 | 静态done |
| failed | 轻shake最多1次+error badge | 180–240ms | error badge |
| located | pin/node短暂halo | 300ms一次 | focus outline |

禁止无限pulse所有running nodes；100 nodes中只有当前/新事件动，稳定running静态。

## 状态恢复

reload时直接显示canonical status，不重播complete/confetti。只有本session新边沿触发Glance。event去重key可用entity+status transition+updatedAt，放内存/session presentation store，不进Core。

## 性能

transform/opacity/stroke-dash优先；避免大面积filter/box-shadow动画。不可用three/ogl背景。离屏节点不播放；document hidden暂停。

---

# 8. D05 — Invisible Shell / 去卡片化材料

## donor insight

ios26 `materials.json` thin material约bg opacity .03/blur 100；glass-legibility提供反模式；identity variant shape-adaptive border。采用的是“看得见交互边界但没有卡片墙”的配方，不复制整个iOS皮肤。

## 组件

```tsx
export interface InvisibleShellProps {
  readonly tone?: 'neutral' | 'accent' | 'danger'
  readonly elevation?: 'none' | 'floating' | 'dominant'
  readonly interactive?: boolean
  readonly children: ReactNode
}
```

## 使用

- 节点rest：通常none/透明。
- hover/selected：极薄tint/outline。
- centered index/Composer：floating material。
- Work View：dominant但内容区域仍非卡片堆叠。
- modal/permission：清晰实底，不能为了glass牺牲legibility。

## Legibility规则

1. blur不可作为文字对比唯一保证。
2. 背景复杂时增加scrim/opaque fallback。
3. high contrast禁用透明材料。
4. nested glass最多一层；Work View内部section不用再套glass cards。
5. 边界shape随容器实际形态，不所有东西16px圆角矩形。

## 性能降级

`@media (prefers-reduced-transparency)`若可用；否则根据platform/perf flag关闭backdrop-filter。WebView/Windows桌面实测；blur区域限制在导航/Composer而不是整canvas。

---

# 9. D06 — 微交互 donor 的采用与拒绝

## motion/react 基础

Huabu web 已引入/可解析`motion/react`后，LCOS primitives集中使用；业务组件不得直接各写spring常量。若依赖未进入目标fork package.json，先在正确workspace安装并锁定，不用复制编译产物。

## Amicro

### 采用候选

- `AnimatedMetricCard.tsx` 中mono SVG paths/metric transition：提取成`MonoMetric`，去card shell。
- `mono-charts/` Sankey/Treemap/Radar/Heatmap/Gauge：只在Context/Run Work View确有数据需求时lazy adapter。
- pill-tabs layoutId indicator：Work View内部tabs/Preview adapter可用。
- checkmark draw：approve/complete短促反馈。
- floating label/error shake/chips：Composer advanced/skill forms。
- Curtain/zipper等whimsical：默认拒绝，除非明确功能语义与品牌裁决。

### 禁止

不能因为仓库有36形式就都进bundle；不能保留`AnimatedMetricCard`白卡；不能让chart variant变成新artifact type。

## ReactBits

只评估低侵入、无three/ogl的text/component animation。背景类默认拒绝；Spotlight/Tilt只用于小面积hover且pointer precision不受影响。所有组件必须reduced-motion、keyboard、touch降级。

## grok-bot CommandPalette

采用tabs/virtual scroll/nested steps/Mod+1..9 mechanics；数据来自Search/Assembly/Navigation registry。Drag-drop accept overlay适配Composer/semantic drop，不复制grok产品命令taxonomy。

## Rejection Record字段

- need/source ID
- Huabu现有能力
- donor候选/version/license
- 采用/拒绝原因
- bundle/perf/accessibility
- adapter/delete path

---

# 10. D07 — 右侧栏、Preview Workspace、LCOS Work View最终布局

## 右侧栏固定什么

固定的是Huabu通用Preview Workspace容器能力，不是把Context/Workflow/Skill/Run renderer永远钉在右边。右栏可有agent tabs、file preview、common resources。

## 可拖/中间态什么

- Unified Composer：canvas内可拖局部表面。
- LCOS Work View：floating/docked/immersive，可从右dock拖回floating。
- Instrument node：画布中的world object，可resize/focus/open Work View。
- Preview Workspace panel：按Huabu既有能力resize/dock，不被LCOS fork重造。

## 布局冲突

Preview Workspace和LCOS Work View都占右侧时，arbitration：一个dominant dock；另一个collapse/tab/floating，不能双重挤压到画布不可用。occupied-region registry统一报告。

## 响应式窗口

- 宽≥1440：right dock 420–620px，canvas保留≥720px。
- 1024–1439：dock 360–480px；必要时overlay/floating。
- <1024：Work View优先immersive/bottom sheet语法，但desktop产品若不支持小窗，至少给清晰min-size。

数值是真机起点；不创建mobile新产品语义。

---

# 11. D08 — Action Arc、右键、命令面板最终仲裁

## Action Arc

selection附近最多4个高频、能力驱动动作。动作顺序稳定：primary work/compose、reference/connect、assembly/open、more/secondary。没有能力不占空位。

## 右键

完整、低频、破坏性、设置、切presentation mode、pin/unpin、open destinations。右键菜单由同一capability registry生成，不另写业务if链。

## Command Palette

跨对象/跨surface搜索、Assembly、导航、命令。它不替代Action Arc的空间就近操作；Action Arc不承载复杂nested command。

## 节点常驻

rest不显示工具；状态badge例外但单一。connect affordance/resize只hover/selected或明确mode。符合no node Christmas tree。

## Capability schema

```ts
export interface UiCapability {
  readonly id: string
  readonly label: string
  readonly placement: readonly ('arc' | 'context-menu' | 'command')[]
  readonly priority: number
  readonly enabled: boolean
  readonly disabledReason?: string
  run(): void | Promise<void>
}
```

同一 capability instance可投到不同入口；避免三套action handler。

---

# 12. D09 — Accessibility、DPI 与输入法

## Keyboard/focus

- 所有pointer动作有keyboard路径：select/reference/open/pin/context menu/resize若无法完整键盘则提供size editor。
- focus ring使用screen-space 2px且不被canvas zoom缩小。
- Composer/Work View正确恢复focus到触发node。
- command/index使用aria-activedescendant或roving tabindex。

## Screen reader

canvas node有`aria-label`包含对象species/title/status；badge有文本，不只颜色。Glance事件只对needs-attention/complete等重要边沿适度announce，progress不刷屏。

## Color

Pin颜色另有shape/label；error/review/running不只颜色。WCAG对比按实际背景/透明材料测试。

## Motion/transparency

reduced motion：关闭Glance位移/循环、camera使用更短/直接变换、保留状态。reduced transparency/high contrast：solid shell。

## DPI

100/125/150/200%检查36px命中、glyph stroke、text crisp、overlay anchor。world-spacenode内容随zoom，screen-spaceHUD保持CSS px。不要把`devicePixelRatio`乘到CSS hit size两次。

## IME

中文输入composition期间Enter不提交、Esc不误关；Text node/Composer/Skill forms全部覆盖。

---

# 13. D10 — 主题、品牌与替换接口

## Token contract

所有LCOS视觉只消费semantic tokens；dark/light/high contrast由token provider。donor adapter不得引用硬编码hex，SVG可`currentColor`。

## 可替换

- motion engine封装在`ui/motion`，业务只用preset/primitive。
- chart/tree/graph donor封装adapter，domain model不import donor types。
- glyph registry可替换SVG set，不改entity contracts。
- material renderer可关闭blur，不改layout。

## 不可替代LCOS精髓

保留：DynamicGlyph/Glyth identity、Pin spatial memory、三Surface导航、Selection/Reference/Relation grammar、Action Arc、Unified Composer/Work View、Context/Workflow/Assembly/Skill direct instruments、project continuity。

可替换：canvas机械(Huabu)、tree/graph/timeline/layout/chart/command palette、generic agent tabs/viewers、animation engine。

---

# 14. D11 — 全功能承接审计表

| 功能族 | 最终owner | Phase | 最终入口/形态 | 不得遗漏的证据 |
|---|---|---|---|---|
| Canvas geometry/pan/zoom/select/resize | Huabu | A/B | Canvas/NodeWrapper | 原生文本无回归 |
| Core projection/binding/reconcile | Gen2 Host/Core | G0/A | invisible runtime | restart一致 |
| Main/Context/Workflow | SurfaceRegistry+Huabu | A/C/D | centered index导航 | 三状态隔离 |
| 子画布/工作现场 | workspace/view+canvasId | C/D | navigate/restore | 非第二engine |
| responsive nodes | Presentation owner | B | all species | size×zoom×phase |
| Text/Outline/Mindmap | same artifact/node | B | mode switch | identity不变 |
| media/viewer | Huabu preview+LCOS adapter | B | node/Preview/Work View | lazy/perf |
| Conversation/Glyth/agent | Core identity+Huabu tabs | B/C/D | node+right tabs | session一致 |
| corner badge/Glance | derived presentation | B/D | glyph corner | truth可恢复 |
| Context instruments | LCOS+donors | C | node/Work View | Core relations/revisions |
| Workflow | Core+Huabu+ELK/Rete adapter | C | Surface/Work View | semantics/geometry分离 |
| Assembly | project catalog | C/D | Arc/index/palette | capability filter |
| Skill | Core artifact | C | node/Work View | Skill≠Run |
| Composer/Reference/Voice | LCOS+Core | A/C/D | movable canvas surface | Selection≠Reference |
| Run/Review/Trace | Core+Work View | C | Work View | changeSet/provenance |
| Search/Focus/Pin/Locator | navigation/presentation | D | one centered slot | 状态不混 |
| Action Arc/right-click | capability registry | A/C/D | local/global | max4/no Christmas tree |
| material/motion | UI token owner | D | primitives | reduced modes/perf |

施工者必须把此表扩为repository-specific checklist，给每项填实际文件、测试名、截图/录屏链接和状态。不能写“由某阶段覆盖”而无证据。

---

# 15. D12 — 自动化测试

## Unit

- navigation arbitration、quantity layout。
- Pin CRUD/order/stale target/locator resolution。
- glyph identity/state/badge priority。
- Glance edge detection/dedupe/reduced motion。
- token/donor registry无硬编码/重复preset。
- capability placements Arc/context/command一致。
- Work View/Preview Workspace dock arbitration。

## Component

- centered index所有mode keyboard/focus。
- PinRail 0/1/4/9/20。
- DynamicGlyph sizes/status/themes。
- InvisibleShell contrast/fallback。
- Composer reference/pin/action overlay z-order。
- right panel+Work View resize/occupied region。

## Visual regression

主题light/dark/high contrast；DPI 100/150；zoom .25/1/2；window 1024/1440/1920；motion normal/reduced；transparency normal/solid。快照只辅助，不能替真人手感。

## Dependency checks

- donor modules仅在adapter/lazy chunk import。
- 无three/ogl/大背景依赖。
- motion preset无散落重复spring。
- bundle report记录新增chunk与首屏影响。

---

# 16. D13 — Human Product Smoke Runbook

## 环境记录

- OS/GPU/显示器分辨率/DPI。
- Gen2/Core/Huabu refs。
- clean/dirty files。
- browser/desktop shell/version。
- motion/transparency偏好。

## 30分钟主剧本

1. 打开project，Main camera/selection恢复。
2. centered index确认location；Pin一个artifact/conversation/workspace。
3. resize Text node跨四density；切Text/Outline/Mindmap。
4. Ctrl/Cmd pick references，打开可拖Composer；voice转写但不自动提交。
5. 提交真实Run；Glyth/Run badge与Glance展示；右栏agent tab可查看会话。
6. 打开Run Work View，floating→right dock→immersive→restore；camera safe region正确。
7. 切Context，Structure/Relationship/Evolution/Source至少各做一次真实动作。
8. 切Workflow，connect步骤、auto-layout、运行、review。
9. Assembly插入existing entity/instrument；Search找已有对象，二者不混。
10. Pin定位跨surface对象；Focus/退出；selection/reference/pin各自保持规则。
11. reload web、restart Core、reconnect RFS，检查bindings/run/workview/pins/cameras。
12. reduced motion/high contrast重复核心导航/Composer/Glance。

## 失败记录

每个失败写：步骤、期望、实际、屏幕/zoom/DPI、日志、是否数据损坏、owner、最小复现。不要用“体验有点问题”。

## 通过标准

用户不用知道Core/Huabu/donor；没有明显第二套canvas/右栏/卡片系统；常用动作不寻找三个入口；动画不延迟操作；同对象跨表现/Surface identity连续。

---

# 17. D14 — 性能、稳定与恢复

## 预算

- 100 nodes pan/zoom 55–60fps目标，持续不低于45。
- centered index/Glance不触发全canvas重渲染。
- graph/timeline/pdf/video lazy。
- background tab暂停motion/expensive polling。
- Work View dock resize不每帧触发Core/React全树mutation。

## 内存

切surface/Work View 20次后无recognizer/timer/subscription泄漏；video/pdf/graph dispose；RFS reconnect不重复注册。

## 恢复

- stale pin target可修复/移除。
- missing Huabu node用binding reconciliation重建。
- Core关系存在edge缺失可恢复。
- Work View restore node缺失时定位canonical entity并选择可用surface，不崩溃。
- donor组件错误用error boundary回退neutral preview，不破坏canvas。

---

# 18. 发布拆分与工时

| 包 | 内容 | 预计 |
|---|---|---:|
| D00 | tokens/motion/material owner | 2–3 天 |
| D01–D02 | centered index/Pin/model/persistence | 4–6 天 |
| D03–D04 | DynamicGlyph/Glyth badge/Glance | 4–6 天 |
| D05–D06 | materials/donor primitives | 3–5 天 |
| D07–D08 | right panel/Work View/Arc/menu/palette arbitration | 3–5 天 |
| D09–D10 | accessibility/DPI/theme/replaceability | 3–4 天 |
| D11–D14 | full audit/E2E/perf/restart/fixes | 6–10 天 |

单一工程 agent约25–39个有效工作日。视觉微调不应无限拖延；先满足语义可读、动作一致、性能/accessibility，再在固定motion/material tokens上调参。

---

# 19. Phase D / Gen2 前端整体退出条件

1. centered spatial index在location/pins/search/assembly/focus/command间单slot变形，无top canvas tabs堆叠。
2. Pin是reference/preference，不是新entity；定位跨surface可靠。
3. DynamicGlyph/Glyth统一identity/state/badge；右上角只一个主badge。
4. Glance从canonical state边沿派生、克制、可降级、不无限loop。
5. material去卡片化且legible；donor theme不污染Huabu。
6. right Preview Workspace与LCOS Work View/Composer分工清楚，可拖/停靠/恢复。
7. Action Arc≤4，右键/command palette共享capability registry。
8. 全功能承接表每项有实际文件、测试、真人证据。
9. zoom/DPI/theme/reduced motion/transparency/keyboard/IME通过。
10. 性能、内存、reconnect/restart通过。
11. donor全部经adapter/lazy/license/删除边界；无第二truth。
12. 用户看到的是一个Huabu-native、LCOS-semantics-complete的产品，而不是Huabu旁边拼了一个旧LCOS。

---

# 20. D15 — 源码级接线清单

本节用于避免 GLM 只创建新目录、不把真实页面接上。文件名若上游在施工前变化，先用符号搜索定位同一 owner，再在回传中写新路径；不得因为路径漂移另建重复 owner。

## Huabu `Canvas.tsx`

只消费 Phase A 的 `hostExtension`，并给 centered index/Work View overlay 提供单一 portal root。不得在这里判断 Pin、Glyph、Run、Context。验证：搜索 `lcos` 在 Huabu 核心 Canvas 内应只有 seam import/props/portal，不出现 domain switch。

## Huabu `NodeWrapper.tsx`

继续负责 hover/selected/editing/dragging/resizing、toolbar/overlay/takeover。`DynamicGlyph` 与 `GlythBadge` 由外部 renderer通过 slot呈现；NodeWrapper不认识run status。screen-space overlay offset沿用现有`overlayOffsetY/overlayMaxWidth/overlayInteractionPriority`。

## Huabu `MainLayout.tsx` / `CenterArea.tsx` / `CanvasPage.tsx`

找到现有Preview Workspace和canvas布局组合位置，在此接 `OccupiedRegionProvider` 或等价公开port。不要在Gen2用DOM query测右栏宽度。Preview Workspace open/resize event发布screen rect；LCOS Work View发布自己的rect；camera owner消费合并结果。

## Huabu `previewWorkspace/model.ts` / `persistence.ts`

不把LCOS Pin/Work View塞入`huabu.previewWorkspace.${canvasId}`。只新增必要的external preview descriptor adapter，保持Huabu既有tab/group/persistence语义。LCOS Work View使用project-scoped store；二者通过open destination resolver协作。

## Gen2 `host/hostSeam.ts`

从空数组工厂变为接受注册表输入：

```ts
export interface HostSeamOptions {
  readonly renderers: readonly LcosRendererDescriptor[]
  readonly overlays: readonly LcosOverlayDescriptor[]
  readonly resolveRelationKind: (input: ConnectIntentContext) => ConnectResolution
}

export function createHostSeam(host: Gen2Host, options: HostSeamOptions): HostSeam
```

不要让`createHostSeam()` import具体Pin/Composer组件；由app composition root组装。

## Gen2 app composition root

在真实Web入口（以当前仓库找到的React mount/router为准）只创建一次：Gen2Host、morphology registry、capability registry、navigation store、Work View store、host seam。projectId/token/RFS canvasId改变时dispose重建。StrictMode双mount下不能注册两次timer/recognizer。

## Core preference落点

Pin、presentation mode、Work View session若Core已有project preference/view/workspace route，写typed client；如果没有，将临时persistence放明确`integration preference`表/route而不是混进artifact。任何schema新增必须保持：无geometry；target用canonical ref；可迁移；删除target不级联删entity。

---

# 21. D16 — Donor 代码迁入格式与删除开关

## 每个 adapter 的文件头

```ts
/**
 * Donor: <name>@<version>
 * Source: <repository/path or package>
 * License: <SPDX>
 * Adopted: <mechanic only>
 * LCOS owner: <intent/model>
 * Delete/replace path: <adapter interface>
 */
```

复制源码而不是npm依赖时保留原license/header；重写path也记录来源。不能把donor代码散到业务目录后失去来源。

## Feature switch不是长期双实现

对高风险graph/timeline/material可以短期feature flag验证，但flag必须有删除任务与日期/条件。禁止“旧LCOS renderer”和“Huabu adapter”永久并存。切换单位是adapter，不是domain data；两边读同一model以便对比。

## Bundle与版本

运行依赖写入正确Huabu/Gen2 workspace package，不在root偶然hoist；锁文件按仓库包管理策略提交。记录gzip chunk；Cytoscape/Sigma/PDF/video必须dynamic import。motion为共享基础可主chunk，但业务只通过LCOS motion wrapper。

## Donor替换测试

为每个adapter写contract test，以LCOS input/output断言，不快照donor内部DOM。例：ELK输入workflow projection输出目标positions；替换layout engine时测试仍成立。Cytoscape adapter输出relation/connect/select intents；不让上层读取`cy`实例。

---

# 22. D17 — 发布前逐文件静态审查命令与人工问题

施工环境优先使用`rg`，以下为意图示例，路径以实际repo执行：

```bash
rg -n "@local-creative-os|CoreEntity|Run|Skill" microsoft/Huabu/apps/web/src/components/Panels/Canvas
rg -n "x:|y:|width:|height:|viewport|parentId" apps/web-gen2/src/backend apps/web-gen2/src/spatial
rg -n "new ReactFlow|<ReactFlow" apps/web-gen2/src
rg -n "fetch\(|axios" apps/web-gen2/src --glob '!backend/**'
rg -n "stiffness|damping|backdrop-filter|box-shadow" apps/web-gen2/src --glob '!ui/tokens/**' --glob '!ui/primitives/**'
rg -n "any\b|unknown as|ts-ignore" apps/web-gen2/src
```

审查者逐个回答：

1. Huabu核心是否知道LCOS domain？应否。
2. Gen2是否出现第二ReactFlow/viewport/geometry persistence？应否。
3. UI是否绕typed client裸fetch Core？应否。
4. Pin/Focus/Search/Glance是否被保存为artifact/entity？应否。
5. presentation density是否写入Core？应否。
6. 同一Markdown三态是否仍同entity/node/binding？应是。
7. 所有spring/material常量是否集中？应是。
8. donor是否可从adapter边界替换？应是。
9. 状态badge是否最多一个主标记？应是。
10. right Preview Workspace与LCOS Work View是否有清楚入口文案与owner？应是。

## 发布回传证据包

- `SOURCE_TRACE.md`：需求Source ID→PR/commit→文件/符号→测试/录屏。
- `DONOR_TRACE.md`：donor/version/license/adopted/rejected/delete path/bundle。
- `FEATURE_LEDGER.md`：第14节每项actual status，不复制计划状态。
- automated test results。
- human smoke记录与关键录屏。
- known failures，含数据风险与owner。

这些可作为施工PR附件/持续文档；不要再生成一套与代码脱节的“完成宣言”。
