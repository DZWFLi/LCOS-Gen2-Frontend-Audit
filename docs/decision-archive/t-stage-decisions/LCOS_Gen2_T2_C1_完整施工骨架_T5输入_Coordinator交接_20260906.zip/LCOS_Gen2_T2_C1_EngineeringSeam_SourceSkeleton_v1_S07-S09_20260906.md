# LCOS Gen2 · T2 Phase C1 Engineering Seam / Source Skeleton v1
## Checkpoint 03 · S07–S09
### Dynamic Locator / Camera Request / Arrival · Minimap / Spatial Navigator · Professional Window Occupancy Consumer

日期：2026-09-06  
状态：`PHASE C1 · SOURCE-LEVEL SKELETON · CHECKPOINT 03`  
代码基线：`DZWFLi/LCOS_Gen2 @ c2ff890a867922a1256572199458438572eb0a8c`  
Gen1 donor：`DZWFLi/LCOS-local-creativeOS @ 3e99769`

> 承接：
>
> - `LCOS_Gen2_T2_C1_EngineeringSeam_SourceSkeleton_v1_S01-S03_20260906.md`
> - `LCOS_Gen2_T2_C1_EngineeringSeam_SourceSkeleton_v1_S04-S06_20260906.md`
>
> 本稿不重新讨论产品语义。
> Phase B 已关闭 Locator / Work View camera / safeRect / Surface navigation 等产品问题。
>
> 本 checkpoint 只把以下行为落到 current source：
>
> - `T2-S07 Dynamic Locator + Camera Request + Arrival`
> - `T2-S08 Minimap / Spatial Navigator`
> - `T2-S09 Professional Window Occupancy Consumer`

---

# 0. 本 checkpoint 最重要的三条 current-source 结论

## 0.1 Core navigation `worldPosition` 不能成为 Gen2 Spatial Truth

`packages/contracts/src/navigation-marker.ts` 已经明确写着：

```text
Core 只持久化导航意图
不持久化 world-pin / edge-cursor / cluster / screen x/y / camera zoom
```

这是正确的。

但 current：

`apps/local-core/src/navigation-marker-service.ts`

仍会从旧：

```text
ArtifactView.position
Workspace.frameBounds
```

生成 `ResolvedNavigationTargetV0.worldPosition`。

Phase B + Huabu-first 后：

> 这个 `worldPosition` 只能视为 legacy compatibility hint，
> 不能作为 Locator / Focus / Arrival 的最终空间真相。

真正 local projection geometry 必须：

```text
canonical targetRef
→ ProjectionBinding
→ Huabu spatialId/nodeId
→ Huabu internal node bounds
```

---

## 0.2 Huabu 当前已经有可直接复用的可靠 offscreen bounds primitive

exact：

`huabu/apps/web/src/components/Panels/CanvasLayerPanel/focusNodesOnCanvas.ts`

KEEP：

```ts
getReliableNodeBounds()
```

它解决：

```text
onlyRenderVisibleElements
→ offscreen node 未 mounted / unmeasured
```

并从 `ReactFlowInstance.getInternalNode()` 读取：

```text
internals.positionAbsolute
measured / width / initialWidth / style width
```

这正是 Locator / Focus / Minimap navigation 的可靠本地几何入口。

---

## 0.3 Huabu current resize policy 与 Phase B D15 有真实冲突，但可薄适配

exact：

`huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx`

current `ResizeObserver`：

```text
wrapper size changes
→ anchorViewportCentre()
→ optional revealBoundsInViewport()
→ instance.setViewport(nextViewport, {duration:0})
```

Current comment明确：

> Side panels and split previews change wrapper size; compensate by half delta to keep same flow point centred.

Phase B D15 对 LCOS：

```text
Professional Window open / resize
→ Camera MUST NOT auto move
```

因此需要：

> **LCOS host-only viewport resize policy override。**

不修改 generic Huabu default。

---

# 1. S07 · Dynamic Locator + Camera Request + Arrival

# 1.1 USER BEHAVIOR

Locator 是：

> 已知目标不在当前可视范围时，告诉用户“它在哪个方向”，并允许一步直达。

用户路径：

```text
Known target selected / Focus occurrence / Pin member
↓
target projection outside active safeRect
↓
target-local cue 连续变成 safe-edge locator
↓
click
↓
direct camera travel
↓
target enters safeRect
↓
Arrival feedback on target body/field
↓
locator dissolve
```

禁止：

```text
popup
确认框
“是否前往”
toast “已定位”
固定 zoom
硬切 Camera
```

---

# 1.2 Locator 不是 canonical Marker entity

需要明确区分：

## Core Spatial Marker / Color Pin

durable navigation intent。

## Dynamic Locator

screen-space projection state：

```text
local
near-edge
edge
travelling
arriving
hidden
```

Locator 不能持久化。

---

# 1.3 CURRENT canonical navigation owner

## Contract

`packages/contracts/src/navigation-marker.ts`

Target：

```ts
SpatialMarkerTargetRefV0 {
  projectId
  kind: 'view' | 'entity' | 'surface'
  id
}
```

Resolve：

```ts
NavigationResolutionV0
```

## Service

`apps/local-core/src/navigation-marker-service.ts`

## Route

`apps/local-core/src/routes/navigation-markers.ts`

```text
POST /projects/:id/navigation/resolve
```

Checkpoint 02 另规划：

```text
POST /projects/:id/navigation/occurrences
```

---

# 1.4 CURRENT spatial identity seam

`huabu/apps/web/src/lcos/useLcosCanvasProps.tsx`

reconcile 后：

```text
rt.host.listNodeBindings()
→ useLcosReferenceStore.registerNodeEntity(spatialId, entityRef)
```

Current runtime therefore已经能建立：

```text
Huabu nodeId ↔ Core entity identity
```

T2 不需要通过 title/name 猜 projection。

---

# 1.5 Reverse projection resolution

Locator 需要：

```text
canonical targetRef
→ current canvas node id(s)
```

现有 ProjectionBinding registry 是正确底座。

### PLANNED thin helper

`apps/web-gen2/src/spatial/navigationProjection.ts`

纯逻辑/adapter：

```ts
resolveCurrentCanvasProjection(
  bindings,
  targetRef,
  canvasId
): NavigationProjectionRef[]
```

输出：

```ts
NavigationProjectionRef {
  spatialId: string
  canvasId: string
  targetRef
}
```

不带 geometry。

如果 canonical target 当前 canvas 无 projection：

```text
[]
```

然后：

- Focus 决定是否 Enter other Worksite；
- archived/unavailable 不造 projection；
- Locator 不画 ghost arrow。

---

# 1.6 DO NOT USE Core `worldPosition` as final geometry

Current `NavigationMarkerService`：

```text
view → ArtifactView.position
workspace → frameBounds center
```

在 migration 期间可用于：

```text
legacy diagnostic
compatibility fallback metadata
```

但 **不能**：

```text
worldPosition
→ screen project
→ draw final Locator
```

否则重新让 Core 变成 Spatial Truth。

### T6/T1 migration note

后续应逐步降低甚至移除旧 canonical-looking geometry 输出，
但 T2 不越权在本 checkpoint 改 Core schema。

---

# 1.7 CURRENT Huabu geometry primitives

exact：

`huabu/apps/web/src/components/Panels/CanvasLayerPanel/focusNodesOnCanvas.ts`

## DIRECT KEEP

```ts
getReliableNodeBounds(rfInstance, nodeIds)
```

## REUSE WITH WRAP

```ts
fitNodesOnCanvas()
focusNodesOnCanvas()
revealBoundsInViewport()
```

其中当前 `focusNodesOnCanvas()`：

```text
setCenter(cx,cy)
duration default 800
zoom = min(currentZoom,1)
```

不满足最终 safeRect fit，
所以只作为 camera mechanic donor。

---

# 1.8 PLANNED camera framing pure layer

### PLANNED NEW

`apps/web-gen2/src/spatial/cameraFraming.ts`

不得依赖 React/DOM。

输入：

```ts
WorldRect
ViewportRect
SafeRect
CurrentViewport
CameraFramingOptions
```

输出：

```ts
CameraFramePlan {
  targetViewport
  targetScreenRect
  reason
}
```

算法：

```text
single target
→ actual reliable bounds

multiple target
→ union reliable bounds

safe area
→ active safeRect, not whole viewport

padding
→ optical + minimum pixel margin

zoom
→ bounded min/max

oversized target
→ fit rather than fixed center zoom
```

---

# 1.9 Camera defaults

T5 不拥有 camera physics；
T2 engineering 可以给 safe bounds。

初步施工值：

```text
minZoom: Huabu MIN_ZOOM
maxZoom for Locate/Focus: min(Huabu MAX_ZOOM, 2)
```

Timing：

TapNow donor：

```text
~500ms bounded fit
```

Huabu current local search：

```text
400ms
```

因此 final default建议：

```text
450–550ms
```

但最终 exact easing/duration由 T5 motion回填。

Reduced motion：

```text
duration 0 / minimal
Arrival remains non-motion color/outline state
```

---

# 1.10 PLANNED Huabu camera adapter

### PLANNED NEW

`huabu/apps/web/src/lcos/navigationCamera.ts`

职责：

```text
ReactFlowInstance
+ target node ids
+ current wrapper rect
+ safeRect
→ getReliableNodeBounds
→ cameraFraming.ts
→ rfInstance.setViewport / fitBounds
```

这个文件是**唯一 T2 camera write adapter**。

禁止：

```text
ProjectSearchView directly setCenter()
PinView directly fitView()
LocatorOverlay directly setViewport()
Railway item directly setZoom()
```

所有 explicit camera navigation收敛到这里。

---

# 1.11 Explicit camera reasons

建议 type：

```ts
type NavigationCameraReason =
  | 'focus'
  | 'pin'
  | 'locator'
  | 'search-result'
  | 'rail-locate'
  | 'arrival-reveal'
```

它只是 telemetry/debug reason，
不是产品 mode。

---

# 1.12 Locator screen projection pure layer

### PLANNED NEW

`apps/web-gen2/src/spatial/locatorGeometry.ts`

输入：

```ts
targetScreenRect
safeRect
```

输出：

```ts
LocatorProjection {
  state: 'local' | 'near-edge' | 'edge'
  anchor
  direction
  distance
  progress
}
```

原则：

### target fully/meaningfully inside safeRect

```text
local / hidden
```

### target approaches boundary

```text
continuous progress
```

### target outside

```text
intersect ray/nearest-point with SAFE RECT edge
```

不是浏览器 viewport edge。

---

# 1.13 Local→edge continuity

禁止二元：

```text
inside = pin
outside = arrow
```

导致瞬间跳形。

应派生：

```text
progress 0..1
```

供 T5：

- Morphicons controlled morph；
- position interpolation；
- opacity/scale；
- optional direction rotation。

如果 final glyph path不适合 morph：

```text
Amicro IconSwap
+ shared position interpolation
```

---

# 1.14 PLANNED Locator state

### PLANNED NEW

`apps/web-gen2/src/interaction/locatorState.ts`

纯状态：

```text
idle
tracking(targetRef)
travelling(targetRef)
arriving(targetRef)
```

不 persist。

### Huabu hook

`huabu/apps/web/src/lcos/useLcosLocator.ts`

订阅：

- current target；
- ProjectionBinding；
- `rfInstance`；
- viewport transform；
- safeRect；
- resize/pan/zoom。

derive：

```text
LocatorProjection
```

不存 screen coordinates。

---

# 1.15 PLANNED Locator body

`huabu/apps/web/src/lcos/ui/LcosLocatorOverlay.tsx`

挂：

`LcosHostOverlay.tsx`

并继续 obey：

`overlayArbitration.ts`

Locator/Arrival可能需要增加 outer kind：

```text
navigation-adornment
```

或归 `canvasAdornment` layer。

不要把 Locator 挤进 top Navigation HUD。

---

# 1.16 Arrival

Arrival 不是 toast。

### PLANNED NEW pure helper

`apps/web-gen2/src/presentation/arrival.ts`

输入：

```text
target projection ids
nonce
reducedMotion
```

输出：

```text
arrival presentation phase
```

### Huabu consumer

优先不画 screen-space circle。

真正 Arrival 要落到 target body：

```text
node wrapper class/data attribute
```

最小 seam：

`huabu/apps/web/src/lcos/arrivalState.ts`

ephemeral：

```text
targetNodeIds
nonce
expiresAt
```

Node wrapper / LCOS artifact body消费：

```text
data-lcos-arrival
```

如果 target 是 aggregate/frame/surface，
由对应 body renderer提供 field/rim feedback。

---

# 1.17 Arrival timing

Gen1 old MiniMap beacon：

```text
900ms
```

这是历史可用 precedent。

T5 final可在约：

```text
600–900ms
```

内收敛。

Reduced motion：

- no scale pulse；
- outline/color settle；
- same semantic duration or shorter。

---

# 1.18 Archived / unavailable target

Phase B D13：

### archived

```text
no Locator
no camera
no ghost x/y
Focus shows Archived
Open viewer
```

### unresolved

```text
Locator hidden
UI says unavailable
```

### projection absent current Worksite but occurrence exists remote

```text
Enter Worksite
then re-resolve local projection
then Locate
```

不能提前拿旧 Core worldPosition飞镜头。

---

# 1.19 S07 file ledger

## CURRENT KEEP

```text
packages/contracts/src/navigation-marker.ts
apps/local-core/src/navigation-marker-service.ts
apps/local-core/src/routes/navigation-markers.ts

apps/web-gen2/src/spatial/projectionBinding.ts

huabu/apps/web/src/components/Panels/CanvasLayerPanel/focusNodesOnCanvas.ts
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
```

## PLANNED NEW

```text
apps/web-gen2/src/spatial/navigationProjection.ts
apps/web-gen2/src/spatial/cameraFraming.ts
apps/web-gen2/src/spatial/locatorGeometry.ts
apps/web-gen2/src/interaction/locatorState.ts
apps/web-gen2/src/presentation/arrival.ts

huabu/apps/web/src/lcos/navigationCamera.ts
huabu/apps/web/src/lcos/useLcosLocator.ts
huabu/apps/web/src/lcos/arrivalState.ts
huabu/apps/web/src/lcos/ui/LcosLocatorOverlay.tsx
```

---

# 1.20 S07 unit tests

## cameraFraming

覆盖：

```text
small target
large target
multi-target union
safeRect left/right/top/bottom inset
narrow safeRect
min/max zoom
zero/invalid rect
already visible target
```

## locatorGeometry

覆盖：

```text
inside
near left/right/top/bottom
outside 8 directions
corner intersection
safeRect shifted by Work View
target larger than safeRect
continuous progress monotonic
```

## navigationProjection

覆盖：

```text
entity current projection
view projection
duplicate bindings
wrong canvas filtered
no projection
```

## locator state

```text
tracking→travelling→arriving→idle
new target cancels old
unresolved resets
```

---

# 1.21 S07 integration tests

```text
Focus occurrence
→ projection binding
→ Huabu node id
→ reliable bounds
→ camera plan
→ setViewport
→ arrival
```

Pin member同一路径。

Target offscreen且未 mounted：

```text
getReliableNodeBounds still resolves
```

---

# 1.22 S07 browser acceptance

至少：

- target just outside left/right/top/bottom；
- diagonal；
- very far target；
- tiny target；
- giant node；
- multiple target Focus；
- current zoom 0.3 / 1 / 2+；
- Docked Work View safeRect；
- Floating Work View；
- narrow viewport；
- rapid pan while locator visible；
- click locator；
- no popup；
- Arrival；
- reduced motion；
- target deleted mid-travel；
- archived target。

---

# 1.23 S07 recovery

Camera animation失败：

```text
canonical state unchanged
Locator remains/resolves current geometry
user can retry
```

Binding stale：

```text
reconcile / re-resolve
no guess by title
```

Target disappears：

```text
cancel travel
clear locator
unavailable
```

---

# 1.24 S07 blast radius

Pure geometry：

`BR-0 / BR-1`

Huabu camera adapter：

`BR-2`

不改 Core canonical writes。

---

# 2. S08 · Minimap / Spatial Navigator

# 2.1 USER BEHAVIOR

LCOS Spatial Navigator：

> “我怎么看当前这张空间”。

统一承接：

```text
Minimap
Zoom out
Zoom level / reset 100%
Zoom in
Fit content
potential Lock / Grid Snap as lower-frequency neighbors
```

它不是：

- Railway；
- SurfaceDock；
- LayerPanel；
- Project Search；
- second spatial engine。

---

# 2.2 Current Huabu exact layout

`huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx`

Current：

## bottom-left

```tsx
<Controls position="bottom-left" showInteractive={false}>
  <CanvasZoomLevel />
  <CanvasInteractivityControl .../>
</Controls>
```

ReactFlow native Controls还会带 stock ZoomIn / ZoomOut / FitView。

## standalone Minimap

```tsx
{minimapEnabled && (
  <MiniMap
    pannable
    zoomable
    ariaLabel="Minimap"
    ...
  />
)}
```

## bottom-center

```tsx
<Panel position="bottom-center" className="mb-6">
  <NodeToolbar .../>
</Panel>
```

所以 current Huabu product chrome确实是：

```text
Controls
+
MiniMap
+
NodeToolbar
```

三个独立一级 Canvas UI。

---

# 2.3 Current `CanvasZoomLevel`

same file。

行为：

```text
显示 x倍数
click → zoomTo(1,{duration:200})
```

KEEP mechanic。

Current exact：

```text
200ms reset
```

---

# 2.4 Current `CanvasInteractivityControl`

same file。

它不是直接乱改 ReactFlow store，
而是 lifted：

```text
locked state
→ nodesDraggable / elementsSelectable controlled props
```

这是成熟实现。

如果 Lock 最终进入 Spatial Navigator：

> **只移动 presentation，不重写 lock mechanics。**

---

# 2.5 Current MiniMap preference

`huabu/apps/web/src/store/canvasStore.ts`

Current：

```text
MINIMAP_STORAGE_KEY = huabu.minimapEnabled
```

global UI preference；
default off；
`toggleMinimap()`。

这是 UI preference，
不是 Core truth。

KEEP 可持久 preference，
但 final launcher/body由 LCOS/T5接管。

---

# 2.6 Current viewport truth

same `canvasStore.ts`

源码明确：

> Pan + zoom is local UI state, not canvas data.

每 canvas：

```text
huabu.viewport.<canvasId>
```

localStorage。

这与 Phase B D07 一致：

```text
Worksite Core不再拥有 camera
Huabu owns spatial state
```

---

# 2.7 Gen1 exact donor

`DZWFLi/LCOS-local-creativeOS`
`apps/web/src/features/canvas/CanvasMiniMap.tsx`
`@ 3e99769`

它已经历史验证过：

```text
collapsed launcher
expanded minimap
click map → camera
drag camera rect → camera
zoom out
percentage / reset100
zoom in
grid snap
fit content
safe inset
arrival beacon
```

这说明用户提出：

> “这些东西其实可以直接集成到 minimap 里面”

不是新造概念，
而是恢复并现代化已经存在过的 LCOS结构。

---

# 2.8 Gen1 what to LIFT

## LIFT product composition

```text
Minimap + viewport controls one cluster
```

## LIFT interaction concepts

- click blank map → centre target；
- drag viewport rect；
- zoom around safe viewport center；
- reset 100%；
- fit content；
- collapsed/expanded；
- safe region awareness。

## DO NOT LIFT

- old `Camera` model；
- old `CanvasNode` source；
- old `WorkspaceFrameVM`；
- DOM `document.querySelector('[data-testid=canvas]')`；
- old `ActiveSpatialViewportContext` implementation；
- old homemade map transform as second spatial engine。

Current Gen2 uses ReactFlow/Huabu.

---

# 2.9 TapNow donor

Expanded direct behavior：

```text
200 × 150
dark background rgba(24,24,27,.92)
white viewport border 1.5px
outside mask
click destination
drag viewport
spring ~120/18/1
launcher crossfade ~200ms
```

Use as high-fidelity interaction donor。

---

# 2.10 Lovart/tldraw donor

Use for：

```text
low-chrome resting shell
hit area vs visible area
quiet reveal
compact expansion
```

不是 second minimap engine。

---

# 2.11 Spatial Navigator implementation choice

首选：

> **继续使用 ReactFlow `<MiniMap>` + current ReactFlow camera。**

不要把 Gen1 map transform重新抄一遍。

### Expanded map

可直接 WRAP：

```tsx
<MiniMap pannable zoomable />
```

再提供 host-owned chrome/controller。

### Why not DOM-copy MiniMap

ReactFlow MiniMap已经跟：

- nodes；
- viewport；
- pan；
- zoom

同一空间系统。

第二 mapping engine只会产生：

```text
camera drift
frame mismatch
nested node bugs
zoom desync
```

---

# 2.12 Need a host-specific chrome policy

当前 generic Huabu `Canvas.tsx` 内部直接 render：

```text
Controls
MiniMap
NodeToolbar
```

如果 LCOS overlay另外再画 Spatial Navigator，
会重复两份 controls。

不能靠 CSS：

```text
.lcos .react-flow__controls { display:none }
```

这种脆弱隐藏。

---

# 2.13 PLANNED neutral host chrome policy

扩现有 neutral host seam，而不是 LCOS hardcode。

## MODIFY

`huabu/apps/web/src/lcos-seam/types.ts`

新增：

```ts
export interface CanvasHostChromePolicy {
  readonly viewportControls?: 'native' | 'host'
  readonly minimap?: 'native' | 'host'
  readonly primaryToolbar?: 'native' | 'host'
}

CanvasHostExtension {
  ...
  readonly chromePolicy?: CanvasHostChromePolicy
}
```

default/absent：

```text
native
```

generic Huabu行为完全不变。

---

## MODIFY mirror

`apps/web-gen2/src/integration/huabu/LcosCanvasAdapter.tsx`

mirror：

```text
chromePolicy?
```

这里只做 structural adapter。

---

## HostSeam transport

两种方案中推荐更薄的一种：

### Recommended

`HostSeam` 继续只放 semantic/render seam。

在：

`huabu/apps/web/src/lcos/useLcosCanvasProps.tsx`

对 adapter结果追加：

```ts
chromePolicy: {
  viewportControls:'host',
  minimap:'host',
  primaryToolbar:'host'
}
```

理由：

Chrome policy 是 Huabu-host presentation policy，
不是 Core/WebGen2 domain semantic。

这样不污染 React-free `HostSeam`。

---

# 2.14 MODIFY Huabu Canvas

`huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx`

current：

```text
Controls
MiniMap
NodeToolbar
```

改成：

```text
if hostExtension?.chromePolicy.* !== 'host'
  render stock
```

default：

```text
native
```

因此：

- standalone Huabu；
- Playground；
- non-LCOS hosts

行为不变。

---

# 2.15 PLANNED Spatial Navigator body

`huabu/apps/web/src/lcos/ui/LcosSpatialNavigator.tsx`

由于它需要 ReactFlow context，
最合理 mount：

`LcosHostOverlay.tsx`

它可以直接调用：

```text
useReactFlow()
useStore()
```

和 render ReactFlow：

```text
MiniMap
```

---

# 2.16 Spatial Navigator internal states

```text
COLLAPSED
PEEK / HOVER
EXPANDED
DRAGGING_VIEWPORT
CAMERA_MOVING
DISABLED
```

T5最终 body可调。

---

# 2.17 Default controls inside expanded navigator

工程建议第一版：

```text
Zoom Out
Zoom Level / reset100
Zoom In
Fit
```

Lock：

```text
mechanically available
```

是否和主行同权重由 T5最终 body决定。

Grid Snap：

```text
low-frequency canvas setting
```

可以作为 secondary control，
不要求永久显示。

这里不重新开产品语义。

---

# 2.18 NodeToolbar secondary-entry downgrade

User明确要求：

> Huabu 底下那排工具压进次级入口。

Current source：

`huabu/apps/web/src/components/Panels/Canvas/CanvasToolbar.tsx`

Current capabilities：

```text
Select / Pan / Lasso
Frame
Note
Text
Sketch
Question
Upload
Link
Space Preview
Undo/Redo for non-mouse
```

同时成熟 shortcuts 已经存在：

```text
S / P / L
mode.frame
mode.note
mode.text
mode.sketch
mode.question
```

所以 T2只改**一级占位**：

```text
bottom-center NodeToolbar
→ host secondary/contextual entry
```

不删能力。

---

# 2.19 Canvas Tools secondary body ownership

最终图形/body由 T5。

工程上建议：

`huabu/apps/web/src/lcos/ui/LcosCanvasToolsLauncher.tsx`

挂在 low-priority screen-space位置，
或由 T5最终整合入某个 compact secondary menu。

它复用：

```text
useToolStore
NodeToolbar actions/shortcuts
```

不要复制创建逻辑。

如果可以通过改 `NodeToolbar` 接受：

```text
variant='compact-popover'
```

直接复用同 component，
优先于复制所有 action。

最终 exact variant在 T5回填后定。

---

# 2.20 SurfaceDock bottom-center consequence

当：

```text
chromePolicy.primaryToolbar='host'
```

Huabu原：

```text
Panel bottom-center + NodeToolbar
```

让出。

Checkpoint01：

`Lcos SurfaceDock`

占回 bottom-center。

这不删除 toolbar capability。

---

# 2.21 S08 file ledger

## CURRENT KEEP

```text
huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx
huabu/apps/web/src/components/Panels/Canvas/CanvasToolbar.tsx
huabu/apps/web/src/store/canvasStore.ts
huabu/apps/web/src/lcos-seam/types.ts
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
```

## MODIFY

```text
huabu/apps/web/src/lcos-seam/types.ts
apps/web-gen2/src/integration/huabu/LcosCanvasAdapter.tsx
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
```

## PLANNED NEW

```text
huabu/apps/web/src/lcos/ui/LcosSpatialNavigator.tsx
huabu/apps/web/src/lcos/ui/LcosCanvasToolsLauncher.tsx   # only if NodeToolbar variant cannot serve directly
```

---

# 2.22 S08 tests

## Canvas host policy

- absent policy → stock Controls/MiniMap/NodeToolbar；
- native → stock；
- host → suppress only corresponding stock chrome；
- canvas mechanics unchanged。

## Spatial Navigator

- collapsed；
- expand；
- click map；
- drag viewport；
- zoom−/＋；
- reset100；
- Fit；
- minimap preference；
- current node/viewport sync；
- safeRect positioning；
- reduced motion。

## Canvas tools

- shortcuts still work when toolbar hidden；
- secondary launcher opens；
- Frame/Note/Text/Sketch/Question still arm existing `useToolStore` path；
- no duplicated action handlers。

---

# 2.23 S08 browser acceptance

Modes：

```text
mouse
trackpad
touch
pen
```

States：

- default first launch；
- minimap collapsed；
- expanded；
- 2 nodes；
- 50 nodes；
- 500 nodes；
- zoom .2 / 1 / 3；
- drag viewport；
- Work View open；
- narrow viewport；
- Railway Receive；
- SurfaceDock visible。

Acceptance：

- bottom-center primary space belongs SurfaceDock；
- no duplicate Controls；
- no duplicate Minimap；
- no duplicate toolbar；
- keyboard shortcuts survive；
- touch can still Zoom/Fit；
- no world/camera desync。

---

# 2.24 S08 recovery

Spatial Navigator body crash/disabled：

```text
Huabu camera mechanics remain intact
```

Feature rollback：

```text
chromePolicy revert to native
→ stock Huabu controls immediately return
```

这是很重要的低 blast-radius rollback。

---

# 2.25 S08 blast radius

Chrome policy：

`BR-4 Huabu host behavior override`

但：

```text
host-only
default native
```

把实际 generic Huabu blast radius压低。

Spatial Navigator body：

`BR-1 / BR-2`

---

# 3. S09 · Professional Window Occupancy Consumer

# 3.1 PRODUCT_BEHAVIOR

Professional Window打开后：

```text
Canvas world不动
Camera不动
nodes不动
```

变化的是：

```text
用户当前真正可用的 screen-space region
```

所以：

- Search/Focus/Pin HUD重新居中；
- Locator edge重新计算；
- Minimap/Spatial Navigator避让；
- explicit Focus用最新 safeRect；
- Arrival仍落 target；
- Railway browser-left spine保持。

---

# 3.2 Phase B public seam

T4必须对外提供一套 public screen-space occupancy seam。

允许语义：

```text
occupiedRects
safeRect or safeInsets
activeRegions
```

禁止：

```text
T2 DOM query Work View
hardcoded right panel width
persist safeRect
```

---

# 3.3 CURRENT source audit result

对 current `DZWFLi/LCOS_Gen2 @ c2ff890...` 搜索：

```text
safeRect
occupiedRects
safeInsets
activeRegions
ProfessionalWindow
WorkView
```

没有找到 Phase B 所要求的公共 T4 occupancy seam。

因此 current status：

```text
PHASE_B_PRODUCT_DECISION = CLOSED
CURRENT_T4_PUBLIC_SOURCE_SEAM = NOT_YET_PRESENT
T2_CONSUMER = PLANNABLE
IMPLEMENTATION_DEPENDENCY = WAIT_FOR_T4_ENGINEERING_SEAM
```

这不是产品 OPEN。

---

# 3.4 Current Huabu layout is NOT authority

`huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx`

Current：

```text
left default 260
right default 420
left min 200
right min 264
center min 100
```

且有：

```text
data-right-panel-slot
data-right-panel-content
resize handles
```

这些只是 current Huabu panel implementation。

禁止 T2：

```ts
document.querySelector('[data-right-panel-slot]')
```

禁止：

```ts
safeRight = window.innerWidth - 420
```

---

# 3.5 Current Canvas ResizeObserver conflict

exact：

`huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx`

current effect：

```text
ResizeObserver(wrapper)
→ nextSize
→ currentViewport
→ anchorViewportCentre()
→ optional anchor reveal
→ setViewport(duration:0)
```

这是 generic Huabu “layout resize保持视觉中心”的成熟行为。

但 LCOS D15：

```text
Professional Window resize
→ NO CAMERA MOVE
```

---

# 3.6 Thin technical resolution

不删 current Huabu behavior。

扩：

`CanvasHostExtension`

一个 neutral viewport policy。

### MODIFY

`huabu/apps/web/src/lcos-seam/types.ts`

新增：

```ts
export interface CanvasHostViewportPolicy {
  readonly resizeBehavior?: 'preserve-center' | 'preserve-transform'
}
```

其中：

```text
preserve-center
= current Huabu behavior

preserve-transform
= wrapper resize 不调用 setViewport
```

default absent：

```text
preserve-center
```

---

# 3.7 Huabu Canvas exact modification

`Canvas.tsx`

ResizeObserver里：

```ts
if (hostExtension?.viewportPolicy?.resizeBehavior === 'preserve-transform') {
  previousSize = nextSize
  return
}
```

然后 stock compensation路径不变。

这个是最薄 patch。

不要：

```text
disable entire ResizeObserver
```

因为它未来还可能承载 non-camera measurements。

---

# 3.8 Mirror type

`apps/web-gen2/src/integration/huabu/LcosCanvasAdapter.tsx`

mirror：

```text
viewportPolicy?
```

与 S08 `chromePolicy` 一起保持 structural type parity。

---

# 3.9 LCOS host policy install

`huabu/apps/web/src/lcos/useLcosCanvasProps.tsx`

LCOS host返回：

```ts
{
  hostExtension,
  viewportPolicy: {
    resizeBehavior: 'preserve-transform'
  }
}
```

具体可以：

- 合并到 converted extension；
- 或由 `hostExtensionFromSeam()` optional host policy args生成。

优先不污染 semantic `HostSeam`。

---

# 3.10 T4 occupancy input contract

T2不决定 T4内部 window store。

T2只要求 T4 seam最终满足：

```ts
interface SpatialOccupancySnapshot {
  readonly viewportRect: ScreenRect
  readonly occupiedRects: readonly ScreenRect[]
  readonly safeRect: ScreenRect
  readonly activeRegions?: readonly ScreenRect[]
  readonly revision: number
}
```

这只是 T2 的**消费形状要求**，
最终 exact export name/path必须由 T4 C1 seam给出。

不能自己在 T2 仓里 duplicate provider。

---

# 3.11 T2 exact consumer file

### PLANNED NEW

`huabu/apps/web/src/lcos/useLcosSpatialOccupancy.ts`

职责：

```text
consume T4 public occupancy seam
normalize to T2 ScreenRect
expose latest snapshot
```

如果 T4最终 export已经直接兼容：

这个 hook可以只是一层 alias，
甚至不需要 store。

---

# 3.12 Pure safe-geometry layer

### PLANNED NEW

`apps/web-gen2/src/spatial/safeRegion.ts`

纯函数：

```text
normalizeSafeRect
centerWithinSafeRect
edgePointWithinSafeRect
clampOverlayToSafeRect
safeInsetsFromRects
```

不读 DOM。

---

# 3.13 Consumers of safeRect

## Navigation HUD

`LcosNavigationHud`

center：

```text
safeRect horizontal center
```

不是 browser center。

## Locator

`locatorGeometry.ts`

edge：

```text
safeRect edge
```

## Spatial Navigator

anchor：

```text
inside safeRect lower-left/lower-corner candidate
```

并避开 Railway占位。

## Camera

只有 explicit：

```text
Focus
Pin member
Locator click
Search result locate
```

调用 `cameraFraming.ts` 时传 latest safeRect。

---

# 3.14 What occupancy change does NOT do

当 Work View：

```text
open
dock
resize
move
float
undock
close
```

T2不调用：

```text
navigationCamera
```

只 recompute：

```text
HUD placement
locator projection
minimap placement
```

这是 D15核心。

---

# 3.15 Floating Work View

如果 T4 occupancy seam给：

```text
occupiedRects[]
```

而不是单纯右侧 inset，
T2必须允许：

```text
non-rectangular free regions
```

但第一版 `safeRect` 可取 T4已经裁决的最大/active usable rect。

不要 T2自己解决 rectangle packing。

T4负责把窗口真实 occupancy归一化成可消费 safeRect/active region。

---

# 3.16 Railway / occupancy

Railway browser-left persistent spine：

- 不跟 Camera动；
- 不因 right Work View隐藏；
- 如果 T4 full-screen/immersive完全接管 viewport，则按 T4 activeRegion规则隐藏/降级。

Railway自己的 width由 T2/T5，
但不作为 Work View `occupiedRect` 的 T4输入。

Screen shell最终应由统一 root layout知道：

```text
Railway shell inset
Professional Window occupancy
browser viewport
```

T2 safeRect只消费已经归一化后的 canvas active region。

---

# 3.17 Current Huabu Fullscreen Preview caveat

`MainLayout.tsx` current fullscreen Preview会 unmount Canvas。

Phase B LCOS Professional Window lifecycle不等同 current Preview fullscreen。

所以：

> 不直接复用 “unmount Canvas” 作为 LCOS Immersive语义。

T4 owns最终窗口 lifecycle。

T2只需在 T4报告：

```text
activeRegions / canvas inactive
```

时停 Locator/Minimap camera interactions。

---

# 3.18 S09 file ledger

## CURRENT CONTEXT, DO NOT USE AS AUTHORITY

```text
huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
```

## CURRENT MODIFY

```text
huabu/apps/web/src/lcos-seam/types.ts
apps/web-gen2/src/integration/huabu/LcosCanvasAdapter.tsx
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx
```

## PLANNED NEW T2

```text
apps/web-gen2/src/spatial/safeRegion.ts
huabu/apps/web/src/lcos/useLcosSpatialOccupancy.ts
```

## EXTERNAL IMPLEMENTATION DEPENDENCY

```text
T4 public occupancy export
```

exact path待 T4 C1 seam回填。

不是产品 OPEN。

---

# 3.19 S09 tests

## Huabu viewport policy

```text
default native → resize preserves center
LCOS preserve-transform → resize leaves exact viewport x/y/zoom unchanged
anchor node does not override LCOS policy
policy toggle/re-render stable
```

## safeRegion pure

```text
right dock
left dock
top/bottom occupancy
narrow
floating
zero-size
revision update
```

## T2 consumers

Work View resize：

```text
camera exact unchanged
HUD repositions
Locator edge repositions
Minimap repositions
```

---

# 3.20 S09 browser acceptance

必须 screen-record / telemetry compare：

### Dock right

```text
capture viewport before open
open Work View
capture after
assert x/y/zoom identical
```

### resize

continuous resize 10+ steps：

```text
camera x/y/zoom stable
HUD follows safeRect
```

### close

```text
camera remains same
HUD returns
```

### explicit Focus while Dock open

```text
now camera MAY change
target fitted to remaining safeRect
```

### Floating overlap

```text
no HUD hidden beneath window
Locator uses active safe boundary
```

### narrow viewport

```text
no impossible negative safe width
low-priority chrome collapses
```

---

# 3.21 Recovery

T4 occupancy provider unavailable：

第一原则：

```text
do not query DOM fallback
```

temporary safe fallback：

```text
Canvas wrapper rect
```

注意：

这表示：

> “不知道窗口 occupancy，至少不乱动 camera”。

UI可降低/隐藏 edge-sensitive Locator，
而不是硬猜。

---

# 3.22 Blast radius

Host viewport policy：

`BR-4`，但 host-only default-safe。

safeRegion pure：

`BR-1`

T4 occupancy consumer：

`BR-2 cross-window integration`

---

# 3.23 Coordinator escalation status

## Technical conflict discovered

Current Huabu auto-compensates viewport on wrapper resize。

## Why not escalate

已有薄适配：

```text
CanvasHostExtension viewportPolicy
→ LCOS preserve-transform
→ generic default unchanged
```

所以：

```text
COORDINATOR_ESCALATION = NO
```

---

# 4. Shared architecture S07–S09

```text
           Core canonical target
                    │
                    ▼
        backend/navigation.ts
                    │
                    ▼
         Navigation occurrence
                    │
                    ▼
      ProjectionBinding / current canvas
                    │
                    ▼
         Huabu reliable node bounds
                    │
            ┌───────┴────────┐
            │                │
            ▼                ▼
      locatorGeometry    cameraFraming
            │                │
            │          explicit action only
            │                ▼
            │        navigationCamera.ts
            │                │
            ▼                ▼
       Locator HUD       Huabu viewport
            │                │
            └───────┬────────┘
                    ▼
                 Arrival

T4 occupancy seam
      │
      ▼
  safeRegion.ts
      │
      ├── Navigation HUD
      ├── Locator edge
      ├── Spatial Navigator
      └── explicit camera framing
```

关键不变量：

```text
Occupancy change itself
≠ camera action
```

---

# 5. S07–S09 planned exact-file summary

## apps/web-gen2 CURRENT KEEP

```text
src/spatial/projectionBinding.ts
src/interaction/overlayArbitration.ts
src/integration/huabu/LcosCanvasAdapter.tsx
```

## apps/web-gen2 PLANNED NEW

```text
src/spatial/navigationProjection.ts
src/spatial/cameraFraming.ts
src/spatial/locatorGeometry.ts
src/spatial/safeRegion.ts
src/interaction/locatorState.ts
src/presentation/arrival.ts
```

## Huabu CURRENT KEEP/MODIFY

```text
huabu/apps/web/src/components/Panels/Canvas/Canvas.tsx
huabu/apps/web/src/components/Panels/Canvas/CanvasToolbar.tsx
huabu/apps/web/src/components/Panels/CanvasLayerPanel/focusNodesOnCanvas.ts
huabu/apps/web/src/store/canvasStore.ts
huabu/apps/web/src/lcos-seam/types.ts
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
huabu/apps/web/src/pages/CanvasPage/MainLayout.tsx
```

## Huabu PLANNED NEW

```text
huabu/apps/web/src/lcos/navigationCamera.ts
huabu/apps/web/src/lcos/useLcosLocator.ts
huabu/apps/web/src/lcos/arrivalState.ts
huabu/apps/web/src/lcos/useLcosSpatialOccupancy.ts
huabu/apps/web/src/lcos/ui/LcosLocatorOverlay.tsx
huabu/apps/web/src/lcos/ui/LcosSpatialNavigator.tsx
huabu/apps/web/src/lcos/ui/LcosCanvasToolsLauncher.tsx  # only if NodeToolbar variant cannot be reused
```

---

# 6. HostExtension planned combined policy

为了避免 S08 / S09 各自增加一个 ad-hoc prop，
neutral Huabu extension统一：

```ts
interface CanvasHostExtension {
  nodeTypes?
  overlays?
  recognizers?
  connectIntent?

  chromePolicy?: {
    viewportControls?: 'native' | 'host'
    minimap?: 'native' | 'host'
    primaryToolbar?: 'native' | 'host'
  }

  viewportPolicy?: {
    resizeBehavior?: 'preserve-center' | 'preserve-transform'
  }
}
```

default absent：

```text
100% stock Huabu
```

LCOS：

```text
chromePolicy = host
viewportPolicy.resizeBehavior = preserve-transform
```

这是整组最重要的 blast-radius containment。

---

# 7. T5 engineering input from Checkpoint 03

T5现在可以依赖：

## Locator states

```text
local
near-edge
edge
travelling
arriving
unavailable
```

并且有连续 `progress`。

## Locator geometry

edge = active safeRect edge，
不是 browser edge。

## Camera

explicit navigation only；
target actual bounds；
multi-target union；
safeRect-aware；
~500ms donor feel可参考；
reduced motion supported。

## Arrival

target body/field，
不是 toast。

## Spatial Navigator

```text
collapsed
expanded
viewport drag
zoom
reset100
fit
```

底层 ReactFlow MiniMap/Camera已成熟。

## Bottom Chrome

```text
bottom-center = SurfaceDock primary
Canvas editing tools = secondary
```

## Work View

```text
open/resize
→ camera static
→ HUD/locator/minimap reflow
```

---

# 8. DO NOT BUILD after Checkpoint 03

禁止：

```text
second camera store
second minimap mapping engine
Core-persisted Locator
Core-persisted screen position
Core worldPosition as Huabu truth
Locator popup
Arrival toast
DOM safeRect queries
hardcoded right panel width
persist safeRect
global removal of Huabu resize behavior
CSS-only hide of stock Controls
duplicate NodeToolbar actions
```

---

# 9. Checkpoint 03 acceptance gate

进入 S10–S12 前，需要以下都已写清：

- [x] canonical target owner；
- [x] local projection source；
- [x] reliable offscreen bounds source；
- [x] camera adapter owner；
- [x] locator pure geometry；
- [x] arrival placement；
- [x] current Huabu Minimap owner；
- [x] current controls owner；
- [x] current bottom toolbar owner；
- [x] host-only chrome override；
- [x] current resize-camera conflict；
- [x] host-only resize policy；
- [x] T4 occupancy source gap明确，不用 DOM fallback；
- [x] tests/browser/recovery/blast-radius。

所以：

```text
S07 = READY
S08 = READY
S09 = READY_WITH_T4_IMPLEMENTATION_DEPENDENCY
```

---

# 10. Next checkpoint

下一小步：

```text
T2-S10 Railway Receive Map / Remote Destination
T2-S11 Receiver in Railway
T2-S12 Navigation More / low-frequency management
```

这三张完成后，
T2 C1 的 12 个 seam全部覆盖。

然后必须再做：

```text
C1 Consolidated Exact-File Plan
+
T5 Engineering Input Pack
+
Coordinator Handoff / dependency ledger
```

不会直接从 Checkpoint03跳 production coding。
