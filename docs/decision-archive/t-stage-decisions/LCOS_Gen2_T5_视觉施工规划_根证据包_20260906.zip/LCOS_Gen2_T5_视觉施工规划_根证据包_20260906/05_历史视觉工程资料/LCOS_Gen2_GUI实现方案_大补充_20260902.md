# LCOS Gen2 · GUI 实现方案（GPT 方案的大补充）

> 日期：2026-09-02（晚会话）｜ 位置：`Desktop\Gen2开发\`
> 性质：**对 GPT《全功能Huabu源码级融合与重构阶段计划》的深度补充**。GPT 方案解决了「Owner 架构/H0-H6 阶段/谁归谁」，但**缺交互级细节**（投影怎么做、三视图怎么在 Huabu 成立、scope/collection 怎么呈现、对象怎么去卡壳、视觉基线在哪）。本方案补齐这些，**每一处都标注 LCOS Gen1 + Huabu 源码位置**。
> 前置阅读：`LCOS_Gen2_全功能Huabu源码级融合与重构阶段计划_20260902.md`（GPT 原方案）、`LCOS_Gen2_GUI轮子复用_信息搜集档案_20260902.md`（本轮的逐轴/逐环节证据库）。

***

## 0. 导言：这一轮补齐了什么

这一轮做了「从 LCOS 前端源码 → Huabu 源码 → 参考项目」的**三方源码级对照**，把 GPT 方案里最模糊的两块补实了：

1. **投影层（LCOS 精髓）**：确认三视图/Context lens/Workflow/Scope/Collection = **同一个 Project universe 的不同投影**，并确认它在 LCOS 前端如何实现（`resolve*View`/`ProjectionSurfaces`/`PresentationEntityRefV0`），从而得出「在 Huabu 上加投影层、而不是拆成多个 canvas 文件」。
2. **交互承接（而非轮子替代）**：确认 Huabu 自带三类交互底座（frame 嵌套/折叠/分组/布局、工具栏随语境变、Work View dock），LCOS 概念**映射上去 + 改外观形状**。

**核心判断（贯穿本方案）**：GCOS 精髓 = 投影；Gen2 = 用 Huabu 交互承载 + 复刻投影 + 只改外观形状（去卡壳/物种 morph/自带 Glyth）。

***

## 1. 三条方法论主线

### 1.1 投影继承（最重要的精髓）

- **LCOS：一个 Project universe（nodes+edges）是真值；所有视图只是投影强调。**

- **Gen2：Huabu 承载空间视图（画布物理/frame/工具栏/Work View/drop 全复用），在其上加 LCOS 的投影层。**

- **禁止**：把三视图/子画布拆成多个独立 canvas 文件（会撕碎 `.lcosproj`，丢投影精髓）。

### 1.2 交互承接（而非轮子替代）

- **凡是 Huabu 已有交互 → LCOS 概念直接映射上去 + 改外观形状。**

- 只有 Huabu 完全没有的（Glyph、大纲/mind-map 编辑、关系场/时间线这类 instrument）才补专门组件（arborist/mind-elixir/cytoscape/vis-timeline，且都只是 dock 内 instrument，不接管画布）。

### 1.3 轮子优先 · 标准可改

- 标准分三层：A 视觉表皮（全让轮子）、B 交互机械（全让 Huabu）、C LCOS 身份内核（唯一不让）。

- 视觉基线用**我们自己的**（`ios26` token + FigmaMake 视觉语言 + grok-bot agent 界面），不引 shadcn 当主调、React Bits 只取克制件。

***

## 2. 投影层实现（LCOS 精髓 · 源码级）

### 2.1 LCOS 投影链路（全部实拉）

| 文件（LCOS @3e99769）                                           | 源码证据                                                                                                                                                                                                                                                                                                | 作用                                                                                                                              |
| ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------- |
| `apps/web/src/features/surfaces/ProjectionSurfaces.tsx`     | 「All capability surfaces project the **same Project node identities**. Context Graph has its own exact project-level membership; concrete Context detail and Workflow have independent exact memberships **over that same universe**.」 + `common={nodes,edges,selectedIds,onSelect}` 对所有 surface 共享 | **三视图/Context lens/Workflow 共享同一 universe + 同一 selection**；`props.surface` 分发到 outline/context-space/flow/tree/graph/workflow 等 |
| `apps/web/src/features/surfaces/capabilityViewResolver.ts`  | `resolveContextView(nodes,edges,intent)` / `resolveWorkflowView(nodes,edges,intent)` 纯投影函数；注释「Presentation helper only; it **never decides Core membership or Project Truth**.」「Workflow **never invents membership from node kind**. The honest state is empty.」                                   | 从同一 universe 投影子集 + 不同强调（explicit/selection/workspace/history 五种 sourceKind）                                                    |
| `apps/web/src/features/entities/projectEntityProjection.ts` | `PresentationEntityRefV0`（view/scope/workspace/conversation）+ `projectEntityNodeIds` + `materializeProjectEntityNodes`                                                                                                                                                                              | entity ref → canvas 节点；**真值一份（这些 ref），投影成不同节点**（scope/workspace/conversation 各有映射）                                              |
| `apps/web/src/features/context/contextGraphPopulation.ts`   | `deriveContextGraphAutoNodeIds`（按实体身份 context/collection/decision + 标题线索）+ 注释「Physical Scope must **never gate eligibility**」                                                                                                                                                                       | 投影跟 Scope 无关，只看实体身份                                                                                                             |
| `apps/web/src/features/surfaces/surfaceContracts.ts`        | `SurfaceAttentionMarks`（pinned/related/retrieved）注释「read-only Presentation projection」「Selection stays in the existing spatial session」                                                                                                                                                             | Attention 是只读投影痕迹，不改 selection                                                                                                  |
| `apps/web/src/features/surfaces/surfaceModel.ts`            | `nodeRole(node)`（artifact/feedback/session/run/skill/decision/context/note）+ `statusLabel`（Draft/Current/History/Running/Waiting/Review/Failed）                                                                                                                                                     | 同一节点投影成不同 role / 状态强调                                                                                                           |

### 2.2 三视图 = 投影（`SurfaceDock.tsx` 铁证）

`apps/web/src/features/shell/SurfaceDock.tsx`：

- `SurfaceId` = `arrange/outline/context-space/context-flow/context-tree/context-graph/workflow/...` —— **一组投影面，不是一组画布**。

- `SURFACE_ENTRIES = {main 主画布 / context 上下文 / workflow 工作流}`；`setCapability` 切到 main→`onSurface('arrange')` / context→`onSurface('context-space')` / workflow→`onSurface('workflow')`。

- `capabilityForSurface(surface)` 把 normalize 后的 surface 归到 main/context/workflow 三档 —— **一个 capability 下可有多面**（Context 下有 outline/space/flow/tree/graph 多个 lens）。

- **Scope/现场 = 导航层次**：scope 面包屑（`返回 parent`/`当前现场`/`并回主画布`）—— Scope 是层次，非独立画布。

- `normalizeSurfaceId`：legacy work/deliver 归一到 `workflow`。

### 2.3 结论：Gen2 的投影层

> **一个 Project universe（真值在 Core）= 唯一。三视图/Context lens/Workflow/Scope/Collection/Attention/role 全都是「同一 universe 的投影强调」。** Gen2 用 Huabu 承载空间视图，由 Gen2Host/接缝提供 `resolve*View` 投影。

***

## 3. 对象 = 完全隐形壳，只露选中边框（去节点化）

### 3.1 LCOS 已有物种形态（不是没有，被卡壳盖住）

`apps/web/src/features/canvas/CanvasNodeVisual.tsx`（实读）：

- `nodeVisualFamily(node)` → reference/document/note/context/process/decision/result-slot。

- `ContentObject` 分物种：`ImageObject`（裸图无壳 `/lcos-image-object`）、`DocumentObject`、`MaterialPaperFallback`（**纸面即身份**：白底+1px hairline+极浅折角、注释「不造大卡」）、`SlideDeckFallback`（16:9 页叠）、`ArchiveBundleFallback`（包叠）、`GenericFileFallback`（文件剪影+扩展名、注释「no generic SaaS card shell」）。

`apps/web/src/features/presentation/visualFamily.ts`：`visualFamilyFor(input)` 纯函数，机械按 `artifactKind/mime/fileType/skill.md路径/sourceRun/observedPath` 判定 text/document/image/url/conversation/skill/run/output。

`apps/web/src/features/canvas/nodeCardRegistry.tsx`：`key → renderer` 注册表（`entity:<kind>`/`file:<type>`），`resolveNodeCard` 查表。

### 3.2 元凶：`lcos-material-face` 卡壳

对象 body 根 class = `lcos-object lcos-material-face lcos-node-dot-identity`。**`lcos-material-face`（材质卡面）+** **`lcos-object-caption`（常驻标题条）就是让它看起来像「卡」的原因**。物种本体是对的，被这层通用壳外包成卡。

### 3.3 实现规则（把已有的「去卡壳化」）

```css
/* 对象壳：默认完全透明 */
.lcos-object { background:transparent; border:none; box-shadow:none; }
/* 只有选中才显边框（克制，不发光、不套多色） */
.lcos-object.is-selected {
  outline:1.5px solid color-mix(in srgb, var(--lcos-ui-accent) 55%, transparent);
  outline-offset:2px;
}
```

- 标题行 `lcos-object-caption` → **近 zoom/hover 才渐进披露**（呼应 FigmaMake `03_VISUAL_LANGUAGE` 的「dynamic scale：远 zoom 保剪影，近 zoom 渐进披露 label」）。

- 对象本体保持物种原样（Image 裸图 / Paper 纸面 / SlideDeck 页叠 / Archive 包叠 / GenericFile 剪影）。

### 3.4 对应 Huabu

- Huabu `apps/web/src/components/Nodes/NodeWrapper.tsx`：**3px 透明 border（`NODE_SHELL_INSET`）外壳**，非选中不显色——这正是「隐形壳」机制。

- Huabu `apps/web/src/components/Nodes/shared/TextNodeBody.tsx`：`resolveTextBodyBox`（`width - NODE_SHELL_INSET`）让 border 算进 padding。**Gen1 少了这层，Huabu 天生就是透明壳。**

- 选中框：直接吃 Huabu node 的 `selected` rim（`NodeWrapper`），不另造。

***

## 4. 子画布 / Scope / 三视图在 Huabu 的成立方式

### 4.1 已核实 Huabu 多画布/容器机制（但用于**投影呈现**，非独立 canvas 文件）

| Huabu 位置                                                                                                                                                            | 源码                                                                                                                                                                          | 作用                                        | <br />                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------- | :------------------------ |
| `packages/shared/src/canvas-engine/frame/index.ts`（+geometry/detection/mutation/sizing/fit）                                                                         | `frameNodes/autoFrameNodeByOverlap/unframe/findBestFrameForNode/findFrameAtPoint`、`'hug'/'manual'` sizing、free/column/row/grid、`fitFrameToChildren`                         | frame 容器/自动成组/布局                          | <br />                    |
| `apps/web/src/components/Nodes/frame/FrameNode.tsx`                                                                                                                 | `parentId` 嵌套、`layoutMode`(free/column/row/grid)、`hug/manual`、内嵌重命名、工具条（Move/Columns/Rows/Grid/Ungroup）、`data.gridCount/gridRowCount`                                       | frame 节点形态                                | <br />                    |
| `apps/web/src/store/canvasStore.ts`                                                                                                                                 | `collapsedFrameIds` + `setAllFramesCollapsed`（折叠/展开所有 frame）、`switchCanvas(canvasId)`、`loadCanvas(canvasId)`、`viewportStorageKey(canvasId)`、`canvasHistoryManager.activate` | 折叠 frame；画布切换（但 **不拆成独立 canvas 文件**）      | <br />                    |
| `apps/web/src/hooks/useFrameDragToCreate.ts`                                                                                                                        | frame 工具拖拽创建                                                                                                                                                                | frame 创建交互                                | <br />                    |
| `apps/web/src/components/Panels/Canvas/FloatingToolbars/NodeFloatingToolbar.tsx` / `MultiSelectToolbar.tsx` / `EdgeStyleToolbar.tsx` / `StrokeSelectionToolbar.tsx` | 四种语境工具栏，全 i18n                                                                                                                                                              | **工具栏随语境变**——切成 Context/Workflow 后可注入仪器按钮 | <br />                    |
| `apps/web/src/store/previewWorkspace/actions.ts`                                                                                                                    | `openPreviewNode(nodeId,{transient:true})`、`openPreviewTarget`；\`PreviewTarget={kind:'node'                                                                                 | 'chat', canvasId}\`                       | 打开 Preview / Work View 目标 |
| `apps/web/src/components/Panels/Canvas/Canvas.tsx` L1547                                                                                                            | `onNodeDoubleClick` 门控 `EXPANDABLE_TYPES={image,video,web,pdf,office,note}`（**不含 frame**）                                                                                   | 双击缝隙——可接管 scope 进入交互                      | <br />                    |

### 4.2 三视图 / 子画布 / Scope 的投影呈现（不拆 canvas 文件）

> **一个 Project = 一个宿主画布（canvasId 一份）。三视图/Scope/子画布是其上「同一 universe 的投影 + frame 物理呈现」。scope/子画布的**身份与层次在 Core\*\*（Binding / scopeId / collection membership），Huabu frame 只做物理呈现，绝不新增独立 canvas 持久化。\*\*

- **三视图**：顶栏 Surface tab（main/context/workflow）→ 切换投影强调（复用 Huabu toolbar 随语境变注入仪器按钮）+ `resolve*View`。**画布 canvasId 不变**。

- **Scope/子画布**：用 Huabu `frame`（`collapsedFrameIds` 折叠/展开）+ `FrameNode`。**进入子画布** = 借 `onNodeDoubleClick` 缝隙（frame 不在 `EXPANDABLE_TYPES`，正好接管）→ 映射到「进入 scope」。scope 身份 = Core `scopeId`（经 `ProjectionBinding`），frame 只是空间投影。

- **Collection**：frame（hug）+ grid 布局兜住成员；形状=Collection micro（Glyth），近 zoom 才显边框。

- **Clonny/Colony 聚簇**：`autoFrameNodeByOverlap` 拖近自动成组；聚簇氛围（subtle field）。

- **Scope 布局**：迁移 LCOS `apps/web/src/features/canvas/scopeLayout.ts`（`proposeScopeLayout`/`proposeIslandRecoveryLayout`/`applyScopeLayout`，纯函数，锁 respectLocked）。

- **Collection 展开**：迁移 LCOS `apps/web/src/features/canvas/collectionExpandLayout.ts`（`layoutExpandedCollectionMembers`，fan-out 网格、绕开障碍物）。

### 4.3 关键：绝不拆成多个 canvas 文件

LCOS 项目导入导出 = `.lcosproj`（一个 Project 自包含文件，schema v18）。见 LCOS\_GEN2 `apps/local-core/src/lcosproj-service.ts`（`exportProjectTruth`/`relativePaths`/`inspect/open`）+ LCOS R1B patch「打开工程文件（.lcosproj）/onImportLcosproj/application/vnd.local-creative-os.project」。**一个 Project = 一个** **`.lcosproj`**。三视图/子画布若拆成独立 canvas 文件，`.lcosproj` 完整性即破碎。

***

## 5. 各仪器接 Huabu（projection 强调 + dock 内 instrument）

| 仪器                   | LCOS 实现（迁移）                                                                                         | Gen2 挂载                                                                           |
| -------------------- | --------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------- |
| Context Structure    | `features/context/` + `ContextTreeSurface`(13KB)                                                    | Huabu Work View dock + `react-arborist`                                           |
| Context Evolution    | `ContextHistoryRail`(2.8KB)/`ContextSurfaceRuntime.history`                                         | Huabu Work View dock + `vis-timeline`                                             |
| Context Relationship | `ContextRelationshipHomeSurface`(21KB)/`ContextFlowSurface`(28KB) + `deriveContextGraphAutoNodeIds` | Huabu Work View dock + `Cytoscape`                                                |
| Context Source       | `contextMerge.ts`/`threadModel`/`handoffProjection`                                                 | dock + `react-arborist`/diff                                                      |
| Workflow Action Path | `WorkflowSurface`(63KB)/`WorkflowGraphSurface`(14KB) + `resolveWorkflowView`                        | **同一 canvas 的投影强调**（Action Path 是强调，不是独立画布）+ `@xyflow/react` pattern              |
| Assembly             | `features/assembly/AssemblyCaptureWorkspace`                                                        | Huabu Work View dock + `react-resizable-panels`(target 一侧/warehouse 一侧) + 原生 drop |
| Skill Builder        | `features/presentation/mindMapLayout` + Skill package                                               | Work View dock + `react-arborist`(大纲) + `mind-elixir`(导图)                         |
| Harness Run          | `features/shell/appShell.ts` `runtimePresentationStatus`                                            | Work View dock + `tabs`+`react-virtuoso`（与 Skill 分离）                              |

### 5.1 参考项目（Assembly/Skill 的形态与交互）

- **Apple/macOS**（`LCOS0.15收口\苹果mac设计套件_ios26-design-system_源码合并版.md`，141 文件，MIT）：`packages/tokens/src/{colors,materials,spacing,typography,animations}.json`（Liquid Glass 材质在 `materials.json`）、36 组件规格、48 页模板、四模式契约（Light/Dark/IC/ICD）+ WCAG 对比度 + 禁纯黑白(`#0B0B0F`/`#F2F2F7`)。**这是「Apple 感」的权威来源，不是 shadcn。**

- **SwiftUI-For-Web**（`LCOS0.15收口\SwiftUI-For-Web_JS源码合并版.md`，146 文件，MIT）：组合式布局 + 修饰链 + Web Animations API。

- **grok-bot**（`LCOS0.15收口\grok-bot_前端源码合并版.md`，185 文件）：`SandButton`/`sand-kit-primitives`/`CommandPalette`/`Agent*` 系列；**Donor 裁决**（草案 §8）：Agent row actions → Glyth Action Arc/Right-click；connection state → Glyth morphology/motion；permission → Composer/Run 瞬态权限 UI；async state → Work View/Run/Search/Warehouse 公共状态。**不可复制** sidebar/chat-first 结构（踩 No-Go #11）。

- **FigmaMake 视觉基准**（`GEN2\LCOS_Gen2_FigmaMake_Pack_20260901\guidelines\`）：`03_VISUAL_LANGUAGE`（Bright/quiet/spatial/precise、Liquid Glass 只用于 chrome、porcelain 白、低饱和、发丝线、更多对象剪影少卡片）、`05_MOTION_MATERIAL`（运动解释连续性非装饰、时长词汇 100ms/180-220/260-360/320-450、材料栈、reduced-motion）、`06_NO_GO_SUPERSEDED`（禁 ReactFlow 审美 #12、禁通用卡片 #4、禁常驻按钮排 #5、禁大侧边栏 #11）。

- **Bloub + Motion donor**（`LCOS0.15收口\倒数返工\LCOS_GLYTH_INTERACTION_MOTION_DONOR_CENSUS_20260901.md` + `P3_INTERACTION_MOTION`）：Glyth presence/blink/gaze/state 算法；`motion`（framer-motion）MIT 可复用。

***

## 6. 视觉基线（用我们自己的，不引 shadcn 当主调）

| 项     | 来源                                 | 说明                                                        |
| ----- | ---------------------------------- | --------------------------------------------------------- |
| 材质/配色 | `ios26` + LCOS token               | 瓷白/quiet/hairline；Liquid Glass 只用于 chrome/浮动控件；四模式契约      |
| 图标    | **lucide-react**（Huabu 已在依赖，SF 风格） | 极简单色 monochrome；LCOS `iconShapes.ts`(4KB) 退休              |
| 字体    | 系统栈（SF/Segoe/Inter）                | Huabu 顶层 font                                             |
| 浮层材质  | Huabu `FLOATING_CHROME_PROPS`      | 统一 Popover/tooltip 材质，popover glass rgba(255,255,255,.72) |
| Glyph | **自绘 SVG**（Bloub+另一项目形态）           | 深石墨近黑身体 + 两眼 + 状态 accent；Near/Mid/Far                     |

**明确排除**：shadcn（第二套设计语言 + 踩 No-Go #11/#12）、React Bits 主调（Commons Clause + 营销动画踩 No-Go #4/#12）——React Bits 仅取克制组件（BlurText/Dock 类）作点缀。

***

## 7. 交互承接底座（Huabu 现成，最大化复用）

- **画布物理**：React Flow（pan/zoom/select/drag/resize/hit-test）+ Huabu `canvas-engine`（change.ts 507 / delta.ts 126 / diff.ts 175 行）+ `snapSession`/`MultiSelectResizer`。

- **frame 容器**：`frame/index` 全套（嵌套/成组/布局/折叠）。

- **工具栏随语境变**：`NodeFloatingToolbar`/`MultiSelectToolbar`/`EdgeStyleToolbar`/`StrokeSelectionToolbar`。

- **Work View**：`PreviewWorkspace`（dock/tab/双 group/transient+pin/fullscreen）+ `PreviewTarget`。

- **drop**：Huabu `Canvas.tsx` L1345-1492 四类原生 drop（桌面文件/内部 DnD/URL/纯文本）。LCOS 语义投送（五阶段 `features/drop/`）作插件迁。

- **LOD/自适应**：`useTextAutoSize`（宽锁/字号二分锁/高度内容驱动）+ `useTextNodeSurface` + `semanticZoom`（150px/滞回/√(w·h)）+ `useNodeLOD` + `useNodeTakeover`。

***

## 8. 需要引入的轮子（许可证确认）

| 轮子                       | 用途                  | 许可证                      | 备注                              |
| ------------------------ | ------------------- | ------------------------ | ------------------------------- |
| `cmdk`                   | 搜索/命令菜单             | MIT                      | React19 需 v1.0.4+               |
| `react-arborist`         | 大纲/树（Context/Skill） | MIT                      | <br />                          |
| `mind-elixir-core`       | 可编辑思维导图             | MIT                      | Skill Builder                   |
| `markmap`                | 只读导图投影              | MIT                      | 可选                              |
| `cytoscape.js`           | 关系场                 | MIT                      | Context Relationship            |
| `vis-timeline`           | Context Evolution   | MIT OR Apache-2.0        | <br />                          |
| `react-resizable-panels` | Assembly 分栏         | MIT                      | 宪法 §9.5「仅当 PreviewWorkspace 不够」 |
| `motion`(framer-motion)  | Arc/Glance 动效       | MIT                      | Glyth presence                  |
| `React Bits`             | 克制点缀                | MIT+Commons Clause（禁售源码） | 仅取克制件，避开大动效/分发风险                |

**已在 Huabu 依赖**：`@xyflow/react`、`lucide-react`、`@floating-ui/react`、`@dnd-kit/*`、`@milkdown/*`、`zustand`、`clsx`、`tailwind-merge`、`react-virtuoso`、`tailwindcss@4`。

***

## 9. 落点目录（不动 Huabu 原文件，收进 `lcos/`）

```text
Huabu/apps/web/src/lcos/
  host/            # LcosHostProvider、composition、lifecycle
  projection/      # resolve*View（从 universe 投影强调）、spatialId↔entity 反向索引
  canvas/          # presentation policy（LOD/resize/隐形壳）、Action Arc slot、connect bridge、Semantic Drop 插件
  work-view/       # entity target + renderer registry（shadcn tabs + virtuoso 壳）
  surfaces/        # surfaceProfile（main/context/workflow）+ 仪器注入
  instruments/     # Context(arborist/vis-timeline/cytoscape)/Workflow/Skill(mind-elixir)/Run(tabs+virtuoso)
  glyph/           # 唯一自绘：Glyth SVG + motion presence
  ui/              # 复用的 Huabu Common + 补缺轮子
```

**需薄改的 Huabu 文件**（宪法 §9 六处 + 本轮补充）：

- `Canvas.tsx`：`onNodeDoubleClick`（frame 进入 scope）、LCOS overlay slot、connect bridge、viewport policy。

- `NodeWrapper.tsx`：Action Arc replacement + decoration resolver。

- `previewWorkspace/model.ts`：`PreviewTarget` 扩展 `{kind:'entity',projectId,entityType,entityId,view?}`。

- `PreviewRenderer.tsx`：LCOS renderer registry。

- `MainLayout.tsx`：occupied rect 输出、viewport policy。

- `CanvasPage.tsx`/`CenterArea.tsx`：LcosHostContext 注入。

- `index.css`：`--lcos-ui-*` token 并入、隐形壳/选中 rim。

***

## 10. 轴对照汇总（A-H，本轮的逐轴结论）

| 轴                             | Gen1 件                                                                                    | 轮子替代                                                  | 保留（身份）                                                |
| ----------------------------- | ----------------------------------------------------------------------------------------- | ----------------------------------------------------- | ----------------------------------------------------- |
| A 画布物理                        | spatialCamera/hitTest/交互机(\~50行)                                                          | ✅ Huabu ReactFlow                                     | `spatialOverviewProjection`(节流)                       |
| B 文本自适应                       | InlineNoteEditor(20KB)                                                                    | ✅ Huabu useTextAutoSize                               | 语义参考（就地编辑）                                            |
| C LOD                         | spatialLodForCount(按对象数)                                                                  | ✅ Huabu useNodeLOD                                    | `documentSemanticZoom`(markdown 三级)                   |
| D 物种形态                        | visualFamilyFor + \*Fallback 系列                                                           | ⚠️ 用 Huabu nodeTypes 当壳                               | **visualFamilyFor + 物种 Fallback 形态（去卡壳）**             |
| E 选择/Arc/Composer             | ObjectOrbit/SelectionComposer                                                             | ✅ Huabu FloatingToolbar/DropdownMenu/Popover + lucide | **Arc 3/4 契约 / Selection≠Reference / Composer 语义**    |
| F Glyph                       | ConversationGlyth                                                                         | ⚠️ 无现成（Bloub+另一项目）                                    | **自绘 SVG + motion presence**                          |
| G 左侧 rail                     | WorkspaceRailVNext(37KB)                                                                  | ⚠️ 语义不可换；壳 Huabu Common+lucide+dnd-kit                | **四 Surface peer / 成员预览 / 跨 Surface drop / Receiver** |
| H 投影/三视图/Scope/Collection/子画布 | ProjectionSurfaces/capabilityViewResolver/surfaceModel/scopeLayout/collectionExpandLayout | Huabu frame + 画布物理承载；**投影层在 Gen2Host**                | **投影精髓：一 universe 多面投影；Scope 身份在 Core**               |
| H2 Work View                  | workbench/workrail/ImmersiveViewer 多套壳                                                    | ✅ Huabu PreviewWorkspace                              | **entity target / 生命周期 / 相机冻结**                       |

***

## 11. 实现顺序（建议，接 H0）

1. **H0a 投影层**：Gen2Host 加 `resolve*View`（从 universe 投影强调）+ `spatialId↔entity` 反向索引（**迁移 LCOS** **`projectionBinding.ts`** **的** **`findNode`，补** **`findBySpatialId`**）。
2. **H0b 对象隐形壳**：迁移 `visualFamilyFor` + `*Fallback`，去掉 `material-face` 卡壳，接入 Huabu 透明 shell + 选中 rim。
3. **H1 Surface tab + 投影切换**：顶栏 main/context/workflow 切换 → 换投影强调 + 注入仪器按钮（复用 Huabu toolbar 随语境变）+ 接 `react-arborist`(Context outline)。
4. **H2 Scope/子画布借 frame**：frame 呈现场景 + 双击进入子画布（借 `onNodeDoubleClick` 缝隙）+ `scopeLayout`/`collectionExpandLayout` 迁移 + frame↔Binding(scopeId)。
5. **H3 Work View entity target + Assembly 分栏**：`PreviewWorkspace` 扩 entity target，Assembly 用 panels 分栏 + 原生 drop。
6. **H4 Context/Workflow 仪器**：arborist/vis-timeline/cytoscape 挂 dock；Workflow Action Path 作投影强调。
7. **H5 Skill Builder(arborist+mind-elixir) + Harness Run(tabs+virtuoso)**。
8. **H6 Glyth 自绘 + 视觉收口**（ios26 token/Liquid Glass/reduced-motion）。

***

## 12. 待验证（下步）

1. frame 双击进入 scope：需在 `onNodeDoubleClick` 里给「scope/frame 节点」建 `openScope`，而非限于 `EXPANDABLE_TYPES`。
2. **一 Project ↔ 一宿主 canvas** 下，三视图投影切换是否会丢失「某 surface 的独立 focus/选择」——决定 `resolve*View` 的 intent 状态放哪（Core vs Host）。
3. `react-resizable-panels` 是否必要（Assembly 分栏），还是 Huabu Work View + frame 分栏就够。
4. frame↔Binding(scopeId) 映射的具体路由（Core 侧 scope 实体 + space 投影）。

***

*关联：GPT 主计划、GUI 轮子复用信息搜集档案（§8/§9/§10/§11/§12/§13）、节点宪法、Gen1 差异分析、FigmaMake 视觉基准、ios26/SwiftUI/grok-bot 参考档案。*

---

# 附录 · 交流原文（本方案的决策脉络，含用户启发与纠正）

> 这一大轮不是「直接得出方案」，而是**用户逐步启发 + 我逐步纠偏**的过程。以下是关键对话原文（保留原话，未删改决策核心），按主题分段。**这些原话是「为什么这么定」的依据，比结论本身更重要。**

---

## A. 起点：用轮子搭 LCOS GUI（不自己设计）

**用户**：「评估一下怎么样让gui的设计呈现，尽可能复用huabu和现成的预设组件库，我们lcos自己的那一套怎么样用现有的轮子搭出来，不要再自己设计了，审美还有工程经验不够」

> 触发点：**审美/工程经验不足 → 借市场验证过的轮子，别自研。** 这是本轮的起点。

---

## B. 我第一次偏了（以为是从零找外部库）

**我（早前）**：「用 shadcn/ui 补 primitives」→ 后来发现方向错。

**用户**：「你自己好好看看之前的上下文还有早期的我们自己的library，还有那些我们在视觉上引入的参考项目和那么多源码，apple gork bot那些」

> **纠正一**：我们早就研究过 Apple/macOS、grok-bot、FigmaMake 视觉基准——**这才是我们自己的审美基准**，不是从零找外部库。

---

## C. 用户定调「轮子优先 · 标准可改」

**用户**：「现在就是两边，一边是轮子，一边是标准，我的意思是你好好研究怎么样最大化的利用轮子，标准是可以改动的」

> 关键：**轮子优先，标准（我们自己的 ios26/FigmaMake 视觉细节）可以让步。** 审美的责任交给成熟轮子，我们只保留「LCOS 身份」这一层不可让步的内核。

---

## D. 用户确认「去节点化 = 完全隐形壳，只露选中边框」

**用户**：「只接受完全隐形的卡片，只显露选中时的边框，你可以再好好掰开我们lcos  github源码看一下当前涉及到的部分是怎么实现的，实际上只是没有实现好，而不是没有」

> **纠正二（重要）**：这**不是没有，是没实现好**。Gen1 其实已有物种形态 + Apple token，只是被 `material-face` 卡壳盖住。我挖源码证实：`CanvasNodeVisual.tsx` 已分物种（Image 裸图/Paper 纸面/SlideDeck/Archive/GenericFile），`ui-primitives.css` 有 `--lcos-ui-*` token。缺的只是「把透明壳恰好在选中时显 outline」。

---

## E. 用户启发「嵌套画布伪装 scope、工具栏随切换变」

**用户**：「怎么样用现有huabu的轮子，在保留huabu本身能力的情况下来承接lcos我们这一堆自己搓的东西，并且提升它们，比如子画布实际上可以用嵌套画布来做，只不过嵌套画布还有和我们lcos新画布scope一样的gui视觉体验，还能继承嵌套画布方便缩放的点，collction，三视图都是一样的意思，现在画布自己不是也有工具栏啥的吗，是不是就可以直接借用这个切换之后这个工具栏啥的进行变化，然后利用嵌套伪装scope完成三视图的效果，我只是单纯以很愚蠢的文科生视角来想的，只是为了启发你，包括前面搜出来这么多gpt没考虑进去的，你自己被纠正的，还有轴对照的几类，都要这样去想，然后最大化利用目前huabu提供的交互，我们改一下外观形状这样，懂吗，还有装配台的交互，自定义编辑这些，你都要从library里翻出原md来，看清楚之后再想」

> **纠正三（方法论核心）**：不是「找轮子替代 LCOS 概念」，而是「**看 Huabu 提供什么交互，把 LCOS 概念用 Huabu 机制承接 + 改外观形状**」。子画布可用嵌套画布、三视图可用「画布内工具栏随切换变」、装配台/自定义编辑要从 library 翻原 md 看清楚。**这是本方案 §1.2「交互承接」的出处。**

---

## F. 我第一次误判三视图（A1 = 画布内隔离）

**我（早前）**：判 A1「同画布隔离节点」→ 被用户纠正。

**用户**：「继续验证」→ 我验证了 Huabu `switchCanvas` 是多画布机制。

---

## G. 我误判 A2（三个独立 canvasId）→ 被用户第一层纠正

**我（早前）**：「A2 更隔离，三视图=三个独立 canvasId」
**用户**：「更隔离，重点是我们把lcos的体验复刻完全没有，你的a1像是一个画布上把节点隔离开来进行摄像机移动」

> 用户选 A2（更隔离），但点出：A1 只是「一个画布上把节点隔离 + 摄像机移动」，**没复刻 LCOS 的工作现场**。

---

## H. 我误判 A2 = 独立 canvas 文件 → 被用户第二层纠正（层级）

**我（早前）**：「A2 = 三个独立 canvasId 文件」
**用户**：「你要理清楚层级哦，还有我们lcos目前的项目导入导出机制，别给我和huabu一样是一张张canva来作为一个的，因为目前huabu就是只新建立/打开一个canva，你要是拆开来完全就不是lcos的样子」

> **纠正四（层级，最关键）**：我一个项目（.lcosproj）= 一个自包含真值单位；**三视图/子画布绝不能拆成多个独立 canvas 文件**。我挖源码证实 `.lcosproj`（`exportProjectTruth`/schema v18）—— 一个 Project = 一个 `.lcosproj`。

---

## I. 用户定死「投影画布」= 精髓

**用户**：「投影画布（更像 LCOS）：三视图是同一项目实体的三种展示——同一批实体，Main 看重内容形态、Context 看关系/版本、Workflow 看行动路径。实体改一处，三处同步；只是各视图强调/仪器不同。，肯定是投影啊，这是lcos的精髓，要不然花大力气做的gen1有什么用，麻烦你再全局核实一下lcos的实现情况」

> **纠正五（最终定论）**：三视图 = **同一项目实体的三种投影展示**，且这是 **LCOS 的精髓**（Gen1 花大力气做的就是这个）。要我全局核实 LCOS 实现——我挖出 `ProjectionSurfaces.tsx`「same Project node identities」、`capabilityViewResolver.ts`「never decides Core truth」、`PresentationEntityRefV0`，确认 **一个 universe 多面投影**。

---

## J. 用户要求发散到其它前端实现

**用户**：「你再深入的看一下其它前端的lcos实现方式，对应到huabu，一样是源码级对照，就从投影还有三视图开始发散」

> 我发散核实：`deriveContextGraphAutoNodeIds`（Context Graph 自动推断）、`SurfaceAttentionMarks`（Attention 只读投影）、`nodeRole/statusLabel`（同一节点 → 不同 role/状态强调）、`SurfaceDock.tsx`（`SURFACE_ENTRIES={main/context/workflow}`，切换只 `onSurface` 换投影面、不切画布）。

---

## K. 用户要求成文（含源码位置、要足够细）

**用户**：「你回顾一下这一大轮的情况，总结一个详细的guigen2实现，md要足够足够细致，把对应源码位置全部都要写入，这个作为前面gpt的方案的大补充」
**用户**：「不够细啊，把我们的交流原文一并放进去」

> 本方案 = 把这一大轮的**全部核实结论 + 源码定位**成文（§1-§12），并附**交流原文**（本附录）作为决策脉络。

---

## L. 全程脉络一句话总结（用户视角）

> **起点**：审美不够 → 借轮子。
> **第一次纠偏**：不是从零找外部库，而是用我们自己已研究过的 Apple/macOS、grok-bot、FigmaMake 视觉基准。
> **定调**：轮子优先、标准可改。
> **第二次纠偏**：去节点化 = 完全隐形壳只露选中边框，而且 Gen1 已实现只是没做好。
> **第三次纠偏**：不是轮子替代，而是**交互承接**——用 Huabu 的交接触发、我们改外观形状。
> **第四次纠偏（层级）**：一个 Project（.lcosproj）= 真值单位，绝不能拆成多个 canvas 文件。
> **第五次纠偏（最终）**：**投影画布 = LCOS 精髓**，三视图是同一项目实体的三种投影展示。
> **结论**：Gen2 = 用 Huabu 交互承载（frame/工具栏/Work View/drop）+ 复刻投影（一 universe 多面投影）+ 只改外观形状（去卡壳/物种 morph/自带 Glyth）。
---

# 附录二 · GPT完整版 vs 我们体系对账（含「假语义完成」判定）

> 来源：解包 `LCOS_GEN2_ACCOUNT_MIGRATION_20260902.zip`（GPT 完整版计划，50 entry，46 文件）后，重点读「GUI 实现形式」的权威文档。由于本方案起草时对 GPT 完整版理解不够，以下对账**纠正**了前文若干处（尤其「帧→scope」「独立canvas→三视图」两处方向）。

## A. 对账核心：GPT 完整版比我们更完整的权威判断

| 主题 | GPT 完整版权威 | 我们体系（前文） | 结论 |
|---|---|---|---|
| 基线 | Gen2 `main=602089f`(G0.8a)；**`apps/web-gen2` 仍是集成库，不是可交付 GUI Host** | 只知 567cb1e(G0.9c) | **基线有分叉需对齐**；「不是 GUI Host」是最大真缺口 |
| 投影 | §10.7「Huabu same physics + LCOS different semantic projections」 | 「投影=精髓」 | ✅ 一致，GPT 更明确 |
| 三视图 | 三Surface同构 §10：不能 `MainSelectionState/ContextSelectionState/WorkflowSelectionState`，要同一 `SelectionController{surfaceId,selectedProjectionIds,...}` | 之前纠结「独立 canvasId / 同画布隔离」 | ✅ **修正**：同一 Spatial Interaction Kernel + 不同 surfaceId 的 projection |
| 去卡片化 | §11「Visual Bounds ≠ Interaction Bounds ≠ Semantic LOD」 | 「隐形壳只露选中边框」 | ✅ 一致（「隐形壳」的科学依据） |
| ontology 泄漏 | 重建总纲 §5.3「Huabu Frame=LCOS Context/Collection 是 **forbid**（must not leak）」 | 之前「用 frame 当 scope」 | ❌ **修正**：frame 只能当空间投影，scope/collection 身份语义必须留 LCOS/Core |
| Scope/Path | 三Surface同构 §4 Scope=Workflow Component/Field/Lens；§5 Active Path=真实 relation 本身就是路径（**不生成 Active Path Node**） | 之前「frame 当 scope」 | ❌ **修正**：Scope 不是孤立节点；Active Path 不额外建 Node |
| Surface Component | Component Grammar Freeze §18：= Spatial Instrument，无强制 title bar、无通用紧凑条、collapse→Map Locator | 「物种 morph」 | ✅ 一致，且更细 |
| 唯一 owner | 重建总纲 §17：每核心概念最多一个 production owner（Selection 1 / Reference 1 / ...） | 「三块自持」 | ✅ 一致（**这是硬 KPI**） |
| 20% 语义 | §21「80% mature 是机械 code 比例，**不是产品语义比例**；LCOS 价值在 20% semantic layer」 | 「三块自持」 | ✅ **正面回应假语义完成** |

## B. 「假语义完成」判定（GPT 完整版自己的 + 用户原话标准）

### B1 用户原话红线（根母稿 §12.5）
> 「宁可慢一倍，也不要用十倍返工。尤其禁止：MVP式完成、语义完成、基本完成、接口已经有所以功能算完成、测试绿所以体验算完成。」

### B2 GPT 完整版点破的「代码有了但 GUI 没有」（开发记忆 §4）
```text
apps/web-gen2 仍是集成库，不是可交付 GUI Host
object species renderer/decorator 与 Huabu NodeWrapper 未正式接线
Selection≠Reference / Action Arc / Compact Composer / Semantic Drop 未端到端产品化
Unified Work View 未按 LCOS 接入 Preview Workspace
Work View 打开/缩放时 Huabu viewport correction/reveal 未在 LCOS mode 关闭
native connect → Core relation → edge/binding UI 桥未落地
Search→Focus、Color Pin、Nav/Locator、HUD safe-rect 联动未完成
Context/Workflow/Assembly/Skill/Run specialist instruments 未接
```
**这些 = 语义上像完成、实现上无实用性的典型**。

### B3 「理想 vs 现实」三态（最新UX_GUI对照）
- **🔴 未完成**（不要再当微调，是 GUI 主体）：Artifact 真正去卡片化、File/PDF/PPT/Image 物种统一、Unified Work View、Context/Workflow 大工作界面直接操作、Assembly 最新入口、Skill Builder、Harness Run、整套 icon/scale/material/color 系统。
- **🟡 已有代码但需真人盖章**：Click/Selection、Shift 多选、Marquee、Action Arc、Right-click、Compact Composer、Selection≠Reference、Semantic Drop 直接目标、Search/Focus/Color Pin/Voice 路径、active viewport 导航适配。
- **✅ 已较接近**：基础 Canvas 交互、Action Arc、Compact Composer、Semantic Drop、Search/Focus/Pin/Voice。

## C. 对前文的关键修正（我在撰写本方案时方向偏离处）

### C1 「用 Huabu frame 当 scope/collection」→ 修正为「只当空间投影」
重建总纲 §5.3 明确 **Huabu Frame = LCOS Context/Collection 是 forbid**（ontology leak）。frame 只能当**空间投影**，scope/collection 的**身份与语义必须留 LCOS/Core**（经 Frontend Domain Adapter）。这与「投影=精髓」一致：scope/collection 是同一 Project universe 内的层次，frame 只是它们在某张 Huabu 画布上的物理呈现，绝不能反过来定义 LCOS 真值。

### C2 「三视图=独立 canvasId」→ 修正为「同一 Spatial Kernel + 不同 surfaceId projection」
三Surface同构 §10：不能三个 Selection/Interaction 副本，要同一 kernel（`SelectionController{surfaceId,...}`）。三视图共享**同一套空间物理**，区别只在**语义投影与专属 component capability**（Main 项目地形 / Context 理解+Structure·Evolution·Relation·Source / Workflow 行动+Scope·Path·Review）。**不拆独立 canvas 文件**（L0「同一套物理，不同语义现场」+ 根母稿「Same physics, different semantics」）。

### C3 「Active Path 单独建 Node」→ 禁止（移除）
真实 relation/path 本身就是路径，**不再生成 Active Path Node**；Active Path Component 仅在提供额外真能力（筛选活跃路径/分析执行状态/reorganize/camera focus）时才存在，否则退役。

## D. GPT 完整版要求我们体系额外补齐的硬约束（建议回填宪法/方案）

1. **禁止 ontology leak**：Huabu Space≠LCOS Project、Frame≠Context/Collection、Edge≠all Relation、persistence≠LCOS persistence、spatial distance≠semantic truth、Agent Node≠mandatory receiver ontology。
2. **唯一 owner 硬 KPI**：每核心概念最多 1 个 production owner；出现 `MainSelectionManager/ContextSelectionAdapter/WorkflowSelectionController` 立即 STOP。
3. **Custom Primitive Rejection Record**：任何通用 primitive 自研前须填（Huabu candidate / 为何不用 / secondary candidates / license / maintenance / 为何全拒 / 为何必须自研 / owner / acceptance），无此文件不得提交 custom。
4. **四种合法 donor 决策**：ADOPT / COPY / WRAP / REJECT；禁止「REFERENCE AS IMPLEMENTATION」。
5. **QA 阶梯**：source conformance → type/lint/unit → browser interaction smoke → screenshot/visual smoke → canonical persistence/reload → cross-surface parity。（禁止 static gate PASS 就宣称完成。）
6. **Production owner 退休同 patch**：引入新 owner 的同 patch 退休旧 owner，禁止兼容层无限期存在。

## E. 一句话结论

> **GPT 完整版 = 我们方案的「上游权威」**，它把「投影=精髓」「三Surface同构」「去卡片化」「唯一 owner」都讲得更准。它最大的价值是**戳破假语义完成**：`apps/web-gen2` 只是集成库不是 GUI Host；很多交互「代码有路径、产品没兑现」。我们前文本方案的**「frame当scope」「独立canvas三视图」是错的**，已按「只当空间投影 + 同一kernel不同surfaceId」修正。Gen2 真正要做的，是**把已经冻结的 L0 产品语义，映射到更少的成熟 owner（Huabu 机械 + LCOS 语义 + 极薄 adapter），并逐项通过 Browser interaction smoke 证明真实可用**，而不是「有接口就宣称完成」。
---

## 全局动工指令（两条，覆盖所有阶段）

### 全局指令 1 · 默认不新增安全门 / 不删既有安全措施

> **默认不新增 hash、冻结 contract、baseline 或 gate。** 只有能明确说出一个**具体失败场景**，并说明 Git、版本号、主键、事务、唯一约束、类型和普通测试**为什么不足**时，才允许加入。
> **不要为了简化而删除已有安全措施。**
> 门禁只放在**不可逆、跨系统、安全、正式发布**这些边界。
> 前置检查不得挤掉真正的代码执行、模拟或测量。

要点：
- 新增 hash/contract/baseline/gate 是**例外**，默认**不加**。
- 要加就要先写清具体失败场景 + 逐一论证已有手段（Git/版本号/主键/事务/唯一约束/类型/普通测试）为何挡不住。
- **只准加**在四类边界：不可逆 / 跨系统 / 安全 / 正式发布。
- 门禁**不得挤掉**真正的执行、模拟或测量（检查是配角，执行是主角）。
- 已有安全措施**一律保留**，不得为简化而删。

### 全局指令 2 · 每个细分阶段施工前必须先联网调研成熟 GUI 形态与 UX 方案

> **所有细分阶段的对应施工开始前，一定要先联网搜索 GitHub 或全网搜索，理解了这个阶段应该有的成熟 GUI 实现形态和对应的 UX 交互方案之后，再进行施工执行。**

- 即：**先调研、后动手**。每个 H 阶段/模块动工前，先搜 GitHub/全网，搞清成熟项目这一步的 GUI 形态和 UX 交互。
- 反模式：不查就照自家脑补开工（Gen1 正是"没看别人怎么做"导致呈现灾难的教训）。
- 落地：动工前在 Handoff 里写明「本阶段调研到的成熟形态/UX」，再进入 M0/M1/M2。
