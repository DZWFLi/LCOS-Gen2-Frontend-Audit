# LCOS Gen2 · T2 Phase C1 Engineering Seam / Source Skeleton v1
## Checkpoint 02 · S04–S06
### Project Search / Focus-Where / Color Pin Navigation

日期：2026-09-06  
状态：`PHASE C1 · SOURCE-LEVEL SKELETON · CHECKPOINT 02`  
代码基线：`DZWFLi/LCOS_Gen2 @ c2ff890a867922a1256572199458438572eb0a8c`

> 本稿承接：
>
> `LCOS_Gen2_T2_C1_EngineeringSeam_SourceSkeleton_v1_S01-S03_20260906.md`
>
> 不重新讨论 Phase B 已关闭的产品语义。
> 只处理 current source 如何落实：
>
> - `T2-S04 Project Search`
> - `T2-S05 Focus / Where`
> - `T2-S06 Color Pin Navigation`
>
> 本 checkpoint 的目标仍然是：
>
> **exact-file / exact-owner / exact-consumer / reuse / migration / retirement / test / browser acceptance / recovery / blast radius。**
>
> 最终视觉 body、glyph、材质、字体、精确 motion 仍交 T5；
> 但 donor 已测得的 hard geometry / state / timing 会作为 T5 engineering input 固定保留。

---

# 0. Phase B / T2 已冻结行为

本 checkpoint 直接继承以下不可重新 OPEN 的行为：

```text
Search
= 不知道对象在哪里/叫什么时，项目级找东西

Focus / Where
= 已经知道对象是谁，只回答它出现在哪里

Pin
= 用户显式建立的长期导航锚点/颜色组
```

固定：

```text
Cmd/Ctrl+F = Project Search
F = current Selection 的 Focus / Where
```

禁止：

- 把 FTS / vector / database / OCR 暴露成产品 search modes；
- 把 Focus 做成带搜索框的第二 Search；
- 把 Pin 当 Focus mode；
- 把 Huabu canvas-local Search 当 Project Search；
- 把 Search result local nodeId 当 canonical identity；
- 把 Pin screen/world position持久化；
- archived target 自动 Restore；
- target missing 时按 title/provider/time 模糊重绑。

---

# 1. Shared current-source reality

S04–S06 并不是三个互不相干的小工具。

Current source 已经形成一条明显可以复用的链：

```text
Core Project Search
→ entityRef + locationRefs/locationCount
→ known canonical target
→ navigation resolution / occurrence resolution
→ current/cross-surface Focus
→ Huabu reliable bounds + camera
→ Arrival

Color Pin
→ canonical targetRef
→ NavigationMarkerService resolve
→ same Focus/Locate path
```

因此 C1 的施工目标不是：

```text
SearchStore
FocusStore
PinStore
各写一套 navigation
```

而是：

> **Search / Focus / Pin 共享一个 T2 navigation HUD presentation family，
> canonical truth 分别留在各自 Core owner，
> 最终 camera request 收敛到后续 S07 的同一条 Locate/Arrival seam。**

---

# 2. Existing overlay seam：不能再造第二 z-index 世界

## 2.1 CURRENT exact files

`huabu/apps/web/src/lcos/LcosHostOverlay.tsx`

当前已经是：

> 唯一 LCOS canvas-level overlay 容器。

它从真实 stores采集状态，
再调用：

`apps/web-gen2/src/interaction/overlayArbitration.ts`

中的：

```ts
visibleOverlays()
overlayZ()
overlayLayers
```

Current `OverlayKind` 已包含一个尚未落线的：

```text
focus-hud
```

当前 `LcosHostOverlay` 只真正 mount：

```text
LcosComposerShell
LcosDropPreview
```

并明确注释：

```text
actionArc/workView 待 B 阶段接 surface store
```

---

## 2.2 T2 裁决

Search / Focus / Pin 的顶部空间 HUD：

**必须进入这套已有 overlay arbitration。**

禁止：

```text
CenterArea.tsx
  + absolute Search HUD
  + absolute Focus HUD
  + absolute Pin HUD
```

### PLANNED MODIFY

`apps/web-gen2/src/interaction/overlayArbitration.ts`

把当前 dormant `focus-hud` 概念扩为统一的：

```text
navigation-hud
```

优先方式：

```text
OverlayKind:
  ...
  | 'navigation-hud'
```

编码前先全仓 ripgrep `focus-hud`：

- 若仍无真实 consumer：直接 retire `focus-hud`；
- 若发现 current consumer：一轮 compatibility alias 后退休。

### 为什么不是三种 OverlayKind

Search / Focus / Pin 在产品上语义不同，
但在 screen-space 上是**同一个 top-center HUD slot**。

内部模式仲裁：

```text
Search > Focus > Pin > none
```

所以 outer overlay 只需要一个：

```text
navigation-hud
```

避免 z-index 层把产品 mode 再复制一次。

---

# 3. T2-S04 · Project Search

## 3.1 PRODUCT_BEHAVIOR

用户：

```text
Cmd/Ctrl+F
→ 顶部/中心 compact Project Search
→ 输入自然关键词
→ 看到项目级结果
→ ↑/↓ 浏览
→ Enter / click 提交结果
```

提交：

### 单一明确 occurrence

```text
Search closes
→ Focus/Locate target
→ camera
→ Arrival
```

### 多 occurrence

```text
Search result identifies object
→ Search closes
→ Focus / Where mode
→ show occurrences
→ user chooses location
→ Locate/Enter as appropriate
```

Search 不要求用户知道：

```text
FTS
vector
OCR
semantic index
database
```

---

## 3.2 CURRENT canonical owner

### Service

`apps/local-core/src/project-search-service.ts`

`ProjectSearchService.search()`

Current 明确：

```text
federated search over existing sources
no new search DB
```

当前 sources：

- Artifact title；
- Artifact text；
- Notes；
- Conversation FTS；
- Resource title / descriptor；
- derived search_documents FTS；
- vector candidates；
- related expansion。

### Ranking

current service显式：

```text
exact title/phrase
> text artifact
> note
> conversation FTS
> resource title
> descriptor summary
```

T2 frontend 不得重新 rerank。

---

## 3.3 CURRENT route owner

`apps/local-core/src/routes/curation.ts`

Current endpoint：

```text
GET /projects/:projectId/search
```

query params：

```text
q
limit
types
usedHereTarget
```

current route只解析参数，
调用：

```text
ProjectSearchService.search()
```

---

## 3.4 CURRENT typed frontend boundary

`apps/web-gen2/src/backend/search.ts`

已有：

```ts
CoreSearchClient
CoreSearchParams
CoreSearchUsedHereTarget
```

`searchProject()`：

```text
GET /projects/:projectId/search
```

并在源码注释里明确：

```text
Returns SearchResultVNext as-is
NO rerank
NO scoring
NO semantic fallback
NO mixing Huabu RFS SEARCH
```

### KEEP EXACTLY

这个 client 不重写。

---

## 3.5 CURRENT frontend production consumer

当前源码审计未找到：

```text
new CoreSearchClient(...)
.searchProject(...)
```

在 vendored Huabu production UI 中的真实 consumer。

所以 current state：

```text
CORE_SEARCH_OWNER_EXISTS
TYPED_CLIENT_EXISTS
LCOS_PROJECT_SEARCH_UI_CONSUMER_MISSING
```

这不是产品 OPEN。

---

# 4. Huabu current local Search：强 mechanics donor，但不是 semantic owner

## 4.1 CURRENT hotkey

`huabu/apps/web/src/hooks/useGlobalSearchHotkey.ts`

Current capture-phase：

```text
Cmd/Ctrl+F
```

会：

### focus inside node preview

```text
usePreviewSearchStore.open(nodeId)
```

### otherwise

```text
expand left panel
setSearchOpen(true)
ensureCanvasSearchScope(canvasId)
focus CanvasSearchInput
```

并且：

```text
window.addEventListener('keydown', onKeyDown, true)
```

也就是 capture phase 抢占。

---

## 4.2 CURRENT canvas search input

`huabu/apps/web/src/components/Panels/CanvasLayerPanel/CanvasSearchInput.tsx`

Current：

```text
panelStore.isSearchOpen
searchStore.query
searchStore.scope = { kind:'canvas', canvasId }
```

成熟 mechanics：

- mount autofocus；
- query；
- loading spinner；
- result count；
- clear；
- Esc close；
- Esc focus return canvas；
- canvas switch clears stale scope。

---

## 4.3 CURRENT canvas search results

`huabu/apps/web/src/components/Panels/CanvasLayerPanel/CanvasSearchResults.tsx`

成熟 mechanics：

- Virtuoso；
- grouped result rows；
- active row；
- ↑/↓；
- Enter；
- ←/→；
- live highlight；
- conversation thread open；
- result focus；
- reliable offscreen node focus helper。

---

## 4.4 ADOPTION

### KEEP / LIFT mechanics

- autofocus；
- Esc close + focus return；
- keyboard active-row loop；
- virtualized result list when needed；
- loading/error/count feedback；
- preview-local Cmd+F；
- explicit local Canvas Search icon in LayerPanel。

### DO NOT REUSE semantic state

- `useSearchStore` as Project Search；
- `scope:{kind:'canvas'}`；
- Huabu node type filter as Project type taxonomy；
- RFS Search result as Core Search result；
- Canvas-local result grouping as Project canonical identity。

---

# 5. Cmd/Ctrl+F exact arbitration

这是 S04 当前最明确的真实 source conflict。

## 5.1 Current conflict

Phase B / frozen product：

```text
Cmd/Ctrl+F = Project Search
```

Current Huabu：

```text
Cmd/Ctrl+F = Canvas Search
```

但这个冲突可以薄改，不需要 Coordinator。

---

## 5.2 MODIFY

`huabu/apps/web/src/hooks/useGlobalSearchHotkey.ts`

保留 current focus-scope判断：

```text
data-search-scope="node"
```

### New rule

```text
if focus/active content is node Preview:
    keep preview-local find

else:
    open LCOS Project Search
```

### Canvas-local search after patch

仍保留：

```text
LayerFilterBar explicit Search glyph
→ CanvasSearchInput
→ Huabu searchStore
```

但不再拥有 ordinary global Cmd/Ctrl+F。

---

## 5.3 Why preview-local Cmd+F survives

Preview 用户正在：

- PDF；
- 文档；
- Conversation；
- expanded node content

里面阅读时，Cmd+F 的最自然含义仍是：

> 当前正在看的内容里找。

这不与“普通 LCOS shell Cmd+F = Project Search”冲突。

---

# 6. PLANNED Project Search presentation seam

## 6.1 PLANNED NEW · React-free

`apps/web-gen2/src/presentation/projectSearch.ts`

只做：

```text
SearchResultVNext
→ ProjectSearchItemVM[]
```

VM 最少：

```ts
ProjectSearchItemVM {
  key
  entityRef
  title
  snippet
  matchReason
  matchModality
  sourceAnchor?
  locationCount
  locationRefs
  usedHere?
  availability?
}
```

禁止：

- rerank；
- secondary semantic search；
- copy Core result into persistent local DB；
- infer canonical target from title。

---

## 6.2 PLANNED NEW · UI-only state

`huabu/apps/web/src/lcos/navigationUiStore.ts`

这是允许存在的**纯 presentation state**：

```ts
mode: 'none' | 'search' | 'focus' | 'pin'

searchQuery
activeSearchIndex
focusTarget?
activeOccurrenceIndex?
activePinId?
```

严格：

```text
NO persist()
NO canonical entities
NO memberships
NO locations truth
NO camera truth
```

它不是 “NavigationStore”。

文件名刻意叫：

```text
navigationUiStore
```

避免语义漂移。

---

## 6.3 PLANNED NEW hook

`huabu/apps/web/src/lcos/useLcosProjectSearch.ts`

职责：

```text
query
→ CoreSearchClient.searchProject
→ stale request guard
→ projectSearch presenter
→ results/error/loading
```

建议：

- 80–120ms local debounce；
- request sequence guard；
- query cleared → no request；
- 50 max 上限沿 Core；
- error 不自动 fallback Huabu search。

如果 `CoreSearchClient` 后续补 `AbortSignal`，
优先 abort；
否则先 sequence guard。

---

## 6.4 PLANNED HUD body

`huabu/apps/web/src/lcos/ui/LcosNavigationHud.tsx`

内部：

```text
mode=search → ProjectSearchView
mode=focus  → FocusWhereView
mode=pin    → ColorPinView
```

当前阶段可先在同一文件实现语义 body，
T5 回填后再拆：

```text
ProjectSearchHud.tsx
FocusWhereHud.tsx
ColorPinHud.tsx
```

不要为了“组件化”提前造空文件森林。

---

## 6.5 MODIFY overlay mount

`huabu/apps/web/src/lcos/LcosHostOverlay.tsx`

增加：

```text
LcosNavigationHud
```

并让：

`visibleOverlays()`

决定该 outer HUD 是否让位于：

- drag；
- resize；
- Work View exclusive states；
- Composer；
- Action Arc。

具体 coexistence 后续 S09 safeRect / T4 Work View 回填。

---

# 7. Search result commit algorithm

## 7.1 Commit known result

```text
1. take entityRef from Core
2. do NOT trust display title as identity
3. inspect locationCount / refs
4. choose handoff
```

### `locationCount === 1`

```text
→ Focus target at that occurrence
```

### `locationCount > 1`

```text
→ mode=focus
→ retrieve full occurrence list if needed
```

### `locationCount === 0`

不是自动认定“不可导航”。

可能是：

- resource；
- conversation；
- note；
- archived；
- entity with no current projection。

交给 canonical navigation/availability resolution。

---

# 8. Search locationRefs current source debt

`ProjectSearchService.#enrichHit()`

当前 artifact 搜索会调用：

```text
#locationsForArtifact()
```

它目前：

```text
artifact views
→ listProjectWorkspaceMemberships(projectId)
→ Workspace ids/names
```

并：

```text
LOCATION_REFS_LIMIT = 5
locationCount = full count
locationRefs = first 5
```

这是重要 current-source reality。

---

## 8.1 Phase B compatibility implication

Phase B D07 已关闭：

```text
old Workspace
→ slim/migrated Worksite
```

所以 Search 的 locations 不能长期教用户：

```text
Workspace
```

新 UI 应表现：

```text
Worksite / Surface occurrence
```

### T6-owned migration point

`apps/local-core/src/project-search-service.ts`

需要跟 T6 Worksite migration同步：

- current workspace membership compatibility read 可保留；
- output location identity 逐步迁到正式 Worksite ref；
- normal new result不再暴露旧 Workspace product ontology。

T2 只消费 final typed location ref。

---

# 9. S04 source-level file plan

## CURRENT KEEP

```text
apps/local-core/src/project-search-service.ts
apps/local-core/src/routes/curation.ts
apps/web-gen2/src/backend/search.ts
huabu/apps/web/src/components/Panels/CanvasLayerPanel/CanvasSearchInput.tsx
huabu/apps/web/src/components/Panels/CanvasLayerPanel/CanvasSearchResults.tsx
```

## MODIFY

```text
huabu/apps/web/src/hooks/useGlobalSearchHotkey.ts
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
apps/web-gen2/src/interaction/overlayArbitration.ts
apps/web-gen2/src/index.ts
```

## PLANNED NEW

```text
apps/web-gen2/src/presentation/projectSearch.ts
huabu/apps/web/src/lcos/navigationUiStore.ts
huabu/apps/web/src/lcos/useLcosProjectSearch.ts
huabu/apps/web/src/lcos/ui/LcosNavigationHud.tsx
```

---

# 10. S04 tests

## Unit

### `projectSearch.test.ts`

- identity preserved；
- matchReason preserved；
- no rerank；
- location metadata preserved；
- archived/unavailable state passes through；
- 0/1/many location presentation。

### `navigationUiStore.test.ts`

- `openSearch`；
- query reset；
- Search→Focus transition；
- no persistence；
- mode arbitration Search>Focus>Pin。

### `useGlobalSearchHotkey.test.ts`

- ordinary canvas Cmd+F → Project Search；
- node preview Cmd+F → preview-local；
- LayerPanel explicit local Search remains；
- Shift/Alt combos no false trigger；
- Esc returns focus.

---

# 11. S04 browser acceptance

- Cmd+F opens Project Search；
- search “known artifact title”；
- ↑/↓ changes active result；
- Enter selects canonical result；
- one location direct locate；
- multiple location → Focus；
- no Canvas LayerPanel forced open；
- LayerPanel Search icon still opens canvas-local Search；
- PDF/Preview Cmd+F still local；
- no vector/FTS mode UI；
- network failure shows recoverable Search error without falling back to wrong search engine。

---

# 12. S04 recovery / blast radius

Search request fail：

```text
keep HUD
show transient error
query preserved
no fake results
```

Core returns empty：

```text
honest no-result
```

stale request returns late：

```text
sequence guard drops stale payload
```

Blast radius：

`BR-1 Local adapter + BR-2 navigation handoff`

No canonical writes。

---

# 13. T2-S05 · Focus / Where

## 13.1 PRODUCT_BEHAVIOR

Focus 用于：

> 已知对象的“它在哪”。

入口：

```text
Selection + F
Search result handoff
Pin member
Rail/marker known target
```

Focus UI 不有 query。

它展示：

```text
这个对象出现在：
Main / Context / Workflow / Worksite / Conversation Worksite ...
```

用户点 occurrence：

```text
current canvas occurrence
→ Locate

other Worksite occurrence
→ Enter Worksite
→ Locate / Arrival
```

---

# 14. CURRENT occurrence data

现有 Search 已提供：

```text
locationRefs
locationCount
```

但：

```text
locationRefs capped at 5
```

所以它能支持：

```text
Search result summary
```

不能完整支持：

```text
Focus 7 / 12 / 20 occurrence cases
```

这是**真实技术 gap**。

---

# 15. Why T2 cannot derive all occurrences in browser

错误做法：

```text
GET ProjectGraphSnapshot
→ frontend scan ArtifactViews
→ frontend scan Workspace memberships
→ infer locations
```

问题：

1. 复制 Core location projection logic；
2. 强依赖旧 Workspace schema；
3. T2 会形成第二 “Where index”；
4. Worksite migration 后必然漂移；
5. archived / conversation / note 等 target 规则会继续分叉。

所以禁止。

---

# 16. Thin Core read seam for Focus

当前最合适 owner：

`NavigationMarkerService`

理由：

它已经负责：

```text
canonical targetRef
→ resolved navigation target
```

并且现有 route：

`apps/local-core/src/routes/navigation-markers.ts`

已经公开：

```text
POST /projects/:id/navigation/resolve
```

所以 Focus full occurrences 不需要另造 “Focus service”。

---

## 16.1 PLANNED MODIFY Core

### `packages/contracts/src/navigation-marker.ts`

新增 read-projection contract，例如：

```ts
NavigationOccurrenceV1 {
  occurrenceId
  targetRef
  surfaceRef
  surfaceKind
  anchorRef?
  projectionRef?
  availability
}

NavigationOccurrencesV1 {
  projectId
  targetRef
  occurrences
  total
}
```

这不是 canonical entity。

### `apps/local-core/src/navigation-marker-service.ts`

新增：

```ts
resolveNavigationOccurrences(projectId, targetRef)
```

策略：

#### target kind=view

```text
one resolved occurrence
```

#### target kind=entity artifact

```text
Artifact
→ all current authoritative views/projections
→ Worksite/Surface occurrence projection
```

#### note

按 canonical anchor / projection rules。

#### conversation

Conversation Worksite occurrence。

#### surface

one surface occurrence。

#### archived

返回 availability/read-only info，
不返回 ghost world coordinate。

### `apps/local-core/src/routes/navigation-markers.ts`

新增：

```text
POST /projects/:id/navigation/occurrences
```

input：

```json
{
  "targetRef": {
    "projectId":"...",
    "kind":"entity",
    "id":"..."
  }
}
```

unresolved：

```text
HTTP 200 + honest result
```

与 `navigation/resolve` 同纪律。

---

## 16.2 T6 cross-review

这个 read seam 需要 T6 对 Worksite ref / Archive lifecycle 做 schema cross-review，
但它不是重新 OPEN 产品语义。

当前实现若仍需读 Workspace compatibility：

```text
legacy read only
→ output new Worksite-facing occurrence ref
```

不保留双产品体系。

---

# 17. Existing NavigationMarker contract caveat

`packages/contracts/src/navigation-marker.ts`

当前 `StableSurfaceRefV0` 仍包含：

```text
workspace:<id>
scope:<id>
conversation:<id>
assembly
main
```

且 `NavigationSurfaceKindV0` 仍包含：

```text
scene
collection
assembly
```

Phase B 后这属于 compatibility vocabulary debt。

T2 不在本 checkpoint 擅自重定义 T6 canonical Worksite schema，
但 S05/S06 的 presenter必须：

```text
consume migrated/compat target
not display old product ontology verbatim
```

---

# 18. CURRENT Huabu spatial primitive for Focus

exact file：

`huabu/apps/web/src/components/Panels/CanvasLayerPanel/focusNodesOnCanvas.ts`

高价值 primitives：

```ts
anchorViewportCentre()
revealBoundsInViewport()
getReliableNodeBounds()
fitNodesOnCanvas()
focusNodesOnCanvas()
```

---

## 18.1 KEEP

最重要：

`getReliableNodeBounds()`

它解决：

```text
onlyRenderVisibleElements
→ offscreen node unmeasured
→ fitView empty rect
```

Current fallback：

- measured width/height；
- width/height；
- initialWidth/initialHeight；
- numeric style width/height；
- `internals.positionAbsolute`。

这个必须直接复用/LIFT。

---

## 18.2 WRAP, not final

Current：

```ts
focusNodesOnCanvas()
→ setCenter()
→ duration default 800
→ zoom=min(currentZoom,1)
```

这不是最终 LCOS Focus framing。

Gen2 需要：

```text
reliable union bounds
+ safeRect
+ optical padding
+ target-size-aware fit
+ bounded min/max zoom
+ explicit Focus timing
```

所以：

```text
getReliableNodeBounds = KEEP
focusNodesOnCanvas = engineering donor / WRAP
```

最终 camera request 在 S07 统一落。

---

# 19. PLANNED Focus frontend seam

## 19.1 React-free presenter

`apps/web-gen2/src/presentation/focusOccurrences.ts`

input：

```text
NavigationOccurrencesV1
+ current Surface/Worksite
```

output：

```ts
FocusOccurrenceVM {
  id
  label
  surfaceKind
  surfaceId
  current
  enterRequired
  archived
  unavailable
  anchorRef?
}
```

---

## 19.2 Backend typed client

`apps/web-gen2/src/backend/navigation.ts`

职责：

```ts
resolveTarget(projectId,targetRef)
resolveOccurrences(projectId,targetRef)
```

同一个 client 后续 S07 Locator 继续复用。

不存任何 navigation truth。

---

## 19.3 Huabu hook

`huabu/apps/web/src/lcos/useLcosFocus.ts`

职责：

```text
Selection canonical ref
→ resolveOccurrences
→ focus presenter
→ navigationUiStore mode=focus
```

用户选择 occurrence：

```text
same current Worksite
→ S07 locate target

different Worksite
→ S03 enterWorksite
→ S07 locate/arrival
```

---

# 20. Selection → canonical Focus target

Focus 不能从：

```text
node label
node type + title
```

猜 entity。

Current LCOS runtime已有 ProjectionBinding identity cache：

`huabu/apps/web/src/lcos/useLcosCanvasProps.tsx`

reconcile 后：

```text
host.listNodeBindings()
→ useLcosReferenceStore.registerNodeEntity(...)
```

因此：

```text
selected Huabu nodeId
→ LCOS binding/entity ref
→ Focus targetRef
```

这就是 `F` 的正确 identity seam。

---

# 21. Focus archived behavior

Phase B D13：

Archived object：

- Searchable；
- Referenceable；
- Agent-readable；
- read-only；
- Focus 显示 Archived；
- 可打开 viewer；
- 不自动 Restore；
- 不定位 ghost coordinate。

所以 `FocusOccurrenceVM` 对 archived target：

```text
archived=true
enterRequired=false
locatable=false
```

主动作：

```text
Open viewer
```

不是：

```text
Focus ghost x/y
```

---

# 22. Focus top HUD states for T5

工程保证提供：

```text
0 occurrence
1 current occurrence
1 remote occurrence
2
3
4
7
12
20+
archived
unavailable
cross-surface
current
```

T5 需要解决：

- 1个 location 几乎零 chrome；
- 2–4 compact glyphs；
- 7/12/20 overflow/fan/cluster；
- current occurrence；
- cross-surface identity；
- archived/unavailable；
- Search→Focus glyph continuity。

T5 不需要解决 canonical indexing。

---

# 23. S05 tests

## Core

`navigation-marker-service.test.ts`

新增：

- artifact one occurrence；
- artifact many occurrences；
- no 5-result truncation；
- target missing；
- archived；
- conversation；
- cross-project fail-close；
- legacy Workspace compatibility；
- no duplicate occurrence；
- no ghost coordinate。

`navigation-markers route test`

- POST occurrences；
- malformed；
- unresolved as HTTP 200；
- all occurrences returned。

## web-gen2

`focusOccurrences.test.ts`

- 0/1/many；
- current first/marked；
- remote enterRequired；
- archived；
- no title identity inference。

## Huabu

`useLcosFocus.test.ts`

- F on selection；
- mapping from binding；
- same worksite locate；
- remote worksite enter+locate；
- Esc close；
- Focus does not expose input.

---

# 24. S05 browser acceptance

- select artifact, press `F`；
- 1 occurrence；
- 3 occurrences；
- >5 occurrences；
- occurrence across Main/Context/Workflow；
- occurrence in long-term Worksite；
- target currently offscreen；
- target unmeasured due virtualization；
- archived target；
- no Project Search field appears；
- choosing location direct navigation, no modal confirm；
- right Work View open → safeRect behavior deferred to S09 but no overlap regression allowed.

---

# 25. S05 recovery / blast radius

Core occurrences fail：

```text
keep selection
show Focus unavailable
no camera movement
```

chosen occurrence disappears between read and click：

```text
resolve again
if unresolved → show unavailable
no fuzzy rebound
```

Blast radius：

- Core read projection: `BR-2/BR-3 compatibility read`
- frontend: `BR-2 navigation`

没有 canonical mutation。

---

# 26. T2-S06 · Color Pin Navigation

## 26.1 PRODUCT_BEHAVIOR

Color Pin：

> 用户明确给一个或多个对象建立的长期颜色导航关系。

Many-to-many：

```text
one target ↔ many Pin
one Pin ↔ many targets
```

Pin 不是：

- Focus state；
- node color style；
- Selection；
- camera bookmark；
- stored x/y。

---

# 27. CURRENT canonical contract

`packages/contracts/src/color-pin.ts`

### `ColorPinDefinitionV0`

```text
id
projectId
color
label?
createdAt
updatedAt
```

### `ColorPinMembershipV0`

```text
id
projectId
colorPinId
targetRef
createdAt
updatedAt
```

源码明确：

> Many-to-many target ↔ Color Pin relationship. No coordinates are persisted here.

### `ColorPinSnapshotV0`

```text
definitions[]
memberships[]
```

这部分 KEEP。

---

# 28. CURRENT Core route

`apps/local-core/src/routes/color-pins.ts`

### GET

```text
GET /projects/:id/color-pins
```

返回：

```text
ColorPinSnapshotV0
```

### POST assign

```text
POST /projects/:id/color-pins/memberships
```

input：

```text
targetRef
colorPinId?
color?
label?
```

关键：

写入前：

```text
NavigationMarkerService.resolveNavigationTarget()
```

target必须 canonical resolved。

之后：

```text
MutationSafetyService.assignColorPin()
```

### DELETE

```text
DELETE /projects/:id/color-pins/memberships/:membershipId
```

走：

```text
MutationSafetyService.removeColorPinMembership()
```

---

# 29. CURRENT mutation / realtime mechanic

`apps/local-core/src/mutation-safety-service.ts`

Color Pin add/remove：

```text
runCurationMutation(...)
→ ChangeSet
→ #publishChangeSet()
```

Current published Project Event：

```text
channel='mutation'
type='change_set.changed'
payload={
  changeSetId,
  status,
  operationId
}
```

Event hub：

`apps/local-core/src/project-events/project-event-hub.ts`

支持：

- per-project seq；
- replay；
- reconnect；
- snapshot_required；
- subscribe；
- in-memory bounded event buffer。

Route：

`apps/local-core/src/routes/project-events.ts`

```text
GET /projects/:id/events
```

SSE：

```text
project-event
replay
snapshot
heartbeat
```

---

# 30. CURRENT frontend realtime donor

Huabu 已有成熟 SSE mechanics：

`huabu/apps/web/src/store/canvasSyncStore.ts`

使用：

```text
huabu/apps/web/src/api/_sse
readTypedSSEStream
```

并实现：

- AbortController；
- reconnect loop；
- exponential backoff；
- snapshot/update reconciliation；
- stale frame guard。

### ADOPT MECHANICS

Project Event client可以 LIFT：

- SSE parser；
- AbortController lifecycle；
- reconnect/backoff；
- late frame guard。

### DO NOT MERGE TRUTH

`canvasSyncStore`

继续只负责 Huabu Canvas sync。

不要把 Core Project Events 硬塞进这个 store。

---

# 31. CURRENT frontend Color Pin consumer

当前 `apps/web-gen2/src/backend/` 没有 Color Pin typed client。

当前 audit 未找到 vendored Huabu production：

```text
ColorPinSnapshotV0
/projects/.../color-pins
```

consumer。

所以：

```text
CORE_PIN_OWNER_EXISTS
FRONTEND_PIN_CLIENT_MISSING
FRONTEND_PIN_UI_MISSING
```

---

# 32. PLANNED Color Pin typed client

`apps/web-gen2/src/backend/colorPins.ts`

class：

```ts
CoreColorPinClient
```

methods：

```text
getSnapshot(projectId)
assignMembership(projectId,input)
removeMembership(projectId,membershipId)
```

只做 typed HTTP。

---

# 33. PLANNED Project Event invalidation client

为了 Pin、Railway、以后 Archive/Receiver 等 canonical projection 不各写 polling：

`apps/web-gen2/src/backend/projectEvents.ts`

职责：

```text
connect(projectId,lastSeenSeq?,runtimeId?)
parse Core Project SSE
yield typed ProjectEventEnvelope
```

它不存 canonical state。

## Transport

由于 current `HttpClient.request()` 会整包 parse body，
不适合无限 SSE stream。

不要修改它成为一坨万能 streaming manager。

优先：

```text
CoreProjectEventsClient
```

读取公开的：

```text
http.config.baseUrl
http.config.token
http.config.fetch
```

并用 `fetch()` + `response.body` streaming。

SSE parser mechanics可借：

`huabu/apps/web/src/api/_sse`

如果跨 package import 不允许：

- LIFT parser 为 web-gen2 内部小型 parser；
- 保持协议行为一致；
- 不复制 canvasSync store。

---

# 34. Pin event invalidation strategy

Current `change_set.changed` payload不直接告诉 frontend：

```text
change type = Color Pin
```

只给：

```text
changeSetId/status/operationId
```

因此最薄且诚实的策略：

### Own write

POST/DELETE response authoritative：

```text
update local snapshot view
```

### External project mutation event

当 Pin feature 已 mounted：

```text
channel=mutation
type=change_set.changed
→ debounce/coalesce 100–250ms
→ GET /color-pins refresh
```

这个 refetch可能包含非 Pin mutation触发，
但 snapshot轻量，且不需要引入第二 event taxonomy。

后续若 Core event payload加入 changed domains，
再优化。

第一版不要为了省一个 GET 新造 ColorPinEvent。

---

# 35. PLANNED Color Pin presenter

`apps/web-gen2/src/presentation/colorPins.ts`

input：

```text
ColorPinSnapshotV0
current target refs
```

derive：

```ts
ColorPinGroupVM
ColorPinTargetMembershipVM
```

纯函数：

```text
definitions + memberships
→ group members
→ membershipsForTarget(targetRef)
→ counts
→ active group filtering
```

不保存：

```text
screen positions
node positions
camera
selection
```

---

# 36. PLANNED Huabu hook

`huabu/apps/web/src/lcos/useLcosColorPins.ts`

职责：

- initial GET snapshot；
- assign/remove；
- own-write update；
- project-event invalidation refetch；
- expose `ColorPinGroupVM[]`；
- expose current target memberships；
- feed Navigation HUD；
- feed T3 Action Arc Pin entry。

不是 canonical store。

---

# 37. Pin authoring integration boundary with T3

T3 owns Action Arc interaction grammar。

因此 T2 不在 NodeWrapper 偷加一套 Pin toolbar。

正确 seam：

```text
Selection
→ T3 Action Arc
→ Pin action
→ T2 useLcosColorPins.assign(...)
→ Core
```

T2向 T3 提供：

```text
available pin groups
target membership
assign/remove callbacks
pending/error
```

最终 Arc视觉 T5/T3。

---

# 38. Pin navigation integration

Top Navigation HUD：

```text
Pin idle
→ display existing real Pin groups only
```

不显示空槽。

用户选 Pin group：

```text
→ group member identities
```

用户点 member：

```text
targetRef
→ S05/S07 resolve occurrence/locate
→ camera
→ Arrival
```

如果 target unresolved：

```text
honest unavailable
```

不模糊重绑。

---

# 39. TapNow high-fidelity donor input

已完成源码级测量，T5 可以直接使用。

## 39.1 palette

```text
#F0606B
#F4A14B
#EDC63D
#4FC978
#4EA8FF
#A55CF0
```

第一版 contract允许 Core自定义 `#RRGGBB`，
因此这些是 default visual donor palette，不成为 canonical枚举。

---

## 39.2 node-local Pin

```text
single core: 18px
multi core: 14px
overlap margin-left: -10px
transition: 200ms ease-out
```

filtered inactive：

```text
saturate(.35) brightness(.55)
```

active node：

```text
3px group color
~22px color glow
```

---

## 39.3 chooser

```text
popover top
align center
sideOffset 8
pill
p-2
gap-1
```

button：

```text
outer 24px
inner 18px
selected white border/check
```

---

## 39.4 Pin action motion

```text
stage 26px
pressed scale .90
hover/focus/open offset -1px
pin icon rotate ~-5deg
```

membership confirmation：

```text
0.88
→ 1.06 @58%
→ 1
320ms
cubic-bezier(.2,.85,.2,1)
```

必须 reduced motion fallback。

---

## 39.5 member locate

TapNow donor：

```text
padding:1
maxZoom:2
minZoom:.5
duration:500ms
```

LCOS不直接抄 ReactFlow call。

最终：

```text
TapNow motion feel
+ Huabu reliable bounds
+ LCOS safeRect
```

S07落最终 camera seam。

---

# 40. Pin top HUD states for T5

工程保证：

```text
none
one group
multiple groups
active group
filtered node active
filtered node inactive
target with 1 pin
target with many pins
group empty-after-delete
unresolved member
pending assignment
mutation failure
```

Pin与Search/Focus共享 top-center HUD slot，
但 semantic mode不合并。

---

# 41. S06 tests

## Core existing/regression

- assign canonical target；
- cross-project reject；
- target missing reject；
- create definition；
- reuse same color definition；
- many-to-many；
- duplicate membership idempotent；
- remove；
- ChangeSet；
- Undo/Redo；
- event published after committed write。

## web-gen2

`backend/colorPins.test.ts`

- GET；
- POST；
- DELETE；
- envelope errors。

`presentation/colorPins.test.ts`

- group membership；
- many-to-many；
- target membership；
- no coordinate fields；
- unresolved presentation。

`backend/projectEvents.test.ts`

- snapshot；
- replay；
- project-event；
- abort；
- reconnect；
- runtime change → snapshot-required。

## Huabu

`useLcosColorPins.test.ts`

- initial fetch；
- own assign；
- own delete；
- external mutation invalidation；
- debounce；
- failure no fake success。

---

# 42. S06 browser acceptance

- select node → Arc Pin；
- assign one Pin；
- assign second Pin；
- same Pin to multiple targets；
- top HUD group appears；
- filter/group select；
- member click locate；
- remote occurrence → Focus/Enter；
- mutation error rollbacks pending UI；
- second client writes Pin → current client refreshes；
- unresolved target shows unavailable；
- reduced motion；
- right Work View open does not hide target navigation permanently。

---

# 43. S06 recovery / rollback

Assign fail：

```text
remove pending visual
leave previous snapshot intact
show inline recoverable error
```

Delete fail：

```text
restore membership visual
```

SSE disconnect：

```text
own writes still work
reconnect with seq
snapshot-required → refresh canonical Pin snapshot
```

Runtime restart：

```text
SSE runtimeId mismatch
→ snapshot_required
→ GET Color Pin snapshot
```

No localStorage fallback。

Blast radius：

- typed client/presenter: `BR-1`
- navigation HUD integration: `BR-2`
- realtime invalidation: `BR-2`
- no schema change for Color Pin itself。

---

# 44. Shared T2 Navigation HUD state machine

不是 canonical state machine。

只是 pure UI arbitration：

```text
NONE
SEARCH
FOCUS
PIN
```

priority：

```text
Search > Focus > Pin > none
```

行为：

## Search opens

```text
Focus/Pin presentation yields
canonical states remain untouched
```

## Search commit many-occurrence target

```text
Search → Focus
```

## Focus closes

如果有 active Pin filter：

```text
Focus → Pin
```

否则：

```text
Focus → none
```

## dragging

outer overlay arbitration可让 Navigation HUD让道。

这不是产品 “mode manager”。

---

# 45. PLANNED shared file ledger after Checkpoint 02

## CURRENT KEEP

```text
apps/local-core/src/project-search-service.ts
apps/local-core/src/routes/curation.ts
apps/local-core/src/navigation-marker-service.ts
apps/local-core/src/routes/navigation-markers.ts
apps/local-core/src/routes/color-pins.ts
apps/local-core/src/mutation-safety-service.ts
apps/local-core/src/project-events/project-event-hub.ts
apps/local-core/src/routes/project-events.ts

packages/contracts/src/navigation-marker.ts
packages/contracts/src/color-pin.ts

apps/web-gen2/src/backend/search.ts
apps/web-gen2/src/backend/client.ts
apps/web-gen2/src/interaction/overlayArbitration.ts
apps/web-gen2/src/index.ts

huabu/apps/web/src/hooks/useGlobalSearchHotkey.ts
huabu/apps/web/src/components/Panels/CanvasLayerPanel/CanvasSearchInput.tsx
huabu/apps/web/src/components/Panels/CanvasLayerPanel/CanvasSearchResults.tsx
huabu/apps/web/src/components/Panels/CanvasLayerPanel/focusNodesOnCanvas.ts
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
huabu/apps/web/src/lcos/useLcosCanvasProps.tsx
huabu/apps/web/src/store/canvasSyncStore.ts
huabu/apps/web/src/api/_sse
```

---

## PLANNED NEW · web-gen2

```text
apps/web-gen2/src/backend/navigation.ts
apps/web-gen2/src/backend/colorPins.ts
apps/web-gen2/src/backend/projectEvents.ts

apps/web-gen2/src/presentation/projectSearch.ts
apps/web-gen2/src/presentation/focusOccurrences.ts
apps/web-gen2/src/presentation/colorPins.ts
apps/web-gen2/src/interaction/navigationHud.ts
```

---

## PLANNED NEW · Huabu LCOS presentation

```text
huabu/apps/web/src/lcos/navigationUiStore.ts
huabu/apps/web/src/lcos/useLcosProjectSearch.ts
huabu/apps/web/src/lcos/useLcosFocus.ts
huabu/apps/web/src/lcos/useLcosColorPins.ts
huabu/apps/web/src/lcos/ui/LcosNavigationHud.tsx
```

T5视觉回填后可拆小子组件，
C1 seam不先造空壳。

---

## MODIFY

```text
huabu/apps/web/src/hooks/useGlobalSearchHotkey.ts
huabu/apps/web/src/lcos/LcosHostOverlay.tsx
apps/web-gen2/src/interaction/overlayArbitration.ts
apps/web-gen2/src/index.ts
```

---

## CROSS-OWNER MODIFY / REVIEW

T6/Core migration review：

```text
packages/contracts/src/navigation-marker.ts
apps/local-core/src/navigation-marker-service.ts
apps/local-core/src/routes/navigation-markers.ts

apps/local-core/src/project-search-service.ts
```

原因：

- Worksite ref migration；
- Archive availability；
- all-occurrence read projection。

这不是跨线程产品 OPEN，
只是 already-closed Phase B behavior 落 exact schema。

---

# 46. DO NOT BUILD after Checkpoint 02

禁止：

```text
ProjectSearchStore that owns results canonically
FocusStore with persistent locations
ColorPinStore with canonical membership
localStorage Pin
frontend occurrence index
second Search ranking
Focus query input
Pin-specific camera engine
Search camera engine
three separate HUD overlay roots
new z-index constants outside overlayArbitration
duplicate Project Event polling loops
```

允许：

```text
navigationUiStore
```

仅因为它保存：

```text
open mode
query
active index
```

而且：

```text
non-persisted
non-canonical
```

---

# 47. Shared browser regression matrix

## Search

```text
Cmd+F ordinary canvas
Cmd+F Preview
LayerPanel local search
keyboard
Esc
network fail
```

## Focus

```text
Selection + F
1 location
3 locations
7+
cross-surface
offscreen unmeasured
archived
unavailable
```

## Pin

```text
1 group
many groups
1 target-many pins
1 pin-many targets
assign/remove
event refresh
member locate
remote occurrence
reduced motion
```

## Overlay arbitration

```text
Navigation HUD + no selection
Navigation HUD + selected node
Navigation HUD + Composer
Navigation HUD + drag
Navigation HUD + Work View
```

任何状态都不能出现：

```text
Search HUD
+
Focus HUD
+
Pin HUD
```

三坨并存。

---

# 48. Recovery matrix

| Failure | UI recovery | Canonical impact |
|---|---|---|
| Search 503 | keep query + retry | none |
| stale Search response | discard | none |
| occurrence resolve fail | Focus unavailable | none |
| target removed mid-navigation | re-resolve → unavailable | none |
| archived target | viewer path only | none |
| Pin assign fail | rollback pending | none |
| Pin delete fail | restore local presentation | none |
| SSE disconnect | reconnect/backoff | none |
| SSE runtime restart | snapshot refresh | none |
| camera Focus fail | no canonical rollback needed | none |

---

# 49. Blast radius matrix

| Seam | Blast radius |
|---|---|
| Search presenter | BR-1 |
| Cmd+F arbitration | BR-2 |
| Navigation HUD | BR-2 |
| Focus occurrence Core read seam | BR-2 / compatibility BR-3 |
| Huabu Focus camera wrapper | BR-2 |
| Color Pin client/presenter | BR-1 |
| Project Event invalidation | BR-2 |
| Worksite/StableSurface migration | T6 BR-3 |

---

# 50. Coordinator escalation status

当前 S04–S06 没发现必须回 Coordinator 的不可解技术冲突。

发现的三个 source gap：

### Gap A

```text
Huabu Cmd+F currently owns Canvas Search
```

可薄改 hotkey arbitration。

### Gap B

```text
Search locationRefs only returns first 5
```

可在 existing NavigationMarkerService/route增加 read-only occurrence projection。

### Gap C

```text
Color Pin has Core owner but no frontend client
```

可加 typed client；realtime复用 existing Project Event SSE。

都不要求重新产品裁决。

---

# 51. T5 engineering input from Checkpoint 02

T5 可以现在依赖以下真实结构：

## Shared top HUD

```text
one physical slot
Search > Focus > Pin > none
```

## Search states

```text
idle/open
typing
loading
results
active row
no result
error
commit
Search→Focus
```

## Focus states

```text
1
2
3
4
7
12
20+
current
remote
archived
unavailable
```

## Pin states

```text
group idle
group active
one pin
many pins
filter active/inactive
assign pending
confirmation pulse
unresolved member
```

## Engineering constraints

- HUD screen-space；
- not ReactFlow-scaled；
- obey overlay arbitration；
- later obey T4 safeRect；
- Search/Focus/Pin no simultaneous body；
- no persistent text unless needed；
- hover/focus may reveal labels；
- final glyph can use Morphicons/Amicro；
- TapNow measured Pin timing available；
- safeRect + camera final in S07/S09。

---

# 52. Checkpoint 02 conclusion

S04–S06 已形成一条清晰的 source-level plan：

```text
Project Search:
Core ProjectSearchService
→ existing CoreSearchClient
→ NEW project search presenter/hook
→ shared Navigation HUD
→ Search result canonical entityRef

Focus:
known targetRef
→ NEW navigation occurrences read projection
→ NEW focus presenter
→ Huabu reliable bounds
→ S07 Locate/Arrival

Color Pin:
Core ColorPin contract/routes
→ NEW typed client/presenter/hook
→ shared Navigation HUD / T3 Arc
→ same Focus/Locate path
→ existing Project Event SSE invalidation
```

最关键的复用原则：

```text
Search 不重写 Core ranking
Focus 不重写 Huabu reliable bounds
Pin 不重写 Core membership
Realtime 不重新造 polling truth
HUD 不重新造 overlay system
```

---

# 53. Next checkpoint

Checkpoint 03 优先进入：

```text
T2-S07 Dynamic Locator + Camera Request + Arrival
T2-S08 Minimap / Spatial Navigator
T2-S09 Professional Window Occupancy Consumer
```

这三张是同一条 viewport navigation family：

```text
target bounds
→ safeRect
→ local/offscreen projection
→ locator
→ camera
→ arrival
→ minimap
→ Work View occupancy reflow
```

完成后再做：

```text
S10 Railway Receive Map
S11 Receiver in Railway
S12 Navigation More / low-frequency management
```

如果 S07–S09 超过单 checkpoint 可读规模，
拆 `03A / 03B`，
但不会提前跳阶段。
