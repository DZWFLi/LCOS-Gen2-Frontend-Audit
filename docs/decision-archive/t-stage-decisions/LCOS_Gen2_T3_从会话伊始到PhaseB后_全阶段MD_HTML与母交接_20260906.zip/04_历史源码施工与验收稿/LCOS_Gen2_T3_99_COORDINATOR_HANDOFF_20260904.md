# LCOS Gen2 · T3
## 99_COORDINATOR_HANDOFF
### Local Object Interaction / Action Arc / Compact Composer / Reference / Voice

> 日期：2026-09-04  
> 状态：`PLAN_READY_FOR_COORDINATOR_REVIEW`  
> 不代表 production patch 已施工。

---

# 0. 一句话

T3已经从“要不要重新做一套交互/Composer”收敛为：

```text
Huabu成熟 mechanics
+
LCOS现有 Reference/Core semantics
+
极薄 local affordance / draft / typed client glue
+
Orbit/CopilotKit permissive OSS primitive
+
Lovart/TapNow/Spatial高保真设计答案
```

真正自研量比早期计划明显缩小。

---

# 1. 正式交付

```text
01_Evidence_Census_Authority_Recovery
02_Current_Source_Consumer_Owner_Audit
03_Donor_Upstream_Adoption_Retirement_Matrix
04_Source_Level_Construction_Plan
05_Acceptance_Recovery_CrossReview_Plan
99_COORDINATOR_HANDOFF
```

前 5 册均按 V6 要求做实际 UTF‑8 30KB 检查。

---

# 2. Current baseline

```text
LCOS Gen2:
c2ff890a867922a1256572199458438572eb0a8c

Huabu vendored pin:
58339e269b784728d67730c70bfe7792cae2457d

Huabu upstream observed:
dc128fff2d37b5481ec305070a7e86d3de85f7d2
```

施工前若 HEAD变化，重核 touched paths。

---

# 3. PROTECT

```text
Huabu pointer router
Huabu Selection
Huabu geometry
CanvasFloatingPopover
Popover / DropdownMenu
NodeWrapper interaction phase
ProjectionBinding
referenceController
Local Core Relation
Local Core Run
Local Core Receiver
Local Core Voice
SemanticDrop pure machine
```

---

# 4. RETIRE / REPLACE

```text
LcosComposerShell fixed bottom shell

lcosDropState:
surface:left-dock
surface:bottom-dock

LcosDropPreview:
左侧导航坞
底部停靠区

Reference fixed 4px independent slop
```

注意：

Drop pure FSM不退。

---

# 5. 新增量允许范围

合理：

```text
pure local action resolver
local affordance transient state
Composer draft owner
contextmenu neutral host seam
typed Run/Receiver/Voice clients
FormData transport
ActionArc body
CompactComposer body
Voice recorder adapter
real SemanticDrop target adapter
```

条件新增：

```text
double-click activation seam
```

只有 LCOS species确实需覆盖 stock Preview。

---

# 6. 明确不新增

```text
second PointerRouter
second Selection
ActionCapabilityRegistry
ContextMenuFramework
positioning engine
Voice Workbench
Run domain
Composer framework
Drop manager
global listener layer
```

---

# 7. P0 construction order

```text
1 shared drag threshold
2 local affordance owner
3 selected re-click observer
4 pure action resolver
5 Action Arc
6 contextmenu
7 Composer draft
8 Compact Composer
9 Reference Pick
10 Run/Receiver
11 Voice
12 Semantic Drop real target
13 Glyth/WorkView cross integration
14 retire old shell/hardcodes
```

---

# 8. Donor decisions

## Orbit

```text
zumerlab/orbit
1.4.12
9b8906713...
MIT

LIFT:
radial geometry only
```

## CopilotKit

```text
MIT

LIFT:
CopilotChatAudioRecorder mechanics

REJECT:
whole CopilotChatInput ownership
```

## Huabu

```text
DIRECT_USE:
pointer
floating
popover/menu
input mechanics

UPSTREAM PATTERN:
ThreadChatInput draft/body split
```

## Lovart

```text
ENGINEERING:
reference only

VISUAL:
high-fidelity
```

## TapNow

```text
ENGINEERING:
reference only

ARCH:
responsibility donor

VISUAL:
high-fidelity
```

## Spatial v4

```text
behavior/motion high-fidelity
no implementation ownership
```

## LibTV

```text
product bundle:
wheel provenance only
```

---

# 9. Biggest source contradictions found

## C1

Reference `4px` slop
vs
Huabu input-mode threshold。

Fix同源。

## C2

`composerOpen = !dropActive`

错误 open owner。

改 explicit affordance mode。

## C3

prompt local state
vs
refs Zustand。

WorkView suppression会半丢 draft。

新增 single ComposerDraft owner。

## C4

Drop machine有 destination carry，
production `overDestination=false`。

接 real hit。

## C5

Drop destination hardcoded left/bottom。

被 latest UX覆盖。

## C6

Core已有 Run/Receiver/Voice，
web-gen2无 clients。

补薄 client，不新 domain。

---

# 10. T3→T1 handoff request

需要：

```text
takeover mark / floating anchor canonical helper
LOD anchor behavior
```

T3不自己算。

---

# 11. T3→T2 handoff request

需要：

```text
safe/occupied rect interface
Pin/Focus action callbacks/owner
```

T3只消费。

---

# 12. T3→T4 handoff request

需要：

```text
WorkView canonical open state
Assembly action
Skill target
Surface concrete Drop target descriptors
Glyth open/work semantics
```

---

# 13. T3→T5 handoff request

需要：

```text
Action Arc final visual token
Composer visual polish
Reference satellite
Voice icon/waveform style
```

不能改 T3 semantics。

---

# 14. T3→T6 handoff request

需要：

```text
Run typed contracts
Receiver typed contracts
Glyth durable Conversation Context mutation
Semantic Drop commit/recovery API
Relation/Pin cross-owner where relevant
```

Voice transcription Core route已存在。

---

# 15. Open micro policies

当前尚不能由 T3独断：

```text
1 Voice transcript碰到已有 prompt时：cursor insert / append / replace？
2 哪些 LCOS species double-click覆盖 stock Preview？
3 WorkView打开时 active Voice recording的 stop/cancel policy
4 完整 Assembly/Context/Workflow drop target taxonomy
5 target switch时非空 Composer draft的 UX
```

这些不阻塞基础 architecture。

---

# 16. Key acceptance

必须真实验证：

```text
first click select
re-click Arc
drag不弹 Arc
Ctrl Reference
Shift Selection
Composer target-local
no autofocus
WorkView draft survives
right-click native editor exemption
Voice no auto-send
Run failure draft survives
Glyth body drop != Relation != Reference
```

---

# 17. Coordinator review focus

主协调不需要重新审所有细节。

重点检查：

```text
A. T2/T4/T6接口是否已经有更新正本
B. 是否要同步 Huabu upstream ThreadChatInput相关提交
C. Glyth double-click是否真的需要 activation seam
D. target-switch / voice-active WorkView micro policy是否已有其它线程裁决
```

其余 T3内部 architecture已经可施工。

---

# 18. Construction handoff discipline

施工 Agent每个 card：

```text
READ FIRST
TARGET FILES
KEEP
CHANGE
DO NOT CHANGE
DONOR
OWNER
JSX
CSS
STATE
TEST
RETIRE
```

不允许“参考设计自行发挥”。

---

# 19. Final state

```text
ROUND 1 = CLOSED
ROUND 2 = COMPLETE
ROUND 3 = RECOVERED/SUPERSESSION MAPPED
ROUND 4 = COMPLETE FOR T3 KEY DONORS
ROUND 5 = COMPLETE WITH OPEN CROSS POLICIES
ROUND 6 = NOT REQUIRED BEFORE COORDINATOR REVIEW

T3 SOURCE-LEVEL PLAN
= READY FOR COORDINATOR REVIEW
```

---

# 20. Core design sentence

> **成熟产品告诉 LCOS 应该长什么样；Huabu 和成熟 OSS 提供通用机械；LCOS只拥有自己的语义与极薄 glue。**

对于 T3，这句话已经落成具体源码边界，而不是口号。
