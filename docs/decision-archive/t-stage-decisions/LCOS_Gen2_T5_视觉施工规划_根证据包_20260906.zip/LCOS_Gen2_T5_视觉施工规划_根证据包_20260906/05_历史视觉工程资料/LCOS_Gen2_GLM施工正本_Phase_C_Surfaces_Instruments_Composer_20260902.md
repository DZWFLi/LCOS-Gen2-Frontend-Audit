# LCOS Gen2 · GLM 施工正本 Phase C
## Context / Workflow / Assembly / Skill / Composer / Run Instruments

> Phase C 不再造“第二层应用”。所有 LCOS 独有能力以 Huabu 空间中的 direct-manipulation instrument、Unified Work View 或局部 Composer 进入；Core 保持 domain/run truth，Huabu 保持 geometry truth，成熟 donor 只提供机械器官。

---

# 0. 权威与语义边界

| Source ID | 文件/原文 | 施工约束 |
|---|---|---|
| U-ALL-01 | 用户：`不光是这几条，实际上我们的所有功能都要对照一下` | Context/Workflow/Assembly/Skill/Run/Composer/Voice/Agent/子画布/工作现场全部承接。 |
| U-SIMPLIFY | 用户：相同对象/语义应合并，只在表现或 GUI 排布上区别 | lens/view/presentation 不升级成 Entity；共享 primitives 不复制。 |
| F-SURFACE | 三 Surface 硬规则 | Main/Context/Workflow 独立状态、同一物理内核；右栏 catalog capability-filtered。 |
| F-CONTEXT | Context/Workflow Component CameraFocus 审判 | Context 四种核心 instrument、Workflow 物种、direct editing/camera focus。 |
| F-L0-C | Latest L0 §7–§10 | instruments 直接操纵；Skill ≠ Harness Run。 |
| F-COMPOSER | `LCOS_v015_UNIFIED_COMPACT_COMPOSER_...md` | Action Arc、right-click、reference、voice、target adapters、Esc/keyboard、A22–A24。 |
| F-LOVART | Lovart Composer/ReferencePick 拆解 | Selection ≠ Reference、Composer 原位、双局部反馈、advanced 下沉。 |
| F-WORK | Unified Work View | 重型 instrument 进入同一 Work View，不造永久侧栏。 |
| F-DONOR-BC | Phase B/C Mature Donor Census | Rete/n8n/ELK/Cytoscape/Sigma/vis-timeline/react-arborist/Mind Elixir/Markmap/dnd-kit/cmdk。 |
| F-VIDEO | Video donor 映射 | Lovart/Trae/TapNow/Codex Desktop 只取行为，不复制产品 taxonomy。 |
| GH-G1-C | 旧 LCOS `features/context/workflow/assembly/execution/capture/surfaces` | 迁纯 domain/presentation logic，替换 canvas/shell。 |
| GH-G2-C | Local Core routes：workflow/workbench/runs/runtime/reviews/skill-author/voice/receiver/resources/revision-workflows | typed clients 必须对接既有 canonical routes。 |

## 0.1 五类东西不得混淆

1. Entity：Artifact、Conversation、Skill、Run 等 Core canonical object。
2. Relation：Core canonical relationship。
3. Surface：Main/Context/Workflow 的独立空间现场。
4. Instrument/Lens：对同一 project truth 的操作/呈现工具，不必成为 entity。
5. Work View/Composer：临时或持续工作容器，不是新 domain type。

## 0.2 子画布/工作现场裁决

“子画布”不再实现成嵌套第二 canvas engine。若它表示独立工作连续性，映射为同 project 下独立 Huabu `canvasId`/workspace projection，并由 ProjectionBinding 关联；若只是某对象内部结构，使用 Work View instrument 或局部 layout，不新建 canvas。只有用户明确创建可独立恢复、拥有自己 camera/selection/history 的工作现场，才创建新 canvas identity。

---

# 1. 目标目录

```text
apps/web-gen2/src/
  backend/
    runs.ts
    runtime.ts
    runtimeReviews.ts
    workflows.ts
    workbench.ts
    skills.ts
    voice.ts
    receivers.ts
    resources.ts
    revisions.ts
  surfaces/
    surfaceRegistry.ts
    MainSurfaceAdapter.ts
    ContextSurfaceAdapter.ts
    WorkflowSurfaceAdapter.ts
    surfaceContextSnapshot.ts
  instruments/
    context/
      ContextInstrumentHost.tsx
      StructureInstrument.tsx
      EvolutionInstrument.tsx
      RelationshipInstrument.tsx
      SourceInstrument.tsx
      contextProjection.ts
      contextIntents.ts
    workflow/
      WorkflowInstrumentHost.tsx
      StepNode.tsx
      CheckpointNode.tsx
      ReviewNode.tsx
      ActivePath.tsx
      workflowProjection.ts
      workflowIntents.ts
      workflowLayout.ts
    assembly/
      AssemblyCatalog.tsx
      assemblyRegistry.ts
      assemblyAdmission.ts
      assemblyDropAdapter.ts
    skill/
      SkillInstrument.tsx
      SkillTree.tsx
      SkillAuthoringPort.ts
    run/
      RunWorkView.tsx
      RunReview.tsx
      RunTrace.tsx
  composer/
    UnifiedComposer.tsx
    composerState.ts
    referencePick.ts
    receiverResolver.ts
    targetAdapters.ts
    voiceState.ts
    actionArc.ts
    commandPaletteAdapter.ts
```

每个 donor 放 `instruments/*/donorAdapters/`，donor 原始模型不能向外泄漏。Core client 只讲 HTTP/contracts，不 import React/Huabu；instrument 只通过 port，不直接拼 URL。

---

# 2. C00 — Core route → typed port 补齐

## 当前缺口

Gen2 Host 仅显式暴露 projects/artifacts/relations/search；Core 已有大量 route。GUI 若直接 fetch 会产生第二套业务语义、错误处理和 mutation 生命周期。

## 客户端模板

```ts
export class CoreRunClient {
  constructor(private readonly http: HttpClient) {}

  list(projectId: string, query?: RunQuery): Promise<readonly RunSummary[]> {
    return this.http.get(`/projects/${encodeURIComponent(projectId)}/runs`, query)
  }

  create(projectId: string, draft: CanonicalRunDraft): Promise<RunCreateResult> {
    return this.http.post(`/projects/${encodeURIComponent(projectId)}/runs`, draft)
  }

  review(projectId: string, runId: string, input: RunReviewInput): Promise<RunReviewResult> {
    return this.http.post(`/projects/${encodeURIComponent(projectId)}/runs/${encodeURIComponent(runId)}/review`, input)
  }
}
```

路径以 Core 真实 route 为准，不能凭文档猜。实施者逐 route 阅读 handler、contract、validation、MutationSafety/ChangeSet，再写 client + contract test。所有 mutation 成功通知 Host reconciler。

## Port 清单

| Port | GUI 消费者 | canonical owner | Phase C 最小方法 |
|---|---|---|---|
| RunPort | Composer/Run Work View | Core runs/runtime | create/get/list/cancel/retry |
| RunReviewPort | Review instrument | Core runtime-reviews | propose/approve/reject/get diff |
| WorkflowPort | Workflow Surface | Core workflow/revision-workflows | load/save proposal/validate/execute |
| WorkbenchPort | Workflow/Run | Core workbench | open/inspect/apply |
| SkillPort | Skill instrument | Core skill-author-dispatch | list/get/propose author/update |
| VoicePort | Composer | Core voice-transcription | start/submit/status/cancel |
| ReceiverPort | Composer/Conversation | Core receiver | list/resolve/connect |
| ResourcePort | Context/Assembly | Core resources | list/get/reference |

## Fail-close

若 route 不存在或 contract 不支持用户原文能力：记录具体缺口，停止那张 instrument 的 mutation；可以做 read-only projection，不能在 localStorage 伪造 canonical state。

---

# 3. C01 — 三 Surface adapter 与状态隔离

## Main

Project Main Presentation：主要 artifacts、conversations、results、用户空间编排。不是“active workspace”的唯一 owner。Main 可打开 Context/Workflow 对象投影，但不把完整 instrument 常驻。

## Context

同 project truth 的结构/演化/关系/来源现场。Context adapter 从 Core entities/relations/revisions/provenance 投影为 Huabu nodes/edges或 instrument node；camera/selection/history 独立。

## Workflow

同 project truth 的流程/步骤/检查点/审阅/执行现场。Workflow canonical model 从 Core WorkflowPort；Huabu geometry 与布局是 presentation。

## Adapter 形状

```ts
export interface SurfaceAdapter {
  readonly descriptor: SurfaceDescriptor
  hydrate(): Promise<SurfaceHydrationResult>
  contextSnapshot(): SurfaceContextSnapshot
  projectEntity(ref: CoreEntityRef): Promise<ProjectionBinding>
  removeProjection(ref: CoreEntityRef): Promise<void>
  dispose(): void
}
```

## 切换交互

不使用顶部 `Canvas tabs`。入口采用 centered spatial index/导航系统（Phase D）或对象 intent；右侧 catalog 在当前 surface 下过滤能力。切换前保存 Huabu canvas session；切换后恢复对应 canvasId。切换不关闭 project-scoped Work View，除非其 adapter 只在原 surface 有意义，此时显示 restore target 而不是销毁。

## 测试

- 三 camera、selection、undo stack 独立。
- 同 artifact 多 projection 不复制 artifact。
- agent snapshot 默认当前 surface。
- Context relation edit 更新 Core relation，Main edge经 reconcile 同步。

---

# 4. C02 — Context Surface：四种 instrument，不是四张白卡

## 4.1 Structure Instrument

### 产品角色

表达 project/artifact/context 的层级与包含，支持折叠、重排、reference、定位、投影。不是文件树皮肤。

### donor

- `react-arborist`：虚拟树、键盘、drag/drop primitive。
- 旧 LCOS presentation hierarchy：canonical→visible rows 的纯逻辑。
- Huabu node/pointer：空间位置、选中、drag owner。

### 接法

donor 只在 Work View/大型 instrument 内渲染 tree mechanics；小/working node 使用 LCOS 自己的无卡片 hierarchy projection。tree drag 输出 `ContextIntent`：

```ts
export type ContextIntent =
  | { type: 'context.reparent'; entity: CoreEntityRef; parent: CoreEntityRef; index: number }
  | { type: 'context.reorder'; parent: CoreEntityRef; orderedChildren: readonly CoreEntityRef[] }
  | { type: 'context.reference'; entity: CoreEntityRef }
  | { type: 'context.locate'; entity: CoreEntityRef }
```

是否有 canonical parent/reorder relation 必须读 Core contract。没有则 reparent 只生成 proposal，不在 UI 本地永久生效。

### morphology

mark：hierarchy glyph+count；summary：root+一级 3–5 项；working：可展开的局部层级；reading：Work View tree+detail split。

## 4.2 Evolution Instrument

### donor

`vis-timeline` 提供时间轴机械；版本 diff 用已有 diff viewer/轻 adapter。它们不拥有 revision truth。

### projection model

```ts
export interface EvolutionEvent {
  readonly id: string
  readonly at: string
  readonly entity: CoreEntityRef
  readonly kind: 'revision' | 'run' | 'relation-change' | 'review'
  readonly label: string
  readonly changeSetId?: string
}
```

kind 必须映射已有 Core event，不新建 `timeline-event` entity。选择 event 只定位/review；拖动时间点默认不改 history。分支/restore 走 revision workflow。

### morphology

mark：时间/变化数量；summary：最近 3 个事件；working：可 scrub 的局部 timeline；reading：Work View timeline+diff。

## 4.3 Relationship Instrument

### donor 分层

- 中小关系编辑：Cytoscape.js 可作为 instrument 内 graph/layout/edge interaction donor。
- 大图只读/探索：Sigma.js + Graphology。
- deterministic layout：ELK.js。
- Huabu 仍是 surface spatial runtime；donor graph 只能在 instrument/Work View 内，不接管整个画布。

### 选择规则

节点 <300 且要编辑 edge：Cytoscape；节点很多且以探索为主：Sigma；普通 Context surface 直接用 Huabu nodes/edges，不引入内嵌 graph。不可同时为同一画面加载 Cytoscape+Sigma。

### adapter

```ts
export interface RelationshipGraphModel {
  readonly nodes: readonly { ref: CoreEntityRef; label: string; kind: string }[]
  readonly edges: readonly { relationId: string; source: CoreEntityRef; target: CoreEntityRef; kind: RelationKind }[]
}
```

donor node id 由稳定编码生成，但 mutation 必须回 Core relationId；donor layout positions 是 instrument internal presentation，可缓存但不成为 project geometry truth。

## 4.4 Source Instrument

显示来源/provenance/reference chain、外部 resource、change trace。小态以 source marks/数量表达；Work View 才展开 trace/diff。复用 Gen1 `features/trace/changeTrace.ts` 的纯映射，重新对接 Core changeSet/revision。

## 4.5 四 instrument 共存规则

它们是 lens/instrument，不是四个顶层 Surface，也不是四种 Context entity。一个 Context Surface 可以放多个 instrument projection，但默认一个 dominant instrument；切 lens 不复制实体。右侧 catalog 允许插入 instrument，插入的是 view/instrument projection；若 Core 已有 `view` binding type，复用它。

---

# 5. C03 — Workflow Surface：流程语义归 Core，机械归 donor

## donor 裁决

| donor | 取什么 | 不取什么 |
|---|---|---|
| ReactFlow/xyflow | 已由 Huabu 提供 nodes/edges/ports/drag/zoom | 不再嵌第二 ReactFlow |
| Rete.js | socket compatibility、dataflow/editor 模型启发或 headless engine | 不让其成为 UI/canonical workflow owner |
| n8n | 节点参数 UX、execution/retry/review 产品行为参考 | 不复制 n8n taxonomy/shell |
| ELK.js | deterministic auto layout | 不持久化成 domain truth |

## Workflow canonical projection

```ts
export interface WorkflowProjectionModel {
  readonly workflowId: string
  readonly revisionId: string
  readonly steps: readonly WorkflowStepProjection[]
  readonly relations: readonly WorkflowEdgeProjection[]
  readonly checkpoints: readonly WorkflowCheckpointProjection[]
}
```

Huabu node positions/bindings独立；workflow step identity/revision/compatibility来自 Core。

## Workflow 物种

### Step

mark：type glyph/status；summary：label+IO 端口；working：关键参数/validation；reading：Work View 参数/文档/测试。

### Active Path

不是新 node。由 Run/Workflow state 计算，对现有 step/edge 添加 restrained highlight；刷新可重建。

### Checkpoint

canonical workflow checkpoint 若 Core 有则投影；否则 review boundary 作为 relation/step property，不造 entity。GUI 用 timeline/edge marker，不堆卡。

### Review

连接 RunReviewPort，显示 pending/approved/rejected 与 diff；review action 在 Work View/Action Arc，结果写 Core。

### Skill invocation

Workflow step 可引用 Skill entity；它不是复制 Skill。projection 绑定 workflow step，内部 ref 指向 skillId/version。

### Workbench

如果 Core `workbench` 是执行/修改容器，Work View adapter 显示；不再造第二 workflow surface。

## 直接操纵

- 拖 node：只改 Huabu geometry。
- connect ports：先解析兼容性，生成 workflow edit proposal/Core mutation，再投影 edge。
- 删除 step：先 Core mutation/revision，再 reconcile；失败恢复空间 projection。
- 自动布局：ELK 计算目标 geometry，经 Huabu batch move；不写 Core。
- edit parameter：Work View/inline working，写 workflow revision/proposal。

## compatibility adapter

```ts
export type PortCompatibility =
  | { ok: true; coercion?: ExistingCoercionKind }
  | { ok: false; reason: string }

export interface WorkflowCompatibilityPort {
  inspect(from: WorkflowPortRef, to: WorkflowPortRef): Promise<PortCompatibility>
}
```

`ExistingCoercionKind` 必须来自 Core/Rete adapter 已知规则；GUI 不发明“智能连接类型”。

## Auto layout preset

```ts
export const workflowLayoutPreset = {
  direction: 'RIGHT',
  nodeGap: 52,
  layerGap: 112,
  portGap: 18,
  animationMs: 220,
} as const
```

screen/world 具体转换由 Huabu geometry API。用户手工布局后 auto-layout 必须是显式动作，可 undo；不在每次 mutation 后自动洗牌。

---

# 6. C04 — Assembly：共享项目仓库与能力目录

## 产品裁决

Assembly 是 project shared warehouse/catalog，不是第四 Surface，也不是右侧栏静态组件大全。入口由 Action Arc/导航/command palette；可在 Main/Context/Workflow 当前 surface 插入其能力允许的对象/仪器。

## Registry

```ts
export interface AssemblyItem {
  readonly id: string
  readonly label: string
  readonly kind: 'artifact' | 'conversation' | 'skill' | 'instrument' | 'workflow-step' | 'resource'
  readonly entityRef?: CoreEntityRef
  readonly capabilities: readonly SurfaceCapability[]
  readonly keywords: readonly string[]
  readonly preview?: AssemblyPreview
}
```

`kind` 只映射已有对象/投影类别，不创建 AssemblyEntity。

## Catalog donor

cmdk/grok-bot CommandPalette 提供 tabs、virtual list、nested steps、Mod+数字快捷键；Assembly adapter 提供数据与 intent。命令面板不是项目 truth，不保存 item 副本。

## capability filter

```ts
export function availableInSurface(
  item: AssemblyItem,
  surface: SurfaceDescriptor,
): boolean {
  return item.capabilities.some(cap => surface.capabilities.has(cap))
}
```

同一 catalog，当前 surface filter。右侧 shelf 也消费此 selector，禁止复制一套列表逻辑。

## 插入路径

1. 选 item。
2. 进入 placement preview，不立即创建随机 geometry。
3. 用户在画布点击/拖放位置。
4. 若 item 是现有 entity，创建 projection binding；若是 canonical create command，先 Core create 再投影；若是 instrument view，创建 view/projection preference。
5. Esc 取消，无 orphan Core/entity/node。

## Search/Assembly 区别

Search 找已有 project/world objects；Assembly 提供可插入/创建/启用能力。两者 UI grammar 可同源（centered index/cmdk），结果和 intent 必须不同。

---

# 7. C05 — Skill Instrument 与 Harness Run 分离

## Skill

项目中的可复用能力 artifact，具有 identity/version/input/output/root/subskill/authoring proposal。它可以在 Main/Context/Workflow 被引用或投影。

## Harness Run

一次执行/评估记录，具有 receiver/references/input/output/log/review/changeSet。它引用 Skill，但不是 Skill 的“运行态字段”。

## UI 共用与边界

共用：Glyth/glyph、status primitive、Work View shell、tree/outline、Composer reference strip。

不共用 truth：Skill authoring 写 SkillPort；Run action 写 RunPort。不能在 Skill node 内直接变更 run status，也不能把某次 Run 的参数自动覆盖 Skill default。

## Skill morphology

- mark：skill glyph/版本 cue。
- summary：名称、短描述、输入输出计数。
- working：root/subskill 轮廓、可引用/加入 workflow。
- reading：Skill Work View，tree + details + author proposal/review。

## donor

react-arborist 用于 root/subskill tree；Mind Elixir/Markmap 只在 skill structure 需要 spatial mindmap 时评估。首选复用 Phase B Outline/Mindmap primitives；不为 Skill 再引一个 mindmap stack。

## authoring 流

```mermaid
flowchart TD
  E["Edit intent"] --> D["Skill draft"]
  D --> P["Core author proposal"]
  P --> R["Review"]
  R -->|approve| V["New canonical version"]
  R -->|reject| D
```

如果 Core `skill-author-dispatch` 已提供 proposal/review，直接 typed client。UI 不直接写 skill 文件或 localStorage。

---

# 8. C06 — Unified Compact Composer

## 角色

Composer 是画布内局部 active surface，不是 project object，不固定右栏，不开新 modal。它冻结当前 receiver、显式 ordered references、target、prompt/voice、advanced parameters，提交 CanonicalRunDraft。

## 状态机

```ts
export type ComposerMode = 'rest' | 'compose' | 'pick-references' | 'advanced' | 'submitting' | 'error'

export interface ComposerState {
  readonly id: string
  readonly mode: ComposerMode
  readonly anchor: ComposerAnchor
  readonly receiver: RunReceiverRef | null
  readonly references: readonly OrderedEntityReference[]
  readonly target?: CoreEntityRef
  readonly prompt: string
  readonly voice: VoiceCaptureState
  readonly parameters: Readonly<Record<string, unknown>>
}
```

## 位置与中间态

Composer 默认锚定 selection/Action Arc附近，但不遮住目标；可以拖动。它不是固定右栏。切 reference-pick 时 Composer 保持原位，canvas 进入轻 reference mode；每次 pick 在 node badge 与 Composer strip 两处反馈。

## Selection ≠ Reference

打开 Composer 时 references 为空，除非用户通过显式 command传入。Selection 只作为 foreground execution context/anchor，不报告为“用户选择的参考”。Ctrl/Cmd pick 添加 reference；Shift 仍多选。

## Receiver

迁旧 `commandDraft.ts::resolveComposerReceiver`：单一 selected conversation可解析已连接 receiver；多个 conversation fail-close；没有 receiver 提示先连接/选择。不能默认猜最近 agent。

## Target adapters

```ts
export interface ComposerTargetAdapter<T = unknown> {
  readonly kind: string
  supports(ref: CoreEntityRef): boolean
  freeze(ref: CoreEntityRef): Promise<T>
  validate(input: ComposerValidationInput<T>): Promise<ComposerValidationResult>
}
```

Artifact/conversation/scope/view/workspace/skill/workflow step/run review 各 adapter 必须映射现有 Core ref contract。unsupported fail-close，不用字符串 nodeId 冒充 canonical ref。

## Advanced

折叠到底部；默认不抢注意力。参数 schema来自 receiver/runtime capability，不把 provider型号暴露为产品 taxonomy。用户改过的 explicit值可保留 project/user preference，但不写成 node property。

## 键盘

- Enter：非 IME、非 multiline modifier 时提交。
- Shift+Enter：换行。
- Ctrl/Cmd+click：reference。
- Esc 第一层退出 reference/advanced，第二层关闭 Composer；submitting 只按 capability允许取消。
- Tab 在 Composer 内循环，但不永久 trap canvas。

## Action Arc 分工

Arc 最多 4 个当前能力动作，如 Compose/Open Work/Reference/Assembly；更多、破坏性、设置类进右键。不能把 node 上所有功能围一圈。

---

# 9. C07 — Voice 进入 Composer，不成为第二 Composer

## 状态

```ts
export type VoiceCaptureState =
  | { kind: 'idle' }
  | { kind: 'requesting-permission' }
  | { kind: 'recording'; startedAt: number; level: number }
  | { kind: 'transcribing'; requestId: string }
  | { kind: 'ready'; transcript: string; edited: boolean }
  | { kind: 'failed'; reason: string; recoverable: boolean }
```

## 规则

- Voice 只填/增强同一个 prompt；不造 VoiceRun/VoiceComposer。
- permission fail 可回文本。
- transcript 进入可编辑 prompt，不自动提交。
- receiver/references/target 在提交时冻结，不在转写等待期间偷偷变化。
- 录音 waveform/Glance 是 presentation，不是状态 owner。
- Core voice-transcription route canonical request/status；浏览器 MediaRecorder只采集。

## UX

rest mic affordance轻；recording 用单一状态环/波形；transcribing 不锁住 reference strip；Esc 先停止/取消 capture。reduced motion 下仍有文本状态和 timer。

---

# 10. C08 — Run Work View / Review / Trace

## Run Work View 分区

1. identity/status/receiver。
2. ordered references 与 target。
3. input prompt/parameters。
4. live/recorded progress。
5. outputs/artifacts。
6. changeSet/diff/review。
7. provenance/trace/log。

这些可在同一 Work View 内按 density/size排布，不做七张卡。主信息在中心；次级 diagnostics 使用 Huabu Preview Workspace tab 或折叠 pane。

## Review

approve/reject/modify 是 Core mutation；按钮必须显示作用对象/changeSet。破坏性或不可逆动作右键/确认。AI 对 surface 的改动默认 proposal；批准后 projection reconcile。

## Trace

迁旧 `changeTrace.ts` 的映射思想，对接 changeSet/revision/run event。trace 不生成新的“Trace entity”。大日志虚拟化；node只显示状态 cue，完整内容 Work View。

## 状态恢复

web reload后从 Core run status恢复；正在执行的动画不作为 truth。断网显示 stale/offline，不把 run置失败。reconnect 后查询并 reconcile outputs。

---

# 11. C09 — Local agent 接入与 Huabu agent tabs 的分工

## 相同点

LCOS 和 Huabu都可以连接本地 agent，底层 transport/provider 可复用 Huabu已有 session/tab/connect UI；不再写一套 terminal/chat shell。

## LCOS 不可替代层

- agent进入某 project/surface的 canonical identity/receiver。
- 当前 surface context snapshot。
- ordered references/target/Run draft。
- proposal/changeSet/review。
- outputs投影、binding、reconciliation。
- Conversation Glyth 与 project continuity。

## 接线

Huabu Preview Workspace tab展示 agent会话；LCOS Conversation node/Glyth引用同一 session identity。选择 node 可 activate对应 tab；tab关闭不删除 Core conversation/project binding。agent response产出的 artifacts走 Core create，再投影；不能由 tab DOM直接创建 Huabu node作为唯一事实。

## Context 注入

默认只注入当前 surface snapshot；当前 selection作为foreground context、explicit references单独有序。跨 surface material由用户显式reference/Search/Assembly proposal。禁止为了“更智能”把整个项目所有surface偷偷打包。

---

# 12. C10 — Donor integration registry 与拒绝记录

## Registry 格式

```ts
export interface DonorRegistration {
  readonly name: string
  readonly version: string
  readonly license: string
  readonly owner: 'huabu' | 'lcos-adapter'
  readonly usedFor: readonly string[]
  readonly forbiddenAsTruth: readonly string[]
  readonly lazyBoundary: string
}
```

## Phase C donor map

| donor | 采用位置 | adapter 输出 | 禁止 |
|---|---|---|---|
| Huabu/ReactFlow | 所有 Surface | geometry/pointer/node/edge | 第二 canvas engine |
| Cytoscape | Relationship Work View | graph intent | Core relation truth |
| Sigma/Graphology | 大关系探索 | selection/locate | 编辑 owner |
| vis-timeline | Evolution Work View | event selection | revision truth |
| ELK | Context/Workflow layout | target positions | canonical geometry |
| react-arborist | Outline/Structure/Skill tree | reorder intent | entity identity |
| Mind Elixir/Markmap | 仅若共享 mindmap primitive不足 | branch intent | 第二 content model |
| dnd-kit | catalog/list内部排序 | ordered ids | canvas drag |
| cmdk/grok-bot | Assembly/command palette | typed command | project taxonomy |
| Rete | workflow compatibility/headless启发 | compatibility | UI/runtime truth |
| n8n | UX reference | 无 runtime import优先 | shell/taxonomy copy |

每引一个运行依赖，先填：Huabu是否已有、为何共享 primitive不足、bundle成本、license、lazy boundary、删除策略。没有答案不安装。

---

# 13. C11 — 子画布/工作现场详细规则

## 创建独立工作现场的必要条件

同时满足：

1. 需要独立 camera/selection/history。
2. 需要跨 reload/restart恢复。
3. 用户将其视为可再次进入的工作地点，而非当前对象的详情。
4. 内容可以由同 project canonical entities/relations投影，不需第二 truth。

满足则创建 workspace/view canonical identity（复用 Core已有类型），配置新 Huabu canvasId与bindings。若只需要某 Skill/Context结构的局部编辑，使用 Work View instrument。

## 进入/退出

- 从对象“进入工作现场”是 navigate intent，不打开 top tab。
- 导航系统显示当前位置与返回路径；Phase D实现 centered index/Pin。
- 退出恢复母 surface camera；子现场自身camera保持。
- 同 entity可跨现场投影，不复制。

## 权限与 agent

当前工作现场决定 agent snapshot；project仍是owner。Agent不能成为workspace owner。跨现场修改生成 proposal，用户批准后各投影 reconcile。

---

# 14. C12 — 自动测试与真实 E2E

## Contract/client

- 每个 Core route client有request/response/error contract test。
- project boundary、not-found、validation、MutationSafety、changeSet。
- UI没有裸 fetch 到Core route。

## Context E2E

1. Main已有 artifacts/relations。
2. 进入Context，Structure显示同实体层级。
3. Relationship连接/删除写Core；Main projection同步。
4. Evolution选择revision打开diff；restore走Core revision workflow。
5. Source定位provenance/changeSet。
6. 四instrument切换不复制entity。

## Workflow E2E

1. load canonical workflow。
2. 投影steps/ports/edges。
3. move只改Huabu geometry；reconnect/reload保持。
4. connect兼容端口写Core revision/proposal；不兼容解释reason。
5. ELK explicit layout可undo；不改workflow semantics。
6. 执行run，active path从Core state高亮。
7. review/approve outputs后Main投影。

## Assembly E2E

- 同catalog在三surface过滤不同能力。
- Search与Assembly结果/intent区分。
- placement preview/cancel无orphan。
- existing entity只创建projection；create command先Core后projection。

## Composer E2E

- opening不复制selection。
- Ctrl/Cmd references有序、双局部反馈。
- receiver单一解析，多conversation fail-close。
- Composer可拖、保持原位、Esc层级正确。
- voice permission/record/transcribe/edit/submit/fail。
- submit真实Core Run；reload看到同run/references/status。

## Agent E2E

- Huabu tab与LCOS Glyth同session。
- tab关闭不删Core identity。
- 当前surface snapshot正确。
- output走Core→projection→binding。

---

# 15. 视觉与交互验收细节

## Context

- 不出现四张大白卡。
- Structure tree在small/working/Work View之间连续。
- Relationship大图不会抢Huabu全画布pointer；退出instrument后canvas正常。
- timeline scrub不改变history，只有显式restore mutation。

## Workflow

- ports至少36px屏幕命中，不随zoom不可点。
- edge/connect preview沿用Huabu原生手感。
- parameter editor不常驻每个node。
- active path克制，不以大面积发光替代状态文字。

## Composer

- rest footprint小；compose展开但不遮target。
- reference-pick没有全屏蒙层；canvas可识别轻状态。
- advanced下沉；voice不另开modal。
- IME中文Enter不误提交。

## Work View

- instrument可floating/docked/immersive/restore。
- right Preview Workspace仍能查看agent tabs/files。
- 同时只有一个dominant LCOS Work View。

---

# 16. 施工拆分与工时

| 包 | 内容 | 预计 |
|---|---|---:|
| C00 | Core typed clients/ports | 4–7 天 |
| C01 | 三Surface adapters/切换/agent snapshot | 3–5 天 |
| C02a | Context Structure/Source | 3–4 天 |
| C02b | Evolution/timeline/diff | 3–4 天 |
| C02c | Relationship graph adapters | 4–6 天 |
| C03 | Workflow projection/step/ports/layout/review | 7–10 天 |
| C04 | Assembly/catalog/placement | 3–4 天 |
| C05 | Skill instrument/author proposal | 4–6 天 |
| C06–C07 | Composer/reference/receiver/voice | 6–9 天 |
| C08–C09 | Run Work View/agent integration | 4–6 天 |
| C10–C12 | donor registry/E2E/perf/restart | 4–6 天 |

单一工程 agent：45–67个有效工作日。可以由多个施工 agent按 owner并行，但必须先完成 C00 contracts和Phase A/B shared kernel；同一文件/owner不得并行乱改。Context与Workflow可并行，Composer/Run可并行，最终统一做跨surface E2E。

---

# 17. Phase C 退出条件

1. Main/Context/Workflow 真正独立且共享 Huabu物理内核。
2. Context四instrument direct manipulation落地，无四白卡/第二canvas。
3. Workflow canonical semantics经Core，geometry经Huabu，ELK/Rete等不成为truth。
4. Assembly为共享capability catalog，Search/Assembly区分。
5. Skill与Harness Run实体/写入/GUI角色清楚。
6. Composer是可拖局部中间态；Selection≠Reference；receiver/target/voice真实接Core。
7. Run review/trace/changeSet在Work View真实工作。
8. Huabu agent tabs被复用，但LCOS project/surface/reference/proposal/binding未被替代。
9. 子画布只在独立工作连续性条件满足时创建新canvasId；局部详情用Work View。
10. 每个donor有adapter/license/lazy/delete边界。
11. 真实Core+Huabu+restart E2E通过。

若只能展示mock graph/mock workflow/mock run，不算完成。

