# LCOS Gen2 · GUI 复用「现成轮子」信息搜集档案

> 日期：2026-09-02
> 阶段：**信息搜集**（用户要求：先全面搜集，再规划，再执行）。本文件只记录已实拉核实的证据。规划结论随文附录，但标明了「下步需核实的点」，未定案。
> 核心诉求：别再自己设计 GUI，用 Huabu + 现成预设组件库，把 LCOS 自己的那一套搭出来。审美与工程经验不足，借市场验证过的轮子。
> 证据来源：本次全面搜集 = Huabu 源码 + LCOS Gen1 源码 + **我们早期已系统研究并冻结的视觉参考档案**（Apple/macOS、grok-bot、SwiftUI-For-Web、FigmaMake 视觉语言、motion donor）。后者才是「我们自己的视觉基准」。

***

## 0. 一句话更正（推翻早前两轮方向）

**第一轮错**：说「引 React Bits」。**第二轮错**：说「用 shadcn/ui 补 primitives」。本次全面搜集到我们自己的视觉档案后，两个都推翻了。

真正的事实：

1. **视觉基准 = 我们早期的视觉档案，不是外部 UI 库**。参考图要的 Apple/macOS「瓷白 + Liquid Glass + 极简 monochrome」感，正是我们从 `ios26-design-system`（Apple iOS26 官方设计套件 web 重实现，MIT）吸取的——它有完整 design token + Liquid Glass 材质 + 组件规格 + 四模式契约。这比 React Bits/shadcn 的 SaaS 审美**正**得多。
2. **交互/组件基座 = Huabu 自带**。`components/Common/` 已有完整 primitives（Button/Popover/Modal/Tooltip/Toast/Select/Toggle/TabGroup/DropdownMenu/FloatingToolbar…），且已和 Huabu 画布 token 一体。LCOS 的 `Lcos*` 应被它替换，不是被 shadcn 替换。
3. **agent 界面语言 = 我们自己的 grok-bot**（DZWFLi 私有仓）。`SandButton`/`sand-kit-primitives`/`AgentRowActions`/`CommandPalette` 等，是比任何外部轮子更契合 LCOS 的 AI 界面参考。
4. **红线 = FigmaMake No-Go**。明确禁 ReactFlow 审美、禁通用卡片、禁大侧边栏、禁「雾面卡套雾面」……**React Bits 的营销动效、shadcn 的 dashboard 风正好踩这些雷**——所以不是「不选它们」，而是「它们违反我们的 No-Go」。

**修正后方向**：

- 视觉/材质 → 套用 `ios26` + LCOS token 层（不发明、不引 shadcn）；

- primitives → 用 Huabu `Common/*`（替换 Lcos\*）；

- 图标 → lucide（已在依赖，SF 风格）+ 自绘 Glyth；

- agent/AI 界面 → 参考 grok-bot 的 sand-kit 语义；

- 只有 Huabu Common 没有的（多选、树、时间线、图、思维导图、command menu）才引入专门轮子。

***

## 1. Huabu 已带的轮子（实拉核实，`apps/web/package.json` + 源码）

### 1.1 设计系统 primitives（`components/Common/`，一整套已有）

| 组件                                                                                                                                                                                           | 源码核实                                                                                                                              | 能力                              |
| -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------- | ------------------------------- |
| `Button.tsx`                                                                                                                                                                                 | variant=solid/outline/ghost，tone=neutral/info/success/warning/danger，size=sm/md/lg，iconOnly，`shortcutBadge`+`shortcutBadgeActive` | Apple 式克制按钮；快捷键角标               |
| `Popover.tsx`                                                                                                                                                                                | createPortal、视口/边界钳制（`viewportMargin`/`boundary`）、Esc+外侧关闭、`data-popover-dismiss-ignore`、`ResizeObserver` 重钳                      | 宪法 A20 近场摆位正所需                  |
| `Input.tsx` / `TextInput.tsx` / `SplitSelect.tsx` / `Select.tsx` / `Toggle.tsx` / `RangeSlider.tsx` / `ColorPicker.tsx`                                                                      | 全套表单/控件                                                                                                                           | 覆盖 Composer/reference/skill 表单项 |
| `Modal.tsx`                                                                                                                                                                                  | 含 `role="dialog"` 识别                                                                                                              | A18 对话主导层的载体                    |
| `Tooltip.tsx`                                                                                                                                                                                | placement 全向                                                                                                                      | 工具提示                            |
| `Toast.tsx`                                                                                                                                                                                  | tone 语义（复用 Button 的 Tone）                                                                                                         | A18/A19 反馈                      |
| `TabGroup.tsx`                                                                                                                                                                               | 分组 tab                                                                                                                            | 右侧 Work View 标签页                |
| `DropdownMenu.tsx`                                                                                                                                                                           | 下拉菜单                                                                                                                              | Action Arc / 右键管理               |
| `FloatingToolbar.tsx`                                                                                                                                                                        | 浮动工具条                                                                                                                             | Arc / 单选工具条                     |
| `EmptyState.tsx` / `Loading.tsx` / `CommandBlock.tsx` / `NodeRef.tsx` / `PathInput.tsx` / `AgentIcon.tsx` / `ThinkingIndicator.tsx` / `AgentAvatarMark.tsx` / `DragToCanvasHandleButton.tsx` | 各类辅助件                                                                                                                             | 填空/加载/命令块/agent 面               |

### 1.2 视觉 token 与材质（`index.css` :root，已实读）

```css
:root {
  --fg-default:#191919; --fg-muted:#515151; --fg-subtle:#767676; --fg-inverse:#fff;
  --bg-default:#f5f5f5; --bg-surface:#fff; --bg-hover:#f2f2f2; --bg-inverse:#1f1f1f;
  --edge-default:#e6e6e6;
  --info:#2e90ff; --success:#16a34a;
}
```

- 已具备瓷白/quiet 底（`#f5f5f5` 底 / `#fff` 面 / `#e6e6e6` 发丝线）——贴「porcelain-white、quiet、hairline」目标。

- `FLOATING_CHROME_PROPS`（`floatingChrome.ts`）：统一浮层材质，所有 Popover 共用。

- 字体：Huabu 用「Inter / SF Pro / Segoe」系统栈。

### 1.3 画布/编辑/图标（`apps/web/package.json`）

| 依赖                        | 版本     | 用途                       |
| ------------------------- | ------ | ------------------------ |
| `@xyflow/react`           | ^12.10 | React Flow 画布引擎          |
| `lucide-react`            | ^0.577 | 极简单色 SVG 图标（SF 风格）——已在依赖 |
| `@dnd-kit/*`              | ^6/^10 | 拖拽排序（限 instrument 内 DOM） |
| `@floating-ui/react`      | ^0.27  | 浮层定位（Popover 底层）         |
| `@milkdown/*`             | ^7     | 富文本编辑（Crepe）             |
| `zustand`                 | ^5     | 状态                       |
| `react-virtuoso`          | ^4.18  | 虚拟列表                     |
| `clsx` + `tailwind-merge` | —      | 类名合并                     |
| `tailwindcss@4`           | —      | CSS 引擎                   |

**关键**：`clsx`+`tailwind-merge`+`@floating-ui`+`lucide` 都在，接入任何 shadcn-like 组件零额外基建。但 Huabu 已有 Common，无需。

***

## 2. LCOS Gen1 自有 UI（实拉核实，`features/ui/`）→ 待替换对象

| Gen1 文件                        | 大小             | 对应 Huabu Common            | 裁决   |
| ------------------------------ | -------------- | -------------------------- | ---- |
| `LcosButton.tsx`               | 1.5KB          | `Button.tsx`               | 替换   |
| `LcosIconButton.tsx`           | 1.4KB          | `Button` iconOnly / lucide | 替换   |
| `LcosIcon.tsx`                 | 4.4KB          | lucide-react（已在依赖）         | 替换   |
| `LcosTextField.tsx`            | 1.4KB          | `TextInput.tsx`            | 替换   |
| `LcosPopover.tsx`              | 5.5KB          | `Popover.tsx`              | 替换   |
| `LcosTooltip.tsx`              | 4.3KB          | `Tooltip.tsx`              | 替换   |
| `LcosToaster.tsx`              | 2.8KB          | `Toast.tsx`                | 替换   |
| `ConfirmDialog.tsx`            | 1.3KB          | `Modal.tsx`                | 替换   |
| `iconShapes.ts`                | 4.0KB          | lucide                     | 替换   |
| `MindMapEditor.tsx`            | 14KB           | mind-elixir-core（待核）       | 见 §4 |
| `ObjectOrbit.tsx`              | 10.1KB         | 需核（Arc）                    | 见 §4 |
| `ProjectObjectOrbit.tsx`       | 4.4KB          | 需核                         | 见 §4 |
| `SelectionGroupActions.tsx`    | 5.2KB          | `DropdownMenu`/`Popover`   | 见 §4 |
| `dismissibleLayer.ts`          | 0.5KB          | 保留纯逻辑                      | 迁逻辑  |
| `overlayStack.ts`              | 7.7KB          | 保留纯逻辑（A19 纪律）              | 迁逻辑  |
| `spatialOverlayPlacement.ts`   | 7.8KB+2KB 测试   | 保留纯逻辑（A20 契约）              | 迁逻辑  |
| `spatialOverlayEnvironment.ts` | 1.2KB          | 语义迁 A25 active viewport    | 迁逻辑  |
| `asyncState.ts`                | 5.7KB+4.4KB 测试 | 保留纯逻辑                      | 迁逻辑  |
| `shellChromeInsets.ts`         | 1.2KB          | 语义迁 A25                    | 迁逻辑  |
| `ui-primitives.css`            | 31KB           | 融入 Huabu token 层           | 退休   |

***

## 3. 候选外部轮子（许可证已核实，待定是否引入）

| 轮子                         | 仓库              | 许可证                        | 与 Huabu 栈兼容                      | 用途                | 引入判定                       |
| -------------------------- | --------------- | -------------------------- | -------------------------------- | ----------------- | -------------------------- |
| **cmdk**                   | pacocoursey/dip | MIT                        | React19 需 v1.0.4+（issue #266 已核） | 搜索/命令菜单/combobox  | 需要（Huabu 无）                |
| **react-arborist**         | jameskerr       | MIT                        | 是                                | 大纲/树              | 需（Context/Skill outline）   |
| **mind-elixir-core**       | SSShooter       | MIT                        | 是                                | 可编辑思维导图           | 需（Skill Builder）           |
| **markmap**                | markmap         | MIT                        | 是                                | 只读导图投影            | 可选                         |
| **cytoscape.js**           | cytoscape       | MIT                        | 是                                | 关系场               | 需（Context Relationship）    |
| **vis-timeline**           | visjs           | MIT OR Apache-2.0          | 是                                | Context Evolution | 需                          |
| **react-resizable-panels** | bvaughn         | MIT                        | 是                                | Assembly 分栏       | 需（若 PreviewWorkspace 不够）   |
| **motion (framer-motion)** | motion          | MIT                        | React19 兼容                       | Arc/Glance 动效     | 需（Glyth presence）          |
| **React Bits**             | DavidHDev       | MIT + Commons Clause（禁售源码） | React19+TS+TW4                   | 背景/点缀动效           | 谨慎（CC 限制 + 营销动画不符 LCOS 克制） |

***

## 3.5 微交互 / 动效 donor 定案（2026-09-02 补充 · 替代旧 React Bits 评估）

### 定案（修正 2026-09-02 再核实）：微交互用 motion（framer-motion）+ Huabu 已有动效；Amicro 评估后不可用

> ⚠️ **重要修正**：初判「Amicro 定为微交互 donor」后被源码核实推翻——**`@subhanhq/amicro@1.0.1` 实际不可用**。

**为什么不可用（源码核实）：**
- npm 包 `package.json`：`bin: null`（**无 CLI 命令**）、`main: dist/index.html`、`files: [dist, README, LICENSE]`（只发布展示站）、`scripts` 仅 `dev/build/preview`（一个 vite 展示站）—— **没有 `add`/`init`，README 宣传的「zero-config CLI」是空头支票**。
- GitHub 仓库 `src/` = `components + data + hooks + utils + App.tsx` —— 是它**展示网站本身**的源码（一个 vite 站点），不是可拷贝的组件包；无 registry、无独立组件分发。
- 结论：Amicro 是**「好看但未成库」的展示项目**，不符合 donor「ADOPT/COPY 需完整可分发」的纪律。**不采用**。

**微交互的正确来源（可靠轮子）：**
- **motion（framer-motion）**（MIT，React19 兼容，Huabu 生态通用）—— 微交互/过渡/Arrange 的首选，`motion/react`。
- **Huabu 已有动效**（`useNodeTakeover`、LOD、overlay 过渡、FloatingToolbar 动画）—— 优先复用。
- **React Bits**：仍**弃用**（Commons Clause + 营销页氛围与 LCOS 相冲）。

**微交互的边界（沿用本轮定调）：**
- 节点**本体**去卡片化（物种 morph），不使用卡片壳。
- 节点**之外**的 UI 容器 / instrument 层（Arc 弧排、集合/Assembly 散布、Work View 纵深过渡）**可精致成卡**，用 motion 写排布与过渡；只要不像 SaaS 注册表即可。
- 动效以 **motion** 手写（简单、可控、MIT），不依赖 Amicro 这类「未成库」的项目。


## 3.6 微交互 donor 全网再核实 · Amicro 真相（2026-09-02 二次修正）

> ⚠️ **二次修正**：上一轮 §3.5 判「Amicro 不采用」是基于 npm 发布版（只有展示站、`files:[dist,...]`、`bin:null`、`npx add` 走不通）。全网搜 + 读 `registry/registry.json` 后确认——**GitHub 源码里 Amicro 是完整 shadcn registry，30+ 组件可拷**，只是 npm 发布版没打 CLI/registry。上一轮「不采用」说得过猛，改为「**部分可用 + 精准收割**」。

**Amicro 源码事实（已读 registry/registry.json）**
- 标准 shadcn registry（`registry/ui/`、`registry/hooks/`、`registry/lib/presets.ts`），组件依赖 `framer-motion`。
- `npx add` 走不通（npm 发布版没带 CLI/registry），要用 GitHub `registry/` 手动拷。
- **registry 里是装饰性微交互**（entrance / text / hover / cursor / scroll / loading / hooks / presets）——**不含**我上一轮以为的 arc / wheel-fan / linear-spread / scatter / carousel 排布语法（那些在它自己 `src/` 展示站，不可拷）。

**精准收割（对 LCOS 最值钱）**
| 组件 | 用途 | 判定 |
|---|---|---|
| `registry/lib/presets.ts` | **motion spring 配置预设**——LCOS 所有过渡统一用它 | ✅ **收** |
| `registry/hooks/use-reduced-motion` | 无障碍（QA 阶梯 reduced-motion 必测） | ✅ **收** |
| `registry/hooks/use-web-haptics` | **drop 五阶段 accept/settle 触觉反馈**（A系列 haptic） | ✅ **收** |
| `registry/ui/scroll/sticky-reveal` | Work View / 右栏 Apple 式内容揭示 | 🟡 或许 |
| cursor-trail / mouse-follow / spotlight | 指针意象（Glyph 靠近/选中艺术化） | 🟡 可选 |
| text-reveal / blur-text / character-stagger 等文字动效 | 标题/入场——偏营销氛围，与 LCOS 克制相冲 | ⚠️ 慎用 |
| card-hover / tilt-card / glow-button / spotlight | **卡片类 hover**——去卡片化要避免，**只能限用于节点之外容器** | ⚠️ 限定容器 |

**边界重申**
- 节点**本体**去卡片化（物种 morph），不使用卡片壳。
- 节点**之外**的 UI 容器/instrument 层可精致动效，但**不能**是 SaaS 注册表样。
- 微交互主力仍是 **motion（framer-motion）+ Huabu 已有动效**；Amicro 只收 `presets.ts` + 两个 hook + 极少数可选件。
## 4. 待核实（规划前需确认的点）

1. **Huabu** **`Common/`** **是否有「多选下拉」与「树形」**：只看到 `Select/SplitSelect`（单选类），未见多选/树。确认是否需引入 dnd-kit 已能覆盖。
2. **Arc（Action Arc）语义**：Huabu `FloatingToolbar`/`DropdownMenu` 能否承载「3/4 上限 + Esc/outside 关闭 + 贴右上角」的 Arc 契约？`ObjectOrbit` 的动作排序优先级是否可迁？
3. **mind-elixir-core 的 React19 兼容**：确认 peerDep 是否支持 React19（Gen2 用 React19）。
4. **React Bits 的 Commons Clause**：限制「销售源码/托管他人使用」。LCOS 是开源项目，需确认 CC 是否允许。倾向不用（LCOS 克制调性也无需营销动画）。
5. **Glyth 自绘 SVG**：唯一没有现成轮子的，需单独设计一段保真路径（深石墨身体+两眼+状态 accent + Near/Mid/Far）。这是「必须自绘」而非「复用轮子」的边界。
6. **`@huabu/shared`** **是否也可复用**（如 `colors`/`spatial` utils）——查 `packages/shared`。

***

## 5. 暂定规划（待 §4 全部核实后定案——本段未定）

### 5.1 三层复用原则（修正版）

```
LCOS GUI = Huabu Common primitives（替换 Lcos*）
         + Huabu 画布/编辑/图标/浮层（xyflow/milkdown/lucide/floating-ui）
         + 专门轮子补齐缺口（cmdk/arborist/mind-elixir/cytoscape/vis-timeline/panels/motion）
         + 唯一自绘：Glyth 保真 SVG
```

**明确不做**：不引 shadcn（Huabu Common 已覆盖）；不引 React Bits（Commons Clause + 营销动画不符）；不引 radix（Huabu Popover 已够）。

### 5.2 接入方式（沿用既有架构，不动 Huabu 原文件）

- 新增代码集中在 `Huabu/apps/web/src/lcos/`（ui/canvas/work-view/composer/instruments/glyph）。

- 需要时对 Huabu 六处文件做薄接缝（宪法 §9 不变）。

- 专门轮子用 `pnpm add`，图标/材质/字体现成套用 Huabu 既有。

### 5.3 待定项的临时规避

在 §4 未核实前，凡是「待核实」的组件一律不写进最终映射，等核实后回填。

\*\*\*---

## 6. 我们早期的视觉参考档案（本次补充 · 这才是视觉基准）

用户提醒后补挖——这才是「我们自己的视觉基准」，比外部 UI 库准确得多。全部为本机已存的档案（部分为 MIT 开源，部分是私有/grok-bot 参考）：

### 6.1 Apple / macOS 官方视觉（`ios26-design-system`，MIT）

文件：`E:\OS开发\LCOS0.15收口\苹果mac设计套件_ios26-design-system_源码合并版.md`（141 文件）

- **design token 源**：`packages/tokens/src/{colors,materials,spacing,typography,animations}.json`——Liquid Glass 玻璃材质参数在 `materials.json`。

- **36 个组件规格**（`specs/`）+ 48 页面模板（iphone/ipad-examples/）。

- **四模式契约**：Light/Dark/Increased-Contrast-Light/Increased-Contrast-Dark；禁纯黑白（用 `#0B0B0F`/`#F2F2F7`）；WCAG 对比度表（muted 用 `#52525B` 而非 `#8E8E93`）。

- **关键启示**：参考图的「Apple 感」= 这个 token + Liquid Glass 系统，不是 shadcn。

### 6.2 SwiftUI 语法（`SwiftUI-For-Web`，MIT）

文件：`E:\OS开发\LCOS0.15收口\SwiftUI-For-Web_JS源码合并版.md`（146 文件）

- SwiftUI API 的 JS 实现，零依赖，Web Animations API + CSS + View Transitions。

- 参考：组合式布局（VStack/Text/Button/ForEach）+ 修饰链（.padding()/.foregroundColor()/.cornerRadius()）+ 状态（ObservableObject）。

- **用途**：Arc/Composer/Work View 的布局与动效语法参考（克制、可预测）。

### 6.3 grok-bot（私有参考，DZWFLi）

文件：`E:\OS开发\LCOS0.15收口\grok-bot_前端源码合并版.md`（185 文件）

- `src/recovered/ui/sand-kit-primitives`（`SandButton` 等）+ `ProductionRenderer`/`CommandPalette`/`Agent*` 系列。

- **Donor 裁决**（草案 §8）：Agent row actions → Glyth Action Arc/Right-click；connection state → Glyth morphology/motion；permission → Composer/Run 瞬态权限 UI；async state → Work View/Run/Search/Warehouse 公共状态。

- **不可复制**：sidebar-first / chat-first 结构（踩 No-Go #11 大侧边栏）。

- **结论**：「agent 界面语言」用 grok-bot 语义，不比任何外部轮子差。

### 6.4 FigmaMake 视觉基准（已冻结，最权威）

文件：`E:\OS开发\GEN2\LCOS_Gen2_FigmaMake_Pack_20260901\guidelines\`

- **03\_VISUAL\_LANGUAGE.md**：Bright/quiet/spatial/precise；Liquid Glass 只用于 chrome/浮动控件；porcelain 白+soft neutral 体；低饱和；发丝线；低噪；更多对象剪影少卡片剪影。层级 = 内容 > 关系 > 瞬态控件 > chrome。

- **05\_MOTION\_MATERIAL.md**：运动解释连续性（非装饰）；时长词汇（微 100ms / 快 180-220 / 常 260-360 / Dock 320-450）；材料栈（chrome 强透 / dock 软分离 / 瞬态强 blur / 内容原生）；reduced-motion。

- **06\_NO\_GO\_SUPERSEDED.md**：#4 禁通用卡片 anatomy；#5 禁常驻按钮排；#11 禁大侧边栏；#12 **禁 ReactFlow 审美**（节点编辑器 = 端口/盒子/常驻标签）。

### 6.5 对象物种与 Glyth（已冻结）

- `04_OBJECT_SPECIES.md`：Image/PDF/Text/Link/Glyth/Skill/Run/Collection/Surface Component 各自的形态纪律。

- Glyth：深石墨近黑身体 + 两眼 + 克制 accent；Near 完整 / Mid 可辨 / Far 归 map-pin 族。

### 6.6 Bloub + Motion donor（已登记）

- `LCOS_GLYTH_INTERACTION_MOTION_DONOR_CENSUS_20260901.md`：Glyth presence / 眨眼 / 注视/状态过渡的 donor 算法。

- `P3_INTERACTION_MOTION`（framer-motion 源码）：`motion` 已可复用（MIT）。

***

## 7. 视觉基准结论（修正）

**LCOS Gen2 的「视觉怎么来」优先级（从高到低）**：

1. **我们自己的视觉档案**（ios26 token + FigmaMake Visual Language + No-Go + grok-bot agent 界面）——这是审美基准，不是外部库。
2. **Huabu 自带**（Common primitives + 画布 token + lucide 图标 + motion）——交互与组件基座。
3. **外部轮子只补缺口**（cmdk/arborist/cytoscape/vis-timeline/mind-elixir/panels——都是 instrument，不碰视觉主调）。
4. **明确排除**：shadcn（第二套设计语言 + 踩 No-Go #11/#12）、React Bits（Commons Clause 禁售源码 + 营销动画踩 No-Go #4/#12）。

**一句话**：参考图的 Apple 感，版权归 `ios26-design-system` + 我们自己的 FigmaMake 视觉语言；组件用 Huabu Common；图标用 lucide；agent 界面用 grok-bot 语义；Glyph 自绘。外部轮子只在仪器层补缺，绝不决定视觉主基调。

***

*关联：节点宪法（§9.5 donor 准入法）、摸牌四（donor 许可证）、全功能主计划（H0-H6）、Gen1 差异分析（§8.2）、FigmaMake guidelines（视觉基准）。*

***

## 8. 轮子优先 · 标准可改（本次核心定调，覆盖前几轮）

### 8.1 用户定调

> 「一边是轮子，一边是标准。**轮子优先，标准是可以改动的**。」

含义：不是「死守我们的 ios26/FigmaMake 标准、让轮子迁就标准」，而是反过来——**把成熟轮子用满，标准为让轮子落地而调整**。审美的责任交给轮子，我们的标准只保留「LCOS 身份」这一层不可让步的内核。

### 8.2 三层：哪些是可让步的「标准」，哪些是不可让步的「身份」

| 层                      | 内容                                                                                                                    | 是否可让步          | 理由                                              |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------- | -------------- | ----------------------------------------------- |
| **A. 纯视觉表皮**           | 配色/材质/圆角/阴影/图标风格/卡片形态/按钮排布                                                                                            | **✅ 全让给轮子**    | 这是审美，正是我们要借轮子的地方；我们自己的 ios26 视觉档案是「备选」，不是「必须守住」 |
| **B. 交互机械**            | 指针/相机/选择/拖拽/connect/resize/LOD                                                                                        | **✅ 让给 Huabu** | Huabu Mechanics 现成，质量高于自研；LCOS 不重造              |
| **C. LCOS 身份内核**（唯一不让） | Glyth 形态、Selection≠Reference、Action Arc 契约、去节点化（Objects not generic nodes）、Skill≠Run、Work View 生命周期、仪器直接操纵、Core 为领域真值 | **❌ 不让**       | 这是「为什么是 LCOS 不是别的东西」；轮子必须适配它，不能反过来定义它           |

### 8.3 重新校准的「轮子利用矩阵」（标准让位后）

| 用途                | 轮子（第一选择）                                                                            | 用户标准（原）                    | 让步裁决                                                      |
| ----------------- | ----------------------------------------------------------------------------------- | -------------------------- | --------------------------------------------------------- |
| 视觉表皮（配色/材质/圆角/阴影） | **Huabu Common +** **`--fg/--bg/--edge`** **token**（现成、已一体）                         | ios26 token + Liquid Glass | ✅ **用 Huabu 默认，不强行套 ios26**；需要时再叠 LCOS token 层            |
| 卡片/面板形态           | **Huabu** **`Popover`/`FloatingToolbar`/`EmptyState`** **+ shadcn card（如需）**        | No-Go #4 禁通用卡片             | ✅ **让步**：通用面板壳可用 shadcn/Huabu（对象物种除外——对象仍走物种 morph，见 C）   |
| 图标                | **lucide-react**（已在依赖，SF 风格 monochrome）                                             | 自绘 iconShapes              | ✅ **全部 lucide**（SF 风格正合参考图），iconShapes 退休                 |
| 按钮/分割/分段          | **Huabu** **`Button`(variant/tone/size) +** **`TabGroup`** **+** **`DropdownMenu`** | Arc/右键分工                   | ✅ 用 Huabu；Arc 语义（3/4 上限）保留为行为契约                           |
| 命令菜单/搜索           | **cmdk**                                                                            | 自有搜索面板                     | ✅ 引入 cmdk，壳按 LCOS                                         |
| 大纲/树              | **react-arborist**                                                                  | 自有树                        | ✅ 引入                                                      |
| 关系场               | **cytoscape.js**                                                                    | 自有关系视图                     | ✅ 引入                                                      |
| 时间线               | **vis-timeline**                                                                    | 自有时间线                      | ✅ 引入                                                      |
| 思维导图              | **mind-elixir-core**                                                                | MindMapEditor              | ✅ 引入                                                      |
| 动效                | **motion（framer-motion）**                                                           | 自研动效                       | ✅ 引入                                                      |
| 分栏                | **react-resizable-panels**                                                          | 自研分栏                       | ✅ 引入（Work View 缺口）                                        |
| 富文本               | **@milkdown**（已在依赖）                                                                 | InlineNoteEditor           | ✅ 用 Huabu                                                 |
| AI/agent 界面       | **grok-bot sand-kit 语义**（不抄结构）                                                      | —                          | ✅ 参考行为，不抄 sidebar/chat-first                              |
| 点缀动效              | **React Bits**（选型：BlurText/Dock/Spotlight 类，避开营销页大动效）                               | ios26 克制                   | ⚠️ **有限引入**（只取克制组件，避开 Commons Clause 分发风险 + 避开 No-Go 大动效） |

### 8.4 明确让步掉的标准条款（原 No-Go / ios26）

| 原标准                          | 让步为                                                                                                       | 因为               |
| ---------------------------- | --------------------------------------------------------------------------------------------------------- | ---------------- |
| No-Go #12「禁 ReactFlow 审美」    | **放宽**：Huabu 用 ReactFlow 是底坐，但「节点编辑器观感（端口/盒子/常驻标签）」通过物种 morph + Action Arc + 去节点化规避，不靠裸 ReactFlow 呈现      | 轮子优先，座必须是 Huabu  |
| No-Go #4「禁通用卡片 anatomy」      | **部分让步**：通用面板壳（settings/warehouse/tab）可用 shadcn/Huabu card；**但对象物种（Image/PDF/Glyth/Skill/Run）仍走物种 morph** | 面板≠对象；对象才守 C 层身份 |
| ios26「四模式 Light/Dark/IC 契约」  | **暂不强制**：先单模式（浅色瓷白），暗色/高对比作为 H6 增强                                                                        | 轮子优先，先跑通         |
| ios26「Liquid Glass 强玻璃参数」    | **改为 Huabu 默认半透明浮层**（`FLOATING_CHROME_PROPS`），需要时再叠参数                                                     | Huabu 已有一致浮层材质   |
| grok-bot「sidebar/chat-first」 | **仍禁止**（C 层：LCOS 是空间操作系统，不是聊天壳）                                                                           | 身份不让             |

### 8.5 落点（与既有「视觉基准」合并后的最终方向）

```
LCOS Gen2 GUI =
   轮子（最大化用满）
     ├─ Huabu Mechanics（指针/相机/选择/拖拽/connect/resize/LOD）—— B 层
     ├─ Huabu Common primitives（Button/Select/Popover/Modal/Tooltip/Toast/... + cn + token）—— AB 层
     ├─ lucide-react 图标 —— A 层
     ├─ shadcn（仅补 Huabu 缺的：card/tabs/command 等）—— A 层
     ├─ cmdk / arborist / cytoscape / vis-timeline / mind-elixir / panels / motion —— 仪器层
     └─ React Bits（克制点缀，可选）—— A 层
   +
   标准（只留不可让步的内核）
     ├─ Glyth 形态（深石墨+双眼）—— C 层（自绘 SVG）
     ├─ Selection ≠ Reference —— C 层
     ├─ Action Arc 3/4 契约 —— C 层
     ├─ 去节点化（对象物种 morph，非通用卡片）—— C 层
     ├─ Skill ≠ Run —— C 层
     ├─ Work View 生命周期（Spatial/Focus/Docked/Immersive）—— C 层
     ├─ 仪器=直接操纵 —— C 层
     └─ Core 领域真值 —— C 层
```

**一句话**：A/B 层（视觉表皮 + 交互机械）**全交给轮子**（Huabu + shadcn + instrument 库），**标准降为仅 C 层身份内核**。这正是「最大化利用轮子」——不再用我们自己的 ios26/FigmaMake 视觉细节当硬约束，只保留「LCOS 是什么」的骨架。

***

## 9. 对象 = 完全隐形壳，只露选中边框（本次源码确认 · 去节点化的真实现）

### 9.1 结论：Gen1「没有实现好」，不是「没有」

掰开 `CanvasNodeVisual.tsx` + `ui-primitives.css` 后确认：**Gen1 早已实现「物种形态 + Apple 设计 token」，只是被一层通用材质卡壳盖住，导致看起来像是卡。**

### 9.2 源码证据（实拉核实）

`ui-primitives.css`（Apple 风格 token 全在）：

- `--lcos-ui-accent:#0088ff`（light）/`#0091ff`（dark）——accent/focus 环

- `--lcos-ui-label-primary:rgba(0,0,0,.85)` / `--lcos-ui-label-tertiary:rgba(60,60,67,.3)`——**Apple 式 label 层级**

- `--lcos-ui-fill-secondary:rgba(120,120,128,.16)`——fill

- `--lcos-ui-destructive:#ff383c`——destructive

- `--lcos-ui-glass-bg:rgba(255,255,255,.72)` / `--lcos-ui-glass-border:rgba(255,255,255,.3)`——**Apple 毛玻璃**（popover/menu/tooltip 用）

- `.lcos-icon`：**基于 lucide**（SF 风格），`glyph` 只 tint 12%/14%、`currentColor`——苹果图标纪律

- `.lcos-orbit-sat`：**Action Arc 已实现**——38px visual body/pill、round、14px blur、贴右上角、Esc/外点关闭（A22 契约的样式落地）

- `.lcos-drop-feedback`：五阶段语义 drop feedback、Apple ease-in-out

`CanvasNodeVisual.tsx`（物种形态已分）：

- `ImageObject`：裸图无壳、`lcos-image-object`、无边框

- `MaterialPaperFallback`：纸面即身份（白底 + 1px hairline + 极浅折角、「不造大卡」、letterhead 内嵌）

- `SlideDeckFallback`（16:9 页叠）、`ArchiveBundleFallback`（包叠堆）、`GenericFileFallback`（文件剪影 + 扩展名）

- `DocumentObject`：markdown 用 `DocumentSemanticBody`（直接读）、缩略图 `is-direct-reading`，否则 `is-collapsed-material`

### 9.3 元凶：卡壳来自 `material-face` 常驻边框 + 常驻标题条

对象 body 的根 class 是 `lcos-object lcos-material-face lcos-node-dot-identity`——**`lcos-material-face`** **这根「材质卡面」给了常驻底色/边框，`lcos-object-caption`常驻标题条**，所以即便是 `ImageObject`（裸图）也被包成一张卡。

### 9.4 实现规则（把已有的「去卡壳化」）

**对象外层 = 完全透明的壳。** 没有背景、没有常驻边框、没有常驻标题条。只有在 `selected` 时才显边框（outline 环）。

```css
/* 对象壳：默认完全透明 */
.lcos-object {
  background: transparent;
  border: none;
  box-shadow: none;
}
/* 只有选中才显边框（克制，不发光、不套多色） */
.lcos-object.is-selected {
  outline: 1.5px solid color-mix(in srgb, var(--lcos-ui-accent) 55%, transparent);
  outline-offset: 2px;
  border-radius: 8px; /* 若物种本体是矩形（纸/文件）则 0-4px；圆角物种再定 */
}
```

**标题行**：从「常驻 caption 条」改为「**到近 zoom / hover 才渐进披露**」，呼应 FigmaMake `03_VISUAL_LANGUAGE` 的「dynamic scale——远 zoom 保剪影，近 zoom 渐进披露 label」。

**caption 不再是卡的一部分**：图下小标题、PDF 角落分页角标等，悬浮/近距才出现；对象本体保持「物种原样」。

### 9.5 落到 Gen2（配合轮子优先 + 标准可改）

- **对象壳**：Huabu node 的 `selected` 态已自带 rim（NodeWrapper）——直接吃 Huabu 的选中框，**不另造**。

- **species body**：Gen1 那套 `visualFamilyFor` + `*Fallback`（Paper/SlideDeck/Archive/GenericFile/Image）**原样迁移**，但外层去掉 `material-face` 常驻壳。

- **材质**：`--lcos-ui-*`（accent/label/glass/fill/destructive）即 Apple 标准，**不需要重新发明**；需要时叠 Huabu `--fg/--bg/--edge`。

- **Arc**：`.lcos-orbit-sat` 样式迁到 Huabu `FloatingToolbar`/`DropdownMenu` 壳（语义 A22 契约即 3/4 上限 + Esc）。

- **图标**：lucide（已在依赖）。

- **caption**：近 zoom/hover 披露，不常驻。

### 9.6 一句话

> **对象 = 物种原样 + 透明壳 + 仅选中显边框 + label 近距披露。Gen1 的物种形态和 Apple token 都在，只是被** **`material-face`** **常驻卡壳盖住了；去掉那层，就是「完全隐形卡片、只露选中边框」。**

***

## 10. 交互承接（核心方法论修正）：用 Huabu 交接触发，我们只改形状

> 用户启发（2026-09-02 晚）：不要「找轮子替代 LCOS 概念」，而应「**看 Huabu 提供什么交互，把 LCOS 概念用 Huabu 机制承接 + 改外观形状**」。最大化利用 Huabu 已有的交互（而它已经很多），我们只做外观/形状。下面每个概念都按这个思路重想。

### 10.1 已完成核实的 Huabu 交互底座

| Huabu 交互         | 源码                                                                                           | 说明                                                                                                                                             | <br />                                           |
| ---------------- | -------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------- | :----------------------------------------------- |
| **frame 容器/分组**  | `frame/index` + `geometry/detection/mutation/sizing/fit` + `useFrameDragToCreate`            | `parentId` 嵌套、`hug/manual` sizing、free/column/row/grid 布局、`autoFrameNodeByOverlap`、`findBestFrameForNode`、`collapsedFrameIds` 折叠/展开、内嵌重命名、取消框架 | <br />                                           |
| **工具栏·随类型变**     | `NodeFloatingToolbar` / `MultiSelectToolbar` / `EdgeStyleToolbar` / `StrokeSelectionToolbar` | 全部 i18n；**节点类型/多选/边线/笔画四种语境下工具栏不同**——切换 surface 可复用这套「工具栏随上下文变」机制                                                                              | <br />                                           |
| **Work View 承载** | `previewWorkspace/model.ts` + `actions.ts`（`openPreviewNode`/`openPreviewTarget`）            | \`PreviewTarget = {kind:'node'                                                                                                                 | 'chat', canvasId}`（待扩 `    entity\`）；双击开 Preview |
| **多画布**          | `canvasStore` `canvasId` + `viewportStorageKey(canvasId)`                                    | 不同 canvasId 可独立 viewport/绑定                                                                                                                    | <br />                                           |

### 10.2 用 Huabu 交互承接 LCOS 概念（改形状版）

| LCOS 概念                       | 原实现（改为这样承接 Huabu）                    | 借 Huabu 交互                                                                                          | 我们改/补的形状                                                                                             |
| ----------------------------- | ------------------------------------ | --------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- |
| **子画布 / Scope**               | 原来是 `node.scopeId` 分区                | **用 frame 嵌套 +** **`collapsedFrameIds`**：scope = 一个可折叠 frame 容器，展开=子画布                              | frame 形状改成像「scope 空间」，标题=scope 名，双击折叠进入                                                              |
| **三视图 Main/Context/Workflow** | 一组独立 Surface（63KB 屎山）                | **同一 canvas 内，靠工具栏/Surface 档位切换**：切 view 时工具栏变（复用 Node/MultiSelect/Edge toolbar 机制）+ 画布语义变（投影/仪器不同） | 顶栏加 Surface 切换 tab；切到 Context 时工具栏出现 Structure/Evolution/Relation 仪器按钮；切到 Workflow 出现 Action Path 按钮 |
| **Collection / 集合**           | `collectionExpandLayout`(fan-out 网格) | **frame 容器 + 布局模式**：Collection = 一个 hug 的 frame，grid/column 布局兜住成员                                  | frame 形状=Collection micro（Glyth），近 zoom 才显边框（去卡壳）                                                    |
| **Clonny / Colony 聚簇**        | 聚簇布局                                 | **`autoFrameNodeByOverlap`**：拖近自动成组                                                                 | 聚簇氛围（subtle field）                                                                                   |
| **Assembly / 装配台**            | 项目级共享 warehouse、object markers、分栏    | **Work View dock + frame 分栏（target 一侧、warehouse 一侧）+** **`react-resizable-panels`**（拆分）+ 拖拽         | 用 Huabu Work View（PreviewWorkspace）当装配台；用 frame + panels 做左右分栏；拖入用 Huabu 原生 drop                     |
| **Skill Builder / 自定义编辑**     | 大纲+思维导图直接操纵                          | **`react-arborist`(大纲) +** **`mind-elixir`(导图)+ Work View dock**                                    | 编辑器挂 Work View                                                                                       |
| **Glyth**                     | 自绘 SVG                               | 无现成                                                                                                 | **自绘（Bloub+另一项目）**，借 Huabu 的 node 壳 + `useNodeTakeover`                                              |

### 10.3 关键洞察（用户视角）

> 「子画布实际上可以用**嵌套画布**来做——嵌套画布还能继承**方便缩放**的点；collection、三视图都是一样的意思。现在画布不是有**工具栏**吗？是不是就可以直接借用：切 Surface 之后工具栏跟着变。利用**嵌套伪装 scope**完成三视图效果。最大化利用 Huabu 提供的交互，我们只改**外观形状**。」

**核心就是：Huabu 的 frame（嵌套/折叠/分组/布局）+ 工具栏（随上下文变）+ Work View 是三个「现成交互底座」。LCOS 的这些概念都不用自己画，而是「映射到这三类交互上 + 改形状」。**

### 10.4 待验证（下一步要证的）

1. frame 的 `collapsedFrameIds` 折叠后，双击是否即「进入子画布」？还是需要我们在 NodeWrapper 加 dblclick→openScope 的映射？（FrameNode 目前双击是重命名/开 toolbar，不是进 scope）
2. frame 能否承载「Scope 身份」——frame ↔ Binding 的映射（frame spatialId → Core scopeId）？
3. 工具栏切换 surface：是加 `SurfaceTab` 状态，还是复用 canvasId 切画布？——倾向**切 canvasId 但视觉像同一画布**（伪造），或**同一 canvasId 内 frame 分组当 scope sandbox**。
4. `react-resizable-panels` 是否必要，还是 Huabu Work View + frame 分栏就够（Panels 是 B6 缺件，宪法 §9.5 标记「仅当 PreviewWorkspace 不够才引入」）。

### 10.5 一句话

> **做「交互承接」而非「轮子替代」。凡是 Huabu 已有交互（frame 嵌套/折叠/分组/布局、工具栏随语境变、Work View dock、原生 drop），LCOS 概念就映射上去 + 改外观形状；只有 Huabu 完全没有的（Glyth、大纲/mind-map 编辑、关系场/时间线这类 instrument）才补充专门组件（arborist/mind-elixir/cytoscape/vis-timeline，也都只是 dock 内的 instrument，不接管画布）。**

***

## 11. 三视图方案定案（A2 · 更隔离·复刻 LCOS 工作现场）

> 用户裁决（2026-09-02 晚）：**A2 更隔离**。关键理由：「我们要把 LCOS 的体验复刻完全，A1 那种（一张画布内隔离节点+摄像机移动）不行——LCOS 三视图是**真正独立的空间现场**（各自摄像机/视口/选择/历史）。」以下用 Huabu 现成的多画布机制承接。

### 11.1 已核实的 Huabu 多画布机制（承载三视图的底座）

| 机制                               | 源码                                                          | 作用                                                                                                  |
| -------------------------------- | ----------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `switchCanvas(canvasId)`         | canvasStore.ts L2053                                        | **干净彻底切换**：flush 当前保存 → cancel 队列 → 清 viewport → 加载新 canvas。**天然是「切到另一个工作现场」**                      |
| `loadCanvas(canvasId)`           | canvasStore.ts L1882                                        | `isLoading`/`getCanvas`/`canvasHistoryManager.activate`/独立 viewport（`viewportStorageKey(canvasId)`） |
| 按 canvasId 独立 viewport           | canvasStore.ts L216 `viewportStorageKey`                    | 每个画布**独立摄像机**                                                                                       |
| `PreviewWorkspace.loadForCanvas` | actions.ts                                                  | 每个画布**独立 Work View**                                                                                |
| 双击进 Preview                      | Canvas.tsx L1547 `onNodeDoubleClick`（`EXPANDABLE_TYPES` 门控） | 子画布进入入口的缝隙                                                                                          |

### 11.2 三视图 = 三个独立 canvasId（复刻 LCOS 工作现场）

```
根项目
 ├─ Main  canvasId = main      （材料/浏览/参考）—— 摄像机 A / 选择 A / 历史 A
 ├─ Context canvasId = context （结构/演进/关系/来源仪器）—— 摄像机 B / 选择 B / 历史 B
 └─ Workflow canvasId = workflow（行动路径/物料流/run）—— 摄像机 C / 选择 C / 历史 C
   ↑ 共用 React Flow 物理内核 / 共用 Gen2Host+RFS+Binding；
     只是 canvasId 不同 → 摄像机/视口/选择/历史/Work View 各自独立（LCOS 工作现场）
```

- **切换**：顶栏 Surface tab（Main/Context/Workflow）→ `switchCanvas(canvasId)`。

- **每个视图独立的一切**（摄像机/视口/选择/历史/Work View）= Huabu `canvasId` 天然给；`viewportStorageKey`/`canvasHistoryManager.activate`/`loadForCanvas` 全部按 canvasId 隔离。

- **Sub canvas / Scope**：进入 scope = 再切一个 canvasId（子画布），同样独立视口（继承嵌套画布可缩放点）。

- **语义**：三视图投影不同 + 各自仪器（Context=Structure/Evolution/Relation/Source；Workflow=Action Path/run）——由 `lcos/surfaces/surfaceProfile` 注入，不动 Huabu 画布物理。

### 11.3 与你启发的一致性

- 你选 **更隔离** → 对应 `switchCanvas`（真正切画布，不是画布内隔离）。

- 「三视图是独立空间现场」→ 各自 canvasId 的摄像机/选择/历史。

- 「工具栏随 Surface 切换变化」→ 切 canvasId 后，工具栏按当前 surfaceProfile 注入仪器按钮（复用 Huabu toolbar 随语境变机制）。

- 「嵌套画布可缩放」→ 子画布/scope 用 `switchCanvas` 进新画布，天然独立可缩放视口。

- 「只改外观形状」→ 画布物理/切换/Work View/drop 全用 Huabu；我们只加 Surface tab、仪器注入、形状（透明壳/Glyth/Collection micro）。

### 11.4 待验证的 2 个细点（下步）

1. `switchCanvas` 切到不存在的 canvasId 会不会 404？——子画布/三视图的 canvasId 需要先在 Core 创建（作为子画布实体），否则加载失败。→ 需在 Core 端为三视图/子画布建「画布实体 + Binding」，或复用「一个项目多 canvas」的持久化。
2. 三视图各自的节点集合是**不同 canvasId 的独立节点**（完全隔离），还是同一 Core 项目的**投影**（同一批实体，不同画布展示不同）？——这决定「三视图是三个独立画布」还是「一个画布三种投影」。你选 A2 更隔离，倾向**独立画布**（各自真实节点），但需想清楚跨视图的一致性（同一实体在 Main 改了，Context 要不要同步）。

### 11.5 一句话

> **A2 定案：三视图 = 三个独立 canvasId 的独立空间现场（摄像机/视口/选择/历史/Work View 全独立），用 Huabu** **`switchCanvas`** **现成机制切换；子画布/scope = 再切一个 canvasId。我们只加 Surface tab + 仪器注入 + 外观形状，画布物理全用 Huabu。这真正复刻 LCOS 的工作现场体验。**

***

## 12. 层级约束（最高层级 · 推翻 A2 的「独立 canvas 文件」）

> 用户裁决（2026-09-02 晚）：「理清层级。LCOS 目前的项目导入导出机制——**别和 Huabu 一样是一张张 canvas 来作为一个项目**。Huabu 现在是只新建/打开一个 canvas，你要是拆开来完全就不是 LCOS 的样子。」

### 12.1 LCOS 项目层级（源码实证：`.lcosproj`）

`apps/local-core/src/lcosproj-service.ts`（已实读）：

- **`.lcosproj`** **= 一个 Project 的自包含文件单位**（schema v18）。

- export 走 `exportProjectTruth(projectId, tmpPath)`——把**整个 Project truth**（Project + FileRecords + conversation\_sessions + 元数据）打包进一个 `.lcosproj`。

- `relativePaths` 记录所有文件记录；`inspect/open` 恢复整个 Project。

- **一个 Project = 一个** **`.lcosproj`** **文件**。

`打开工程文件（.lcosproj）/ onImportLcosproj / application/vnd.local-creative-os.project`（R1B patch 实证）= 项目打开/导入的 UI。

### 12.2 层级真相（LCOS 是「Project 整体」，不是 canvas 碎片）

```
Project（.lcosproj，一个自包含真值单位）
 ├─ Main        —— Project 内的一个工作现场（投影）
 ├─ Context     —— Project 内的一个工作现场（投影）
 ├─ Workflow    —— Project 内的一个工作现场（投影）
 ├─ 子画布/Scope —— Project 内的嵌套层次（投影）
 ├─ Collection  —— Project 内的成员集合（投影）
 └─ ...         —— 全部是 Project 内部的层次与投影，不是独立持久化 canvas
```

**禁止**：把 Project 拆成「Main/Context/Workflow/子画布」几个独立 `canvasId` 文件——那会撕碎 `.lcosproj` 的完整性，**完全不是 LCOS**。

### 12.3 因此：三视图/子画布 = Project 内层次，借助 Huabu 但**不拆成独立 canvas 文件**

- **Project 在 Core（.lcosproj）持有完整真值**；Huabu 只是**这张 Project 的一个空间视图宿主**。

- Huabu 的「一个 canvas」物理上是我们**借用的渲染画布**，但**不能**成为 Project 的持久化单位。

- 三视图/子画布/scope/collection：在 **Core 端**它们是 Project 内部的实体/关系/层次（`scopeId`/`collection members`/`surface profile`），在 **Huabu 端**它们可以借 frame/分组/多个渲染空间 **投影**，但**投影不能各自持久化成独立 canvas**——所有几何/成员/身份都回到底层 Project truth（经 Gen2Host/RFS/Binding 的 ProjectionBinding，而非 Huabu 的独立 canvas 存储）。

### 12.4 关键结论（修正 A2）

> **A2 的「三个独立 canvasId」在「Project=.lcosproj 整体」前提下是错的。** 正确的做法：
>
> 1. **Project 真值单元** = Core 的 Project（.lcosproj），而非 Huabu canvas。
> 2. **Huabu 只当一个空间渲染宿主**，承载 Project 的一张/多张空间视图。
> 3. **三视图/子画布/scope/collection** = Project 内的**层次与投影**（surface profile + scopeId + collection membership），用 Huabu 的 frame/分组/渲染空间做**视觉投影**，**几何/身份经 ProjectionBinding 回写 Core**。
> 4. **绝不能**让 Huabu 的多个 canvasId 成为「一个项目的多个文件」——那会破坏 `.lcosproj` 整体。

> 一句话：**LCOS 的层级是「Project（.lcosproj）整体 = 真值 + 持久化单位」；三视图/子画布/scope/collection 只是 Project 内部的层次投影，可用 Huabu 的渲染空间与 frame 做视觉投影，但投影不拆成独立持久化 canvas。层级必须理清在 Project 这一层，不是 canvas 这一层。**

***

## 13. 投影 = LCOS 精髓（源码级 · 三视图发散 · 全局核实）

> 用户裁决（2026-09-02 晚）：「肯定是投影啊，这是 lcos 的精髓，要不然花大力气做的 gen1 有什么用。再深入看其它前端的 lcos 实现，对应到 huabu，源码级对照，从投影和三视图发散。」本节记录全局核实的投影链路（从前端源码实拉），并从三视图发散到各仪器 / Surface 切换 / Scope 呈现 / Attention / role。

### 13.1 投影核心链路（已确认，从「一份 universe」投影出所有视图）

| 文件                              | 源码证据                                                                                                                                                                                                                       | 投影作用                                           |
| ------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| `projectEntityProjection.ts`    | `PresentationEntityRefV0`（view/scope/workspace/conversation）+ `projectEntityNodeIds` + `materializeProjectEntityNodes`                                                                                                     | 实体 ref → canvas 节点；**真值一份（这些 ref），投影成不同节点**    |
| `ProjectionSurfaces.tsx`        | props `nodes/edges` 传给所有 surface；注释「All capability surfaces project the **same Project node identities**」；`common = {nodes,edges,selectedIds,onSelect}` 对所有 surface 共享                                                     | **三视图/Context 各面共享同一 universe + 同一 selection** |
| `capabilityViewResolver.ts`     | `resolveContextView(nodes,edges,intent)` / `resolveWorkflowView(nodes,edges,intent)` 纯投影；注释「Presentation helper only; it never decides Core membership or Project Truth」「Workflow never invents membership from node kind」 | 从同一 universe 投影子集 + 不同强调；**不创建第二真值**           |
| `deriveContextGraphAutoNodeIds` | 按实体身份（context/collection/decision）+ 标题线索推断进 Context Graph；注释「Physical Scope must never gate eligibility」                                                                                                                   | 投影跟 Scope 无关，只看实体身份                            |
| `surfaceContracts.ts`           | `SurfaceAttentionMarks`（pinned/related/retrieved）注释「read-only Presentation projection」；`ContextHistoryEntry`/`WorkSurfaceRuntime`/`DeliverSurfaceRuntime`                                                                  | Attention/历史/run 都是只读投影痕迹                      |
| `surfaceModel.ts`               | `nodeRole(node)`（artifact/feedback/session/run/skill/decision/context/note）+ `statusLabel`（Draft/Current/History/Running/...）                                                                                              | 同一节点投影成不同 role / 状态强调                          |

### 13.2 三视图 = 投影，不是独立画布（`SurfaceDock.tsx` 铁证）

- `SurfaceId`：`arrange/outline/context-space/context-flow/context-tree/context-graph/workflow/...`（**一组投影面，不是一组画布**）。

- `SURFACE_ENTRIES = {main 主画布 / context 上下文 / workflow 工作流}` —— **三 capability**，切换只调 `onSurface('arrange'/'context-space'/'workflow')`，**不切画布、不隔离节点、只是换投影面**。

- `capabilityForSurface(surface)`：normalize 后把 surface 归到 main/context/workflow 三档 —— **一个 capability 下可有多面**（Context 有 outline/space/flow/tree/graph 多个 lens）。

- Scope/现场 = **导航层次**：scope 面包屑（返回 parent / 当前现场 / 「并回主画布」）—— Scope 是层次，非独立画布。

- `normalizeSurfaceId`：legacy work/deliver 会被迁到 `workflow` —— 说明「surface」是投影面，历史值可归一化迁移。

### 13.3 由此发散：LCOS 前端「投影」贯穿全身（同一批实体，多个强调）

| 概念            | 实现                                                                     | 投影方式                                        |
| ------------- | ---------------------------------------------------------------------- | ------------------------------------------- |
| Main          | arrange（项目材料浏览）                                                        | universe 全量，内容形态最强                          |
| Context       | context-space/flow/tree/graph（Structure/Evolution/Relationship/Source） | `resolveContextView` 同一 universe 投影 + 各仪器强调 |
| Workflow      | workflow（Action Path/run/skill）                                        | `resolveWorkflowView` 同一 universe 投影 + 行动强调 |
| Scope/现场      | scope 面包屑 / 当前现场 / 并回                                                  | **导航层次**（不是画布），same universe                |
| Collection/集合 | collectionExpandLayout（fan-out）                                        | universe 内成员集合的展开布局                         |
| Attention     | pinned/related/retrieved（`SurfaceAttentionMarks`）                      | 只读投影痕迹，不改 selection                         |
| role/status   | `nodeRole`/`statusLabel`                                               | 同一节点 → 不同 role/状态强调                         |

### 13.4 LCOS 精髓（总结）

> **一个 Project universe（nodes+edges，真值在 Core）= 唯一；三视图/Context 各 lens/Workflow/Scope/Collection/Attention/role 全都只是「从同一 universe 用** **`resolve*View`/推断函数投影出的不同强调了」。实体改一处，就一处，处处同步。Surface 切换 = 换投影面（onSurface），不改画布、不隔离节点。Scope/Collection = 同一 universe 内的层次，非独立画布。**

> 这也正是 Gen1 花大力气做出来的「投影」——**它比 Huabu 的「单 canvas 单视图」高一个维度**。Gen2 若照搬 Huabu「一 canvas 一文件 + 把三视图拆成独立 canvasId」，就把这个精髓丢了（回到 §12 的坑）。

### 13.5 对照 Huabu：Huabu 缺的是「投影层」，不是「画布」

| 能力         | LCOS（已有投影）                                            | Huabu（单 canvas）        | Gen2 该做的                                                                           |
| ---------- | ----------------------------------------------------- | ---------------------- | ---------------------------------------------------------------------------------- |
| 多面投影       | `resolveContextView/resolveWorkflowView`（同一 universe） | **无**（一 canvas 一 view） | **把「投影层」加在 Huabu 之上**：Huabu 承载 universe 的空间视图，我们（Gen2Host/接缝）加 `resolve*View` 投影强调 |
| Surface 切换 | `onSurface`（换投影面）                                     | 无                      | 顶栏 Surface tab → 切换 Huabu 上的投影强调（不切 canvasId 文件）                                   |
| Scope 层次   | scope 面包屑/并回                                          | 无（frame 是物理分组）         | 用 Huabu frame 做 scope 的**物理呈现**，但 scope **身份/层次在 Core**（Binding），非独立 canvas        |
| 实体一份       | `PresentationEntityRefV0` 真值                          | canvas nodes 各自        | Core 持有真值，Huabu 画布只承载当前投影                                                          |

### 13.6 修正 §11 的 A2

> 之前 §11 我判 A2（三个独立 canvasId）——**错**。正确是「**一个 universe + 多面投影**」：三视图/Context lens/Workflow/Scope/Collection 全是**同一 Project universe 的投影**，用 Huabu 承载空间视图 + 我们在其上加 `resolve*View` 投影层。canvasId 层面：**一个 Project = 一个宿主画布**（可含多 frame 分组呈现 scope），**绝不拆成多个独立 canvas 文件**。这既保住 LCOS 投影精髓，又复用 Huabu 的画布物理 / frame / 工具栏 / Work View / drop。


---

## 全局动工指令（两条，覆盖所有阶段）

### 全局指令 1 · 默认不新增安全门 / 不删既有安全措施

> **默认不新增 hash、冻结 contract、baseline 或 gate。** 只有能明确说出一个**具体失败场景**，并说明 Git、版本号、主键、事务、唯一约束、类型和普通测试**为什么不足**时，才允许加入。
> **不要为了简化而删除已有安全措施。**
> 门禁只放在**不可逆、跨系统、安全、正式发布**这些边界。
> 前置检查不得挤掉真正的代码执行、模拟或测量。

要点：
- 新增 hash/contract/baseline/gate 是**例外**，默认**不加**。
- 要加就要先写清具体失败场景 + 逐一论证已有手段（Git/版本号/主键/事务/唯一约束/类型/普通测试）为何挡不住。
- **只准加**在四类边界：不可逆 / 跨系统 / 安全 / 正式发布。
- 门禁**不得挤掉**真正的执行、模拟或测量（检查是配角，执行是主角）。
- 已有安全措施**一律保留**，不得为简化而删。

### 全局指令 2 · 每个细分阶段施工前必须先联网调研成熟 GUI 形态与 UX 方案

> **所有细分阶段的对应施工开始前，一定要先联网搜索 GitHub 或全网搜索，理解了这个阶段应该有的成熟 GUI 实现形态和对应的 UX 交互方案之后，再进行施工执行。**

- 即：**先调研、后动手**。每个 H 阶段/模块动工前，先搜 GitHub/全网，搞清成熟项目这一步的 GUI 形态和 UX 交互。
- 反模式：不查就照自家脑补开工（Gen1 正是"没看别人怎么做"导致呈现灾难的教训）。
- 落地：动工前在 Handoff 里写明「本阶段调研到的成熟形态/UX」，再进入 M0/M1/M2。
