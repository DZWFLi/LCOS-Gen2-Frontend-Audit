# LCOS Gen2 · Huabu Host 下的 Donor 重编排草案

日期：2026-09-01

## 一句话总裁决

旧模型：

LCOS SpatialCanvas
+ React Flow
+ dnd-kit
+ react-arborist
+ Cytoscape
+ vis-timeline
+ ELK
+ resizable-panels
+ ...

新模型：

Huabu = Primary Spatial Host
↓
先吃 Huabu 已有能力
↓
只把 Huabu 没有的成熟 donor 作为 Instrument / Work View / Semantic Adapter 接入
↓
LCOS 只保留 canonical semantics、对象物种、业务动作与视觉语言

核心原则：

> donor 不再和 Huabu 并列争夺“画布 owner”；donor 只作为 Huabu 宿主上的器官。

---

## 1. 被 Huabu 大量吞掉的 donor

| 旧 donor / 能力 | 旧用途 | Huabu 现状 | Gen2 决策 |
|---|---|---|---|
| xyflow / React Flow | node/edge/selection/resize/lasso/subflow | Huabu 本身就是 ReactFlow + 自研 pointer/selection/resize/LOD | 不再单独接第二套；只继续吸收 Huabu 已用的 ReactFlow mechanics |
| tldraw | selection/handles/marquee/direct manipulation craft | Huabu 已覆盖主要机械层 | 降为 craft/reference donor，不作为 runtime |
| react-rnd | resize math/handles | Huabu NodeWrapper + NodeResizer 已覆盖 | 默认淘汰；仅遇到 Huabu 缺口才重新评估 |
| dnd-kit（world-space） | canvas drag/drop | Huabu 已有 pointer router / drop mechanics | 禁止用于主空间；只留 DOM 列表/仓库内部 |
| 自研 SpatialCanvas mechanics | pan/zoom/selection/drop | Huabu 主体覆盖 | Legacy owner 退休 |

---

## 2. 仍然非常值得保留，而且现在更容易接的 donor

### A. Glyth / Conversation

#### bloub / grok-icon-study
继续保留：
- gaze
- blink
- presence
- shape state
- spring channel
- body / eye / overlay 分层

新接法：

Huabu NodeWrapper
→ takeover / semantic LOD
→ LCOS Glyth renderer
→ bloub/grok motion engine

不要再做独立 Canvas sprite owner。

#### Motion
继续作为 LCOS 特有动效层：
- Glyth
- Action Arc
- Color Pin
- Locator
- Work View transition
- transient preview

Huabu 管空间机械，Motion 管 LCOS perceptual motion。

---

### B. Floating UI / Desktop behavior

#### Base UI
继续非常有价值：
- Popover
- Menu
- Context Menu
- Dialog
- Tooltip
- focus return
- Esc
- outside click
- nested overlay

新接法：

Huabu Canvas overlay portal
+
LCOS Base UI primitives

特别适合：
- Action Arc 次级菜单
- Right-click
- Compact Composer popover
- Color Pin menu
- small management dialogs

#### sonner
继续只做 toast。

不要让 Huabu toast、旧 LCOS toast、sonner 三套并存。
Gen2 选一个 owner，建议仍收敛为 LCOS toast façade。

---

### C. Search / Catalog / Assembly

#### cmdk
仍然很适合：
- Command Palette
- Skill picker
- Reference picker
- Assembly warehouse search
- Surface Component catalog

新接法：

cmdk = list/search shell
Core Search = canonical search
Huabu Focus = spatial arrival

#### react-resizable-panels
价值反而更清楚：
- Work View dock
- Assembly Warehouse ↔ Target
- Diff before/after
- logs/result split

它只管 DOM layout，不碰 Huabu world-space。

#### react-arborist
继续用于：
- Assembly source hierarchy
- Context structure
- Skill package outline
- Workflow outline

放在：
- Work View
- Surface Component Functional Face

不做主画布。

#### dnd-kit
保留范围：
- Assembly warehouse list
- Skill outline reorder
- Catalog reorder
- multiple DOM containers

禁止接管 Huabu object drag。

---

## 3. Context Surface：现在应该变成 Huabu 里的“仪器”

### Cytoscape.js
仍然是 Relationship Lens 的强候选。

新位置：

Huabu Main / Context
→ 选中对象 / scope
→ 打开 Relationship Lens Component / Work View
→ Cytoscape projection

它不再和主 Canvas 抢位置。

### Sigma.js + Graphology
只用于：
- 大规模关系 overview
- read-heavy global relationship lens

不是默认 Context editor。

### vis-timeline
仍然非常适合 Context Evolution。

新接法：

Huabu Context Surface
→ 用户打开 Evolution instrument
→ vis-timeline
→ 点击某时间点
→ Huabu Focus / Work View

Timeline 不持有 history truth。

### diff viewer
继续用于：
- version diff
- Before / Delta / After
- artifact revision compare

作为 Work View / Component Functional Face。

---

## 4. Workflow Surface：Huabu 反而把 donor 接法简化了

### Rete.js
保留“语义 donor”，不运行第二套 editor。

借：
- typed socket
- capability schema
- connection validation
- dataflow vs control flow
- plugin semantics

Huabu Edge / connect gesture
→ LCOS Workflow semantic adapter
→ Rete-style validation model
→ Core Workflow truth

### n8n
继续只做产品/交互 donor：
- execution state
- logs
- node insertion
- workflow diff
- progressive disclosure
- run feedback

不复制 editor-ui。

### ELK
从“基础依赖”降为“高级 Tidy secondary donor”。

先用 Huabu 自带：
- align
- distribute
- frame layout
- spatial grouping

只有当 Workflow / Context 真需要：
- layered directed layout
- port-aware routing
- deterministic large graph tidy

再接 ELK：

Huabu current positions
→ ELK candidate
→ preview
→ user accept
→ RFS geometry commit

绝不自动重排。

---

## 5. Skill Builder：以前那套 donor 组合仍然成立

Root Skill
↓
react-arborist outline
↔
Mind Elixir editable mind map
↓
LCOS Skill Package

Markmap：
只做 read projection / preview。

最佳宿主不再是独立 page：
- Workflow Surface 中的 Skill Artifact
- → Unified Work View
- → Skill Builder instrument

Huabu 只负责 Skill Artifact 在空间里的身份与入口。

---

## 6. Assembly：最适合“Huabu + donor”组合的地方

Huabu 负责：
- current spatial target
- object identity
- spatial selection
- drop arrival
- target location

Work View 内 donor：
- react-resizable-panels = Target / Warehouse split
- cmdk = warehouse search
- react-arborist = source tree
- dnd-kit = warehouse DOM drag/reorder
- Base UI = menus/popovers
- Core Assembly Admission Rules = canonical mutation

这会比旧 Assembly 从零手搓简单很多。

---

## 7. Apple / Finder / Nothing / Teenage Engineering 这类不是 runtime donor

继续作为 craft authority：

Apple：
- material
- hierarchy
- motion
- focus
- keyboard
- accessibility
- transient chrome

Finder/macOS Desktop：
- artifact/object identity
- desktop object feel
- spatial persistence mental model

Nothing / Teenage Engineering：
- LCOS 当前视觉母语参考
- 精密、克制、对象化、低文字密度

这些都应该“覆盖 Huabu 的皮”，不改 Huabu mechanics。

---

## 8. grok-bot donor 现在更适合放在哪里

继续吸收：
- Agent row 行为 inventory
- permission state
- reconnect / lifecycle
- async state
- command palette provider
- floating primitive discipline

翻译成：

Agent row actions
→ Glyth Action Arc / Right-click

connection state
→ Glyth morphology / motion

permission
→ Composer / Run transient permission UI

async state
→ Work View / Run / Search / Warehouse common state

不要复制 sidebar-first / chat-first 结构。

---

## 9. 建议正式废掉或降级的旧 donor 角色

### 直接退休
- 第二套 ReactFlow runtime
- 第二套 SpatialCanvas
- world-space dnd-kit
- react-rnd 作为 node geometry owner
- 手搓 resize / lasso / pointer router
- 多套 popover/menu/dialog owner

### 降为 secondary
- tldraw runtime
- ELK always-on
- Sigma default graph
- Markmap canonical editor

### 保留为 primary specialist
- bloub / grok presence engine
- Motion
- Base UI
- cmdk
- react-resizable-panels
- react-arborist
- Cytoscape
- vis-timeline
- Mind Elixir
- Rete semantic model
- diff viewer

---

## 10. 最值得马上做的 Huabu Donor Reuse Spike

### Spike 1 · Glyth on Huabu NodeWrapper
证明：
- LCOS Conversation binding
- custom Glyth renderer
- takeover / semantic LOD
- gaze / blink / state motion

### Spike 2 · Action Arc + Compact Composer
证明：
- Huabu overlay portal
- Base UI floating primitive
- selection anchored local composer
- no second camera math

### Spike 3 · Unified Work View
证明：
- Huabu Canvas remains live
- react-resizable-panels dock
- resize does not mutate Huabu camera truth
- HUD safe placement

### Spike 4 · Assembly
证明：
- Huabu current target
- resizable split
- cmdk warehouse
- dnd-kit internal DOM drag
- final canonical mutation stays Core

### Spike 5 · Context Instrument
任选一个：
- Cytoscape Relationship Lens
或
- vis-timeline Evolution

证明第三方 instrument 可以在 Work View 中使用，同时 Huabu 仍是空间 host。

---

## 11. 新的 Donor 选择门禁

每个能力严格按：

1. Huabu 已有？
   → ADOPT / WRAP Huabu

2. Huabu 没有，但旧 donor census 有成熟 specialist？
   → ADOPT / COPY / WRAP specialist

3. 都没有？
   → 才允许 custom

禁止：

“参考一下 donor，然后自己写一个差不多的。”

---

## 12. 最终架构图

LCOS Core
Domain Truth
        ↓
Projection / Capability Adapter
        ↓
Huabu Host
Spatial Truth
        │
        ├─ LCOS Object Species
        │   ├─ Artifact
        │   ├─ Glyth
        │   ├─ Skill
        │   └─ Run
        │
        ├─ LCOS Floating Layer
        │   ├─ Action Arc
        │   ├─ Composer
        │   ├─ Color Pin
        │   └─ Locator
        │
        └─ Unified Work View
            ├─ Cytoscape
            ├─ vis-timeline
            ├─ react-arborist
            ├─ Mind Elixir
            ├─ cmdk
            ├─ dnd-kit
            ├─ react-resizable-panels
            └─ diff / logs / execution instruments

最关键的变化：

> Huabu 不只是替代旧画布，而是把以前“横向拼装的一堆 donor”变成一套有明确宿主关系的纵向体系。
